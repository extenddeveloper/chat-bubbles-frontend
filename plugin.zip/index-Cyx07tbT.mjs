var e=Object.create,t=Object.defineProperty,n=Object.getOwnPropertyDescriptor,r=Object.getOwnPropertyNames,i=Object.getPrototypeOf,a=Object.prototype.hasOwnProperty,o=(e,t)=>()=>(t||(e((t={exports:{}}).exports,t),e=null),t.exports),s=(e,i,o,s)=>{if(i&&typeof i==`object`||typeof i==`function`)for(var c=r(i),l=0,u=c.length,d;l<u;l++)d=c[l],!a.call(e,d)&&d!==o&&t(e,d,{get:(e=>i[e]).bind(null,d),enumerable:!(s=n(i,d))||s.enumerable});return e},c=(n,r,o)=>(o=n==null?{}:e(i(n)),s(r||!n||!n.__esModule||!a.call(n,`default`)?t(o,`default`,{value:n,enumerable:!0}):o,n));(function(){let e=document.createElement(`link`).relList;if(e&&e.supports&&e.supports(`modulepreload`))return;for(let e of document.querySelectorAll(`link[rel="modulepreload"]`))n(e);new MutationObserver(e=>{for(let t of e)if(t.type===`childList`)for(let e of t.addedNodes)e.tagName===`LINK`&&e.rel===`modulepreload`&&n(e)}).observe(document,{childList:!0,subtree:!0});function t(e){let t={};return e.integrity&&(t.integrity=e.integrity),e.referrerPolicy&&(t.referrerPolicy=e.referrerPolicy),t.credentials=e.crossOrigin===`use-credentials`?`include`:e.crossOrigin===`anonymous`?`omit`:`same-origin`,t}function n(e){if(e.ep)return;e.ep=!0;let n=t(e);fetch(e.href,n)}})();var l=o((e=>{var t=Symbol.for(`react.element`),n=Symbol.for(`react.portal`),r=Symbol.for(`react.fragment`),i=Symbol.for(`react.strict_mode`),a=Symbol.for(`react.profiler`),o=Symbol.for(`react.provider`),s=Symbol.for(`react.context`),c=Symbol.for(`react.forward_ref`),l=Symbol.for(`react.suspense`),u=Symbol.for(`react.memo`),d=Symbol.for(`react.lazy`),f=Symbol.iterator;function p(e){return typeof e!=`object`||!e?null:(e=f&&e[f]||e[`@@iterator`],typeof e==`function`?e:null)}var m={isMounted:function(){return!1},enqueueForceUpdate:function(){},enqueueReplaceState:function(){},enqueueSetState:function(){}},h=Object.assign,g={};function _(e,t,n){this.props=e,this.context=t,this.refs=g,this.updater=n||m}_.prototype.isReactComponent={},_.prototype.setState=function(e,t){if(typeof e!=`object`&&typeof e!=`function`&&e!=null)throw Error(`setState(...): takes an object of state variables to update or a function which returns an object of state variables.`);this.updater.enqueueSetState(this,e,t,`setState`)},_.prototype.forceUpdate=function(e){this.updater.enqueueForceUpdate(this,e,`forceUpdate`)};function v(){}v.prototype=_.prototype;function y(e,t,n){this.props=e,this.context=t,this.refs=g,this.updater=n||m}var b=y.prototype=new v;b.constructor=y,h(b,_.prototype),b.isPureReactComponent=!0;var x=Array.isArray,S=Object.prototype.hasOwnProperty,C={current:null},w={key:!0,ref:!0,__self:!0,__source:!0};function T(e,n,r){var i,a={},o=null,s=null;if(n!=null)for(i in n.ref!==void 0&&(s=n.ref),n.key!==void 0&&(o=``+n.key),n)S.call(n,i)&&!w.hasOwnProperty(i)&&(a[i]=n[i]);var c=arguments.length-2;if(c===1)a.children=r;else if(1<c){for(var l=Array(c),u=0;u<c;u++)l[u]=arguments[u+2];a.children=l}if(e&&e.defaultProps)for(i in c=e.defaultProps,c)a[i]===void 0&&(a[i]=c[i]);return{$$typeof:t,type:e,key:o,ref:s,props:a,_owner:C.current}}function E(e,n){return{$$typeof:t,type:e.type,key:n,ref:e.ref,props:e.props,_owner:e._owner}}function D(e){return typeof e==`object`&&!!e&&e.$$typeof===t}function O(e){var t={"=":`=0`,":":`=2`};return`$`+e.replace(/[=:]/g,function(e){return t[e]})}var k=/\/+/g;function A(e,t){return typeof e==`object`&&e&&e.key!=null?O(``+e.key):t.toString(36)}function j(e,r,i,a,o){var s=typeof e;(s===`undefined`||s===`boolean`)&&(e=null);var c=!1;if(e===null)c=!0;else switch(s){case`string`:case`number`:c=!0;break;case`object`:switch(e.$$typeof){case t:case n:c=!0}}if(c)return c=e,o=o(c),e=a===``?`.`+A(c,0):a,x(o)?(i=``,e!=null&&(i=e.replace(k,`$&/`)+`/`),j(o,r,i,``,function(e){return e})):o!=null&&(D(o)&&(o=E(o,i+(!o.key||c&&c.key===o.key?``:(``+o.key).replace(k,`$&/`)+`/`)+e)),r.push(o)),1;if(c=0,a=a===``?`.`:a+`:`,x(e))for(var l=0;l<e.length;l++){s=e[l];var u=a+A(s,l);c+=j(s,r,i,u,o)}else if(u=p(e),typeof u==`function`)for(e=u.call(e),l=0;!(s=e.next()).done;)s=s.value,u=a+A(s,l++),c+=j(s,r,i,u,o);else if(s===`object`)throw r=String(e),Error(`Objects are not valid as a React child (found: `+(r===`[object Object]`?`object with keys {`+Object.keys(e).join(`, `)+`}`:r)+`). If you meant to render a collection of children, use an array instead.`);return c}function M(e,t,n){if(e==null)return e;var r=[],i=0;return j(e,r,``,``,function(e){return t.call(n,e,i++)}),r}function N(e){if(e._status===-1){var t=e._result;t=t(),t.then(function(t){(e._status===0||e._status===-1)&&(e._status=1,e._result=t)},function(t){(e._status===0||e._status===-1)&&(e._status=2,e._result=t)}),e._status===-1&&(e._status=0,e._result=t)}if(e._status===1)return e._result.default;throw e._result}var P={current:null},ee={transition:null},F={ReactCurrentDispatcher:P,ReactCurrentBatchConfig:ee,ReactCurrentOwner:C};function te(){throw Error(`act(...) is not supported in production builds of React.`)}e.Children={map:M,forEach:function(e,t,n){M(e,function(){t.apply(this,arguments)},n)},count:function(e){var t=0;return M(e,function(){t++}),t},toArray:function(e){return M(e,function(e){return e})||[]},only:function(e){if(!D(e))throw Error(`React.Children.only expected to receive a single React element child.`);return e}},e.Component=_,e.Fragment=r,e.Profiler=a,e.PureComponent=y,e.StrictMode=i,e.Suspense=l,e.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED=F,e.act=te,e.cloneElement=function(e,n,r){if(e==null)throw Error(`React.cloneElement(...): The argument must be a React element, but you passed `+e+`.`);var i=h({},e.props),a=e.key,o=e.ref,s=e._owner;if(n!=null){if(n.ref!==void 0&&(o=n.ref,s=C.current),n.key!==void 0&&(a=``+n.key),e.type&&e.type.defaultProps)var c=e.type.defaultProps;for(l in n)S.call(n,l)&&!w.hasOwnProperty(l)&&(i[l]=n[l]===void 0&&c!==void 0?c[l]:n[l])}var l=arguments.length-2;if(l===1)i.children=r;else if(1<l){c=Array(l);for(var u=0;u<l;u++)c[u]=arguments[u+2];i.children=c}return{$$typeof:t,type:e.type,key:a,ref:o,props:i,_owner:s}},e.createContext=function(e){return e={$$typeof:s,_currentValue:e,_currentValue2:e,_threadCount:0,Provider:null,Consumer:null,_defaultValue:null,_globalName:null},e.Provider={$$typeof:o,_context:e},e.Consumer=e},e.createElement=T,e.createFactory=function(e){var t=T.bind(null,e);return t.type=e,t},e.createRef=function(){return{current:null}},e.forwardRef=function(e){return{$$typeof:c,render:e}},e.isValidElement=D,e.lazy=function(e){return{$$typeof:d,_payload:{_status:-1,_result:e},_init:N}},e.memo=function(e,t){return{$$typeof:u,type:e,compare:t===void 0?null:t}},e.startTransition=function(e){var t=ee.transition;ee.transition={};try{e()}finally{ee.transition=t}},e.unstable_act=te,e.useCallback=function(e,t){return P.current.useCallback(e,t)},e.useContext=function(e){return P.current.useContext(e)},e.useDebugValue=function(){},e.useDeferredValue=function(e){return P.current.useDeferredValue(e)},e.useEffect=function(e,t){return P.current.useEffect(e,t)},e.useId=function(){return P.current.useId()},e.useImperativeHandle=function(e,t,n){return P.current.useImperativeHandle(e,t,n)},e.useInsertionEffect=function(e,t){return P.current.useInsertionEffect(e,t)},e.useLayoutEffect=function(e,t){return P.current.useLayoutEffect(e,t)},e.useMemo=function(e,t){return P.current.useMemo(e,t)},e.useReducer=function(e,t,n){return P.current.useReducer(e,t,n)},e.useRef=function(e){return P.current.useRef(e)},e.useState=function(e){return P.current.useState(e)},e.useSyncExternalStore=function(e,t,n){return P.current.useSyncExternalStore(e,t,n)},e.useTransition=function(){return P.current.useTransition()},e.version=`18.3.1`})),u=o(((e,t)=>{t.exports=l()})),d=c(u(),1),f=[`page`,`collection`,`designPage`,`siteSettings`,`component`,`layoutTemplate`,`vectorSet`,`codeFile`,`colorStyle`,`textStyle`,`linkStyle`,`blockquoteStyle`,`inlineCodeStyle`,`localization`,`localizationGlossary`],p=class e{#e;#t;id;title;baseId;constructor(e,t){this.#e=e,this.#t=t,this.id=e.id,this.title=e.title,this.baseId=e.baseId}get url(){return this.#e.url}get hasJoined(){return this.#e.joined}get lastEditedAt(){return this.#e.lastEditedAt}get createdBy(){return this.#e.createdBy??null}get base(){return this.baseId?this.#t.invoke(`getBranches`,[this.baseId]).then(([t])=>t?new e(t,this.#t):null):Promise.resolve(null)}async switch(){return this.#t.invoke(`switchBranch`,this.id)}async getChanges(){return(await this.#t.invoke(`getBranchChanges`,this.id)).map(e=>e.type===`unknown`||!f.includes(e.type)?{type:`unknown`,nodeId:e.nodeId,name:e.name,isRemoved:e.isRemoved}:e)}async join(){return this.#t.invoke(`joinBranch`,this.id)}async leave(){return this.#t.invoke(`leaveBranch`,this.id)}async rename(e){return this.#t.invoke(`renameBranch`,this.id,e)}async delete(){return this.#t.invoke(`deleteBranch`,this.id)}async merge(e){return this.#t.invoke(`mergeBranch`,this.id,e)}},m=class extends Error{name=this.constructor.name},h=class extends Error{name=this.constructor.name},g=Symbol(),_=Symbol(),v=Symbol(),y=Symbol(),b=Symbol(),x=Symbol(),S=Symbol(),C=Symbol(),w=Symbol(),T=Symbol(),E=Symbol(),D={getAiServiceInfo:g,sendTrackingEvent:_,getCurrentUser:v,getProjectInfo:y,environmentInfo:b,initialState:x,showUncheckedPermissionToasts:S,marshal:C,unmarshal:w,getHTMLForNode:T,setHTMLForNode:E},O=`INTERNAL_`;`${O}`,`${O}`,`${O}`,`${O}`;var k=`${O}getHTMLForNode`,A=`${O}setHTMLForNode`;function j(e){return e!==void 0}function M(e){return e===void 0}function N(e){return e===null}function P(e){return e!==null}function ee(e){return e===!0||e===!1}function F(e){return typeof e==`string`}function te(e){return typeof e==`function`}function I(e){return typeof e==`object`&&!!e&&!Array.isArray(e)}function ne(e){if(typeof e!=`object`||!e)return!1;let t=Object.getPrototypeOf(e);return t===null||t===Object.prototype}function re(e){return Array.isArray(e)}function ie(e,t){throw t instanceof Error?t:Error(t===void 0?e?`Unexpected value: ${e}`:`Application entered invalid state`:String(t))}function L(e,...t){if(e)return;let n=Error(`Assertion Error`+(t.length>0?`: `+t.join(` `):``));if(n.stack)try{let e=n.stack.split(`
`);e[1]?.includes(`assert`)?(e.splice(1,1),n.stack=e.join(`
`)):e[0]?.includes(`assert`)&&(e.splice(0,1),n.stack=e.join(`
`))}catch{}throw n}function ae(e){for(let t of Reflect.ownKeys(e)){let n=e[t];!n||typeof n!=`object`&&!te(n)||ae(n)}return Object.freeze(e)}function oe(e,t){if(e===t)return!0;if(e.length!==t.length)return!1;for(let n=0;n<e.length;n++)if(e[n]!==t[n])return!1;return!0}function se(e){return[e.slice(0,-1),e.at(-1)]}var R=`__class`;function ce(e){return I(e)&&D.marshal in e}function le(e){if(ce(e))return e[D.marshal]();if(re(e))return e.map(le);if(ne(e)){let t={};for(let n of Object.keys(e))t[n]=le(e[n]);return t}return e}function ue(e){return e.type===`separator`}function de(e,t){let n=[];for(let r of e){if(ue(r)){n.push(r);continue}let{onAction:e,...i}=r,a=i;if(r.onAction){let e=Math.random();t.set(e,r.onAction),a.actionId=e}r.submenu&&(a.submenu=de(r.submenu,t)),n.push(a)}return n}var fe=`type`,pe={[fe]:`pluginReadySignal`},me=`pluginReadyResponse`,he={methodResponse:!0,subscriptionMessage:!0,permissionUpdate:!0,menuAction:!0};function ge(e){return I(e)&&F(e[fe])&&e[fe]in he}function _e(e){return I(e)&&e[fe]===me}var ve=class{#e;#t;get nodeId(){return this.#t.nodeId}get nodeType(){return this.#t.nodeType}get id(){return this.#t.id}get name(){return this.#t.name}get description(){return this.#t.description??null}constructor(e,t){this.#e=e,this.#t=t}async setAttributes(e){let t=await this.#e.invoke(`updateVariable`,this.nodeId,this.id,{...e,type:this.type});if(N(t))return null;let n=this.constructor;return new n(this.#e,t)}async remove(){await this.#e.invoke(`removeVariables`,this.nodeId,[this.id])}},ye=`Variable`;function be(e){let t=e.at(0);return L(!M(t)),`${t.toLowerCase()}${e.slice(1,-ye.length)}`}var xe=be(`Boolean${ye}`),Se=class e extends ve{type=xe;#e;constructor(e,t){super(e,t),this.#e=t}static[D.unmarshal](t,n){return new e(t,n)}[D.marshal](){return this.#e}},Ce=be(`Number${ye}`),we=class e extends ve{type=Ce;#e;constructor(e,t){super(e,t),this.#e=t}static[D.unmarshal](t,n){return new e(t,n)}[D.marshal](){return this.#e}},Te=be(`String${ye}`),Ee=class e extends ve{type=Te;#e;constructor(e,t){super(e,t),this.#e=t}static[D.unmarshal](t,n){return new e(t,n)}[D.marshal](){return this.#e}},De=be(`FormattedText${ye}`),Oe=class e extends ve{type=De;#e;constructor(e,t){super(e,t),this.#e=t}static[D.unmarshal](t,n){return new e(t,n)}[D.marshal](){return this.#e}},ke=be(`Enum${ye}`),Ae=class e{#e;#t;#n;id;name;nameByLocale;constructor(e,t,n,r){this.#e=e,this.#t=t,this.#n=n,this.id=r.id,this.name=r.name,this.nameByLocale=r.nameByLocale,Object.freeze(this)}async setAttributes(t){let n=await this.#e.invoke(`updateEnumCase`,this.#t,this.#n,this.id,t);return n?new e(this.#e,this.#t,this.#n,n):null}async remove(){await this.#e.invoke(`removeEnumCase`,this.#t,this.#n,this.id)}},je=class e extends ve{type=ke;#e;#t;#n;get cases(){return this.#n||=ae(this.#t.cases.map(e=>new Ae(this.#e,this.nodeId,this.id,e))),this.#n}constructor(e,t){super(e,t),this.#e=e,this.#t=t}static[D.unmarshal](t,n){return new e(t,n)}[D.marshal](){return this.#t}async addCase(e){let t=await this.#e.invoke(`addEnumCase`,this.nodeId,this.id,e);return t?new Ae(this.#e,this.nodeId,this.id,t):null}async setCaseOrder(e){await this.#e.invoke(`setEnumCaseOrder`,this.nodeId,this.id,e)}},Me=be(`Color${ye}`),Ne=class e extends ve{type=Me;#e;constructor(e,t){super(e,t),this.#e=t}static[D.unmarshal](t,n){return new e(t,n)}[D.marshal](){return this.#e}},z=be(`Image${ye}`),Pe=class e extends ve{type=z;#e;constructor(e,t){super(e,t),this.#e=t}static[D.unmarshal](t,n){return new e(t,n)}[D.marshal](){return this.#e}},Fe=be(`File${ye}`),Ie=class e extends ve{type=Fe;#e;get allowedFileTypes(){return this.#e.allowedFileTypes}constructor(e,t){super(e,t),this.#e=t}static[D.unmarshal](t,n){return new e(t,n)}[D.marshal](){return this.#e}},Le=be(`Link${ye}`),Re=class e extends ve{type=Le;#e;constructor(e,t){super(e,t),this.#e=t}static[D.unmarshal](t,n){return new e(t,n)}[D.marshal](){return this.#e}},ze=be(`Date${ye}`),Be=class e extends ve{type=ze;#e;get displayTime(){return this.#e.displayTime}constructor(e,t){super(e,t),this.#e=t}static[D.unmarshal](t,n){return new e(t,n)}[D.marshal](){return this.#e}},Ve=be(`Border${ye}`),He=class e extends ve{type=Ve;#e;constructor(e,t){super(e,t),this.#e=t}static[D.unmarshal](t,n){return new e(t,n)}[D.marshal](){return this.#e}},Ue=be(`Unsupported${ye}`),We=class e extends ve{type=Ue;#e;constructor(e,t){super(e,t),this.#e=t}static[D.unmarshal](t,n){return new e(t,n)}[D.marshal](){return this.#e}},Ge=class{#e;#t;#n;id;name;constructor(e,t,n,r){this.#e=e,this.#t=t,this.#n=r,this.id=n.id,this.name=n.name}async setAttributes(e){let t={...e,type:this.type,id:this.id};if(this.#n){L(Ke(t),`Nested fields must be array item fields`);let e=await this.#e.invoke(`updateArrayItemFields`,this.#t,this.#n,[t]);if(N(e))return null;let n=e.fields.find(e=>e.id===this.id);return n?(L(n.type===this.type),this.#r(n,this.#n)):null}let[n]=await this.#e.invoke(`addCollectionFields2`,this.#t,[t]);return L(j(n)),N(n)?null:(L(n.type===this.type),this.#r(n,void 0))}async remove(){if(this.#n){await this.#e.invoke(`removeArrayItemFields`,this.#t,this.#n,[this.id]);return}await this.#e.invoke(`removeCollectionFields`,this.#t,[this.id])}#r(e,t){let n=this.constructor,r=new n(this.#e,this.#t,e,t);return Object.freeze(r),r}};function Ke(e){return Wt(e.type)}var qe=class extends Ge{required;constructor(e,t,n,r){super(e,t,n,r),this.required=n.required}},Je=class extends Ge{type=Kt},Ye=class extends Ge{type=qt},Xe=class extends Ge{type=Jt},Ze=class extends qe{type=Yt;basedOn;constructor(e,t,n,r){super(e,t,n,r),this.basedOn=n.basedOn}},Qe=class extends qe{type=Xt},$e=class extends qe{type=Zt},et=class extends qe{type=$t},tt=class extends qe{type=en;displayTime;constructor(e,t,n,r){super(e,t,n,r),this.displayTime=n.displayTime}},nt=class extends Ge{type=on},rt=class extends Ge{type=sn},it=class extends qe{type=tn;allowedFileTypes;constructor(e,t,n,r){super(e,t,n,r),this.allowedFileTypes=n.allowedFileTypes}},at=class extends Ge{type=nn;#e;#t;cases;constructor(e,t,n,r){super(e,t,n,r),this.#e=e,this.#t=t,this.cases=ae(n.cases.map(r=>new Ae(e,t,n.id,r)))}async addCase(e){let t=await this.#e.invoke(`addEnumCase`,this.#t,this.id,e);return t?new Ae(this.#e,this.#t,this.id,t):null}async setCaseOrder(e){await this.#e.invoke(`setEnumCaseOrder`,this.#t,this.id,e)}},ot=class extends qe{type=rn;collectionId;constructor(e,t,n,r){super(e,t,n,r),this.collectionId=n.collectionId}},st=class extends qe{type=an;collectionId;constructor(e,t,n,r){super(e,t,n,r),this.collectionId=n.collectionId}};function ct(e){return Wt(e.type)}var lt=class extends qe{type=Qt;fields;constructor(e,t,n,r){super(e,t,n,r);let i=n.fields;this.fields=i.map(r=>{let i=dt(r,e,t,n.id);return ct(i)?i:new rt(e,t,r,n.id)})}};function ut(e,t,n){return e.map(e=>dt(e,t,n,void 0))}function dt(e,t,n,r){let i=ft(e,t,n,r);return Object.freeze(i),i}function ft(e,t,n,r){switch(e.type){case Kt:return new Je(t,n,e,r);case qt:return new Ye(t,n,e,r);case Jt:return new Xe(t,n,e,r);case Yt:return new Ze(t,n,e,r);case Xt:return new Qe(t,n,e,r);case Zt:return new $e(t,n,e,r);case $t:return new et(t,n,e,r);case en:return new tt(t,n,e,r);case on:return new nt(t,n,e,r);case sn:return new rt(t,n,e,r);case tn:return new it(t,n,e,r);case nn:return new at(t,n,e,r);case rn:return new ot(t,n,e,r);case an:return new st(t,n,e,r);case Qt:return new lt(t,n,e,r);default:return new rt(t,n,e,r)}}var pt=`action`;function mt(e){return!!e&&pt in e&&F(e[pt])}function ht(e){return Object.keys(e).reduce((t,n)=>{let r=e[n];return mt(r)&&(t[n]=r),t},{})}var gt=class e{id;url;extension;constructor(e){this.url=e.url,this.id=e.id,this.extension=e.extension}static[D.unmarshal](t,n){return new e(n)}[D.marshal](){return{[R]:`FileAsset`,id:this.id,url:this.url,extension:this.extension}}},_t=class e{id;url;thumbnailUrl;altText;resolution;#e;#t;constructor(e,t){this.#t=e,this.url=t.url,this.id=t.id,this.thumbnailUrl=t.thumbnailUrl,this.altText=t.altText,this.resolution=t.resolution}static[D.unmarshal](t,n){return new e(t,n)}[D.marshal](){return{[R]:`ImageAsset`,id:this.id,url:this.url,thumbnailUrl:this.thumbnailUrl,altText:this.altText,resolution:this.resolution}}cloneWithAttributes({altText:t,resolution:n}){return new e(this.#t,{[R]:`ImageAsset`,id:this.id,url:this.url,thumbnailUrl:this.thumbnailUrl,altText:t??this.altText,resolution:n??this.resolution})}async measure(){return Tt(this.url)}async getData(){if(this.#e&&this.#e.bytes.length>0)return this.#e;let e=await this.#t.invoke(`getImageData`,{id:this.id,resolution:this.resolution});if(!e)throw Error(`Failed to load image data`);return this.#e=e,e}async loadBitmap(){let{mimeType:e,bytes:t}=await this.getData(),n=new Blob([t],{type:e});return createImageBitmap(n)}async loadImage(){let e=await this.getData(),t=URL.createObjectURL(new Blob([e.bytes]));return new Promise((e,n)=>{let r=new Image;r.onload=()=>e(r),r.onerror=()=>n(),r.src=t})}};function vt(e){return e.type===`bytes`?[e.bytes.buffer]:[]}function yt(e){if(!I(e))return!1;let t=`bytes`,n=`mimeType`;return!(!(t in e)||!(n in e)||!(e[t]instanceof Uint8Array)||!F(e[n]))}async function bt(e){if(e instanceof File)return wt(e);let t=await St(e.image);return{name:e.name,altText:e.altText,resolution:e.resolution,preferredImageRendering:e.preferredImageRendering,...t}}async function xt(e){if(e instanceof File)return wt(e);let t=await St(e.file);return{name:e.name,...t}}async function St(e){if(e instanceof File)return wt(e);if(yt(e))return{type:`bytes`,mimeType:e.mimeType,bytes:e.bytes};if(F(e))return{type:`url`,url:e};throw TypeError(`Asset input must be a URL string, File, or { bytes: Uint8Array, mimeType: string }.`)}function Ct(e){return Promise.all(e.map(bt))}async function wt(e){return new Promise((t,n)=>{let r=new FileReader;r.onload=r=>{let i=e.type,a=r.target?.result;if(!a||!(a instanceof ArrayBuffer)){n(Error(`Failed to read file, arrayBuffer is null`));return}t({bytes:new Uint8Array(a),mimeType:i,type:`bytes`,name:e.name})},r.onerror=e=>{n(e)},r.readAsArrayBuffer(e)})}async function Tt(e){let t=e instanceof File,n=t?URL.createObjectURL(e):e,r=new Image;return r.crossOrigin=`anonymous`,new Promise((e,t)=>{r.onload=()=>{e({width:r.naturalWidth,height:r.naturalHeight})},r.onerror=e=>{t(e)},r.src=n}).finally(()=>{t&&URL.revokeObjectURL(n)})}var Et=class{},Dt=`unsupported`,Ot=class e extends Et{type=Dt;#e;constructor(e){super(),this.#e=e}static[D.unmarshal](t,n){return new e(n)}[D.marshal](){return this.#e}},kt=class e{selector;family;weight;style;url;constructor(e){this.selector=e.selector,this.family=e.family,this.weight=e.weight,this.style=e.style,this.url=e.url}static[D.unmarshal](t,n){let r=At.get(n.selector);if(r)return r;let i=new e(n);return At.set(n.selector,i),i}[D.marshal](){return{[R]:`Font`,selector:this.selector,family:this.family,weight:this.weight,style:this.style,url:this.url}}},At=new Map,jt=`LinearGradient`,Mt=`RadialGradient`,Nt=`ConicGradient`,Pt=class{#e;get stops(){return this.#e.stops}constructor(e){this.#e=e}cloneWithAttributes(e){let t=this.constructor;return new t({...this.#e,...e})}},Ft=class e extends Pt{[R]=jt;#e;get angle(){return this.#e.angle}constructor(e){super(e),this.#e=e}static[D.unmarshal](t,n){return new e({...n,stops:V(t,n.stops)})}[D.marshal](){return le({...this.#e,[R]:this[R]})}toCSS(){let e=this.#e.stops.map(e=>(L(F(e.color),`ColorStyle not supported yet`),`${e.color} ${e.position*100}%`)).join(`, `);return`linear-gradient(${this.angle}deg, ${e})`}},It=class e extends Pt{[R]=Mt;#e;get width(){return this.#e.width}get height(){return this.#e.height}get x(){return this.#e.x}get y(){return this.#e.y}constructor(e){super(e),this.#e=e}static[D.unmarshal](t,n){return new e({...n,stops:V(t,n.stops)})}[D.marshal](){return le({...this.#e,[R]:this[R]})}toCSS(){let e=this.stops.map((e,t)=>{L(F(e.color),`ColorStyle not supported yet`);let n=this.stops[t+1],r=e.position===1&&n?.position===1?e.position-1e-4:e.position;return`${e.color} ${r*100}%`}).join(`, `);return`radial-gradient(${this.width} ${this.height} at ${this.x} ${this.y}, ${e})`}},Lt=class e extends Pt{[R]=Nt;#e;get angle(){return this.#e.angle}get x(){return this.#e.x}get y(){return this.#e.y}constructor(e){super(e),this.#e=e}static[D.unmarshal](t,n){return new e({...n,stops:V(t,n.stops)})}[D.marshal](){return le({...this.#e,[R]:this[R]})}toCSS(){let e=this.stops.map(e=>(L(F(e.color),`ColorStyle not supported yet`),`${e.color} ${e.position*360}deg`)).join(`, `);return`conic-gradient(from ${this.angle}deg at ${this.x} ${this.y}, ${e})`}},Rt=`ColorStyle`;function zt(e){return I(e)?e[R]===Rt:!1}var Bt=class e{id;name;path;light;dark;#e;constructor(e,t){this.id=t.id,this.name=t.name,this.light=t.light,this.dark=t.dark,this.path=t.path,this.#e=e}static[D.unmarshal](t,n){return new e(t,n)}[D.marshal](){return{[R]:`ColorStyle`,id:this.id,name:this.name,light:this.light,dark:this.dark,path:this.path}}async setAttributes(t){let n=await this.#e.invoke(`setColorStyleAttributes`,this.id,t);return n?new e(this.#e,n):null}async getPluginData(e){return this.#e.invoke(`getPluginDataForNode`,this.id,e)}async setPluginData(e,t){return this.#e.invoke(`setPluginDataForNode`,this.id,e,t)}async getPluginDataKeys(){return this.#e.invoke(`getPluginDataKeysForNode`,this.id)}async remove(){return this.#e.invoke(`removeColorStyle`,this.id)}};function B(e){return e instanceof Bt}var Vt={ColorStyle:Bt,ConicGradient:Lt,FileAsset:gt,Font:kt,ImageAsset:_t,LinearGradient:Ft,RadialGradient:It,TextStyle:class e{id;name;path;tag;font;boldFont;italicFont;boldItalicFont;color;transform;alignment;decoration;decorationColor;decorationThickness;decorationStyle;decorationSkipInk;decorationOffset;balance;breakpoints;minWidth;fontSize;letterSpacing;lineHeight;paragraphSpacing;#e;constructor(e,t){this.id=t.id,this.name=t.name,this.path=t.path,this.tag=t.tag,this.font=kt[D.unmarshal](e,t.font),this.boldFont=t.boldFont&&kt[D.unmarshal](e,t.boldFont),this.italicFont=t.italicFont&&kt[D.unmarshal](e,t.italicFont),this.boldItalicFont=t.boldItalicFont&&kt[D.unmarshal](e,t.boldItalicFont),this.color=zt(t.color)?Bt[D.unmarshal](e,t.color):t.color,this.transform=t.transform,this.alignment=t.alignment,this.decoration=t.decoration,this.decorationColor=zt(t.decorationColor)?Bt[D.unmarshal](e,t.decorationColor):t.decorationColor,this.decorationThickness=t.decorationThickness,this.decorationStyle=t.decorationStyle,this.decorationSkipInk=t.decorationSkipInk,this.decorationOffset=t.decorationOffset,this.balance=t.balance,this.breakpoints=t.breakpoints,this.minWidth=t.minWidth,this.fontSize=t.fontSize,this.letterSpacing=t.letterSpacing,this.lineHeight=t.lineHeight,this.paragraphSpacing=t.paragraphSpacing,this.#e=e}static[D.unmarshal](t,n){return new e(t,n)}[D.marshal](){return{[R]:`TextStyle`,id:this.id,name:this.name,path:this.path,tag:this.tag,font:this.font[D.marshal](),boldFont:this.boldFont?.[D.marshal]()??null,italicFont:this.italicFont?.[D.marshal]()??null,boldItalicFont:this.boldItalicFont?.[D.marshal]()??null,color:B(this.color)?this.color[D.marshal]():this.color,transform:this.transform,alignment:this.alignment,decoration:this.decoration,decorationColor:B(this.decorationColor)?this.decorationColor[D.marshal]():this.decorationColor,decorationThickness:this.decorationThickness,decorationStyle:this.decorationStyle,decorationSkipInk:this.decorationSkipInk,decorationOffset:this.decorationOffset,balance:this.balance,breakpoints:this.breakpoints,minWidth:this.minWidth,fontSize:this.fontSize,letterSpacing:this.letterSpacing,lineHeight:this.lineHeight,paragraphSpacing:this.paragraphSpacing}}async setAttributes(t){let n=await this.#e.invoke(`setTextStyleAttributes`,this.id,t);return n?new e(this.#e,n):null}async getPluginData(e){return this.#e.invoke(`getPluginDataForNode`,this.id,e)}async setPluginData(e,t){return this.#e.invoke(`setPluginDataForNode`,this.id,e,t)}async getPluginDataKeys(){return this.#e.invoke(`getPluginDataKeysForNode`,this.id)}async remove(){return this.#e.invoke(`removeTextStyle`,this.id)}},BooleanVariable:Se,BorderVariable:He,ColorVariable:Ne,DateVariable:Be,EnumVariable:je,FileVariable:Ie,FormattedTextVariable:Oe,ImageVariable:Pe,LinkVariable:Re,NumberVariable:we,StringVariable:Ee,UnsupportedVariable:We,UnsupportedComputedValue:Ot};function Ht(e){return ne(e)&&F(e[R])&&e[R]in Vt}function V(e,t){if(Ht(t))return Vt[t[R]][D.unmarshal](e,t);if(re(t))return t.map(t=>V(e,t));if(ne(t)){let n={};for(let r of Object.keys(t))n[r]=V(e,t[r]);return n}return t}var Ut={boolean:!0,color:!0,date:!0,file:!0,formattedText:!0,image:!0,link:!0,number:!0,string:!0};function Wt(e){return Object.hasOwn(Ut,e)}function Gt(e){return Wt(e.type)}var Kt=`boolean`,qt=`color`,Jt=`number`,Yt=`string`,Xt=`formattedText`,Zt=`image`,Qt=`array`,$t=`link`,en=`date`,tn=`file`,nn=`enum`,rn=`collectionReference`,an=`multiCollectionReference`,on=`divider`,sn=`unsupported`;function cn(e){return e.map(e=>{if(e.type!==`enum`)return e;let t=e.cases.map(e=>{let t=e.nameByLocale?ht(e.nameByLocale):void 0;return{...e,nameByLocale:t}});return{...e,cases:t}})}function ln(e,t){let n={};for(let r in e){let i=e[r];if(!i)continue;if(i.type!==`array`){n[r]=V(t,i);continue}let a=i.value.map(e=>{let n=ln(e.fieldData,t),r={};for(let e in n){let t=n[e];!t||!Gt(t)||(r[e]=t)}return{...e,fieldData:r}});n[r]={...i,value:a}}return n}var un=class{id;name;readonly;managedBy;#e;constructor(e,t){this.id=e.id,this.name=e.name,this.readonly=e.readonly,L(e.managedBy!==`user`,`Managed Collection can only be managed by a plugin`),this.managedBy=e.managedBy,this.#e=t,ae(this)}async getItemIds(){return this.#e.invoke(`getManagedCollectionItemIds`,this.id)}async setItemOrder(e){return this.#e.invoke(`setManagedCollectionItemOrder`,this.id,e)}async getFields(){return this.#e.invoke(`getManagedCollectionFields3`,this.id)}async setFields(e){let t=cn(e);return this.#e.invoke(`setManagedCollectionFields`,this.id,t)}async addItems(e){return this.#e.invoke(`addManagedCollectionItems2`,this.id,e)}async removeItems(e){return this.#e.invoke(`removeManagedCollectionItems`,this.id,e)}async setAsActive(){return this.#e.invoke(`setActiveCollection`,this.id)}async setPluginData(e,t){return this.#e.invoke(`setPluginDataForNode`,this.id,e,t)}async getPluginData(e){return this.#e.invoke(`getPluginDataForNode`,this.id,e)}async getPluginDataKeys(){return this.#e.invoke(`getPluginDataKeysForNode`,this.id)}async navigateTo(e){return this.#e.invoke(`navigateTo`,this.id,e)}},dn=class{id;name;slugFieldName;slugFieldBasedOn;readonly;managedBy;#e;constructor(e,t){this.id=e.id,this.name=e.name,this.slugFieldName=e.slugFieldName,this.slugFieldBasedOn=e.slugFieldBasedOn,this.readonly=e.readonly,this.managedBy=e.managedBy,this.#e=t,ae(this)}async setItemOrder(e){return this.#e.invoke(`setCollectionItemOrder`,this.id,e)}async getFields(){return ut(await this.#e.invoke(`getCollectionFields3`,this.id,!0),this.#e,this.id)}async addFields(e){let t=await this.#e.invoke(`addCollectionFields2`,this.id,e);return L(t.every(P)),ut(t,this.#e,this.id)}async removeFields(e){return this.#e.invoke(`removeCollectionFields`,this.id,e)}async setFieldOrder(e){return this.#e.invoke(`setCollectionFieldOrder`,this.id,e)}async getItems(){return(await this.#e.invoke(`getCollectionItems3`,this.id)).map(e=>new fn(e,this.#e))}async addItems(e){await this.#e.invoke(`addCollectionItems2`,this.id,e)}async removeItems(e){return this.#e.invoke(`removeCollectionItems`,e)}async setAsActive(){return this.#e.invoke(`setActiveCollection`,this.id)}async setPluginData(e,t){return this.#e.invoke(`setPluginDataForNode`,this.id,e,t)}async getPluginData(e){return this.#e.invoke(`getPluginDataForNode`,this.id,e)}async getPluginDataKeys(){return this.#e.invoke(`getPluginDataKeysForNode`,this.id)}async navigateTo(e){return this.#e.invoke(`navigateTo`,this.id,e)}},fn=class e{id;nodeId;createdAt;updatedAt;slug;slugByLocale;draft;fieldData;#e;constructor(e,t){let n=ln(e.fieldData,t);this.id=e.externalId??e.nodeId,this.nodeId=e.nodeId,this.createdAt=e.createdAt,this.updatedAt=e.updatedAt,this.slug=e.slug,this.slugByLocale=e.slugByLocale,this.draft=e.draft??!1,this.fieldData=n,this.#e=t,ae(this)}async remove(){return this.#e.invoke(`removeCollectionItems`,[this.id])}async setAttributes(t){let n=await this.#e.invoke(`setCollectionItemAttributes2`,this.id,t);return n?new e(n,this.#e):null}async setPluginData(e,t){return this.#e.invoke(`setPluginDataForNode`,this.id,e,t)}async getPluginData(e){return this.#e.invoke(`getPluginDataForNode`,this.id,e)}async getPluginDataKeys(){return this.#e.invoke(`getPluginDataKeysForNode`,this.id)}async navigateTo(e){return this.#e.invoke(`navigateTo`,this.nodeId,e)}},pn=`isVariant`;function mn(e){if(!(pn in e))return!1;let t=e[pn];return ee(t)}function hn(e){return mn(e)?e.isVariant:!1}function gn(e){return!mn(e)||!hn(e)?!1:!N(e.gesture)}var _n=`isBreakpoint`;function vn(e){if(!(_n in e))return!1;let t=e[_n];return ee(t)}function yn(e){return vn(e)?e.isBreakpoint:!1}var bn=class{id;originalId;#e;constructor(e,t){this.id=e.id,this.originalId=e.originalId??null,this.#e=t}get isReplica(){return this.originalId!==null}async remove(){return this.#e.invoke(`removeNodes2`,[this.id])}async select(){return this.#e.invoke(`setSelection`,[this.id])}async clone(){return this.#e.cloneNode(this.id)}async setAttributes(e){if(this[R]===`UnknownNode`)throw Error(`Can not set attributes on unknown node`);return this.#e.setAttributes(this.id,e)}async getRect(){return this.#e.invoke(`getRect`,this.id)}async zoomIntoView(e){return this.#e.invoke(`zoomIntoView`,[this.id],e)}async navigateTo(e){return this.#e.invoke(`navigateTo`,this.id,e)}async getParent(){return this.#e.getParent(this.id)}async getChildren(){return Yn(this)?Promise.resolve([]):this.#e.getChildren(this.id)}async getNodesWithType(e){return Yn(this)?Promise.resolve([]):(await this.#e.invoke(`getNodesWithType`,this.id,e)).map(e=>H(e,this.#e))}async getNodesWithAttribute(e){return Yn(this)?Promise.resolve([]):(await this.#e.invoke(`getNodesWithAttribute`,this.id,e)).map(e=>H(e,this.#e))}async getNodesWithAttributeSet(e){return Yn(this)?Promise.resolve([]):(await this.#e.invoke(`getNodesWithAttributeSet`,this.id,e)).map(e=>H(e,this.#e))}async*walk(){if(yield this,!Yn(this))for(let e of await this.getChildren())yield*e.walk()}async getPluginData(e){return this.#e.invoke(`getPluginDataForNode`,this.id,e)}async setPluginData(e,t){return this.#e.invoke(`setPluginDataForNode`,this.id,e,t)}async getPluginDataKeys(){return this.#e.invoke(`getPluginDataKeysForNode`,this.id)}},xn=class extends bn{[R]=`FrameNode`;name;visible;locked;backgroundColor;backgroundImage;backgroundGradient;rotation;opacity;borderRadius;border;imageRendering;position;top;right;bottom;left;centerX;centerY;width;height;maxWidth;minWidth;maxHeight;minHeight;aspectRatio;zIndex;link;linkOpenInNewTab;linkSmoothScroll;linkClickTrackingId;linkRelValues;linkPreserveParams;overflow;overflowX;overflowY;layout;gap;padding;stackDirection;stackDistribution;stackAlignment;stackWrapEnabled;gridColumnCount;gridRowCount;gridAlignment;gridColumnWidthType;gridColumnWidth;gridColumnMinWidth;gridRowHeightType;gridRowHeight;gridItemFillCellWidth;gridItemFillCellHeight;gridItemHorizontalAlignment;gridItemVerticalAlignment;gridItemColumnSpan;gridItemRowSpan;isVariant;isPrimaryVariant;isBreakpoint;isPrimaryBreakpoint;inheritsFromId;gesture;constructor(e,t){super(e,t),this.name=e.name??null,this.visible=e.visible??!0,this.locked=e.locked??!1,this.backgroundColor=V(t,e.backgroundColor)??null,this.backgroundImage=V(t,e.backgroundImage)??null,this.rotation=e.rotation??0,this.opacity=e.opacity??1,this.borderRadius=e.borderRadius??null,this.border=V(t,e.border)??null,this.backgroundGradient=V(t,e.backgroundGradient)??null,this.imageRendering=e.imageRendering??null,this.position=e.position,this.left=e.left??null,this.right=e.right??null,this.top=e.top??null,this.bottom=e.bottom??null,this.centerX=e.centerX??null,this.centerY=e.centerY??null,this.width=e.width??null,this.height=e.height??null,this.maxWidth=e.maxWidth??null,this.minWidth=e.minWidth??null,this.maxHeight=e.maxHeight??null,this.minHeight=e.minHeight??null,this.aspectRatio=e.aspectRatio??null,this.zIndex=e.zIndex??null,this.link=e.link??null,this.linkOpenInNewTab=e.linkOpenInNewTab??null,this.linkSmoothScroll=e.linkSmoothScroll??null,this.linkClickTrackingId=e.linkClickTrackingId??null,this.linkRelValues=e.linkRelValues??null,this.linkPreserveParams=e.linkPreserveParams??null,this.overflow=e.overflow??null,this.overflowX=e.overflowX??null,this.overflowY=e.overflowY??null,this.layout=e.layout??null,this.gap=e.gap??null,this.padding=e.padding??null,this.stackDirection=e.stackDirection??null,this.stackDistribution=e.stackDistribution??null,this.stackAlignment=e.stackAlignment??null,this.stackWrapEnabled=e.stackWrapEnabled??null,this.gridColumnCount=e.gridColumnCount??null,this.gridRowCount=e.gridRowCount??null,this.gridAlignment=e.gridAlignment??null,this.gridColumnWidthType=e.gridColumnWidthType??null,this.gridColumnWidth=e.gridColumnWidth??null,this.gridColumnMinWidth=e.gridColumnMinWidth??null,this.gridRowHeightType=e.gridRowHeightType??null,this.gridRowHeight=e.gridRowHeight??null,this.gridItemFillCellWidth=e.gridItemFillCellWidth??null,this.gridItemFillCellHeight=e.gridItemFillCellHeight??null,this.gridItemHorizontalAlignment=e.gridItemHorizontalAlignment??null,this.gridItemVerticalAlignment=e.gridItemVerticalAlignment??null,this.gridItemColumnSpan=e.gridItemColumnSpan??null,this.gridItemRowSpan=e.gridItemRowSpan??null,this.inheritsFromId=e.inheritsFromId??null,this.gesture=e.gesture??null,this.isVariant=e.isVariant??!1,this.isPrimaryVariant=e.isPrimaryVariant??!1,this.isBreakpoint=e.isBreakpoint??!1,this.isPrimaryBreakpoint=e.isPrimaryBreakpoint??!1,ae(this)}},Sn=class extends bn{[R]=`TextNode`;name;visible;locked;rotation;opacity;zIndex;font;inlineTextStyle;position;top;right;bottom;left;centerX;centerY;width;height;maxWidth;minWidth;maxHeight;minHeight;link;linkOpenInNewTab;linkSmoothScroll;linkClickTrackingId;linkRelValues;linkPreserveParams;gridItemFillCellWidth;gridItemFillCellHeight;gridItemHorizontalAlignment;gridItemVerticalAlignment;gridItemColumnSpan;gridItemRowSpan;overflow;overflowX;overflowY;textTruncation;#e;constructor(e,t){super(e,t),this.#e=t,this.name=e.name??null,this.visible=e.visible??!0,this.locked=e.locked??!1,this.rotation=e.rotation??0,this.opacity=e.opacity??1,this.zIndex=e.zIndex??null,this.font=V(t,e.font)??null,this.inlineTextStyle=V(t,e.inlineTextStyle)??null,this.position=e.position,this.left=e.left??null,this.right=e.right??null,this.top=e.top??null,this.bottom=e.bottom??null,this.centerX=e.centerX??null,this.centerY=e.centerY??null,this.width=e.width??null,this.height=e.height??null,this.maxWidth=e.maxWidth??null,this.minWidth=e.minWidth??null,this.maxHeight=e.maxHeight??null,this.minHeight=e.minHeight??null,this.link=e.link??null,this.linkOpenInNewTab=e.linkOpenInNewTab??null,this.linkSmoothScroll=e.linkSmoothScroll??null,this.linkClickTrackingId=e.linkClickTrackingId??null,this.linkRelValues=e.linkRelValues??null,this.linkPreserveParams=e.linkPreserveParams??null,this.overflow=e.overflow??null,this.overflowX=e.overflowX??null,this.overflowY=e.overflowY??null,this.textTruncation=e.textTruncation??null,this.gridItemFillCellWidth=e.gridItemFillCellWidth??null,this.gridItemFillCellHeight=e.gridItemFillCellHeight??null,this.gridItemHorizontalAlignment=e.gridItemHorizontalAlignment??null,this.gridItemVerticalAlignment=e.gridItemVerticalAlignment??null,this.gridItemColumnSpan=e.gridItemColumnSpan??null,this.gridItemRowSpan=e.gridItemRowSpan??null,ae(this)}async setText(e){await this.#e.invoke(`setTextForNode`,this.id,e)}async getText(){return this.#e.invoke(`getTextForNode`,this.id)}async setHTML(e){await this.#e.invoke(A,this.id,e),await new Promise(e=>{setTimeout(e,30)})}async getHTML(){return this.#e.invoke(k,this.id)}},Cn=class extends bn{[R]=`SVGNode`;name;visible;locked;svg;rotation;opacity;position;top;right;bottom;left;centerX;centerY;width;height;constructor(e,t){super(e,t),this.name=e.name??null,this.visible=e.visible??!0,this.locked=e.locked??!1,this.svg=e.svg,this.rotation=e.rotation??0,this.opacity=e.opacity??1,this.position=e.position,this.left=e.left??null,this.right=e.right??null,this.top=e.top??null,this.bottom=e.bottom??null,this.centerX=e.centerX??null,this.centerY=e.centerY??null,this.width=e.width??null,this.height=e.height??null,ae(this)}},wn=class extends bn{},Tn=class extends wn{[R]=`ShapeContainerNode`;constructor(e,t){super(e,t),ae(this)}},En=class extends wn{[R]=`PathNode`;constructor(e,t){super(e,t),ae(this)}},Dn=class extends wn{[R]=`ShapeGroupNode`;constructor(e,t){super(e,t),ae(this)}},On=class extends wn{[R]=`BooleanShapeNode`;constructor(e,t){super(e,t),ae(this)}},kn=class extends bn{[R]=`VectorSetItemNode`;name;visible;locked;top;right;bottom;left;centerX;centerY;width;height;#e;constructor(e,t){super(e,t),this.#e=t,this.name=e.name??null,this.visible=e.visible??!0,this.locked=e.locked??!1,this.top=e.top??null,this.right=e.right??null,this.bottom=e.bottom??null,this.left=e.left??null,this.centerX=e.centerX??null,this.centerY=e.centerY??null,this.width=e.width??null,this.height=e.height??null,ae(this)}async getSVG(){return this.#e.invoke(`getSVGForNode`,this.id)}},An=class extends bn{[R]=`ComponentInstanceNode`;name;visible;locked;componentIdentifier;insertURL;componentName;controls;rotation;opacity;position;top;right;bottom;left;centerX;centerY;width;height;maxWidth;minWidth;maxHeight;minHeight;aspectRatio;#e;#t;#n;get typedControls(){return this.#n||=V(this.#e,this.#t.typedControls)??{},this.#n}constructor(e,t){super(e,t),this.#e=t,this.#t=e,this.name=e.name??null,this.visible=e.visible??!0,this.locked=e.locked??!1,this.componentIdentifier=e.componentIdentifier,this.componentName=e.componentName??null,this.insertURL=e.insertURL??null,this.controls=V(t,e.controls)??{},this.rotation=e.rotation??0,this.opacity=e.opacity??1,this.position=e.position,this.left=e.left??null,this.right=e.right??null,this.top=e.top??null,this.bottom=e.bottom??null,this.centerX=e.centerX??null,this.centerY=e.centerY??null,this.width=e.width??null,this.height=e.height??null,this.maxWidth=e.maxWidth??null,this.minWidth=e.minWidth??null,this.maxHeight=e.maxHeight??null,this.minHeight=e.minHeight??null,this.aspectRatio=e.aspectRatio??null,ae(this)}async getRuntimeError(){return this.#e.invoke(`getRuntimeErrorForCodeComponentNode`,this.id)}},jn=class extends bn{[R]=`WebPageNode`;#e;path;collectionId;draft;constructor(e,t){super(e,t),this.path=e.path??null,this.collectionId=e.collectionId??null,this.draft=e.draft??!1,this.#e=t,ae(this)}async clone(e){return this.#e.cloneWebPage(this.id,e)}getBreakpointSuggestions(){return this.#e.invoke(`getBreakpointSuggestionsForWebPage`,this.id)}async addBreakpoint(e,t){let n=H(await this.#e.invoke(`addBreakpointToWebPage`,this.id,e,t),this.#e);return L(n instanceof xn),L(yn(n),`Expected node to be a FrameNode`),n}async getActiveCollectionItem(){let e=await this.#e.invoke(`getActiveCollectionItemForWebPage`,this.id);return e?new fn(e,this.#e):null}},Mn=class extends bn{[R]=`ComponentNode`;name;componentIdentifier;insertURL;componentName;#e;constructor(e,t){super(e,t),this.#e=t,this.componentIdentifier=e.componentIdentifier,this.insertURL=e.insertURL??null,this.componentName=e.componentName??null,this.name=e.name??null,ae(this)}async addVariant(e,t){let n=await this.#e.invoke(`addVariantToComponent`,this.id,e,t);if(!n)throw Error(`Failed to add variant to component`);let r=H(n,this.#e);return L(r instanceof xn),L(hn(r),`Node is not a component variant`),r}async addGestureVariant(e,t,n){let r=await this.#e.invoke(`addGestureVariantToComponent`,this.id,e,t,n);if(!r)throw Error(`Failed to add state to component`);let i=H(r,this.#e);return L(i instanceof xn),L(gn(i),`Node is not a gesture variant`),i}async getVariables(){let e=await this.#e.invoke(`getVariables`,this.id);return V(this.#e,e)}async addVariables(e){let t=await this.#e.invoke(`addVariables`,this.id,le(e));return V(this.#e,t)}async removeVariables(e){await this.#e.invoke(`removeVariables`,this.id,e)}async setVariableOrder(e){await this.#e.invoke(`setVariableOrder`,this.id,e)}},Nn=class extends bn{[R]=`VectorSetNode`;name;constructor(e,t){super(e,t),this.name=e.name??null,ae(this)}},Pn=class extends bn{[R]=`DesignPageNode`;name;#e;constructor(e,t){super(e,t),this.#e=t,this.name=e.name??null,ae(this)}async clone(e){return this.#e.cloneDesignPage(this.id,e)}},Fn=class extends bn{[R]=`UnknownNode`;constructor(e,t){super(e,t),ae(this)}async clone(){throw Error(`Cannot clone an unknown node`)}};function H(e,t){switch(e[R]){case`DesignPageNode`:return new Pn(e,t);case`WebPageNode`:return new jn(e,t);case`ComponentNode`:return new Mn(e,t);case`VectorSetNode`:return new Nn(e,t);case`VectorSetItemNode`:return new kn(e,t);case`ComponentInstanceNode`:return new An(e,t);case`FrameNode`:return new xn(e,t);case`SVGNode`:return new Cn(e,t);case`ShapeContainerNode`:return new Tn(e,t);case`PathNode`:return new En(e,t);case`ShapeGroupNode`:return new Dn(e,t);case`BooleanShapeNode`:return new On(e,t);case`TextNode`:return new Sn(e,t);case`UnknownNode`:return new Fn(e,t);default:return new Fn(e,t)}}function In(e){return e instanceof xn}function Ln(e){return e instanceof Sn}function Rn(e){return e instanceof Cn}function zn(e){return e instanceof En}function Bn(e){return e instanceof Tn}function Vn(e){return e instanceof Dn}function Hn(e){return e instanceof On}function Un(e){return e instanceof An}function Wn(e){return e instanceof jn}function Gn(e){return e instanceof Mn}function Kn(e){return e instanceof Pn}function qn(e){return e instanceof Nn}function Jn(e){return e instanceof kn}function Yn(e){return e instanceof Fn}function Xn(e){return!!(In(e)||Ln(e)||Un(e)||Rn(e)||Jn(e)||Bn(e)||zn(e)||Vn(e)||Hn(e)||Yn(e))}function Zn(e){return!!(Wn(e)||Kn(e)||Gn(e)||qn(e)||Yn(e))}var Qn=Symbol(),$n=Symbol(),er=Symbol(),tr=Symbol(),nr=Symbol(),rr=Symbol(),ir={ping:rr,getDeployments:Qn,getChangedPaths:$n,getChangeContributors:er,createManagedCollection:tr,rejectAllPending:nr},ar={addComponentInstance:[`addComponentInstance`],addComponentInstancePlaceholder:[],addDetachedComponentLayers:[`addDetachedComponentLayers`],addImage:[`addImage`],addImages:[`addImages`],addSVG:[`addSVG`],addText:[`addText`],addRedirects:[`addRedirects`],getRedirects:[],removeRedirects:[`removeRedirects`],setRedirectOrder:[`setRedirectOrder`],subscribeToRedirects:[],cloneNode:[`cloneNode`],closePlugin:[],createColorStyle:[`createColorStyle`],createFrameNode:[`createNode`],createTextNode:[`createNode`],createComponentNode:[`createNode`],createTextStyle:[`createTextStyle`],createDesignPage:[`createDesignPage`],createWebPage:[`createWebPage`],getActiveBranch:[],createBranch:[`createBranch`],getActiveCollection:[],getActiveLocale:[],getActiveManagedCollection:[],getBranch:[],getBranches:[],"Branch.getChanges":[],"Branch.switch":[`switchBranch`],"Branch.join":[`joinBranch`],"Branch.leave":[`leaveBranch`],"Branch.rename":[`renameBranch`],"Branch.delete":[`deleteBranch`],"Branch.merge":[`mergeBranch`],getCanvasRoot:[],getChildren:[],getCollection:[],getCollections:[],getColorStyle:[],getColorStyles:[],getCurrentUser:[],getCustomCode:[],getDefaultLocale:[],getFont:[],getFonts:[],getImage:[],getLocales:[],getLocalizationGroups:[],listLocalizationGroups:[],getManagedCollection:[],getManagedCollections:[],getNode:[],getNodesWithAttribute:[],getNodesWithAttributeSet:[],getNodesWithType:[],getParent:[],getPluginData:[],getPluginDataKeys:[],getProjectInfo:[],getPublishInfo:[],getRect:[],getSelection:[],getText:[],getTextStyle:[],getTextStyles:[],hideUI:[],setBackgroundMessage:[],setCloseWarning:[],lintCode:[],makeDraggable:[`onDragEnd`,`onDragStart`,`onDrag`,`setDragData`,`preloadDetachedComponentLayers`,`preloadImageUrlForInsertion`,`preloadDragPreviewImage`],notify:[],preloadDetachedComponentLayers:[`preloadDetachedComponentLayers`],preloadDragPreviewImage:[`preloadDragPreviewImage`],preloadImageUrlForInsertion:[`preloadImageUrlForInsertion`],removeNode:[`removeNodes2`],removeNodes:[`removeNodes2`],setAttributes:[`setAttributes`],setCustomCode:[`setCustomCode`],setImage:[`setImage`],setLocalizationData:[`setLocalizationData`],createLocale:[`createLocale`],getLocaleLanguages:[],getLocaleRegions:[],setMenu:[],showContextMenu:[],setParent:[`setParent`],setPluginData:[`setPluginData`],setSelection:[],setText:[`setText`],typecheckCode:[],showUI:[],subscribeToCanvasRoot:[],subscribeToColorStyles:[],subscribeToCustomCode:[],subscribeToImage:[],subscribeToPublishInfo:[],subscribeToDeployment:[],subscribeToBranches:[],subscribeToActiveBranch:[],subscribeToSelection:[],subscribeToText:[],subscribeToTextStyles:[],createCodeFile:[`createCodeFile`],unstable_getDependencyVersion:[],unstable_ensureMinimumDependencyVersion:[`unstable_ensureMinimumDependencyVersion`],getCodeFiles:[],getCodeFile:[],subscribeToCodeFiles:[],subscribeToOpenCodeFile:[],uploadFile:[],uploadFiles:[],uploadImage:[],uploadImages:[],zoomIntoView:[],navigateTo:[],getVectorSets:[],"VectorSet.getItems":[],"VectorSetItem.getVariables":[],"Node.navigateTo":[],"CodeFile.navigateTo":[],"Collection.navigateTo":[],"ManagedCollection.navigateTo":[],"CollectionItem.navigateTo":[],"ComponentInstanceNode.getRuntimeError":[],"ImageAsset.cloneWithAttributes":[],"ImageAsset.getData":[],"ImageAsset.loadBitmap":[],"ImageAsset.loadImage":[],"ImageAsset.measure":[],"CodeFile.remove":[`removeCodeFile`],"CodeFile.rename":[`renameCodeFile`],"CodeFile.setFileContent":[`setCodeFileContent`],"CodeFile.getVersions":[],"CodeFile.showProgressOnInstances":[],"CodeFile.removeProgressFromInstances":[],"CodeFile.lint":[],"CodeFile.typecheck":[],"CodeFileVersion.getContent":[],"ComponentInstancePlaceholder.setAttributes":[],"ComponentInstancePlaceholder.remove":[],"ComponentInstancePlaceholder.replaceWithComponentInstance":[`replaceComponentInstancePlaceholderWithComponentInstance`],"Field.remove":[`removeCollectionFields`,`removeArrayItemFields`],"Field.setAttributes":[`addCollectionFields2`,`updateArrayItemFields`],"EnumField.addCase":[`addEnumCase`],"EnumField.setCaseOrder":[`setEnumCaseOrder`],"Collection.addFields":[`addCollectionFields2`],"Collection.addItems":[`addCollectionItems2`],"Collection.getFields":[],"Collection.getItems":[],"Collection.getPluginData":[],"Collection.getPluginDataKeys":[],"Collection.removeFields":[`removeCollectionFields`],"Collection.removeItems":[`removeCollectionItems`],"Collection.setAsActive":[],"Collection.setFieldOrder":[`setCollectionFieldOrder`],"Collection.setItemOrder":[`setCollectionItemOrder`],"Collection.setPluginData":[`setPluginDataForNode`],"CollectionItem.getPluginData":[],"CollectionItem.getPluginDataKeys":[],"CollectionItem.remove":[`removeCollectionItems`],"CollectionItem.setAttributes":[`setCollectionItemAttributes2`],"CollectionItem.setPluginData":[`setPluginDataForNode`],"ManagedCollection.addItems":[`addManagedCollectionItems2`],"ManagedCollection.getFields":[],"ManagedCollection.getItemIds":[],"ManagedCollection.getPluginData":[],"ManagedCollection.getPluginDataKeys":[],"ManagedCollection.removeItems":[`removeManagedCollectionItems`],"ManagedCollection.setAsActive":[],"ManagedCollection.setFields":[`setManagedCollectionFields`],"ManagedCollection.setItemOrder":[`setManagedCollectionItemOrder`],"ManagedCollection.setPluginData":[`setPluginDataForNode`],"Node.clone":[`cloneNode`,`cloneWebPage`,`cloneDesignPage`],"WebPageNode.clone":[`cloneWebPage`],"DesignPageNode.clone":[`cloneDesignPage`],"Node.getChildren":[],"Node.getNodesWithAttribute":[],"Node.getNodesWithAttributeSet":[],"Node.getNodesWithType":[],"Node.getParent":[],"Node.getPluginData":[],"Node.getPluginDataKeys":[],"Node.getRect":[],"Node.remove":[`removeNodes2`],"Node.select":[],"Node.setAttributes":[`setAttributes`],"Node.setPluginData":[`setPluginDataForNode`],"Node.walk":[],"Node.zoomIntoView":[],"TextNode.getText":[],"TextNode.setText":[`setTextForNode`],"TextNode.setHTML":[A],"TextNode.getHTML":[],"ComponentNode.addVariant":[`addVariantToComponent`],"ComponentNode.addGestureVariant":[`addGestureVariantToComponent`],"ComponentNode.getVariables":[],"ComponentNode.addVariables":[`addVariables`],"ComponentNode.removeVariables":[`removeVariables`],"WebPageNode.getBreakpointSuggestions":[],"WebPageNode.addBreakpoint":[`addBreakpointToWebPage`],"WebPageNode.getActiveCollectionItem":[],"ColorStyle.getPluginData":[],"ColorStyle.getPluginDataKeys":[],"ColorStyle.remove":[`removeColorStyle`],"ColorStyle.setAttributes":[`setColorStyleAttributes`],"ColorStyle.setPluginData":[`setPluginDataForNode`],"TextStyle.getPluginData":[],"TextStyle.getPluginDataKeys":[],"TextStyle.remove":[`removeTextStyle`],"TextStyle.setAttributes":[`setTextStyleAttributes`],"TextStyle.setPluginData":[`setPluginDataForNode`],"Variable.setAttributes":[`updateVariable`],"Variable.remove":[`removeVariables`],"ComponentNode.setVariableOrder":[`setVariableOrder`],"EnumCase.remove":[`removeEnumCase`],"EnumCase.setAttributes":[`updateEnumCase`],"EnumVariable.addCase":[`addEnumCase`],"EnumVariable.setCaseOrder":[`setEnumCaseOrder`],createCollection:[`createCollection`],createManagedCollection:[`createManagedCollection`],[g]:[],[_]:[],[v]:[],[y]:[],[T]:[],[E]:[],publish:[`publish`],getDeployment:[],getDeploymentIssues:[],getUnpublishedPageChanges:[],listDeployments:[],[Qn]:[],deploy:[`deploy`],[$n]:[],[er]:[],[tr]:[`createManagedCollection`],[nr]:[],[rr]:[]},or=[];for(let e of Object.keys(ar))ar[e].length!==0&&or.push(e);ae(or);function sr(e){let t={};for(let n of or)t[n]=ar[n].every(t=>e[t]);return t}function cr(){let e={};for(let t of or)e[t]=!0;return e}var lr=null;function ur(e){if(typeof window>`u`)return;if(!lr){let e=document.createElement(`style`);document.head.appendChild(e),lr=e.sheet}if(!lr){e();return}let t=lr.insertRule(`* { transition: none !important; animation: none !important; }`);e(),requestAnimationFrame(()=>{requestAnimationFrame(()=>{lr&&lr.deleteRule(t)})})}function dr(e,t){return t===void 0||typeof t==`object`&&t&&Object.keys(t).length===0?e:JSON.stringify([e,t])}var fr=class{methodInvocationId=0;notificationId=0;postMessage;methodResponseHandlers=new Map;mode;subscriptions=new Map;perMethodPermissionMap;permissionSubscriptions=new Set;messageTypesCheckedInIsAllowedTo=new Set;showUncheckedPermissionToasts=!0;environmentInfo=null;initialState;menuItemOnActionCallbackMap=new Map;contextMenuItemOnActionCallbackMap=new Map;rejectAllPending(e){for(let[t,n]of this.methodResponseHandlers)n.reject(e),this.methodResponseHandlers.delete(t)}constructor(e){if(!e){this.postMessage=()=>{},this.mode=`canvas`,this.perMethodPermissionMap=cr(),this.initialState={mode:`canvas`,intent:`plugin/open`};return}switch(e.transport.onMessage(this.onMessage),typeof window<`u`&&(window.addEventListener(`error`,e=>{e.error instanceof h&&(e.preventDefault(),e.stopImmediatePropagation())}),window.addEventListener(`unhandledrejection`,e=>{e.reason instanceof h&&(e.preventDefault(),e.stopImmediatePropagation())})),this.mode=e.mode,this.initialState=e.initialState??{mode:e.mode,intent:`plugin/open`},this.environmentInfo=e.environmentInfo,this.perMethodPermissionMap=sr(e.permissionMap),this.postMessage=(t,n)=>e.transport.send(t,n),this.mode){case`canvas`:case`image`:case`editImage`:case`configureManagedCollection`:case`syncManagedCollection`:case`collection`:case`localization`:case`code`:typeof window<`u`&&window.addEventListener(`pointerdown`,()=>{this.invoke(`onPointerDown`)}),e.theme&&this.applyPluginTheme(e.theme),this.subscribe(`theme`,this.applyPluginTheme),this.applyPrereleaseStyles();break;case`api`:case`browser-console`:break;default:ie(this.mode)}}async invoke(e,...t){return this.invokeTransferable(e,void 0,...t)}async invokeTransferable(e,t,...n){return new Promise((r,i)=>{let a={type:`methodInvocation`,methodName:e,id:this.methodInvocationId,args:n.map(le)};this.methodInvocationId+=1,this.methodResponseHandlers.set(a.id,{resolve:r,reject:i}),this.postMessage(a,t)})}subscribe(e,t,n){let r=dr(e,n),i=this.subscriptions.get(r)??new Set;return i.add(t),this.subscriptions.set(r,i),this.postMessage({type:`subscribe`,topic:e,params:n}),()=>{let i=this.subscriptions.get(r);i&&(i.delete(t),!(i.size>0)&&(this.subscriptions.delete(r),this.postMessage({type:`unsubscribe`,topic:e,params:n})))}}onMessage=e=>{let t=e?.data??e;if(ge(t))switch(t.type){case`permissionUpdate`:this.perMethodPermissionMap=sr(t.permissionMap);for(let e of this.permissionSubscriptions)e();break;case`methodResponse`:{let e=this.methodResponseHandlers.get(t.id);if(!e){switch(this.mode){case`canvas`:case`image`:case`editImage`:case`configureManagedCollection`:case`syncManagedCollection`:case`collection`:case`localization`:case`code`:throw Error(`No handler for response with id ${t.id}`);case`api`:case`browser-console`:if(!(t.id<this.methodInvocationId))throw Error(`No handler for unknown response id ${t.id}`);break;default:ie(this.mode)}break}this.methodResponseHandlers.delete(t.id),F(t.error)?e.reject(new m(t.error)):e.resolve(t.result);break}case`subscriptionMessage`:{let{topic:e,params:n,payload:r}=t,i=this.subscriptions.get(dr(e,n));if(!i)break;for(let e of i)e(r);break}case`menuAction`:{let e=this.getOnActionFromCallbackMap(t.actionId,t.actionType);if(!e)throw Error(`Menu action received for an unknown menu item`);e();break}default:ie(t)}};getOnActionFromCallbackMap(e,t){switch(t){case`pluginMenu`:return this.menuItemOnActionCallbackMap.get(e);case`contextMenu`:return this.contextMenuItemOnActionCallbackMap.get(e);default:ie(t)}}applyPluginTheme=e=>{ur(()=>{document.body.setAttribute(`data-framer-theme`,e.mode);for(let t in e.tokens)document.body.style.setProperty(t,e.tokens[t])})};applyPrereleaseStyles(){typeof window>`u`||new URLSearchParams(window.location.search).get(`styles`)===`prerelease`&&document.body.setAttribute(`data-framer-styles`,`prerelease`)}async cloneNode(e){let t=await this.invoke(`cloneNode`,e);return t?H(t,this):null}async cloneWebPage(e,t){let n=await this.invoke(`cloneWebPage`,e,t);L(n,`Expected to receive data for cloned web page`);let r=H(n,this);return L(r instanceof jn,`Expected cloned node to be an instance of WebPageNode`),r}async cloneDesignPage(e,t){let n=await this.invoke(`cloneDesignPage`,e,t);L(n,`Expected to receive data for cloned design page`);let r=H(n,this);return L(r instanceof Pn,`Expected cloned node to be an instance of DesignPageNode`),r}async setAttributes(e,t){let n=await this.invoke(`setAttributes`,e,t);return n?H(n,this):null}async getParent(e){let t=await this.invoke(`getParent`,e);return t?H(t,this):null}async getChildren(e){return(await this.invoke(`getChildren`,e)).map(e=>{let t=H(e,this);return L(Xn(t)),t})}notify=(e,t)=>{let n=`notification-${this.notificationId}`;return this.notificationId+=1,this.invoke(`notify`,e,{notificationId:n,variant:t?.variant??`info`,buttonText:t?.button?.text,durationMs:t?.durationMs}).then(e=>{e===`actionButtonClicked`&&t?.button?.onClick&&t.button.onClick(),t?.onDisappear&&t.onDisappear()}),{close:()=>this.invoke(`closeNotification`,n)}};async setMenu(e){this.menuItemOnActionCallbackMap=new Map;let t=de(e,this.menuItemOnActionCallbackMap);await this.invoke(`setMenu`,t)}async showContextMenu(e,t){this.contextMenuItemOnActionCallbackMap=new Map;let n=de(e,this.contextMenuItemOnActionCallbackMap);await this.invoke(`showContextMenu`,n,t)}},pr=class{#e;#t;get id(){return this.#e.id}get name(){return this.#e.name}get createdAt(){return this.#e.createdAt}get createdBy(){return this.#e.createdBy}constructor(e,t){this.#t=t,this.#e=e}async getContent(){return await this.#t.invoke(`getCodeFileVersionContent`,this.#e.fileId,this.#e.id)}},mr=class e{#e;#t;get id(){return this.#e.id}get name(){return this.#e.name}get path(){return this.#e.path}get content(){return this.#e.content}get exports(){return this.#e.exports}get versionId(){return this.#e.versionId}constructor(e,t){this.#t=t,this.#e=e}async setFileContent(t){let n=await this.#t.invoke(`setCodeFileContent`,this.id,t);return new e(n,this.#t)}async rename(t){let n=await this.#t.invoke(`renameCodeFile`,this.id,t);return new e(n,this.#t)}async remove(){return this.#t.invoke(`removeCodeFile`,this.id)}async getVersions(){return(await this.#t.invoke(`getCodeFileVersions`,this.id)).map(e=>new pr(e,this.#t))}async showProgressOnInstances(e){return this.#t.invoke(`showProgressOnInstances`,this.id,e)}async removeProgressFromInstances(){return this.#t.invoke(`removeProgressFromInstances`,this.id)}async lint(e){return Promise.resolve([])}async typecheck(e){return await this.#t.invoke(`typecheckCode`,this.name,this.content,e,this.id)}async navigateTo(){return this.#t.invoke(`navigateTo`,this.id)}},hr=(()=>{let e=null;return{disableUntilMouseUp:()=>{if(e)return;e=document.createElement(`style`),e.textContent=`* { pointer-events: none !important; user-select: none !important; -webkit-user-select: none !important; }`,document.head.appendChild(e);let t=()=>{e&&(document.head.removeChild(e),e=null,i())},n=e=>{e.buttons>0&&e.buttons&1||t()},r=()=>{t()};window.addEventListener(`pointerup`,n,!0),window.addEventListener(`pointermove`,n,!0),window.addEventListener(`blur`,r);function i(){window.removeEventListener(`pointerup`,n,!0),window.removeEventListener(`pointermove`,n,!0),window.removeEventListener(`blur`,r)}}}})(),gr=5,_r=(()=>{let e=1;return{next:()=>`drag-${e++}`}})();function vr(){}function yr(e,t,n,r){if(e.mode!==`canvas`)return vr;let i=_r.next(),a=document.body.style.cursor,o={type:`idle`},s=document.body,c=U.subscribeToIsAllowedTo(`makeDraggable`,e=>{e||h()}),l=t=>{U.isAllowedTo(`makeDraggable`)&&o.type!==`idle`&&(o.type===`dragging`&&e.invoke(`onDragEnd`,{...t,dragSessionId:i}).then(e=>{try{r?.(e)}catch{}}).catch(e=>{if(e instanceof Error){r?.({status:`error`,reason:e.message});return}if(typeof e==`string`){r?.({status:`error`,reason:e});return}r?.({status:`error`})}),h())},u=t=>{if(!U.isAllowedTo(`makeDraggable`)||o.type===`idle`)return;if(!(t.buttons>0&&t.buttons&1)){l({cancelled:!1});return}let{clientX:n,clientY:r}=t;if(o.type===`pointerDown`){let t=n-o.dragStart.mouse.x,i=r-o.dragStart.mouse.y;if(Math.abs(t)<gr&&Math.abs(i)<gr)return;o={type:`dragging`,dragStart:o.dragStart},e.invoke(`onDragStart`,o.dragStart),document.getSelection()?.empty(),hr.disableUntilMouseUp()}s.setPointerCapture(t.pointerId);let a={x:n,y:r};e.invoke(`onDrag`,{dragSessionId:i,mouse:a}).then(e=>{o.type===`dragging`&&(document.body.style.cursor=e??``)})},d=e=>{e.key===`Escape`&&l({cancelled:!0})},f=()=>{l({cancelled:!0})},p=r=>{if(!U.isAllowedTo(`makeDraggable`))return;l({cancelled:!0});let a=t.getBoundingClientRect(),c={x:a.x,y:a.y,width:a.width,height:a.height},p,m=t.querySelectorAll(`svg`);if(m.length===1){let e=m.item(0).getBoundingClientRect();p={x:e.x,y:e.y,width:e.width,height:e.height}}let h={x:r.clientX,y:r.clientY};o={type:`pointerDown`,dragStart:{dragSessionId:i,elementRect:c,svgRect:p,mouse:h}},e.invoke(`setDragData`,i,n()),s.addEventListener(`pointermove`,u,!0),s.addEventListener(`pointerup`,u,!0),window.addEventListener(`keydown`,d,!0),window.addEventListener(`blur`,f)},m=()=>{if(!U.isAllowedTo(`makeDraggable`))return;let t=n();t.type===`detachedComponentLayers`&&e.invoke(`preloadDetachedComponentLayers`,t.url),t.type===`image`&&e.invoke(`preloadImageUrlForInsertion`,t.image),t.previewImage&&e.invoke(`preloadDragPreviewImage`,t.previewImage)};t.addEventListener(`pointerdown`,p),t.addEventListener(`mouseenter`,m);function h(){o={type:`idle`},document.body.style.cursor=a,s.removeEventListener(`pointermove`,u,!0),s.removeEventListener(`pointerup`,u,!0),window.removeEventListener(`keydown`,d,!0),window.removeEventListener(`blur`,f)}return()=>{t.removeEventListener(`pointerdown`,p),t.removeEventListener(`mouseenter`,m),l({cancelled:!0}),c()}}var br=class e{#e;#t;get id(){return this.#e.id}get from(){return this.#e.from}get to(){return this.#e.to}get expandToAllLocales(){return this.#e.expandToAllLocales}constructor(e,t){this.#t=t,this.#e=e}remove(){return this.#t.invoke(`removeRedirects`,[this.id])}async setAttributes(t){let n={...t,id:this.id},[r]=await this.#t.invoke(`addRedirects`,[n]);return L(j(r)),N(r)?null:new e(r,this.#t)}},xr=class{#e;#t;constructor(e,t){this.#e=e,this.#t=t}get nodeId(){return this.#e.nodeId}get path(){return this.#e.path}get status(){return this.#e.status}async getNode(){if(this.status===`removed`)return null;let e=await this.#t.invoke(`getNode`,this.nodeId);if(!e)return null;let t=H(e,this.#t);return t instanceof jn?t:null}},Sr=class{#e;constructor(e){this.#e=e}get engine(){return this.#e}get mode(){return this.#e.mode}isAllowedTo(...e){return e.every(e=>this.#e.perMethodPermissionMap[e])}subscribeToIsAllowedTo(...e){let[t,n]=se(e),r=this.isAllowedTo(...t),i=()=>{let e=this.isAllowedTo(...t);e!==r&&(r=e,n(r))};return this.#e.permissionSubscriptions.add(i),()=>{this.#e.permissionSubscriptions.delete(i)}}async showUI(e){return this.#e.invoke(`showUI`,e)}async hideUI(){return this.#e.invoke(`hideUI`)}async setBackgroundMessage(e){return this.#e.invoke(`setBackgroundMessage`,e)}closePlugin(e,t){throw this.#e.invoke(`closePlugin`,e,t),new h}async getCurrentUser(){return this.#e.invoke(`getCurrentUser2`)}async getProjectInfo(){return this.#e.invoke(`getProjectInfo2`)}async getSelection(){return(await this.#e.invoke(`getSelection`)).map(e=>{let t=H(e,this.#e);return L(Xn(t)),t})}async setSelection(e){let t=F(e)?[e]:Array.from(e);return this.#e.invoke(`setSelection`,t)}subscribeToSelection(e){return this.#e.subscribe(`selection`,t=>{e(t.map(e=>{let t=H(e,this.#e);return L(Xn(t)),t}))})}async getCanvasRoot(){let e=H(await this.#e.invoke(`getCanvasRoot`),this.#e);return L(Zn(e)),e}subscribeToCanvasRoot(e){return this.#e.subscribe(`canvasRoot`,t=>{let n=H(t,this.#e);L(Zn(n)),e(n)})}async getPublishInfo(){return this.#e.invoke(`getPublishInfo`)}subscribeToPublishInfo(e){return this.#e.subscribe(`publishInfo`,e)}async createFrameNode(e,t){let n=await this.#e.invoke(`createNode`,`FrameNode`,t??null,e);if(!n)return null;let r=H(n,this.#e);return L(r instanceof xn),r}async removeNodes(e){return this.#e.invoke(`removeNodes2`,e)}async removeNode(e){return this.removeNodes([e])}async cloneNode(e){return this.#e.cloneNode(e)}async getNode(e){let t=await this.#e.invoke(`getNode`,e);return t?H(t,this.#e):null}async getParent(e){return this.#e.getParent(e)}async getChildren(e){return this.#e.getChildren(e)}async getRect(e){return this.#e.invoke(`getRect`,e)}async zoomIntoView(e,t){let n=F(e)?[e]:Array.from(e);return this.#e.invoke(`zoomIntoView`,n,t)}async setAttributes(e,t){return this.#e.setAttributes(e,t)}async setParent(e,t,n){return this.#e.invoke(`setParent`,e,t,n)}async getNodesWithType(e){return(await this.#e.invoke(`getNodesWithType`,null,e)).map(e=>H(e,this.#e))}async getNodesWithAttribute(e){return(await this.#e.invoke(`getNodesWithAttribute`,null,e)).map(e=>H(e,this.#e))}async getNodesWithAttributeSet(e){return(await this.#e.invoke(`getNodesWithAttributeSet`,null,e)).map(e=>H(e,this.#e))}async getImage(){let e=await this.#e.invoke(`getImage`);return e?V(this.#e,e):null}subscribeToImage(e){return this.#e.subscribe(`image`,t=>{if(!t){e(null);return}e(V(this.#e,t))})}async addImage(e){let t=await bt(e),n=vt(t);return this.#e.invokeTransferable(`addImage`,n,t)}async setImage(e){let t=await bt(e),n=vt(t);return this.#e.invokeTransferable(`setImage`,n,t)}async uploadImage(e){let t=await bt(e),n=vt(t),r=await this.#e.invokeTransferable(`uploadImage`,n,t);return V(this.#e,r)}async addImages(e){let t=await Ct(e),n=t.flatMap(vt);await this.#e.invokeTransferable(`addImages`,n,t)}async uploadImages(e){let t=await Ct(e),n=t.flatMap(vt),r=await this.#e.invokeTransferable(`uploadImages`,n,t);return V(this.#e,r)}async uploadFile(e){let t=await xt(e),n=await this.#e.invokeTransferable(`uploadFile`,vt(t),t);return V(this.#e,n)}async uploadFiles(e){let t=await Promise.all(e.map(xt)),n=t.flatMap(vt),r=await this.#e.invokeTransferable(`uploadFiles`,n,t);return V(this.#e,r)}async addSVG(e){return this.#e.invoke(`addSVG`,e)}async addComponentInstance({url:e,attributes:t,parentId:n}){let r=H(await this.#e.invoke(`addComponentInstance`,{url:e,attributes:t,parentId:n}),this.#e);return L(Un(r)),r}async addDetachedComponentLayers({url:e,layout:t,attributes:n}){let r=H(await this.#e.invoke(`addDetachedComponentLayers`,{url:e,layout:t,attributes:n}),this.#e);return L(In(r)),r}async preloadDetachedComponentLayers(e){await this.#e.invoke(`preloadDetachedComponentLayers`,e)}async preloadImageUrlForInsertion(e){await this.#e.invoke(`preloadImageUrlForInsertion`,e)}async preloadDragPreviewImage(e){await this.#e.invoke(`preloadDragPreviewImage`,e)}async getText(){return this.#e.invoke(`getText`)}async setText(e){return this.#e.invoke(`setText`,e)}async addText(e,t){return this.#e.invoke(`addText`,e,t)}async setCustomCode(e){return this.#e.invoke(`setCustomCode`,e)}async getCustomCode(){return this.#e.invoke(`getCustomCode`)}subscribeToCustomCode(e){return this.#e.subscribe(`customCode`,e)}subscribeToText(e){return this.#e.subscribe(`text`,e)}makeDraggable(e,t,n){return yr(this.#e,e,t,n)}async getActiveManagedCollection(){let e=await this.#e.invoke(`getActiveManagedCollection`);return L(e,`Collection data must be defined`),new un(e,this.#e)}async getManagedCollection(){return this.getActiveManagedCollection()}async getManagedCollections(){let e=await this.#e.invoke(`getManagedCollections`);return L(e,`Collections data must be defined`),e.map(e=>new un(e,this.#e))}async getCollection(e){let t=await this.#e.invoke(`getCollection`,e);return t?new dn(t,this.#e):null}async getActiveCollection(){let e=await this.#e.invoke(`getActiveCollection`);return e?new dn(e,this.#e):null}async getCollections(){return(await this.#e.invoke(`getCollections`)).map(e=>new dn(e,this.#e))}notify=(e,t)=>this.#e.notify(e,t);async getPluginData(e){return this.#e.invoke(`getPluginData`,e)}async setPluginData(e,t){return this.#e.invoke(`setPluginData`,e,t)}async getPluginDataKeys(){return this.#e.invoke(`getPluginDataKeys`)}async getColorStyles(){let e=await this.#e.invoke(`getColorStyles`);return V(this.#e,e)}async getColorStyle(e){let t=await this.#e.invoke(`getColorStyle`,e);return t?V(this.#e,t):null}async createColorStyle(e){let t=await this.#e.invoke(`createColorStyle`,e);return V(this.#e,t)}subscribeToColorStyles(e){return this.#e.subscribe(`colorStyles`,t=>e(V(this.#e,t)))}async getTextStyles(){let e=await this.#e.invoke(`getTextStyles`);return V(this.#e,e)}async getTextStyle(e){let t=await this.#e.invoke(`getTextStyle`,e);return t?V(this.#e,t):null}async createTextStyle(e){let t=await this.#e.invoke(`createTextStyle`,e);return V(this.#e,t)}subscribeToTextStyles(e){return this.#e.subscribe(`textStyles`,t=>e(V(this.#e,t)))}async getFont(e,t){let n=await this.#e.invoke(`getFont`,e,t);return n?V(this.#e,n):null}async getFonts(){let e=await this.#e.invoke(`getFonts`);return V(this.#e,e)}getLocales(){return this.#e.invoke(`getLocales`)}getDefaultLocale(){return this.#e.invoke(`getDefaultLocale`)}getActiveLocale(){return this.#e.invoke(`getActiveLocale`)}async getLocalizationGroups(e){return this.#e.invoke(`getLocalizationGroups`,e)}setLocalizationData(e){return this.#e.invoke(`setLocalizationData`,e)}async getRedirects(){return(await this.#e.invoke(`getRedirects`)).map(e=>new br(e,this.#e))}subscribeToRedirects(e){return this.#e.subscribe(`redirects`,t=>e(t.map(e=>new br(e,this.#e))))}async addRedirects(e){return(await this.#e.invoke(`addRedirects`,e)).map(e=>new br(e,this.#e))}async removeRedirects(e){return this.#e.invoke(`removeRedirects`,e)}async setRedirectOrder(e){return this.#e.invoke(`setRedirectOrder`,e)}async createCodeFile(e,t,n){return new mr(await this.#e.invoke(`createCodeFile`,e,t,n),this.#e)}async getCodeFiles(){let e=await this.#e.invoke(`getCodeFiles`),t=[];for(let n of e)t.push(new mr(n,this.#e));return t}async getCodeFile(e){let t=await this.#e.invoke(`getCodeFile`,e);return t?new mr(t,this.#e):null}lintCode(e,t,n){return Promise.resolve([])}typecheckCode(e,t,n,r){return this.#e.invoke(`typecheckCode`,e,t,n,r)}subscribeToCodeFiles(e){return this.#e.subscribe(`codeFiles`,t=>{let n=t?.map(e=>new mr(e,this.#e));return e(n)})}setMenu(e){return this.#e.setMenu(e)}showContextMenu(e,t){return this.#e.showContextMenu(e,t)}async unstable_ensureMinimumDependencyVersion(e,t){return this.#e.invoke(`unstable_ensureMinimumDependencyVersion`,e,t)}async navigateTo(e,t){return this.#e.invoke(`navigateTo`,e,t)}subscribeToOpenCodeFile(e){return this.#e.subscribe(`openCodeFile`,t=>e(t?new mr(t,this.#e):null))}async createDesignPage(e){let t=H(await this.#e.invoke(`createDesignPage`,e),this.#e);return L(t instanceof Pn,`Expected node to be a DesignPageNode`),t}async createWebPage(e){let t=H(await this.#e.invoke(`createWebPage`,e),this.#e);return L(t instanceof jn,`Expected node to be a WebPageNode`),t}async createCollection(e){return new dn(await this.#e.invoke(`createCollection`,e),this.#e)}async createManagedCollection(e){return new un(await this.#e.invoke(`createManagedCollection`,e),this.#e)}async setCloseWarning(e){return this.#e.invoke(`setCloseWarning`,e)}get[D.initialState](){return this.#e.initialState}async getActiveBranch(){return new p(await this.#e.invoke(`getActiveBranch`),this.#e)}async getBranch(e){let[t]=await this.#e.invoke(`getBranches`,[e]);return t?new p(t,this.#e):null}async getBranches(e){return(await this.#e.invoke(`getBranches`,e?Array.from(e):[])).map(e=>new p(e,this.#e))}subscribeToBranches(e){return this.#e.subscribe(`branches`,t=>{e(t.map(e=>new p(e,this.#e)))})}subscribeToActiveBranch(e){return this.#e.subscribe(`activeBranch`,t=>{e(new p(t,this.#e))})}async createBranch(e){return new p(await this.#e.invoke(`createBranch`,e),this.#e)}async publish(){return this.#e.invoke(`publish`)}async getDeployment(e){return this.#e.invoke(`getDeployment`,e)}subscribeToDeployment(e){return this.#e.subscribe(`deployment`,e)}async*getDeploymentIssues(e){let t=await this.#e.invoke(`getDeploymentIssues`,e);for(let e of t)yield e}async getUnpublishedPageChanges(){return(await this.#e.invoke(`getUnpublishedPageChanges`)).map(e=>new xr(e,this.#e))}async*listDeployments(e=30){let t,n=0;for(;n<e;){let r=Math.min(30,e-n),i=await this.#e.invoke(`listDeployments`,r,t);for(let t of i.deployments)if(yield t,n+=1,n>=e)return;if(!i.hasNextPage)return;if(i.cursor===void 0)throw Error(`Deployment pagination response is missing a cursor`);t=i.cursor}}async deploy(e,t){return this.#e.invoke(`deploy`,e,t)}};D.getAiServiceInfo,D.sendTrackingEvent,D.getCurrentUser,D.getProjectInfo,D.getHTMLForNode,D.setHTMLForNode,D.environmentInfo,D.showUncheckedPermissionToasts,D.showUncheckedPermissionToasts,ir.getDeployments,ir.getChangedPaths,ir.getChangeContributors,ir.createManagedCollection,ir.rejectAllPending,ir.ping;var Cr=class{constructor(e){this.origin=e}send(e,t){window.parent.postMessage(e,this.origin,t)}onMessage(e){window.addEventListener(`message`,e)}};async function wr(){return new Promise(e=>{function t({data:n,origin:r}){_e(n)&&(window.removeEventListener(`message`,t),e({transport:new Cr(r),mode:n.mode,permissionMap:n.permissionMap,environmentInfo:n.environmentInfo,origin:r,theme:n.theme??null,initialState:n.initialState}))}window.addEventListener(`message`,t),window.parent.postMessage(pe,`*`)})}async function Tr(){return typeof window>`u`||`Deno`in globalThis||window.parent===window?null:wr()}var Er=await Tr(),U=Er?new Sr(new fr(Er)):new Proxy({},{get(e,t){throw Error(`Cannot access framer.${String(t)} in server runtime. Use createFramerInstance() with a custom transport.`)}});function Dr(...e){let[t,n]=(0,d.useState)(()=>U.isAllowedTo(...e)),[r,i]=(0,d.useState)(e);return oe(e,r)||(n(U.isAllowedTo(...e)),i(e)),(0,d.useEffect)(()=>{let e=U.subscribeToIsAllowedTo(...r,e=>{n(e)});return()=>{e()}},[r]),t}function Or(e,t,n){let r=Dr(`makeDraggable`),i=kr(()=>te(t)?t():t);(0,d.useEffect)(()=>{if(!r)return;let t=e.current;if(t instanceof HTMLElement)return U.makeDraggable(t,i,n)},[r,i,n])}function kr(e){let t=(0,d.useRef)(e);return t.current=e,(0,d.useCallback)((...e)=>t.current(...e),[])}(0,d.forwardRef)(function({data:e,children:t,onDragComplete:n,...r},i){let a=(0,d.useRef)(null);if(Or(a,e,n),(0,d.isValidElement)(t)){let e=Object.assign({},r);return I(t.props)&&Object.assign(e,t.props),e.ref=Mr(a,i,t.ref),(0,d.cloneElement)(t,e)}return d.Children.count(t)>1&&d.Children.only(t),null});var Ar=`current`;function jr(e){return I(e)&&Ar in e}function Mr(...e){return t=>{for(let n of e)te(n)?n(t):jr(n)&&(n.current=t)}}var Nr=o((e=>{function t(e,t){var n=e.length;e.push(t);a:for(;0<n;){var r=n-1>>>1,a=e[r];if(0<i(a,t))e[r]=t,e[n]=a,n=r;else break a}}function n(e){return e.length===0?null:e[0]}function r(e){if(e.length===0)return null;var t=e[0],n=e.pop();if(n!==t){e[0]=n;a:for(var r=0,a=e.length,o=a>>>1;r<o;){var s=2*(r+1)-1,c=e[s],l=s+1,u=e[l];if(0>i(c,n))l<a&&0>i(u,c)?(e[r]=u,e[l]=n,r=l):(e[r]=c,e[s]=n,r=s);else if(l<a&&0>i(u,n))e[r]=u,e[l]=n,r=l;else break a}}return t}function i(e,t){var n=e.sortIndex-t.sortIndex;return n===0?e.id-t.id:n}if(typeof performance==`object`&&typeof performance.now==`function`){var a=performance;e.unstable_now=function(){return a.now()}}else{var o=Date,s=o.now();e.unstable_now=function(){return o.now()-s}}var c=[],l=[],u=1,d=null,f=3,p=!1,m=!1,h=!1,g=typeof setTimeout==`function`?setTimeout:null,_=typeof clearTimeout==`function`?clearTimeout:null,v=typeof setImmediate<`u`?setImmediate:null;typeof navigator<`u`&&navigator.scheduling!==void 0&&navigator.scheduling.isInputPending!==void 0&&navigator.scheduling.isInputPending.bind(navigator.scheduling);function y(e){for(var i=n(l);i!==null;){if(i.callback===null)r(l);else if(i.startTime<=e)r(l),i.sortIndex=i.expirationTime,t(c,i);else break;i=n(l)}}function b(e){if(h=!1,y(e),!m){if(n(c)!==null)m=!0,M(x);else{var t=n(l);t!==null&&N(b,t.startTime-e)}}}function x(t,i){m=!1,h&&(h=!1,_(w),w=-1),p=!0;var a=f;try{for(y(i),d=n(c);d!==null&&(!(d.expirationTime>i)||t&&!D());){var o=d.callback;if(typeof o==`function`){d.callback=null,f=d.priorityLevel;var s=o(d.expirationTime<=i);i=e.unstable_now(),typeof s==`function`?d.callback=s:d===n(c)&&r(c),y(i)}else r(c);d=n(c)}if(d!==null)var u=!0;else{var g=n(l);g!==null&&N(b,g.startTime-i),u=!1}return u}finally{d=null,f=a,p=!1}}var S=!1,C=null,w=-1,T=5,E=-1;function D(){return!(e.unstable_now()-E<T)}function O(){if(C!==null){var t=e.unstable_now();E=t;var n=!0;try{n=C(!0,t)}finally{n?k():(S=!1,C=null)}}else S=!1}var k;if(typeof v==`function`)k=function(){v(O)};else if(typeof MessageChannel<`u`){var A=new MessageChannel,j=A.port2;A.port1.onmessage=O,k=function(){j.postMessage(null)}}else k=function(){g(O,0)};function M(e){C=e,S||(S=!0,k())}function N(t,n){w=g(function(){t(e.unstable_now())},n)}e.unstable_IdlePriority=5,e.unstable_ImmediatePriority=1,e.unstable_LowPriority=4,e.unstable_NormalPriority=3,e.unstable_Profiling=null,e.unstable_UserBlockingPriority=2,e.unstable_cancelCallback=function(e){e.callback=null},e.unstable_continueExecution=function(){m||p||(m=!0,M(x))},e.unstable_forceFrameRate=function(e){0>e||125<e?console.error(`forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported`):T=0<e?Math.floor(1e3/e):5},e.unstable_getCurrentPriorityLevel=function(){return f},e.unstable_getFirstCallbackNode=function(){return n(c)},e.unstable_next=function(e){switch(f){case 1:case 2:case 3:var t=3;break;default:t=f}var n=f;f=t;try{return e()}finally{f=n}},e.unstable_pauseExecution=function(){},e.unstable_requestPaint=function(){},e.unstable_runWithPriority=function(e,t){switch(e){case 1:case 2:case 3:case 4:case 5:break;default:e=3}var n=f;f=e;try{return t()}finally{f=n}},e.unstable_scheduleCallback=function(r,i,a){var o=e.unstable_now();switch(typeof a==`object`&&a?(a=a.delay,a=typeof a==`number`&&0<a?o+a:o):a=o,r){case 1:var s=-1;break;case 2:s=250;break;case 5:s=1073741823;break;case 4:s=1e4;break;default:s=5e3}return s=a+s,r={id:u++,callback:i,priorityLevel:r,startTime:a,expirationTime:s,sortIndex:-1},a>o?(r.sortIndex=a,t(l,r),n(c)===null&&r===n(l)&&(h?(_(w),w=-1):h=!0,N(b,a-o))):(r.sortIndex=s,t(c,r),m||p||(m=!0,M(x))),r},e.unstable_shouldYield=D,e.unstable_wrapCallback=function(e){var t=f;return function(){var n=f;f=t;try{return e.apply(this,arguments)}finally{f=n}}}})),Pr=o(((e,t)=>{t.exports=Nr()})),Fr=o((e=>{var t=u(),n=Pr();function r(e){for(var t=`https://reactjs.org/docs/error-decoder.html?invariant=`+e,n=1;n<arguments.length;n++)t+=`&args[]=`+encodeURIComponent(arguments[n]);return`Minified React error #`+e+`; visit `+t+` for the full message or use the non-minified dev environment for full errors and additional helpful warnings.`}var i=new Set,a={};function o(e,t){s(e,t),s(e+`Capture`,t)}function s(e,t){for(a[e]=t,e=0;e<t.length;e++)i.add(t[e])}var c=typeof window<`u`&&window.document!==void 0&&window.document.createElement!==void 0,l=Object.prototype.hasOwnProperty,d=/^[:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD][:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\-.0-9\u00B7\u0300-\u036F\u203F-\u2040]*$/,f={},p={};function m(e){return l.call(p,e)?!0:l.call(f,e)?!1:d.test(e)?p[e]=!0:(f[e]=!0,!1)}function h(e,t,n,r){if(n!==null&&n.type===0)return!1;switch(typeof t){case`function`:case`symbol`:return!0;case`boolean`:return r?!1:n===null?(e=e.toLowerCase().slice(0,5),e!==`data-`&&e!==`aria-`):!n.acceptsBooleans;default:return!1}}function g(e,t,n,r){if(t==null||h(e,t,n,r))return!0;if(r)return!1;if(n!==null)switch(n.type){case 3:return!t;case 4:return!1===t;case 5:return isNaN(t);case 6:return isNaN(t)||1>t}return!1}function _(e,t,n,r,i,a,o){this.acceptsBooleans=t===2||t===3||t===4,this.attributeName=r,this.attributeNamespace=i,this.mustUseProperty=n,this.propertyName=e,this.type=t,this.sanitizeURL=a,this.removeEmptyString=o}var v={};`children dangerouslySetInnerHTML defaultValue defaultChecked innerHTML suppressContentEditableWarning suppressHydrationWarning style`.split(` `).forEach(function(e){v[e]=new _(e,0,!1,e,null,!1,!1)}),[[`acceptCharset`,`accept-charset`],[`className`,`class`],[`htmlFor`,`for`],[`httpEquiv`,`http-equiv`]].forEach(function(e){var t=e[0];v[t]=new _(t,1,!1,e[1],null,!1,!1)}),[`contentEditable`,`draggable`,`spellCheck`,`value`].forEach(function(e){v[e]=new _(e,2,!1,e.toLowerCase(),null,!1,!1)}),[`autoReverse`,`externalResourcesRequired`,`focusable`,`preserveAlpha`].forEach(function(e){v[e]=new _(e,2,!1,e,null,!1,!1)}),`allowFullScreen async autoFocus autoPlay controls default defer disabled disablePictureInPicture disableRemotePlayback formNoValidate hidden loop noModule noValidate open playsInline readOnly required reversed scoped seamless itemScope`.split(` `).forEach(function(e){v[e]=new _(e,3,!1,e.toLowerCase(),null,!1,!1)}),[`checked`,`multiple`,`muted`,`selected`].forEach(function(e){v[e]=new _(e,3,!0,e,null,!1,!1)}),[`capture`,`download`].forEach(function(e){v[e]=new _(e,4,!1,e,null,!1,!1)}),[`cols`,`rows`,`size`,`span`].forEach(function(e){v[e]=new _(e,6,!1,e,null,!1,!1)}),[`rowSpan`,`start`].forEach(function(e){v[e]=new _(e,5,!1,e.toLowerCase(),null,!1,!1)});var y=/[\-:]([a-z])/g;function b(e){return e[1].toUpperCase()}`accent-height alignment-baseline arabic-form baseline-shift cap-height clip-path clip-rule color-interpolation color-interpolation-filters color-profile color-rendering dominant-baseline enable-background fill-opacity fill-rule flood-color flood-opacity font-family font-size font-size-adjust font-stretch font-style font-variant font-weight glyph-name glyph-orientation-horizontal glyph-orientation-vertical horiz-adv-x horiz-origin-x image-rendering letter-spacing lighting-color marker-end marker-mid marker-start overline-position overline-thickness paint-order panose-1 pointer-events rendering-intent shape-rendering stop-color stop-opacity strikethrough-position strikethrough-thickness stroke-dasharray stroke-dashoffset stroke-linecap stroke-linejoin stroke-miterlimit stroke-opacity stroke-width text-anchor text-decoration text-rendering underline-position underline-thickness unicode-bidi unicode-range units-per-em v-alphabetic v-hanging v-ideographic v-mathematical vector-effect vert-adv-y vert-origin-x vert-origin-y word-spacing writing-mode xmlns:xlink x-height`.split(` `).forEach(function(e){var t=e.replace(y,b);v[t]=new _(t,1,!1,e,null,!1,!1)}),`xlink:actuate xlink:arcrole xlink:role xlink:show xlink:title xlink:type`.split(` `).forEach(function(e){var t=e.replace(y,b);v[t]=new _(t,1,!1,e,`http://www.w3.org/1999/xlink`,!1,!1)}),[`xml:base`,`xml:lang`,`xml:space`].forEach(function(e){var t=e.replace(y,b);v[t]=new _(t,1,!1,e,`http://www.w3.org/XML/1998/namespace`,!1,!1)}),[`tabIndex`,`crossOrigin`].forEach(function(e){v[e]=new _(e,1,!1,e.toLowerCase(),null,!1,!1)}),v.xlinkHref=new _(`xlinkHref`,1,!1,`xlink:href`,`http://www.w3.org/1999/xlink`,!0,!1),[`src`,`href`,`action`,`formAction`].forEach(function(e){v[e]=new _(e,1,!1,e.toLowerCase(),null,!0,!0)});function x(e,t,n,r){var i=v.hasOwnProperty(t)?v[t]:null;(i===null?r||!(2<t.length)||t[0]!==`o`&&t[0]!==`O`||t[1]!==`n`&&t[1]!==`N`:i.type!==0)&&(g(t,n,i,r)&&(n=null),r||i===null?m(t)&&(n===null?e.removeAttribute(t):e.setAttribute(t,``+n)):i.mustUseProperty?e[i.propertyName]=n===null?i.type!==3&&``:n:(t=i.attributeName,r=i.attributeNamespace,n===null?e.removeAttribute(t):(i=i.type,n=i===3||i===4&&!0===n?``:``+n,r?e.setAttributeNS(r,t,n):e.setAttribute(t,n))))}var S=t.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED,C=Symbol.for(`react.element`),w=Symbol.for(`react.portal`),T=Symbol.for(`react.fragment`),E=Symbol.for(`react.strict_mode`),D=Symbol.for(`react.profiler`),O=Symbol.for(`react.provider`),k=Symbol.for(`react.context`),A=Symbol.for(`react.forward_ref`),j=Symbol.for(`react.suspense`),M=Symbol.for(`react.suspense_list`),N=Symbol.for(`react.memo`),P=Symbol.for(`react.lazy`),ee=Symbol.for(`react.offscreen`),F=Symbol.iterator;function te(e){return typeof e!=`object`||!e?null:(e=F&&e[F]||e[`@@iterator`],typeof e==`function`?e:null)}var I=Object.assign,ne;function re(e){if(ne===void 0)try{throw Error()}catch(e){var t=e.stack.trim().match(/\n( *(at )?)/);ne=t&&t[1]||``}return`
`+ne+e}var ie=!1;function L(e,t){if(!e||ie)return``;ie=!0;var n=Error.prepareStackTrace;Error.prepareStackTrace=void 0;try{if(t){if(t=function(){throw Error()},Object.defineProperty(t.prototype,"props",{set:function(){throw Error()}}),typeof Reflect==`object`&&Reflect.construct){try{Reflect.construct(t,[])}catch(e){var r=e}Reflect.construct(e,[],t)}else{try{t.call()}catch(e){r=e}e.call(t.prototype)}}else{try{throw Error()}catch(e){r=e}e()}}catch(t){if(t&&r&&typeof t.stack==`string`){for(var i=t.stack.split(`
`),a=r.stack.split(`
`),o=i.length-1,s=a.length-1;1<=o&&0<=s&&i[o]!==a[s];)s--;for(;1<=o&&0<=s;o--,s--)if(i[o]!==a[s]){if(o!==1||s!==1)do if(o--,s--,0>s||i[o]!==a[s]){var c=`
`+i[o].replace(` at new `,` at `);return e.displayName&&c.includes(`<anonymous>`)&&(c=c.replace(`<anonymous>`,e.displayName)),c}while(1<=o&&0<=s);break}}}finally{ie=!1,Error.prepareStackTrace=n}return(e=e?e.displayName||e.name:``)?re(e):``}function ae(e){switch(e.tag){case 5:return re(e.type);case 16:return re(`Lazy`);case 13:return re(`Suspense`);case 19:return re(`SuspenseList`);case 0:case 2:case 15:return e=L(e.type,!1),e;case 11:return e=L(e.type.render,!1),e;case 1:return e=L(e.type,!0),e;default:return``}}function oe(e){if(e==null)return null;if(typeof e==`function`)return e.displayName||e.name||null;if(typeof e==`string`)return e;switch(e){case T:return`Fragment`;case w:return`Portal`;case D:return`Profiler`;case E:return`StrictMode`;case j:return`Suspense`;case M:return`SuspenseList`}if(typeof e==`object`)switch(e.$$typeof){case k:return(e.displayName||`Context`)+`.Consumer`;case O:return(e._context.displayName||`Context`)+`.Provider`;case A:var t=e.render;return e=e.displayName,e||=(e=t.displayName||t.name||``,e===``?`ForwardRef`:`ForwardRef(`+e+`)`),e;case N:return t=e.displayName||null,t===null?oe(e.type)||`Memo`:t;case P:t=e._payload,e=e._init;try{return oe(e(t))}catch{}}return null}function se(e){var t=e.type;switch(e.tag){case 24:return`Cache`;case 9:return(t.displayName||`Context`)+`.Consumer`;case 10:return(t._context.displayName||`Context`)+`.Provider`;case 18:return`DehydratedFragment`;case 11:return e=t.render,e=e.displayName||e.name||``,t.displayName||(e===``?`ForwardRef`:`ForwardRef(`+e+`)`);case 7:return`Fragment`;case 5:return t;case 4:return`Portal`;case 3:return`Root`;case 6:return`Text`;case 16:return oe(t);case 8:return t===E?`StrictMode`:`Mode`;case 22:return`Offscreen`;case 12:return`Profiler`;case 21:return`Scope`;case 13:return`Suspense`;case 19:return`SuspenseList`;case 25:return`TracingMarker`;case 1:case 0:case 17:case 2:case 14:case 15:if(typeof t==`function`)return t.displayName||t.name||null;if(typeof t==`string`)return t}return null}function R(e){switch(typeof e){case`boolean`:case`number`:case`string`:case`undefined`:return e;case`object`:return e;default:return``}}function ce(e){var t=e.type;return(e=e.nodeName)&&e.toLowerCase()===`input`&&(t===`checkbox`||t===`radio`)}function le(e){var t=ce(e)?`checked`:`value`,n=Object.getOwnPropertyDescriptor(e.constructor.prototype,t),r=``+e[t];if(!e.hasOwnProperty(t)&&n!==void 0&&typeof n.get==`function`&&typeof n.set==`function`){var i=n.get,a=n.set;return Object.defineProperty(e,t,{configurable:!0,get:function(){return i.call(this)},set:function(e){r=``+e,a.call(this,e)}}),Object.defineProperty(e,t,{enumerable:n.enumerable}),{getValue:function(){return r},setValue:function(e){r=``+e},stopTracking:function(){e._valueTracker=null,delete e[t]}}}}function ue(e){e._valueTracker||=le(e)}function de(e){if(!e)return!1;var t=e._valueTracker;if(!t)return!0;var n=t.getValue(),r=``;return e&&(r=ce(e)?e.checked?`true`:`false`:e.value),e=r,e!==n&&(t.setValue(e),!0)}function fe(e){if(e||=typeof document<`u`?document:void 0,e===void 0)return null;try{return e.activeElement||e.body}catch{return e.body}}function pe(e,t){var n=t.checked;return I({},t,{defaultChecked:void 0,defaultValue:void 0,value:void 0,checked:n??e._wrapperState.initialChecked})}function me(e,t){var n=t.defaultValue==null?``:t.defaultValue,r=t.checked==null?t.defaultChecked:t.checked;n=R(t.value==null?n:t.value),e._wrapperState={initialChecked:r,initialValue:n,controlled:t.type===`checkbox`||t.type===`radio`?t.checked!=null:t.value!=null}}function he(e,t){t=t.checked,t!=null&&x(e,`checked`,t,!1)}function ge(e,t){he(e,t);var n=R(t.value),r=t.type;if(n!=null)r===`number`?(n===0&&e.value===``||e.value!=n)&&(e.value=``+n):e.value!==``+n&&(e.value=``+n);else if(r===`submit`||r===`reset`){e.removeAttribute(`value`);return}t.hasOwnProperty(`value`)?ve(e,t.type,n):t.hasOwnProperty(`defaultValue`)&&ve(e,t.type,R(t.defaultValue)),t.checked==null&&t.defaultChecked!=null&&(e.defaultChecked=!!t.defaultChecked)}function _e(e,t,n){if(t.hasOwnProperty(`value`)||t.hasOwnProperty(`defaultValue`)){var r=t.type;if(!(r!==`submit`&&r!==`reset`||t.value!==void 0&&t.value!==null))return;t=``+e._wrapperState.initialValue,n||t===e.value||(e.value=t),e.defaultValue=t}n=e.name,n!==``&&(e.name=``),e.defaultChecked=!!e._wrapperState.initialChecked,n!==``&&(e.name=n)}function ve(e,t,n){(t!==`number`||fe(e.ownerDocument)!==e)&&(n==null?e.defaultValue=``+e._wrapperState.initialValue:e.defaultValue!==``+n&&(e.defaultValue=``+n))}var ye=Array.isArray;function be(e,t,n,r){if(e=e.options,t){t={};for(var i=0;i<n.length;i++)t[`$`+n[i]]=!0;for(n=0;n<e.length;n++)i=t.hasOwnProperty(`$`+e[n].value),e[n].selected!==i&&(e[n].selected=i),i&&r&&(e[n].defaultSelected=!0)}else{for(n=``+R(n),t=null,i=0;i<e.length;i++){if(e[i].value===n){e[i].selected=!0,r&&(e[i].defaultSelected=!0);return}t!==null||e[i].disabled||(t=e[i])}t!==null&&(t.selected=!0)}}function xe(e,t){if(t.dangerouslySetInnerHTML!=null)throw Error(r(91));return I({},t,{value:void 0,defaultValue:void 0,children:``+e._wrapperState.initialValue})}function Se(e,t){var n=t.value;if(n==null){if(n=t.children,t=t.defaultValue,n!=null){if(t!=null)throw Error(r(92));if(ye(n)){if(1<n.length)throw Error(r(93));n=n[0]}t=n}t??=``,n=t}e._wrapperState={initialValue:R(n)}}function Ce(e,t){var n=R(t.value),r=R(t.defaultValue);n!=null&&(n=``+n,n!==e.value&&(e.value=n),t.defaultValue==null&&e.defaultValue!==n&&(e.defaultValue=n)),r!=null&&(e.defaultValue=``+r)}function we(e){var t=e.textContent;t===e._wrapperState.initialValue&&t!==``&&t!==null&&(e.value=t)}function Te(e){switch(e){case`svg`:return`http://www.w3.org/2000/svg`;case`math`:return`http://www.w3.org/1998/Math/MathML`;default:return`http://www.w3.org/1999/xhtml`}}function Ee(e,t){return e==null||e===`http://www.w3.org/1999/xhtml`?Te(t):e===`http://www.w3.org/2000/svg`&&t===`foreignObject`?`http://www.w3.org/1999/xhtml`:e}var De,Oe=function(e){return typeof MSApp<`u`&&MSApp.execUnsafeLocalFunction?function(t,n,r,i){MSApp.execUnsafeLocalFunction(function(){return e(t,n,r,i)})}:e}(function(e,t){if(e.namespaceURI!==`http://www.w3.org/2000/svg`||`innerHTML`in e)e.innerHTML=t;else{for(De||=document.createElement(`div`),De.innerHTML=`<svg>`+t.valueOf().toString()+`</svg>`,t=De.firstChild;e.firstChild;)e.removeChild(e.firstChild);for(;t.firstChild;)e.appendChild(t.firstChild)}});function ke(e,t){if(t){var n=e.firstChild;if(n&&n===e.lastChild&&n.nodeType===3){n.nodeValue=t;return}}e.textContent=t}var Ae={animationIterationCount:!0,aspectRatio:!0,borderImageOutset:!0,borderImageSlice:!0,borderImageWidth:!0,boxFlex:!0,boxFlexGroup:!0,boxOrdinalGroup:!0,columnCount:!0,columns:!0,flex:!0,flexGrow:!0,flexPositive:!0,flexShrink:!0,flexNegative:!0,flexOrder:!0,gridArea:!0,gridRow:!0,gridRowEnd:!0,gridRowSpan:!0,gridRowStart:!0,gridColumn:!0,gridColumnEnd:!0,gridColumnSpan:!0,gridColumnStart:!0,fontWeight:!0,lineClamp:!0,lineHeight:!0,opacity:!0,order:!0,orphans:!0,tabSize:!0,widows:!0,zIndex:!0,zoom:!0,fillOpacity:!0,floodOpacity:!0,stopOpacity:!0,strokeDasharray:!0,strokeDashoffset:!0,strokeMiterlimit:!0,strokeOpacity:!0,strokeWidth:!0},je=[`Webkit`,`ms`,`Moz`,`O`];Object.keys(Ae).forEach(function(e){je.forEach(function(t){t=t+e.charAt(0).toUpperCase()+e.substring(1),Ae[t]=Ae[e]})});function Me(e,t,n){return t==null||typeof t==`boolean`||t===``?``:n||typeof t!=`number`||t===0||Ae.hasOwnProperty(e)&&Ae[e]?(``+t).trim():t+`px`}function Ne(e,t){for(var n in e=e.style,t)if(t.hasOwnProperty(n)){var r=n.indexOf(`--`)===0,i=Me(n,t[n],r);n===`float`&&(n=`cssFloat`),r?e.setProperty(n,i):e[n]=i}}var z=I({menuitem:!0},{area:!0,base:!0,br:!0,col:!0,embed:!0,hr:!0,img:!0,input:!0,keygen:!0,link:!0,meta:!0,param:!0,source:!0,track:!0,wbr:!0});function Pe(e,t){if(t){if(z[e]&&(t.children!=null||t.dangerouslySetInnerHTML!=null))throw Error(r(137,e));if(t.dangerouslySetInnerHTML!=null){if(t.children!=null)throw Error(r(60));if(typeof t.dangerouslySetInnerHTML!=`object`||!(`__html`in t.dangerouslySetInnerHTML))throw Error(r(61))}if(t.style!=null&&typeof t.style!=`object`)throw Error(r(62))}}function Fe(e,t){if(e.indexOf(`-`)===-1)return typeof t.is==`string`;switch(e){case`annotation-xml`:case`color-profile`:case`font-face`:case`font-face-src`:case`font-face-uri`:case`font-face-format`:case`font-face-name`:case`missing-glyph`:return!1;default:return!0}}var Ie=null;function Le(e){return e=e.target||e.srcElement||window,e.correspondingUseElement&&(e=e.correspondingUseElement),e.nodeType===3?e.parentNode:e}var Re=null,ze=null,Be=null;function Ve(e){if(e=Ni(e)){if(typeof Re!=`function`)throw Error(r(280));var t=e.stateNode;t&&(t=Fi(t),Re(e.stateNode,e.type,t))}}function He(e){ze?Be?Be.push(e):Be=[e]:ze=e}function Ue(){if(ze){var e=ze,t=Be;if(Be=ze=null,Ve(e),t)for(e=0;e<t.length;e++)Ve(t[e])}}function We(e,t){return e(t)}function Ge(){}var Ke=!1;function qe(e,t,n){if(Ke)return e(t,n);Ke=!0;try{return We(e,t,n)}finally{Ke=!1,(ze!==null||Be!==null)&&(Ge(),Ue())}}function Je(e,t){var n=e.stateNode;if(n===null)return null;var i=Fi(n);if(i===null)return null;n=i[t];a:switch(t){case`onClick`:case`onClickCapture`:case`onDoubleClick`:case`onDoubleClickCapture`:case`onMouseDown`:case`onMouseDownCapture`:case`onMouseMove`:case`onMouseMoveCapture`:case`onMouseUp`:case`onMouseUpCapture`:case`onMouseEnter`:(i=!i.disabled)||(e=e.type,i=e!==`button`&&e!==`input`&&e!==`select`&&e!==`textarea`),e=!i;break a;default:e=!1}if(e)return null;if(n&&typeof n!=`function`)throw Error(r(231,t,typeof n));return n}var Ye=!1;if(c)try{var Xe={};Object.defineProperty(Xe,"passive",{get:function(){Ye=!0}}),window.addEventListener(`test`,Xe,Xe),window.removeEventListener(`test`,Xe,Xe)}catch{Ye=!1}function Ze(e,t,n,r,i,a,o,s,c){var l=Array.prototype.slice.call(arguments,3);try{t.apply(n,l)}catch(e){this.onError(e)}}var Qe=!1,$e=null,et=!1,tt=null,nt={onError:function(e){Qe=!0,$e=e}};function rt(e,t,n,r,i,a,o,s,c){Qe=!1,$e=null,Ze.apply(nt,arguments)}function it(e,t,n,i,a,o,s,c,l){if(rt.apply(this,arguments),Qe){if(Qe){var u=$e;Qe=!1,$e=null}else throw Error(r(198));et||(et=!0,tt=u)}}function at(e){var t=e,n=e;if(e.alternate)for(;t.return;)t=t.return;else{e=t;do t=e,t.flags&4098&&(n=t.return),e=t.return;while(e)}return t.tag===3?n:null}function ot(e){if(e.tag===13){var t=e.memoizedState;if(t===null&&(e=e.alternate,e!==null&&(t=e.memoizedState)),t!==null)return t.dehydrated}return null}function st(e){if(at(e)!==e)throw Error(r(188))}function ct(e){var t=e.alternate;if(!t){if(t=at(e),t===null)throw Error(r(188));return t===e?e:null}for(var n=e,i=t;;){var a=n.return;if(a===null)break;var o=a.alternate;if(o===null){if(i=a.return,i!==null){n=i;continue}break}if(a.child===o.child){for(o=a.child;o;){if(o===n)return st(a),e;if(o===i)return st(a),t;o=o.sibling}throw Error(r(188))}if(n.return!==i.return)n=a,i=o;else{for(var s=!1,c=a.child;c;){if(c===n){s=!0,n=a,i=o;break}if(c===i){s=!0,i=a,n=o;break}c=c.sibling}if(!s){for(c=o.child;c;){if(c===n){s=!0,n=o,i=a;break}if(c===i){s=!0,i=o,n=a;break}c=c.sibling}if(!s)throw Error(r(189))}}if(n.alternate!==i)throw Error(r(190))}if(n.tag!==3)throw Error(r(188));return n.stateNode.current===n?e:t}function lt(e){return e=ct(e),e===null?null:ut(e)}function ut(e){if(e.tag===5||e.tag===6)return e;for(e=e.child;e!==null;){var t=ut(e);if(t!==null)return t;e=e.sibling}return null}var dt=n.unstable_scheduleCallback,ft=n.unstable_cancelCallback,pt=n.unstable_shouldYield,mt=n.unstable_requestPaint,ht=n.unstable_now,gt=n.unstable_getCurrentPriorityLevel,_t=n.unstable_ImmediatePriority,vt=n.unstable_UserBlockingPriority,yt=n.unstable_NormalPriority,bt=n.unstable_LowPriority,xt=n.unstable_IdlePriority,St=null,Ct=null;function wt(e){if(Ct&&typeof Ct.onCommitFiberRoot==`function`)try{Ct.onCommitFiberRoot(St,e,void 0,(e.current.flags&128)==128)}catch{}}var Tt=Math.clz32?Math.clz32:Ot,Et=Math.log,Dt=Math.LN2;function Ot(e){return e>>>=0,e===0?32:31-(Et(e)/Dt|0)|0}var kt=64,At=4194304;function jt(e){switch(e&-e){case 1:return 1;case 2:return 2;case 4:return 4;case 8:return 8;case 16:return 16;case 32:return 32;case 64:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return e&4194240;case 4194304:case 8388608:case 16777216:case 33554432:case 67108864:return e&130023424;case 134217728:return 134217728;case 268435456:return 268435456;case 536870912:return 536870912;case 1073741824:return 1073741824;default:return e}}function Mt(e,t){var n=e.pendingLanes;if(n===0)return 0;var r=0,i=e.suspendedLanes,a=e.pingedLanes,o=n&268435455;if(o!==0){var s=o&~i;s===0?(a&=o,a!==0&&(r=jt(a))):r=jt(s)}else o=n&~i,o===0?a!==0&&(r=jt(a)):r=jt(o);if(r===0)return 0;if(t!==0&&t!==r&&(t&i)===0&&(i=r&-r,a=t&-t,i>=a||i===16&&a&4194240))return t;if(r&4&&(r|=n&16),t=e.entangledLanes,t!==0)for(e=e.entanglements,t&=r;0<t;)n=31-Tt(t),i=1<<n,r|=e[n],t&=~i;return r}function Nt(e,t){switch(e){case 1:case 2:case 4:return t+250;case 8:case 16:case 32:case 64:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return t+5e3;case 4194304:case 8388608:case 16777216:case 33554432:case 67108864:return-1;case 134217728:case 268435456:case 536870912:case 1073741824:return-1;default:return-1}}function Pt(e,t){for(var n=e.suspendedLanes,r=e.pingedLanes,i=e.expirationTimes,a=e.pendingLanes;0<a;){var o=31-Tt(a),s=1<<o,c=i[o];c===-1?((s&n)===0||(s&r)!==0)&&(i[o]=Nt(s,t)):c<=t&&(e.expiredLanes|=s),a&=~s}}function Ft(e){return e=e.pendingLanes&-1073741825,e===0?e&1073741824?1073741824:0:e}function It(){var e=kt;return kt<<=1,!(kt&4194240)&&(kt=64),e}function Lt(e){for(var t=[],n=0;31>n;n++)t.push(e);return t}function Rt(e,t,n){e.pendingLanes|=t,t!==536870912&&(e.suspendedLanes=0,e.pingedLanes=0),e=e.eventTimes,t=31-Tt(t),e[t]=n}function zt(e,t){var n=e.pendingLanes&~t;e.pendingLanes=t,e.suspendedLanes=0,e.pingedLanes=0,e.expiredLanes&=t,e.mutableReadLanes&=t,e.entangledLanes&=t,t=e.entanglements;var r=e.eventTimes;for(e=e.expirationTimes;0<n;){var i=31-Tt(n),a=1<<i;t[i]=0,r[i]=-1,e[i]=-1,n&=~a}}function Bt(e,t){var n=e.entangledLanes|=t;for(e=e.entanglements;n;){var r=31-Tt(n),i=1<<r;i&t|e[r]&t&&(e[r]|=t),n&=~i}}var B=0;function Vt(e){return e&=-e,1<e?4<e?e&268435455?16:536870912:4:1}var Ht,V,Ut,Wt,Gt,Kt=!1,qt=[],Jt=null,Yt=null,Xt=null,Zt=new Map,Qt=new Map,$t=[],en=`mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset submit`.split(` `);function tn(e,t){switch(e){case`focusin`:case`focusout`:Jt=null;break;case`dragenter`:case`dragleave`:Yt=null;break;case`mouseover`:case`mouseout`:Xt=null;break;case`pointerover`:case`pointerout`:Zt.delete(t.pointerId);break;case`gotpointercapture`:case`lostpointercapture`:Qt.delete(t.pointerId)}}function nn(e,t,n,r,i,a){return e===null||e.nativeEvent!==a?(e={blockedOn:t,domEventName:n,eventSystemFlags:r,nativeEvent:a,targetContainers:[i]},t!==null&&(t=Ni(t),t!==null&&V(t)),e):(e.eventSystemFlags|=r,t=e.targetContainers,i!==null&&t.indexOf(i)===-1&&t.push(i),e)}function rn(e,t,n,r,i){switch(t){case`focusin`:return Jt=nn(Jt,e,t,n,r,i),!0;case`dragenter`:return Yt=nn(Yt,e,t,n,r,i),!0;case`mouseover`:return Xt=nn(Xt,e,t,n,r,i),!0;case`pointerover`:var a=i.pointerId;return Zt.set(a,nn(Zt.get(a)||null,e,t,n,r,i)),!0;case`gotpointercapture`:return a=i.pointerId,Qt.set(a,nn(Qt.get(a)||null,e,t,n,r,i)),!0}return!1}function an(e){var t=Mi(e.target);if(t!==null){var n=at(t);if(n!==null){if(t=n.tag,t===13){if(t=ot(n),t!==null){e.blockedOn=t,Gt(e.priority,function(){Ut(n)});return}}else if(t===3&&n.stateNode.current.memoizedState.isDehydrated){e.blockedOn=n.tag===3?n.stateNode.containerInfo:null;return}}}e.blockedOn=null}function on(e){if(e.blockedOn!==null)return!1;for(var t=e.targetContainers;0<t.length;){var n=_n(e.domEventName,e.eventSystemFlags,t[0],e.nativeEvent);if(n===null){n=e.nativeEvent;var r=new n.constructor(n.type,n);Ie=r,n.target.dispatchEvent(r),Ie=null}else return t=Ni(n),t!==null&&V(t),e.blockedOn=n,!1;t.shift()}return!0}function sn(e,t,n){on(e)&&n.delete(t)}function cn(){Kt=!1,Jt!==null&&on(Jt)&&(Jt=null),Yt!==null&&on(Yt)&&(Yt=null),Xt!==null&&on(Xt)&&(Xt=null),Zt.forEach(sn),Qt.forEach(sn)}function ln(e,t){e.blockedOn===t&&(e.blockedOn=null,Kt||(Kt=!0,n.unstable_scheduleCallback(n.unstable_NormalPriority,cn)))}function un(e){function t(t){return ln(t,e)}if(0<qt.length){ln(qt[0],e);for(var n=1;n<qt.length;n++){var r=qt[n];r.blockedOn===e&&(r.blockedOn=null)}}for(Jt!==null&&ln(Jt,e),Yt!==null&&ln(Yt,e),Xt!==null&&ln(Xt,e),Zt.forEach(t),Qt.forEach(t),n=0;n<$t.length;n++)r=$t[n],r.blockedOn===e&&(r.blockedOn=null);for(;0<$t.length&&(n=$t[0],n.blockedOn===null);)an(n),n.blockedOn===null&&$t.shift()}var dn=S.ReactCurrentBatchConfig,fn=!0;function pn(e,t,n,r){var i=B,a=dn.transition;dn.transition=null;try{B=1,hn(e,t,n,r)}finally{B=i,dn.transition=a}}function mn(e,t,n,r){var i=B,a=dn.transition;dn.transition=null;try{B=4,hn(e,t,n,r)}finally{B=i,dn.transition=a}}function hn(e,t,n,r){if(fn){var i=_n(e,t,n,r);if(i===null)ci(e,t,r,gn,n),tn(e,r);else if(rn(i,e,t,n,r))r.stopPropagation();else if(tn(e,r),t&4&&-1<en.indexOf(e)){for(;i!==null;){var a=Ni(i);if(a!==null&&Ht(a),a=_n(e,t,n,r),a===null&&ci(e,t,r,gn,n),a===i)break;i=a}i!==null&&r.stopPropagation()}else ci(e,t,r,null,n)}}var gn=null;function _n(e,t,n,r){if(gn=null,e=Le(r),e=Mi(e),e!==null){if(t=at(e),t===null)e=null;else if(n=t.tag,n===13){if(e=ot(t),e!==null)return e;e=null}else if(n===3){if(t.stateNode.current.memoizedState.isDehydrated)return t.tag===3?t.stateNode.containerInfo:null;e=null}else t!==e&&(e=null)}return gn=e,null}function vn(e){switch(e){case`cancel`:case`click`:case`close`:case`contextmenu`:case`copy`:case`cut`:case`auxclick`:case`dblclick`:case`dragend`:case`dragstart`:case`drop`:case`focusin`:case`focusout`:case`input`:case`invalid`:case`keydown`:case`keypress`:case`keyup`:case`mousedown`:case`mouseup`:case`paste`:case`pause`:case`play`:case`pointercancel`:case`pointerdown`:case`pointerup`:case`ratechange`:case`reset`:case`resize`:case`seeked`:case`submit`:case`touchcancel`:case`touchend`:case`touchstart`:case`volumechange`:case`change`:case`selectionchange`:case`textInput`:case`compositionstart`:case`compositionend`:case`compositionupdate`:case`beforeblur`:case`afterblur`:case`beforeinput`:case`blur`:case`fullscreenchange`:case`focus`:case`hashchange`:case`popstate`:case`select`:case`selectstart`:return 1;case`drag`:case`dragenter`:case`dragexit`:case`dragleave`:case`dragover`:case`mousemove`:case`mouseout`:case`mouseover`:case`pointermove`:case`pointerout`:case`pointerover`:case`scroll`:case`toggle`:case`touchmove`:case`wheel`:case`mouseenter`:case`mouseleave`:case`pointerenter`:case`pointerleave`:return 4;case`message`:switch(gt()){case _t:return 1;case vt:return 4;case yt:case bt:return 16;case xt:return 536870912;default:return 16}default:return 16}}var yn=null,bn=null,xn=null;function Sn(){if(xn)return xn;var e,t=bn,n=t.length,r,i=`value`in yn?yn.value:yn.textContent,a=i.length;for(e=0;e<n&&t[e]===i[e];e++);var o=n-e;for(r=1;r<=o&&t[n-r]===i[a-r];r++);return xn=i.slice(e,1<r?1-r:void 0)}function Cn(e){var t=e.keyCode;return`charCode`in e?(e=e.charCode,e===0&&t===13&&(e=13)):e=t,e===10&&(e=13),32<=e||e===13?e:0}function wn(){return!0}function Tn(){return!1}function En(e){function t(t,n,r,i,a){for(var o in this._reactName=t,this._targetInst=r,this.type=n,this.nativeEvent=i,this.target=a,this.currentTarget=null,e)e.hasOwnProperty(o)&&(t=e[o],this[o]=t?t(i):i[o]);return this.isDefaultPrevented=(i.defaultPrevented==null?!1===i.returnValue:i.defaultPrevented)?wn:Tn,this.isPropagationStopped=Tn,this}return I(t.prototype,{preventDefault:function(){this.defaultPrevented=!0;var e=this.nativeEvent;e&&(e.preventDefault?e.preventDefault():typeof e.returnValue!=`unknown`&&(e.returnValue=!1),this.isDefaultPrevented=wn)},stopPropagation:function(){var e=this.nativeEvent;e&&(e.stopPropagation?e.stopPropagation():typeof e.cancelBubble!=`unknown`&&(e.cancelBubble=!0),this.isPropagationStopped=wn)},persist:function(){},isPersistent:wn}),t}var Dn={eventPhase:0,bubbles:0,cancelable:0,timeStamp:function(e){return e.timeStamp||Date.now()},defaultPrevented:0,isTrusted:0},On=En(Dn),kn=I({},Dn,{view:0,detail:0}),An=En(kn),jn,Mn,Nn,Pn=I({},kn,{screenX:0,screenY:0,clientX:0,clientY:0,pageX:0,pageY:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,getModifierState:Wn,button:0,buttons:0,relatedTarget:function(e){return e.relatedTarget===void 0?e.fromElement===e.srcElement?e.toElement:e.fromElement:e.relatedTarget},movementX:function(e){return`movementX`in e?e.movementX:(e!==Nn&&(Nn&&e.type===`mousemove`?(jn=e.screenX-Nn.screenX,Mn=e.screenY-Nn.screenY):Mn=jn=0,Nn=e),jn)},movementY:function(e){return`movementY`in e?e.movementY:Mn}}),Fn=En(Pn),H=En(I({},Pn,{dataTransfer:0})),In=En(I({},kn,{relatedTarget:0})),Ln=En(I({},Dn,{animationName:0,elapsedTime:0,pseudoElement:0})),Rn=En(I({},Dn,{clipboardData:function(e){return`clipboardData`in e?e.clipboardData:window.clipboardData}})),zn=En(I({},Dn,{data:0})),Bn={Esc:`Escape`,Spacebar:` `,Left:`ArrowLeft`,Up:`ArrowUp`,Right:`ArrowRight`,Down:`ArrowDown`,Del:`Delete`,Win:`OS`,Menu:`ContextMenu`,Apps:`ContextMenu`,Scroll:`ScrollLock`,MozPrintableKey:`Unidentified`},Vn={8:`Backspace`,9:`Tab`,12:`Clear`,13:`Enter`,16:`Shift`,17:`Control`,18:`Alt`,19:`Pause`,20:`CapsLock`,27:`Escape`,32:` `,33:`PageUp`,34:`PageDown`,35:`End`,36:`Home`,37:`ArrowLeft`,38:`ArrowUp`,39:`ArrowRight`,40:`ArrowDown`,45:`Insert`,46:`Delete`,112:`F1`,113:`F2`,114:`F3`,115:`F4`,116:`F5`,117:`F6`,118:`F7`,119:`F8`,120:`F9`,121:`F10`,122:`F11`,123:`F12`,144:`NumLock`,145:`ScrollLock`,224:`Meta`},Hn={Alt:`altKey`,Control:`ctrlKey`,Meta:`metaKey`,Shift:`shiftKey`};function Un(e){var t=this.nativeEvent;return t.getModifierState?t.getModifierState(e):(e=Hn[e])?!!t[e]:!1}function Wn(){return Un}var Gn=En(I({},kn,{key:function(e){if(e.key){var t=Bn[e.key]||e.key;if(t!==`Unidentified`)return t}return e.type===`keypress`?(e=Cn(e),e===13?`Enter`:String.fromCharCode(e)):e.type===`keydown`||e.type===`keyup`?Vn[e.keyCode]||`Unidentified`:``},code:0,location:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,repeat:0,locale:0,getModifierState:Wn,charCode:function(e){return e.type===`keypress`?Cn(e):0},keyCode:function(e){return e.type===`keydown`||e.type===`keyup`?e.keyCode:0},which:function(e){return e.type===`keypress`?Cn(e):e.type===`keydown`||e.type===`keyup`?e.keyCode:0}})),Kn=En(I({},Pn,{pointerId:0,width:0,height:0,pressure:0,tangentialPressure:0,tiltX:0,tiltY:0,twist:0,pointerType:0,isPrimary:0})),qn=En(I({},kn,{touches:0,targetTouches:0,changedTouches:0,altKey:0,metaKey:0,ctrlKey:0,shiftKey:0,getModifierState:Wn})),Jn=En(I({},Dn,{propertyName:0,elapsedTime:0,pseudoElement:0})),Yn=En(I({},Pn,{deltaX:function(e){return`deltaX`in e?e.deltaX:`wheelDeltaX`in e?-e.wheelDeltaX:0},deltaY:function(e){return`deltaY`in e?e.deltaY:`wheelDeltaY`in e?-e.wheelDeltaY:`wheelDelta`in e?-e.wheelDelta:0},deltaZ:0,deltaMode:0})),Xn=[9,13,27,32],Zn=c&&`CompositionEvent`in window,Qn=null;c&&`documentMode`in document&&(Qn=document.documentMode);var $n=c&&`TextEvent`in window&&!Qn,er=c&&(!Zn||Qn&&8<Qn&&11>=Qn),tr=` `,nr=!1;function rr(e,t){switch(e){case`keyup`:return Xn.indexOf(t.keyCode)!==-1;case`keydown`:return t.keyCode!==229;case`keypress`:case`mousedown`:case`focusout`:return!0;default:return!1}}function ir(e){return e=e.detail,typeof e==`object`&&`data`in e?e.data:null}var ar=!1;function or(e,t){switch(e){case`compositionend`:return ir(t);case`keypress`:return t.which===32?(nr=!0,tr):null;case`textInput`:return e=t.data,e===tr&&nr?null:e;default:return null}}function sr(e,t){if(ar)return e===`compositionend`||!Zn&&rr(e,t)?(e=Sn(),xn=bn=yn=null,ar=!1,e):null;switch(e){case`paste`:return null;case`keypress`:if(!(t.ctrlKey||t.altKey||t.metaKey)||t.ctrlKey&&t.altKey){if(t.char&&1<t.char.length)return t.char;if(t.which)return String.fromCharCode(t.which)}return null;case`compositionend`:return er&&t.locale!==`ko`?null:t.data;default:return null}}var cr={color:!0,date:!0,datetime:!0,"datetime-local":!0,email:!0,month:!0,number:!0,password:!0,range:!0,search:!0,tel:!0,text:!0,time:!0,url:!0,week:!0};function lr(e){var t=e&&e.nodeName&&e.nodeName.toLowerCase();return t===`input`?!!cr[e.type]:t===`textarea`}function ur(e,t,n,r){He(r),t=ui(t,`onChange`),0<t.length&&(n=new On(`onChange`,`change`,null,n,r),e.push({event:n,listeners:t}))}var dr=null,fr=null;function pr(e){ri(e,0)}function mr(e){if(de(Pi(e)))return e}function hr(e,t){if(e===`change`)return t}var gr=!1;if(c){var _r;if(c){var vr=`oninput`in document;if(!vr){var yr=document.createElement(`div`);yr.setAttribute(`oninput`,`return;`),vr=typeof yr.oninput==`function`}_r=vr}else _r=!1;gr=_r&&(!document.documentMode||9<document.documentMode)}function br(){dr&&(dr.detachEvent(`onpropertychange`,xr),fr=dr=null)}function xr(e){if(e.propertyName===`value`&&mr(fr)){var t=[];ur(t,fr,e,Le(e)),qe(pr,t)}}function Sr(e,t,n){e===`focusin`?(br(),dr=t,fr=n,dr.attachEvent(`onpropertychange`,xr)):e===`focusout`&&br()}function Cr(e){if(e===`selectionchange`||e===`keyup`||e===`keydown`)return mr(fr)}function wr(e,t){if(e===`click`)return mr(t)}function Tr(e,t){if(e===`input`||e===`change`)return mr(t)}function Er(e,t){return e===t&&(e!==0||1/e==1/t)||e!==e&&t!==t}var U=typeof Object.is==`function`?Object.is:Er;function Dr(e,t){if(U(e,t))return!0;if(typeof e!=`object`||!e||typeof t!=`object`||!t)return!1;var n=Object.keys(e),r=Object.keys(t);if(n.length!==r.length)return!1;for(r=0;r<n.length;r++){var i=n[r];if(!l.call(t,i)||!U(e[i],t[i]))return!1}return!0}function Or(e){for(;e&&e.firstChild;)e=e.firstChild;return e}function kr(e,t){var n=Or(e);e=0;for(var r;n;){if(n.nodeType===3){if(r=e+n.textContent.length,e<=t&&r>=t)return{node:n,offset:t-e};e=r}a:{for(;n;){if(n.nextSibling){n=n.nextSibling;break a}n=n.parentNode}n=void 0}n=Or(n)}}function Ar(e,t){return e&&t?e===t?!0:e&&e.nodeType===3?!1:t&&t.nodeType===3?Ar(e,t.parentNode):`contains`in e?e.contains(t):e.compareDocumentPosition?!!(e.compareDocumentPosition(t)&16):!1:!1}function jr(){for(var e=window,t=fe();t instanceof e.HTMLIFrameElement;){try{var n=typeof t.contentWindow.location.href==`string`}catch{n=!1}if(n)e=t.contentWindow;else break;t=fe(e.document)}return t}function Mr(e){var t=e&&e.nodeName&&e.nodeName.toLowerCase();return t&&(t===`input`&&(e.type===`text`||e.type===`search`||e.type===`tel`||e.type===`url`||e.type===`password`)||t===`textarea`||e.contentEditable===`true`)}function Nr(e){var t=jr(),n=e.focusedElem,r=e.selectionRange;if(t!==n&&n&&n.ownerDocument&&Ar(n.ownerDocument.documentElement,n)){if(r!==null&&Mr(n)){if(t=r.start,e=r.end,e===void 0&&(e=t),`selectionStart`in n)n.selectionStart=t,n.selectionEnd=Math.min(e,n.value.length);else if(e=(t=n.ownerDocument||document)&&t.defaultView||window,e.getSelection){e=e.getSelection();var i=n.textContent.length,a=Math.min(r.start,i);r=r.end===void 0?a:Math.min(r.end,i),!e.extend&&a>r&&(i=r,r=a,a=i),i=kr(n,a);var o=kr(n,r);i&&o&&(e.rangeCount!==1||e.anchorNode!==i.node||e.anchorOffset!==i.offset||e.focusNode!==o.node||e.focusOffset!==o.offset)&&(t=t.createRange(),t.setStart(i.node,i.offset),e.removeAllRanges(),a>r?(e.addRange(t),e.extend(o.node,o.offset)):(t.setEnd(o.node,o.offset),e.addRange(t)))}}for(t=[],e=n;e=e.parentNode;)e.nodeType===1&&t.push({element:e,left:e.scrollLeft,top:e.scrollTop});for(typeof n.focus==`function`&&n.focus(),n=0;n<t.length;n++)e=t[n],e.element.scrollLeft=e.left,e.element.scrollTop=e.top}}var Fr=c&&`documentMode`in document&&11>=document.documentMode,Ir=null,Lr=null,W=null,Rr=!1;function zr(e,t,n){var r=n.window===n?n.document:n.nodeType===9?n:n.ownerDocument;Rr||Ir==null||Ir!==fe(r)||(r=Ir,`selectionStart`in r&&Mr(r)?r={start:r.selectionStart,end:r.selectionEnd}:(r=(r.ownerDocument&&r.ownerDocument.defaultView||window).getSelection(),r={anchorNode:r.anchorNode,anchorOffset:r.anchorOffset,focusNode:r.focusNode,focusOffset:r.focusOffset}),W&&Dr(W,r)||(W=r,r=ui(Lr,`onSelect`),0<r.length&&(t=new On(`onSelect`,`select`,null,t,n),e.push({event:t,listeners:r}),t.target=Ir)))}function Br(e,t){var n={};return n[e.toLowerCase()]=t.toLowerCase(),n[`Webkit`+e]=`webkit`+t,n[`Moz`+e]=`moz`+t,n}var Vr={animationend:Br(`Animation`,`AnimationEnd`),animationiteration:Br(`Animation`,`AnimationIteration`),animationstart:Br(`Animation`,`AnimationStart`),transitionend:Br(`Transition`,`TransitionEnd`)},Hr={},Ur={};c&&(Ur=document.createElement(`div`).style,`AnimationEvent`in window||(delete Vr.animationend.animation,delete Vr.animationiteration.animation,delete Vr.animationstart.animation),`TransitionEvent`in window||delete Vr.transitionend.transition);function Wr(e){if(Hr[e])return Hr[e];if(!Vr[e])return e;var t=Vr[e],n;for(n in t)if(t.hasOwnProperty(n)&&n in Ur)return Hr[e]=t[n];return e}var Gr=Wr(`animationend`),Kr=Wr(`animationiteration`),qr=Wr(`animationstart`),Jr=Wr(`transitionend`),Yr=new Map,Xr=`abort auxClick cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel`.split(` `);function Zr(e,t){Yr.set(e,t),o(t,[e])}for(var Qr=0;Qr<Xr.length;Qr++){var $r=Xr[Qr];Zr($r.toLowerCase(),`on`+($r[0].toUpperCase()+$r.slice(1)))}Zr(Gr,`onAnimationEnd`),Zr(Kr,`onAnimationIteration`),Zr(qr,`onAnimationStart`),Zr(`dblclick`,`onDoubleClick`),Zr(`focusin`,`onFocus`),Zr(`focusout`,`onBlur`),Zr(Jr,`onTransitionEnd`),s(`onMouseEnter`,[`mouseout`,`mouseover`]),s(`onMouseLeave`,[`mouseout`,`mouseover`]),s(`onPointerEnter`,[`pointerout`,`pointerover`]),s(`onPointerLeave`,[`pointerout`,`pointerover`]),o(`onChange`,`change click focusin focusout input keydown keyup selectionchange`.split(` `)),o(`onSelect`,`focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange`.split(` `)),o(`onBeforeInput`,[`compositionend`,`keypress`,`textInput`,`paste`]),o(`onCompositionEnd`,`compositionend focusout keydown keypress keyup mousedown`.split(` `)),o(`onCompositionStart`,`compositionstart focusout keydown keypress keyup mousedown`.split(` `)),o(`onCompositionUpdate`,`compositionupdate focusout keydown keypress keyup mousedown`.split(` `));var ei=`abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting`.split(` `),ti=new Set(`cancel close invalid load scroll toggle`.split(` `).concat(ei));function ni(e,t,n){var r=e.type||`unknown-event`;e.currentTarget=n,it(r,t,void 0,e),e.currentTarget=null}function ri(e,t){t=!!(t&4);for(var n=0;n<e.length;n++){var r=e[n],i=r.event;r=r.listeners;a:{var a=void 0;if(t)for(var o=r.length-1;0<=o;o--){var s=r[o],c=s.instance,l=s.currentTarget;if(s=s.listener,c!==a&&i.isPropagationStopped())break a;ni(i,s,l),a=c}else for(o=0;o<r.length;o++){if(s=r[o],c=s.instance,l=s.currentTarget,s=s.listener,c!==a&&i.isPropagationStopped())break a;ni(i,s,l),a=c}}}if(et)throw e=tt,et=!1,tt=null,e}function G(e,t){var n=t[ki];n===void 0&&(n=t[ki]=new Set);var r=e+`__bubble`;n.has(r)||(si(t,e,2,!1),n.add(r))}function ii(e,t,n){var r=0;t&&(r|=4),si(n,e,r,t)}var ai=`_reactListening`+Math.random().toString(36).slice(2);function oi(e){if(!e[ai]){e[ai]=!0,i.forEach(function(t){t!==`selectionchange`&&(ti.has(t)||ii(t,!1,e),ii(t,!0,e))});var t=e.nodeType===9?e:e.ownerDocument;t===null||t[ai]||(t[ai]=!0,ii(`selectionchange`,!1,t))}}function si(e,t,n,r){switch(vn(t)){case 1:var i=pn;break;case 4:i=mn;break;default:i=hn}n=i.bind(null,t,n,e),i=void 0,!Ye||t!==`touchstart`&&t!==`touchmove`&&t!==`wheel`||(i=!0),r?i===void 0?e.addEventListener(t,n,!0):e.addEventListener(t,n,{capture:!0,passive:i}):i===void 0?e.addEventListener(t,n,!1):e.addEventListener(t,n,{passive:i})}function ci(e,t,n,r,i){var a=r;if(!(t&1)&&!(t&2)&&r!==null)a:for(;;){if(r===null)return;var o=r.tag;if(o===3||o===4){var s=r.stateNode.containerInfo;if(s===i||s.nodeType===8&&s.parentNode===i)break;if(o===4)for(o=r.return;o!==null;){var c=o.tag;if((c===3||c===4)&&(c=o.stateNode.containerInfo,c===i||c.nodeType===8&&c.parentNode===i))return;o=o.return}for(;s!==null;){if(o=Mi(s),o===null)return;if(c=o.tag,c===5||c===6){r=a=o;continue a}s=s.parentNode}}r=r.return}qe(function(){var r=a,i=Le(n),o=[];a:{var s=Yr.get(e);if(s!==void 0){var c=On,l=e;switch(e){case`keypress`:if(Cn(n)===0)break a;case`keydown`:case`keyup`:c=Gn;break;case`focusin`:l=`focus`,c=In;break;case`focusout`:l=`blur`,c=In;break;case`beforeblur`:case`afterblur`:c=In;break;case`click`:if(n.button===2)break a;case`auxclick`:case`dblclick`:case`mousedown`:case`mousemove`:case`mouseup`:case`mouseout`:case`mouseover`:case`contextmenu`:c=Fn;break;case`drag`:case`dragend`:case`dragenter`:case`dragexit`:case`dragleave`:case`dragover`:case`dragstart`:case`drop`:c=H;break;case`touchcancel`:case`touchend`:case`touchmove`:case`touchstart`:c=qn;break;case Gr:case Kr:case qr:c=Ln;break;case Jr:c=Jn;break;case`scroll`:c=An;break;case`wheel`:c=Yn;break;case`copy`:case`cut`:case`paste`:c=Rn;break;case`gotpointercapture`:case`lostpointercapture`:case`pointercancel`:case`pointerdown`:case`pointermove`:case`pointerout`:case`pointerover`:case`pointerup`:c=Kn}var u=!!(t&4),d=!u&&e===`scroll`,f=u?s===null?null:s+`Capture`:s;u=[];for(var p=r,m;p!==null;){m=p;var h=m.stateNode;if(m.tag===5&&h!==null&&(m=h,f!==null&&(h=Je(p,f),h!=null&&u.push(li(p,h,m)))),d)break;p=p.return}0<u.length&&(s=new c(s,l,null,n,i),o.push({event:s,listeners:u}))}}if(!(t&7)){a:{if(s=e===`mouseover`||e===`pointerover`,c=e===`mouseout`||e===`pointerout`,s&&n!==Ie&&(l=n.relatedTarget||n.fromElement)&&(Mi(l)||l[Y]))break a;if((c||s)&&(s=i.window===i?i:(s=i.ownerDocument)?s.defaultView||s.parentWindow:window,c?(l=n.relatedTarget||n.toElement,c=r,l=l?Mi(l):null,l!==null&&(d=at(l),l!==d||l.tag!==5&&l.tag!==6)&&(l=null)):(c=null,l=r),c!==l)){if(u=Fn,h=`onMouseLeave`,f=`onMouseEnter`,p=`mouse`,(e===`pointerout`||e===`pointerover`)&&(u=Kn,h=`onPointerLeave`,f=`onPointerEnter`,p=`pointer`),d=c==null?s:Pi(c),m=l==null?s:Pi(l),s=new u(h,p+`leave`,c,n,i),s.target=d,s.relatedTarget=m,h=null,Mi(i)===r&&(u=new u(f,p+`enter`,l,n,i),u.target=m,u.relatedTarget=d,h=u),d=h,c&&l)b:{for(u=c,f=l,p=0,m=u;m;m=di(m))p++;for(m=0,h=f;h;h=di(h))m++;for(;0<p-m;)u=di(u),p--;for(;0<m-p;)f=di(f),m--;for(;p--;){if(u===f||f!==null&&u===f.alternate)break b;u=di(u),f=di(f)}u=null}else u=null;c!==null&&fi(o,s,c,u,!1),l!==null&&d!==null&&fi(o,d,l,u,!0)}}a:{if(s=r?Pi(r):window,c=s.nodeName&&s.nodeName.toLowerCase(),c===`select`||c===`input`&&s.type===`file`)var g=hr;else if(lr(s)){if(gr)g=Tr;else{g=Cr;var _=Sr}}else(c=s.nodeName)&&c.toLowerCase()===`input`&&(s.type===`checkbox`||s.type===`radio`)&&(g=wr);if(g&&=g(e,r)){ur(o,g,n,i);break a}_&&_(e,s,r),e===`focusout`&&(_=s._wrapperState)&&_.controlled&&s.type===`number`&&ve(s,`number`,s.value)}switch(_=r?Pi(r):window,e){case`focusin`:(lr(_)||_.contentEditable===`true`)&&(Ir=_,Lr=r,W=null);break;case`focusout`:W=Lr=Ir=null;break;case`mousedown`:Rr=!0;break;case`contextmenu`:case`mouseup`:case`dragend`:Rr=!1,zr(o,n,i);break;case`selectionchange`:if(Fr)break;case`keydown`:case`keyup`:zr(o,n,i)}var v;if(Zn)b:{switch(e){case`compositionstart`:var y=`onCompositionStart`;break b;case`compositionend`:y=`onCompositionEnd`;break b;case`compositionupdate`:y=`onCompositionUpdate`;break b}y=void 0}else ar?rr(e,n)&&(y=`onCompositionEnd`):e===`keydown`&&n.keyCode===229&&(y=`onCompositionStart`);y&&(er&&n.locale!==`ko`&&(ar||y!==`onCompositionStart`?y===`onCompositionEnd`&&ar&&(v=Sn()):(yn=i,bn=`value`in yn?yn.value:yn.textContent,ar=!0)),_=ui(r,y),0<_.length&&(y=new zn(y,e,null,n,i),o.push({event:y,listeners:_}),v?y.data=v:(v=ir(n),v!==null&&(y.data=v)))),(v=$n?or(e,n):sr(e,n))&&(r=ui(r,`onBeforeInput`),0<r.length&&(i=new zn(`onBeforeInput`,`beforeinput`,null,n,i),o.push({event:i,listeners:r}),i.data=v))}ri(o,t)})}function li(e,t,n){return{instance:e,listener:t,currentTarget:n}}function ui(e,t){for(var n=t+`Capture`,r=[];e!==null;){var i=e,a=i.stateNode;i.tag===5&&a!==null&&(i=a,a=Je(e,n),a!=null&&r.unshift(li(e,a,i)),a=Je(e,t),a!=null&&r.push(li(e,a,i))),e=e.return}return r}function di(e){if(e===null)return null;do e=e.return;while(e&&e.tag!==5);return e||null}function fi(e,t,n,r,i){for(var a=t._reactName,o=[];n!==null&&n!==r;){var s=n,c=s.alternate,l=s.stateNode;if(c!==null&&c===r)break;s.tag===5&&l!==null&&(s=l,i?(c=Je(n,a),c!=null&&o.unshift(li(n,c,s))):i||(c=Je(n,a),c!=null&&o.push(li(n,c,s)))),n=n.return}o.length!==0&&e.push({event:t,listeners:o})}var pi=/\r\n?/g,mi=/\u0000|\uFFFD/g;function hi(e){return(typeof e==`string`?e:``+e).replace(pi,`
`).replace(mi,``)}function gi(e,t,n){if(t=hi(t),hi(e)!==t&&n)throw Error(r(425))}function K(){}var _i=null,vi=null;function yi(e,t){return e===`textarea`||e===`noscript`||typeof t.children==`string`||typeof t.children==`number`||typeof t.dangerouslySetInnerHTML==`object`&&t.dangerouslySetInnerHTML!==null&&t.dangerouslySetInnerHTML.__html!=null}var bi=typeof setTimeout==`function`?setTimeout:void 0,xi=typeof clearTimeout==`function`?clearTimeout:void 0,Si=typeof Promise==`function`?Promise:void 0,Ci=typeof queueMicrotask==`function`?queueMicrotask:Si===void 0?bi:function(e){return Si.resolve(null).then(e).catch(wi)};function wi(e){setTimeout(function(){throw e})}function Ti(e,t){var n=t,r=0;do{var i=n.nextSibling;if(e.removeChild(n),i&&i.nodeType===8){if(n=i.data,n===`/$`){if(r===0){e.removeChild(i),un(t);return}r--}else n!==`$`&&n!==`$?`&&n!==`$!`||r++}n=i}while(n);un(t)}function Ei(e){for(;e!=null;e=e.nextSibling){var t=e.nodeType;if(t===1||t===3)break;if(t===8){if(t=e.data,t===`$`||t===`$!`||t===`$?`)break;if(t===`/$`)return null}}return e}function Di(e){e=e.previousSibling;for(var t=0;e;){if(e.nodeType===8){var n=e.data;if(n===`$`||n===`$!`||n===`$?`){if(t===0)return e;t--}else n===`/$`&&t++}e=e.previousSibling}return null}var q=Math.random().toString(36).slice(2),J=`__reactFiber$`+q,Oi=`__reactProps$`+q,Y=`__reactContainer$`+q,ki=`__reactEvents$`+q,Ai=`__reactListeners$`+q,ji=`__reactHandles$`+q;function Mi(e){var t=e[J];if(t)return t;for(var n=e.parentNode;n;){if(t=n[Y]||n[J]){if(n=t.alternate,t.child!==null||n!==null&&n.child!==null)for(e=Di(e);e!==null;){if(n=e[J])return n;e=Di(e)}return t}e=n,n=e.parentNode}return null}function Ni(e){return e=e[J]||e[Y],!e||e.tag!==5&&e.tag!==6&&e.tag!==13&&e.tag!==3?null:e}function Pi(e){if(e.tag===5||e.tag===6)return e.stateNode;throw Error(r(33))}function Fi(e){return e[Oi]||null}var Ii=[],Li=-1;function Ri(e){return{current:e}}function X(e){0>Li||(e.current=Ii[Li],Ii[Li]=null,Li--)}function Z(e,t){Li++,Ii[Li]=e.current,e.current=t}var zi={},Bi=Ri(zi),Vi=Ri(!1),Hi=zi;function Ui(e,t){var n=e.type.contextTypes;if(!n)return zi;var r=e.stateNode;if(r&&r.__reactInternalMemoizedUnmaskedChildContext===t)return r.__reactInternalMemoizedMaskedChildContext;var i={},a;for(a in n)i[a]=t[a];return r&&(e=e.stateNode,e.__reactInternalMemoizedUnmaskedChildContext=t,e.__reactInternalMemoizedMaskedChildContext=i),i}function Wi(e){return e=e.childContextTypes,e!=null}function Gi(){X(Vi),X(Bi)}function Ki(e,t,n){if(Bi.current!==zi)throw Error(r(168));Z(Bi,t),Z(Vi,n)}function qi(e,t,n){var i=e.stateNode;if(t=t.childContextTypes,typeof i.getChildContext!=`function`)return n;for(var a in i=i.getChildContext(),i)if(!(a in t))throw Error(r(108,se(e)||`Unknown`,a));return I({},n,i)}function Ji(e){return e=(e=e.stateNode)&&e.__reactInternalMemoizedMergedChildContext||zi,Hi=Bi.current,Z(Bi,e),Z(Vi,Vi.current),!0}function Yi(e,t,n){var i=e.stateNode;if(!i)throw Error(r(169));n?(e=qi(e,t,Hi),i.__reactInternalMemoizedMergedChildContext=e,X(Vi),X(Bi),Z(Bi,e)):X(Vi),Z(Vi,n)}var Xi=null,Zi=!1,Qi=!1;function $i(e){Xi===null?Xi=[e]:Xi.push(e)}function ea(e){Zi=!0,$i(e)}function ta(){if(!Qi&&Xi!==null){Qi=!0;var e=0,t=B;try{var n=Xi;for(B=1;e<n.length;e++){var r=n[e];do r=r(!0);while(r!==null)}Xi=null,Zi=!1}catch(t){throw Xi!==null&&(Xi=Xi.slice(e+1)),dt(_t,ta),t}finally{B=t,Qi=!1}}return null}var na=[],ra=0,ia=null,aa=0,oa=[],sa=0,ca=null,la=1,ua=``;function da(e,t){na[ra++]=aa,na[ra++]=ia,ia=e,aa=t}function fa(e,t,n){oa[sa++]=la,oa[sa++]=ua,oa[sa++]=ca,ca=e;var r=la;e=ua;var i=32-Tt(r)-1;r&=~(1<<i),n+=1;var a=32-Tt(t)+i;if(30<a){var o=i-i%5;a=(r&(1<<o)-1).toString(32),r>>=o,i-=o,la=1<<32-Tt(t)+i|n<<i|r,ua=a+e}else la=1<<a|n<<i|r,ua=e}function pa(e){e.return!==null&&(da(e,1),fa(e,1,0))}function ma(e){for(;e===ia;)ia=na[--ra],na[ra]=null,aa=na[--ra],na[ra]=null;for(;e===ca;)ca=oa[--sa],oa[sa]=null,ua=oa[--sa],oa[sa]=null,la=oa[--sa],oa[sa]=null}var ha=null,ga=null,_a=!1,va=null;function ya(e,t){var n=Kl(5,null,null,0);n.elementType=`DELETED`,n.stateNode=t,n.return=e,t=e.deletions,t===null?(e.deletions=[n],e.flags|=16):t.push(n)}function ba(e,t){switch(e.tag){case 5:var n=e.type;return t=t.nodeType!==1||n.toLowerCase()!==t.nodeName.toLowerCase()?null:t,t!==null&&(e.stateNode=t,ha=e,ga=Ei(t.firstChild),!0);case 6:return t=e.pendingProps===``||t.nodeType!==3?null:t,t!==null&&(e.stateNode=t,ha=e,ga=null,!0);case 13:return t=t.nodeType===8?t:null,t!==null&&(n=ca===null?null:{id:la,overflow:ua},e.memoizedState={dehydrated:t,treeContext:n,retryLane:1073741824},n=Kl(18,null,null,0),n.stateNode=t,n.return=e,e.child=n,ha=e,ga=null,!0);default:return!1}}function xa(e){return!!(e.mode&1)&&!(e.flags&128)}function Sa(e){if(_a){var t=ga;if(t){var n=t;if(!ba(e,t)){if(xa(e))throw Error(r(418));t=Ei(n.nextSibling);var i=ha;t&&ba(e,t)?ya(i,n):(e.flags=e.flags&-4097|2,_a=!1,ha=e)}}else{if(xa(e))throw Error(r(418));e.flags=e.flags&-4097|2,_a=!1,ha=e}}}function Ca(e){for(e=e.return;e!==null&&e.tag!==5&&e.tag!==3&&e.tag!==13;)e=e.return;ha=e}function wa(e){if(e!==ha)return!1;if(!_a)return Ca(e),_a=!0,!1;var t;if((t=e.tag!==3)&&!(t=e.tag!==5)&&(t=e.type,t=t!==`head`&&t!==`body`&&!yi(e.type,e.memoizedProps)),t&&=ga){if(xa(e))throw Ta(),Error(r(418));for(;t;)ya(e,t),t=Ei(t.nextSibling)}if(Ca(e),e.tag===13){if(e=e.memoizedState,e=e===null?null:e.dehydrated,!e)throw Error(r(317));a:{for(e=e.nextSibling,t=0;e;){if(e.nodeType===8){var n=e.data;if(n===`/$`){if(t===0){ga=Ei(e.nextSibling);break a}t--}else n!==`$`&&n!==`$!`&&n!==`$?`||t++}e=e.nextSibling}ga=null}}else ga=ha?Ei(e.stateNode.nextSibling):null;return!0}function Ta(){for(var e=ga;e;)e=Ei(e.nextSibling)}function Ea(){ga=ha=null,_a=!1}function Da(e){va===null?va=[e]:va.push(e)}var Oa=S.ReactCurrentBatchConfig;function ka(e,t,n){if(e=n.ref,e!==null&&typeof e!=`function`&&typeof e!=`object`){if(n._owner){if(n=n._owner,n){if(n.tag!==1)throw Error(r(309));var i=n.stateNode}if(!i)throw Error(r(147,e));var a=i,o=``+e;return t!==null&&t.ref!==null&&typeof t.ref==`function`&&t.ref._stringRef===o?t.ref:(t=function(e){var t=a.refs;e===null?delete t[o]:t[o]=e},t._stringRef=o,t)}if(typeof e!=`string`)throw Error(r(284));if(!n._owner)throw Error(r(290,e))}return e}function Aa(e,t){throw e=Object.prototype.toString.call(t),Error(r(31,e===`[object Object]`?`object with keys {`+Object.keys(t).join(`, `)+`}`:e))}function ja(e){var t=e._init;return t(e._payload)}function Ma(e){function t(t,n){if(e){var r=t.deletions;r===null?(t.deletions=[n],t.flags|=16):r.push(n)}}function n(n,r){if(!e)return null;for(;r!==null;)t(n,r),r=r.sibling;return null}function i(e,t){for(e=new Map;t!==null;)t.key===null?e.set(t.index,t):e.set(t.key,t),t=t.sibling;return e}function a(e,t){return e=Yl(e,t),e.index=0,e.sibling=null,e}function o(t,n,r){return t.index=r,e?(r=t.alternate,r===null?(t.flags|=2,n):(r=r.index,r<n?(t.flags|=2,n):r)):(t.flags|=1048576,n)}function s(t){return e&&t.alternate===null&&(t.flags|=2),t}function c(e,t,n,r){return t===null||t.tag!==6?(t=$l(n,e.mode,r),t.return=e,t):(t=a(t,n),t.return=e,t)}function l(e,t,n,r){var i=n.type;return i===T?d(e,t,n.props.children,r,n.key):t!==null&&(t.elementType===i||typeof i==`object`&&i&&i.$$typeof===P&&ja(i)===t.type)?(r=a(t,n.props),r.ref=ka(e,t,n),r.return=e,r):(r=Xl(n.type,n.key,n.props,null,e.mode,r),r.ref=ka(e,t,n),r.return=e,r)}function u(e,t,n,r){return t===null||t.tag!==4||t.stateNode.containerInfo!==n.containerInfo||t.stateNode.implementation!==n.implementation?(t=eu(n,e.mode,r),t.return=e,t):(t=a(t,n.children||[]),t.return=e,t)}function d(e,t,n,r,i){return t===null||t.tag!==7?(t=Zl(n,e.mode,r,i),t.return=e,t):(t=a(t,n),t.return=e,t)}function f(e,t,n){if(typeof t==`string`&&t!==``||typeof t==`number`)return t=$l(``+t,e.mode,n),t.return=e,t;if(typeof t==`object`&&t){switch(t.$$typeof){case C:return n=Xl(t.type,t.key,t.props,null,e.mode,n),n.ref=ka(e,null,t),n.return=e,n;case w:return t=eu(t,e.mode,n),t.return=e,t;case P:var r=t._init;return f(e,r(t._payload),n)}if(ye(t)||te(t))return t=Zl(t,e.mode,n,null),t.return=e,t;Aa(e,t)}return null}function p(e,t,n,r){var i=t===null?null:t.key;if(typeof n==`string`&&n!==``||typeof n==`number`)return i===null?c(e,t,``+n,r):null;if(typeof n==`object`&&n){switch(n.$$typeof){case C:return n.key===i?l(e,t,n,r):null;case w:return n.key===i?u(e,t,n,r):null;case P:return i=n._init,p(e,t,i(n._payload),r)}if(ye(n)||te(n))return i===null?d(e,t,n,r,null):null;Aa(e,n)}return null}function m(e,t,n,r,i){if(typeof r==`string`&&r!==``||typeof r==`number`)return e=e.get(n)||null,c(t,e,``+r,i);if(typeof r==`object`&&r){switch(r.$$typeof){case C:return e=e.get(r.key===null?n:r.key)||null,l(t,e,r,i);case w:return e=e.get(r.key===null?n:r.key)||null,u(t,e,r,i);case P:var a=r._init;return m(e,t,n,a(r._payload),i)}if(ye(r)||te(r))return e=e.get(n)||null,d(t,e,r,i,null);Aa(t,r)}return null}function h(r,a,s,c){for(var l=null,u=null,d=a,h=a=0,g=null;d!==null&&h<s.length;h++){d.index>h?(g=d,d=null):g=d.sibling;var _=p(r,d,s[h],c);if(_===null){d===null&&(d=g);break}e&&d&&_.alternate===null&&t(r,d),a=o(_,a,h),u===null?l=_:u.sibling=_,u=_,d=g}if(h===s.length)return n(r,d),_a&&da(r,h),l;if(d===null){for(;h<s.length;h++)d=f(r,s[h],c),d!==null&&(a=o(d,a,h),u===null?l=d:u.sibling=d,u=d);return _a&&da(r,h),l}for(d=i(r,d);h<s.length;h++)g=m(d,r,h,s[h],c),g!==null&&(e&&g.alternate!==null&&d.delete(g.key===null?h:g.key),a=o(g,a,h),u===null?l=g:u.sibling=g,u=g);return e&&d.forEach(function(e){return t(r,e)}),_a&&da(r,h),l}function g(a,s,c,l){var u=te(c);if(typeof u!=`function`)throw Error(r(150));if(c=u.call(c),c==null)throw Error(r(151));for(var d=u=null,h=s,g=s=0,_=null,v=c.next();h!==null&&!v.done;g++,v=c.next()){h.index>g?(_=h,h=null):_=h.sibling;var y=p(a,h,v.value,l);if(y===null){h===null&&(h=_);break}e&&h&&y.alternate===null&&t(a,h),s=o(y,s,g),d===null?u=y:d.sibling=y,d=y,h=_}if(v.done)return n(a,h),_a&&da(a,g),u;if(h===null){for(;!v.done;g++,v=c.next())v=f(a,v.value,l),v!==null&&(s=o(v,s,g),d===null?u=v:d.sibling=v,d=v);return _a&&da(a,g),u}for(h=i(a,h);!v.done;g++,v=c.next())v=m(h,a,g,v.value,l),v!==null&&(e&&v.alternate!==null&&h.delete(v.key===null?g:v.key),s=o(v,s,g),d===null?u=v:d.sibling=v,d=v);return e&&h.forEach(function(e){return t(a,e)}),_a&&da(a,g),u}function _(e,r,i,o){if(typeof i==`object`&&i&&i.type===T&&i.key===null&&(i=i.props.children),typeof i==`object`&&i){switch(i.$$typeof){case C:a:{for(var c=i.key,l=r;l!==null;){if(l.key===c){if(c=i.type,c===T){if(l.tag===7){n(e,l.sibling),r=a(l,i.props.children),r.return=e,e=r;break a}}else if(l.elementType===c||typeof c==`object`&&c&&c.$$typeof===P&&ja(c)===l.type){n(e,l.sibling),r=a(l,i.props),r.ref=ka(e,l,i),r.return=e,e=r;break a}n(e,l);break}t(e,l),l=l.sibling}i.type===T?(r=Zl(i.props.children,e.mode,o,i.key),r.return=e,e=r):(o=Xl(i.type,i.key,i.props,null,e.mode,o),o.ref=ka(e,r,i),o.return=e,e=o)}return s(e);case w:a:{for(l=i.key;r!==null;){if(r.key===l){if(r.tag===4&&r.stateNode.containerInfo===i.containerInfo&&r.stateNode.implementation===i.implementation){n(e,r.sibling),r=a(r,i.children||[]),r.return=e,e=r;break a}n(e,r);break}t(e,r),r=r.sibling}r=eu(i,e.mode,o),r.return=e,e=r}return s(e);case P:return l=i._init,_(e,r,l(i._payload),o)}if(ye(i))return h(e,r,i,o);if(te(i))return g(e,r,i,o);Aa(e,i)}return typeof i==`string`&&i!==``||typeof i==`number`?(i=``+i,r!==null&&r.tag===6?(n(e,r.sibling),r=a(r,i),r.return=e,e=r):(n(e,r),r=$l(i,e.mode,o),r.return=e,e=r),s(e)):n(e,r)}return _}var Na=Ma(!0),Pa=Ma(!1),Fa=Ri(null),Ia=null,La=null,Ra=null;function za(){Ra=La=Ia=null}function Ba(e){var t=Fa.current;X(Fa),e._currentValue=t}function Va(e,t,n){for(;e!==null;){var r=e.alternate;if((e.childLanes&t)===t?r!==null&&(r.childLanes&t)!==t&&(r.childLanes|=t):(e.childLanes|=t,r!==null&&(r.childLanes|=t)),e===n)break;e=e.return}}function Ha(e,t){Ia=e,Ra=La=null,e=e.dependencies,e!==null&&e.firstContext!==null&&((e.lanes&t)!==0&&(Ms=!0),e.firstContext=null)}function Ua(e){var t=e._currentValue;if(Ra!==e){if(e={context:e,memoizedValue:t,next:null},La===null){if(Ia===null)throw Error(r(308));La=e,Ia.dependencies={lanes:0,firstContext:e}}else La=La.next=e}return t}var Wa=null;function Ga(e){Wa===null?Wa=[e]:Wa.push(e)}function Ka(e,t,n,r){var i=t.interleaved;return i===null?(n.next=n,Ga(t)):(n.next=i.next,i.next=n),t.interleaved=n,qa(e,r)}function qa(e,t){e.lanes|=t;var n=e.alternate;for(n!==null&&(n.lanes|=t),n=e,e=e.return;e!==null;)e.childLanes|=t,n=e.alternate,n!==null&&(n.childLanes|=t),n=e,e=e.return;return n.tag===3?n.stateNode:null}var Ja=!1;function Ya(e){e.updateQueue={baseState:e.memoizedState,firstBaseUpdate:null,lastBaseUpdate:null,shared:{pending:null,interleaved:null,lanes:0},effects:null}}function Xa(e,t){e=e.updateQueue,t.updateQueue===e&&(t.updateQueue={baseState:e.baseState,firstBaseUpdate:e.firstBaseUpdate,lastBaseUpdate:e.lastBaseUpdate,shared:e.shared,effects:e.effects})}function Za(e,t){return{eventTime:e,lane:t,tag:0,payload:null,callback:null,next:null}}function Qa(e,t,n){var r=e.updateQueue;if(r===null)return null;if(r=r.shared,$&2){var i=r.pending;return i===null?t.next=t:(t.next=i.next,i.next=t),r.pending=t,qa(e,n)}return i=r.interleaved,i===null?(t.next=t,Ga(r)):(t.next=i.next,i.next=t),r.interleaved=t,qa(e,n)}function $a(e,t,n){if(t=t.updateQueue,t!==null&&(t=t.shared,n&4194240)){var r=t.lanes;r&=e.pendingLanes,n|=r,t.lanes=n,Bt(e,n)}}function eo(e,t){var n=e.updateQueue,r=e.alternate;if(r!==null&&(r=r.updateQueue,n===r)){var i=null,a=null;if(n=n.firstBaseUpdate,n!==null){do{var o={eventTime:n.eventTime,lane:n.lane,tag:n.tag,payload:n.payload,callback:n.callback,next:null};a===null?i=a=o:a=a.next=o,n=n.next}while(n!==null);a===null?i=a=t:a=a.next=t}else i=a=t;n={baseState:r.baseState,firstBaseUpdate:i,lastBaseUpdate:a,shared:r.shared,effects:r.effects},e.updateQueue=n;return}e=n.lastBaseUpdate,e===null?n.firstBaseUpdate=t:e.next=t,n.lastBaseUpdate=t}function to(e,t,n,r){var i=e.updateQueue;Ja=!1;var a=i.firstBaseUpdate,o=i.lastBaseUpdate,s=i.shared.pending;if(s!==null){i.shared.pending=null;var c=s,l=c.next;c.next=null,o===null?a=l:o.next=l,o=c;var u=e.alternate;u!==null&&(u=u.updateQueue,s=u.lastBaseUpdate,s!==o&&(s===null?u.firstBaseUpdate=l:s.next=l,u.lastBaseUpdate=c))}if(a!==null){var d=i.baseState;o=0,u=l=c=null,s=a;do{var f=s.lane,p=s.eventTime;if((r&f)===f){u!==null&&(u=u.next={eventTime:p,lane:0,tag:s.tag,payload:s.payload,callback:s.callback,next:null});a:{var m=e,h=s;switch(f=t,p=n,h.tag){case 1:if(m=h.payload,typeof m==`function`){d=m.call(p,d,f);break a}d=m;break a;case 3:m.flags=m.flags&-65537|128;case 0:if(m=h.payload,f=typeof m==`function`?m.call(p,d,f):m,f==null)break a;d=I({},d,f);break a;case 2:Ja=!0}}s.callback!==null&&s.lane!==0&&(e.flags|=64,f=i.effects,f===null?i.effects=[s]:f.push(s))}else p={eventTime:p,lane:f,tag:s.tag,payload:s.payload,callback:s.callback,next:null},u===null?(l=u=p,c=d):u=u.next=p,o|=f;if(s=s.next,s===null){if(s=i.shared.pending,s===null)break;f=s,s=f.next,f.next=null,i.lastBaseUpdate=f,i.shared.pending=null}}while(1);if(u===null&&(c=d),i.baseState=c,i.firstBaseUpdate=l,i.lastBaseUpdate=u,t=i.shared.interleaved,t!==null){i=t;do o|=i.lane,i=i.next;while(i!==t)}else a===null&&(i.shared.lanes=0);Jc|=o,e.lanes=o,e.memoizedState=d}}function no(e,t,n){if(e=t.effects,t.effects=null,e!==null)for(t=0;t<e.length;t++){var i=e[t],a=i.callback;if(a!==null){if(i.callback=null,i=n,typeof a!=`function`)throw Error(r(191,a));a.call(i)}}}var ro={},io=Ri(ro),ao=Ri(ro),oo=Ri(ro);function so(e){if(e===ro)throw Error(r(174));return e}function co(e,t){switch(Z(oo,t),Z(ao,e),Z(io,ro),e=t.nodeType,e){case 9:case 11:t=(t=t.documentElement)?t.namespaceURI:Ee(null,``);break;default:e=e===8?t.parentNode:t,t=e.namespaceURI||null,e=e.tagName,t=Ee(t,e)}X(io),Z(io,t)}function lo(){X(io),X(ao),X(oo)}function uo(e){so(oo.current);var t=so(io.current),n=Ee(t,e.type);t!==n&&(Z(ao,e),Z(io,n))}function fo(e){ao.current===e&&(X(io),X(ao))}var po=Ri(0);function mo(e){for(var t=e;t!==null;){if(t.tag===13){var n=t.memoizedState;if(n!==null&&(n=n.dehydrated,n===null||n.data===`$?`||n.data===`$!`))return t}else if(t.tag===19&&t.memoizedProps.revealOrder!==void 0){if(t.flags&128)return t}else if(t.child!==null){t.child.return=t,t=t.child;continue}if(t===e)break;for(;t.sibling===null;){if(t.return===null||t.return===e)return null;t=t.return}t.sibling.return=t.return,t=t.sibling}return null}var ho=[];function go(){for(var e=0;e<ho.length;e++)ho[e]._workInProgressVersionPrimary=null;ho.length=0}var _o=S.ReactCurrentDispatcher,vo=S.ReactCurrentBatchConfig,yo=0,bo=null,xo=null,So=null,Co=!1,wo=!1,To=0,Eo=0;function Do(){throw Error(r(321))}function Oo(e,t){if(t===null)return!1;for(var n=0;n<t.length&&n<e.length;n++)if(!U(e[n],t[n]))return!1;return!0}function ko(e,t,n,i,a,o){if(yo=o,bo=t,t.memoizedState=null,t.updateQueue=null,t.lanes=0,_o.current=e===null||e.memoizedState===null?fs:ps,e=n(i,a),wo){o=0;do{if(wo=!1,To=0,25<=o)throw Error(r(301));o+=1,So=xo=null,t.updateQueue=null,_o.current=ms,e=n(i,a)}while(wo)}if(_o.current=ds,t=xo!==null&&xo.next!==null,yo=0,So=xo=bo=null,Co=!1,t)throw Error(r(300));return e}function Ao(){var e=To!==0;return To=0,e}function jo(){var e={memoizedState:null,baseState:null,baseQueue:null,queue:null,next:null};return So===null?bo.memoizedState=So=e:So=So.next=e,So}function Mo(){if(xo===null){var e=bo.alternate;e=e===null?null:e.memoizedState}else e=xo.next;var t=So===null?bo.memoizedState:So.next;if(t!==null)So=t,xo=e;else{if(e===null)throw Error(r(310));xo=e,e={memoizedState:xo.memoizedState,baseState:xo.baseState,baseQueue:xo.baseQueue,queue:xo.queue,next:null},So===null?bo.memoizedState=So=e:So=So.next=e}return So}function No(e,t){return typeof t==`function`?t(e):t}function Po(e){var t=Mo(),n=t.queue;if(n===null)throw Error(r(311));n.lastRenderedReducer=e;var i=xo,a=i.baseQueue,o=n.pending;if(o!==null){if(a!==null){var s=a.next;a.next=o.next,o.next=s}i.baseQueue=a=o,n.pending=null}if(a!==null){o=a.next,i=i.baseState;var c=s=null,l=null,u=o;do{var d=u.lane;if((yo&d)===d)l!==null&&(l=l.next={lane:0,action:u.action,hasEagerState:u.hasEagerState,eagerState:u.eagerState,next:null}),i=u.hasEagerState?u.eagerState:e(i,u.action);else{var f={lane:d,action:u.action,hasEagerState:u.hasEagerState,eagerState:u.eagerState,next:null};l===null?(c=l=f,s=i):l=l.next=f,bo.lanes|=d,Jc|=d}u=u.next}while(u!==null&&u!==o);l===null?s=i:l.next=c,U(i,t.memoizedState)||(Ms=!0),t.memoizedState=i,t.baseState=s,t.baseQueue=l,n.lastRenderedState=i}if(e=n.interleaved,e!==null){a=e;do o=a.lane,bo.lanes|=o,Jc|=o,a=a.next;while(a!==e)}else a===null&&(n.lanes=0);return[t.memoizedState,n.dispatch]}function Fo(e){var t=Mo(),n=t.queue;if(n===null)throw Error(r(311));n.lastRenderedReducer=e;var i=n.dispatch,a=n.pending,o=t.memoizedState;if(a!==null){n.pending=null;var s=a=a.next;do o=e(o,s.action),s=s.next;while(s!==a);U(o,t.memoizedState)||(Ms=!0),t.memoizedState=o,t.baseQueue===null&&(t.baseState=o),n.lastRenderedState=o}return[o,i]}function Io(){}function Lo(e,t){var n=bo,i=Mo(),a=t(),o=!U(i.memoizedState,a);if(o&&(i.memoizedState=a,Ms=!0),i=i.queue,Yo(Bo.bind(null,n,i,e),[e]),i.getSnapshot!==t||o||So!==null&&So.memoizedState.tag&1){if(n.flags|=2048,Wo(9,zo.bind(null,n,i,a,t),void 0,null),Vc===null)throw Error(r(349));yo&30||Ro(n,t,a)}return a}function Ro(e,t,n){e.flags|=16384,e={getSnapshot:t,value:n},t=bo.updateQueue,t===null?(t={lastEffect:null,stores:null},bo.updateQueue=t,t.stores=[e]):(n=t.stores,n===null?t.stores=[e]:n.push(e))}function zo(e,t,n,r){t.value=n,t.getSnapshot=r,Vo(t)&&Ho(e)}function Bo(e,t,n){return n(function(){Vo(t)&&Ho(e)})}function Vo(e){var t=e.getSnapshot;e=e.value;try{var n=t();return!U(e,n)}catch{return!0}}function Ho(e){var t=qa(e,1);t!==null&&ml(t,e,1,-1)}function Uo(e){var t=jo();return typeof e==`function`&&(e=e()),t.memoizedState=t.baseState=e,e={pending:null,interleaved:null,lanes:0,dispatch:null,lastRenderedReducer:No,lastRenderedState:e},t.queue=e,e=e.dispatch=ss.bind(null,bo,e),[t.memoizedState,e]}function Wo(e,t,n,r){return e={tag:e,create:t,destroy:n,deps:r,next:null},t=bo.updateQueue,t===null?(t={lastEffect:null,stores:null},bo.updateQueue=t,t.lastEffect=e.next=e):(n=t.lastEffect,n===null?t.lastEffect=e.next=e:(r=n.next,n.next=e,e.next=r,t.lastEffect=e)),e}function Go(){return Mo().memoizedState}function Ko(e,t,n,r){var i=jo();bo.flags|=e,i.memoizedState=Wo(1|t,n,void 0,r===void 0?null:r)}function qo(e,t,n,r){var i=Mo();r=r===void 0?null:r;var a=void 0;if(xo!==null){var o=xo.memoizedState;if(a=o.destroy,r!==null&&Oo(r,o.deps)){i.memoizedState=Wo(t,n,a,r);return}}bo.flags|=e,i.memoizedState=Wo(1|t,n,a,r)}function Jo(e,t){return Ko(8390656,8,e,t)}function Yo(e,t){return qo(2048,8,e,t)}function Xo(e,t){return qo(4,2,e,t)}function Zo(e,t){return qo(4,4,e,t)}function Qo(e,t){if(typeof t==`function`)return e=e(),t(e),function(){t(null)};if(t!=null)return e=e(),t.current=e,function(){t.current=null}}function $o(e,t,n){return n=n==null?null:n.concat([e]),qo(4,4,Qo.bind(null,t,e),n)}function es(){}function ts(e,t){var n=Mo();t=t===void 0?null:t;var r=n.memoizedState;return r!==null&&t!==null&&Oo(t,r[1])?r[0]:(n.memoizedState=[e,t],e)}function ns(e,t){var n=Mo();t=t===void 0?null:t;var r=n.memoizedState;return r!==null&&t!==null&&Oo(t,r[1])?r[0]:(e=e(),n.memoizedState=[e,t],e)}function rs(e,t,n){return yo&21?(U(n,t)||(n=It(),bo.lanes|=n,Jc|=n,e.baseState=!0),t):(e.baseState&&(e.baseState=!1,Ms=!0),e.memoizedState=n)}function is(e,t){var n=B;B=n!==0&&4>n?n:4,e(!0);var r=vo.transition;vo.transition={};try{e(!1),t()}finally{B=n,vo.transition=r}}function as(){return Mo().memoizedState}function os(e,t,n){var r=pl(e);if(n={lane:r,action:n,hasEagerState:!1,eagerState:null,next:null},cs(e))ls(t,n);else if(n=Ka(e,t,n,r),n!==null){var i=fl();ml(n,e,r,i),us(n,t,r)}}function ss(e,t,n){var r=pl(e),i={lane:r,action:n,hasEagerState:!1,eagerState:null,next:null};if(cs(e))ls(t,i);else{var a=e.alternate;if(e.lanes===0&&(a===null||a.lanes===0)&&(a=t.lastRenderedReducer,a!==null))try{var o=t.lastRenderedState,s=a(o,n);if(i.hasEagerState=!0,i.eagerState=s,U(s,o)){var c=t.interleaved;c===null?(i.next=i,Ga(t)):(i.next=c.next,c.next=i),t.interleaved=i;return}}catch{}n=Ka(e,t,i,r),n!==null&&(i=fl(),ml(n,e,r,i),us(n,t,r))}}function cs(e){var t=e.alternate;return e===bo||t!==null&&t===bo}function ls(e,t){wo=Co=!0;var n=e.pending;n===null?t.next=t:(t.next=n.next,n.next=t),e.pending=t}function us(e,t,n){if(n&4194240){var r=t.lanes;r&=e.pendingLanes,n|=r,t.lanes=n,Bt(e,n)}}var ds={readContext:Ua,useCallback:Do,useContext:Do,useEffect:Do,useImperativeHandle:Do,useInsertionEffect:Do,useLayoutEffect:Do,useMemo:Do,useReducer:Do,useRef:Do,useState:Do,useDebugValue:Do,useDeferredValue:Do,useTransition:Do,useMutableSource:Do,useSyncExternalStore:Do,useId:Do,unstable_isNewReconciler:!1},fs={readContext:Ua,useCallback:function(e,t){return jo().memoizedState=[e,t===void 0?null:t],e},useContext:Ua,useEffect:Jo,useImperativeHandle:function(e,t,n){return n=n==null?null:n.concat([e]),Ko(4194308,4,Qo.bind(null,t,e),n)},useLayoutEffect:function(e,t){return Ko(4194308,4,e,t)},useInsertionEffect:function(e,t){return Ko(4,2,e,t)},useMemo:function(e,t){var n=jo();return t=t===void 0?null:t,e=e(),n.memoizedState=[e,t],e},useReducer:function(e,t,n){var r=jo();return t=n===void 0?t:n(t),r.memoizedState=r.baseState=t,e={pending:null,interleaved:null,lanes:0,dispatch:null,lastRenderedReducer:e,lastRenderedState:t},r.queue=e,e=e.dispatch=os.bind(null,bo,e),[r.memoizedState,e]},useRef:function(e){var t=jo();return e={current:e},t.memoizedState=e},useState:Uo,useDebugValue:es,useDeferredValue:function(e){return jo().memoizedState=e},useTransition:function(){var e=Uo(!1),t=e[0];return e=is.bind(null,e[1]),jo().memoizedState=e,[t,e]},useMutableSource:function(){},useSyncExternalStore:function(e,t,n){var i=bo,a=jo();if(_a){if(n===void 0)throw Error(r(407));n=n()}else{if(n=t(),Vc===null)throw Error(r(349));yo&30||Ro(i,t,n)}a.memoizedState=n;var o={value:n,getSnapshot:t};return a.queue=o,Jo(Bo.bind(null,i,o,e),[e]),i.flags|=2048,Wo(9,zo.bind(null,i,o,n,t),void 0,null),n},useId:function(){var e=jo(),t=Vc.identifierPrefix;if(_a){var n=ua,r=la;n=(r&~(1<<32-Tt(r)-1)).toString(32)+n,t=`:`+t+`R`+n,n=To++,0<n&&(t+=`H`+n.toString(32)),t+=`:`}else n=Eo++,t=`:`+t+`r`+n.toString(32)+`:`;return e.memoizedState=t},unstable_isNewReconciler:!1},ps={readContext:Ua,useCallback:ts,useContext:Ua,useEffect:Yo,useImperativeHandle:$o,useInsertionEffect:Xo,useLayoutEffect:Zo,useMemo:ns,useReducer:Po,useRef:Go,useState:function(){return Po(No)},useDebugValue:es,useDeferredValue:function(e){return rs(Mo(),xo.memoizedState,e)},useTransition:function(){return[Po(No)[0],Mo().memoizedState]},useMutableSource:Io,useSyncExternalStore:Lo,useId:as,unstable_isNewReconciler:!1},ms={readContext:Ua,useCallback:ts,useContext:Ua,useEffect:Yo,useImperativeHandle:$o,useInsertionEffect:Xo,useLayoutEffect:Zo,useMemo:ns,useReducer:Fo,useRef:Go,useState:function(){return Fo(No)},useDebugValue:es,useDeferredValue:function(e){var t=Mo();return xo===null?t.memoizedState=e:rs(t,xo.memoizedState,e)},useTransition:function(){return[Fo(No)[0],Mo().memoizedState]},useMutableSource:Io,useSyncExternalStore:Lo,useId:as,unstable_isNewReconciler:!1};function hs(e,t){if(e&&e.defaultProps){for(var n in t=I({},t),e=e.defaultProps,e)t[n]===void 0&&(t[n]=e[n]);return t}return t}function gs(e,t,n,r){t=e.memoizedState,n=n(r,t),n=n==null?t:I({},t,n),e.memoizedState=n,e.lanes===0&&(e.updateQueue.baseState=n)}var _s={isMounted:function(e){return(e=e._reactInternals)?at(e)===e:!1},enqueueSetState:function(e,t,n){e=e._reactInternals;var r=fl(),i=pl(e),a=Za(r,i);a.payload=t,n!=null&&(a.callback=n),t=Qa(e,a,i),t!==null&&(ml(t,e,i,r),$a(t,e,i))},enqueueReplaceState:function(e,t,n){e=e._reactInternals;var r=fl(),i=pl(e),a=Za(r,i);a.tag=1,a.payload=t,n!=null&&(a.callback=n),t=Qa(e,a,i),t!==null&&(ml(t,e,i,r),$a(t,e,i))},enqueueForceUpdate:function(e,t){e=e._reactInternals;var n=fl(),r=pl(e),i=Za(n,r);i.tag=2,t!=null&&(i.callback=t),t=Qa(e,i,r),t!==null&&(ml(t,e,r,n),$a(t,e,r))}};function vs(e,t,n,r,i,a,o){return e=e.stateNode,typeof e.shouldComponentUpdate==`function`?e.shouldComponentUpdate(r,a,o):t.prototype&&t.prototype.isPureReactComponent?!Dr(n,r)||!Dr(i,a):!0}function ys(e,t,n){var r=!1,i=zi,a=t.contextType;return typeof a==`object`&&a?a=Ua(a):(i=Wi(t)?Hi:Bi.current,r=t.contextTypes,a=(r=r!=null)?Ui(e,i):zi),t=new t(n,a),e.memoizedState=t.state!==null&&t.state!==void 0?t.state:null,t.updater=_s,e.stateNode=t,t._reactInternals=e,r&&(e=e.stateNode,e.__reactInternalMemoizedUnmaskedChildContext=i,e.__reactInternalMemoizedMaskedChildContext=a),t}function bs(e,t,n,r){e=t.state,typeof t.componentWillReceiveProps==`function`&&t.componentWillReceiveProps(n,r),typeof t.UNSAFE_componentWillReceiveProps==`function`&&t.UNSAFE_componentWillReceiveProps(n,r),t.state!==e&&_s.enqueueReplaceState(t,t.state,null)}function xs(e,t,n,r){var i=e.stateNode;i.props=n,i.state=e.memoizedState,i.refs={},Ya(e);var a=t.contextType;typeof a==`object`&&a?i.context=Ua(a):(a=Wi(t)?Hi:Bi.current,i.context=Ui(e,a)),i.state=e.memoizedState,a=t.getDerivedStateFromProps,typeof a==`function`&&(gs(e,t,a,n),i.state=e.memoizedState),typeof t.getDerivedStateFromProps==`function`||typeof i.getSnapshotBeforeUpdate==`function`||typeof i.UNSAFE_componentWillMount!=`function`&&typeof i.componentWillMount!=`function`||(t=i.state,typeof i.componentWillMount==`function`&&i.componentWillMount(),typeof i.UNSAFE_componentWillMount==`function`&&i.UNSAFE_componentWillMount(),t!==i.state&&_s.enqueueReplaceState(i,i.state,null),to(e,n,i,r),i.state=e.memoizedState),typeof i.componentDidMount==`function`&&(e.flags|=4194308)}function Ss(e,t){try{var n=``,r=t;do n+=ae(r),r=r.return;while(r);var i=n}catch(e){i=`
Error generating stack: `+e.message+`
`+e.stack}return{value:e,source:t,stack:i,digest:null}}function Cs(e,t,n){return{value:e,source:null,stack:n??null,digest:t??null}}function ws(e,t){try{console.error(t.value)}catch(e){setTimeout(function(){throw e})}}var Ts=typeof WeakMap==`function`?WeakMap:Map;function Es(e,t,n){n=Za(-1,n),n.tag=3,n.payload={element:null};var r=t.value;return n.callback=function(){nl||(nl=!0,rl=r),ws(e,t)},n}function Ds(e,t,n){n=Za(-1,n),n.tag=3;var r=e.type.getDerivedStateFromError;if(typeof r==`function`){var i=t.value;n.payload=function(){return r(i)},n.callback=function(){ws(e,t)}}var a=e.stateNode;return a!==null&&typeof a.componentDidCatch==`function`&&(n.callback=function(){ws(e,t),typeof r!=`function`&&(il===null?il=new Set([this]):il.add(this));var n=t.stack;this.componentDidCatch(t.value,{componentStack:n===null?``:n})}),n}function Os(e,t,n){var r=e.pingCache;if(r===null){r=e.pingCache=new Ts;var i=new Set;r.set(t,i)}else i=r.get(t),i===void 0&&(i=new Set,r.set(t,i));i.has(n)||(i.add(n),e=zl.bind(null,e,t,n),t.then(e,e))}function ks(e){do{var t;if((t=e.tag===13)&&(t=e.memoizedState,t=t===null||t.dehydrated!==null),t)return e;e=e.return}while(e!==null);return null}function As(e,t,n,r,i){return e.mode&1?(e.flags|=65536,e.lanes=i,e):(e===t?e.flags|=65536:(e.flags|=128,n.flags|=131072,n.flags&=-52805,n.tag===1&&(n.alternate===null?n.tag=17:(t=Za(-1,1),t.tag=2,Qa(n,t,1))),n.lanes|=1),e)}var js=S.ReactCurrentOwner,Ms=!1;function Ns(e,t,n,r){t.child=e===null?Pa(t,null,n,r):Na(t,e.child,n,r)}function Ps(e,t,n,r,i){n=n.render;var a=t.ref;return Ha(t,i),r=ko(e,t,n,r,a,i),n=Ao(),e!==null&&!Ms?(t.updateQueue=e.updateQueue,t.flags&=-2053,e.lanes&=~i,ec(e,t,i)):(_a&&n&&pa(t),t.flags|=1,Ns(e,t,r,i),t.child)}function Fs(e,t,n,r,i){if(e===null){var a=n.type;return typeof a==`function`&&!ql(a)&&a.defaultProps===void 0&&n.compare===null&&n.defaultProps===void 0?(t.tag=15,t.type=a,Is(e,t,a,r,i)):(e=Xl(n.type,null,r,t,t.mode,i),e.ref=t.ref,e.return=t,t.child=e)}if(a=e.child,(e.lanes&i)===0){var o=a.memoizedProps;if(n=n.compare,n=n===null?Dr:n,n(o,r)&&e.ref===t.ref)return ec(e,t,i)}return t.flags|=1,e=Yl(a,r),e.ref=t.ref,e.return=t,t.child=e}function Is(e,t,n,r,i){if(e!==null){var a=e.memoizedProps;if(Dr(a,r)&&e.ref===t.ref){if(Ms=!1,t.pendingProps=r=a,(e.lanes&i)!==0)e.flags&131072&&(Ms=!0);else return t.lanes=e.lanes,ec(e,t,i)}}return zs(e,t,n,r,i)}function Ls(e,t,n){var r=t.pendingProps,i=r.children,a=e===null?null:e.memoizedState;if(r.mode===`hidden`){if(!(t.mode&1))t.memoizedState={baseLanes:0,cachePool:null,transitions:null},Z(Gc,Wc),Wc|=n;else{if(!(n&1073741824))return e=a===null?n:a.baseLanes|n,t.lanes=t.childLanes=1073741824,t.memoizedState={baseLanes:e,cachePool:null,transitions:null},t.updateQueue=null,Z(Gc,Wc),Wc|=e,null;t.memoizedState={baseLanes:0,cachePool:null,transitions:null},r=a===null?n:a.baseLanes,Z(Gc,Wc),Wc|=r}}else a===null?r=n:(r=a.baseLanes|n,t.memoizedState=null),Z(Gc,Wc),Wc|=r;return Ns(e,t,i,n),t.child}function Rs(e,t){var n=t.ref;(e===null&&n!==null||e!==null&&e.ref!==n)&&(t.flags|=512,t.flags|=2097152)}function zs(e,t,n,r,i){var a=Wi(n)?Hi:Bi.current;return a=Ui(t,a),Ha(t,i),n=ko(e,t,n,r,a,i),r=Ao(),e!==null&&!Ms?(t.updateQueue=e.updateQueue,t.flags&=-2053,e.lanes&=~i,ec(e,t,i)):(_a&&r&&pa(t),t.flags|=1,Ns(e,t,n,i),t.child)}function Bs(e,t,n,r,i){if(Wi(n)){var a=!0;Ji(t)}else a=!1;if(Ha(t,i),t.stateNode===null)$s(e,t),ys(t,n,r),xs(t,n,r,i),r=!0;else if(e===null){var o=t.stateNode,s=t.memoizedProps;o.props=s;var c=o.context,l=n.contextType;typeof l==`object`&&l?l=Ua(l):(l=Wi(n)?Hi:Bi.current,l=Ui(t,l));var u=n.getDerivedStateFromProps,d=typeof u==`function`||typeof o.getSnapshotBeforeUpdate==`function`;d||typeof o.UNSAFE_componentWillReceiveProps!=`function`&&typeof o.componentWillReceiveProps!=`function`||(s!==r||c!==l)&&bs(t,o,r,l),Ja=!1;var f=t.memoizedState;o.state=f,to(t,r,o,i),c=t.memoizedState,s!==r||f!==c||Vi.current||Ja?(typeof u==`function`&&(gs(t,n,u,r),c=t.memoizedState),(s=Ja||vs(t,n,s,r,f,c,l))?(d||typeof o.UNSAFE_componentWillMount!=`function`&&typeof o.componentWillMount!=`function`||(typeof o.componentWillMount==`function`&&o.componentWillMount(),typeof o.UNSAFE_componentWillMount==`function`&&o.UNSAFE_componentWillMount()),typeof o.componentDidMount==`function`&&(t.flags|=4194308)):(typeof o.componentDidMount==`function`&&(t.flags|=4194308),t.memoizedProps=r,t.memoizedState=c),o.props=r,o.state=c,o.context=l,r=s):(typeof o.componentDidMount==`function`&&(t.flags|=4194308),r=!1)}else{o=t.stateNode,Xa(e,t),s=t.memoizedProps,l=t.type===t.elementType?s:hs(t.type,s),o.props=l,d=t.pendingProps,f=o.context,c=n.contextType,typeof c==`object`&&c?c=Ua(c):(c=Wi(n)?Hi:Bi.current,c=Ui(t,c));var p=n.getDerivedStateFromProps;(u=typeof p==`function`||typeof o.getSnapshotBeforeUpdate==`function`)||typeof o.UNSAFE_componentWillReceiveProps!=`function`&&typeof o.componentWillReceiveProps!=`function`||(s!==d||f!==c)&&bs(t,o,r,c),Ja=!1,f=t.memoizedState,o.state=f,to(t,r,o,i);var m=t.memoizedState;s!==d||f!==m||Vi.current||Ja?(typeof p==`function`&&(gs(t,n,p,r),m=t.memoizedState),(l=Ja||vs(t,n,l,r,f,m,c)||!1)?(u||typeof o.UNSAFE_componentWillUpdate!=`function`&&typeof o.componentWillUpdate!=`function`||(typeof o.componentWillUpdate==`function`&&o.componentWillUpdate(r,m,c),typeof o.UNSAFE_componentWillUpdate==`function`&&o.UNSAFE_componentWillUpdate(r,m,c)),typeof o.componentDidUpdate==`function`&&(t.flags|=4),typeof o.getSnapshotBeforeUpdate==`function`&&(t.flags|=1024)):(typeof o.componentDidUpdate!=`function`||s===e.memoizedProps&&f===e.memoizedState||(t.flags|=4),typeof o.getSnapshotBeforeUpdate!=`function`||s===e.memoizedProps&&f===e.memoizedState||(t.flags|=1024),t.memoizedProps=r,t.memoizedState=m),o.props=r,o.state=m,o.context=c,r=l):(typeof o.componentDidUpdate!=`function`||s===e.memoizedProps&&f===e.memoizedState||(t.flags|=4),typeof o.getSnapshotBeforeUpdate!=`function`||s===e.memoizedProps&&f===e.memoizedState||(t.flags|=1024),r=!1)}return Vs(e,t,n,r,a,i)}function Vs(e,t,n,r,i,a){Rs(e,t);var o=!!(t.flags&128);if(!r&&!o)return i&&Yi(t,n,!1),ec(e,t,a);r=t.stateNode,js.current=t;var s=o&&typeof n.getDerivedStateFromError!=`function`?null:r.render();return t.flags|=1,e!==null&&o?(t.child=Na(t,e.child,null,a),t.child=Na(t,null,s,a)):Ns(e,t,s,a),t.memoizedState=r.state,i&&Yi(t,n,!0),t.child}function Hs(e){var t=e.stateNode;t.pendingContext?Ki(e,t.pendingContext,t.pendingContext!==t.context):t.context&&Ki(e,t.context,!1),co(e,t.containerInfo)}function Us(e,t,n,r,i){return Ea(),Da(i),t.flags|=256,Ns(e,t,n,r),t.child}var Ws={dehydrated:null,treeContext:null,retryLane:0};function Gs(e){return{baseLanes:e,cachePool:null,transitions:null}}function Ks(e,t,n){var r=t.pendingProps,i=po.current,a=!1,o=!!(t.flags&128),s;if((s=o)||(s=e!==null&&e.memoizedState===null?!1:!!(i&2)),s?(a=!0,t.flags&=-129):(e===null||e.memoizedState!==null)&&(i|=1),Z(po,i&1),e===null)return Sa(t),e=t.memoizedState,e!==null&&(e=e.dehydrated,e!==null)?(t.lanes=t.mode&1?e.data===`$!`?8:1073741824:1,null):(o=r.children,e=r.fallback,a?(r=t.mode,a=t.child,o={mode:`hidden`,children:o},!(r&1)&&a!==null?(a.childLanes=0,a.pendingProps=o):a=Ql(o,r,0,null),e=Zl(e,r,n,null),a.return=t,e.return=t,a.sibling=e,t.child=a,t.child.memoizedState=Gs(n),t.memoizedState=Ws,e):qs(t,o));if(i=e.memoizedState,i!==null&&(s=i.dehydrated,s!==null))return Ys(e,t,o,r,s,i,n);if(a){a=r.fallback,o=t.mode,i=e.child,s=i.sibling;var c={mode:`hidden`,children:r.children};return!(o&1)&&t.child!==i?(r=t.child,r.childLanes=0,r.pendingProps=c,t.deletions=null):(r=Yl(i,c),r.subtreeFlags=i.subtreeFlags&14680064),s===null?(a=Zl(a,o,n,null),a.flags|=2):a=Yl(s,a),a.return=t,r.return=t,r.sibling=a,t.child=r,r=a,a=t.child,o=e.child.memoizedState,o=o===null?Gs(n):{baseLanes:o.baseLanes|n,cachePool:null,transitions:o.transitions},a.memoizedState=o,a.childLanes=e.childLanes&~n,t.memoizedState=Ws,r}return a=e.child,e=a.sibling,r=Yl(a,{mode:`visible`,children:r.children}),!(t.mode&1)&&(r.lanes=n),r.return=t,r.sibling=null,e!==null&&(n=t.deletions,n===null?(t.deletions=[e],t.flags|=16):n.push(e)),t.child=r,t.memoizedState=null,r}function qs(e,t){return t=Ql({mode:`visible`,children:t},e.mode,0,null),t.return=e,e.child=t}function Js(e,t,n,r){return r!==null&&Da(r),Na(t,e.child,null,n),e=qs(t,t.pendingProps.children),e.flags|=2,t.memoizedState=null,e}function Ys(e,t,n,i,a,o,s){if(n)return t.flags&256?(t.flags&=-257,i=Cs(Error(r(422))),Js(e,t,s,i)):t.memoizedState===null?(o=i.fallback,a=t.mode,i=Ql({mode:`visible`,children:i.children},a,0,null),o=Zl(o,a,s,null),o.flags|=2,i.return=t,o.return=t,i.sibling=o,t.child=i,t.mode&1&&Na(t,e.child,null,s),t.child.memoizedState=Gs(s),t.memoizedState=Ws,o):(t.child=e.child,t.flags|=128,null);if(!(t.mode&1))return Js(e,t,s,null);if(a.data===`$!`){if(i=a.nextSibling&&a.nextSibling.dataset,i)var c=i.dgst;return i=c,o=Error(r(419)),i=Cs(o,i,void 0),Js(e,t,s,i)}if(c=(s&e.childLanes)!==0,Ms||c){if(i=Vc,i!==null){switch(s&-s){case 4:a=2;break;case 16:a=8;break;case 64:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:case 4194304:case 8388608:case 16777216:case 33554432:case 67108864:a=32;break;case 536870912:a=268435456;break;default:a=0}a=(a&(i.suspendedLanes|s))===0?a:0,a!==0&&a!==o.retryLane&&(o.retryLane=a,qa(e,a),ml(i,e,a,-1))}return Ol(),i=Cs(Error(r(421))),Js(e,t,s,i)}return a.data===`$?`?(t.flags|=128,t.child=e.child,t=Vl.bind(null,e),a._reactRetry=t,null):(e=o.treeContext,ga=Ei(a.nextSibling),ha=t,_a=!0,va=null,e!==null&&(oa[sa++]=la,oa[sa++]=ua,oa[sa++]=ca,la=e.id,ua=e.overflow,ca=t),t=qs(t,i.children),t.flags|=4096,t)}function Xs(e,t,n){e.lanes|=t;var r=e.alternate;r!==null&&(r.lanes|=t),Va(e.return,t,n)}function Zs(e,t,n,r,i){var a=e.memoizedState;a===null?e.memoizedState={isBackwards:t,rendering:null,renderingStartTime:0,last:r,tail:n,tailMode:i}:(a.isBackwards=t,a.rendering=null,a.renderingStartTime=0,a.last=r,a.tail=n,a.tailMode=i)}function Qs(e,t,n){var r=t.pendingProps,i=r.revealOrder,a=r.tail;if(Ns(e,t,r.children,n),r=po.current,r&2)r=r&1|2,t.flags|=128;else{if(e!==null&&e.flags&128)a:for(e=t.child;e!==null;){if(e.tag===13)e.memoizedState!==null&&Xs(e,n,t);else if(e.tag===19)Xs(e,n,t);else if(e.child!==null){e.child.return=e,e=e.child;continue}if(e===t)break a;for(;e.sibling===null;){if(e.return===null||e.return===t)break a;e=e.return}e.sibling.return=e.return,e=e.sibling}r&=1}if(Z(po,r),!(t.mode&1))t.memoizedState=null;else switch(i){case`forwards`:for(n=t.child,i=null;n!==null;)e=n.alternate,e!==null&&mo(e)===null&&(i=n),n=n.sibling;n=i,n===null?(i=t.child,t.child=null):(i=n.sibling,n.sibling=null),Zs(t,!1,i,n,a);break;case`backwards`:for(n=null,i=t.child,t.child=null;i!==null;){if(e=i.alternate,e!==null&&mo(e)===null){t.child=i;break}e=i.sibling,i.sibling=n,n=i,i=e}Zs(t,!0,n,null,a);break;case`together`:Zs(t,!1,null,null,void 0);break;default:t.memoizedState=null}return t.child}function $s(e,t){!(t.mode&1)&&e!==null&&(e.alternate=null,t.alternate=null,t.flags|=2)}function ec(e,t,n){if(e!==null&&(t.dependencies=e.dependencies),Jc|=t.lanes,(n&t.childLanes)===0)return null;if(e!==null&&t.child!==e.child)throw Error(r(153));if(t.child!==null){for(e=t.child,n=Yl(e,e.pendingProps),t.child=n,n.return=t;e.sibling!==null;)e=e.sibling,n=n.sibling=Yl(e,e.pendingProps),n.return=t;n.sibling=null}return t.child}function tc(e,t,n){switch(t.tag){case 3:Hs(t),Ea();break;case 5:uo(t);break;case 1:Wi(t.type)&&Ji(t);break;case 4:co(t,t.stateNode.containerInfo);break;case 10:var r=t.type._context,i=t.memoizedProps.value;Z(Fa,r._currentValue),r._currentValue=i;break;case 13:if(r=t.memoizedState,r!==null)return r.dehydrated===null?(n&t.child.childLanes)===0?(Z(po,po.current&1),e=ec(e,t,n),e===null?null:e.sibling):Ks(e,t,n):(Z(po,po.current&1),t.flags|=128,null);Z(po,po.current&1);break;case 19:if(r=(n&t.childLanes)!==0,e.flags&128){if(r)return Qs(e,t,n);t.flags|=128}if(i=t.memoizedState,i!==null&&(i.rendering=null,i.tail=null,i.lastEffect=null),Z(po,po.current),r)break;return null;case 22:case 23:return t.lanes=0,Ls(e,t,n)}return ec(e,t,n)}var nc=function(e,t){for(var n=t.child;n!==null;){if(n.tag===5||n.tag===6)e.appendChild(n.stateNode);else if(n.tag!==4&&n.child!==null){n.child.return=n,n=n.child;continue}if(n===t)break;for(;n.sibling===null;){if(n.return===null||n.return===t)return;n=n.return}n.sibling.return=n.return,n=n.sibling}},rc=function(e,t,n,r){var i=e.memoizedProps;if(i!==r){e=t.stateNode,so(io.current);var o=null;switch(n){case`input`:i=pe(e,i),r=pe(e,r),o=[];break;case`select`:i=I({},i,{value:void 0}),r=I({},r,{value:void 0}),o=[];break;case`textarea`:i=xe(e,i),r=xe(e,r),o=[];break;default:typeof i.onClick!=`function`&&typeof r.onClick==`function`&&(e.onclick=K)}Pe(n,r);var s;for(u in n=null,i)if(!r.hasOwnProperty(u)&&i.hasOwnProperty(u)&&i[u]!=null){if(u===`style`){var c=i[u];for(s in c)c.hasOwnProperty(s)&&(n||={},n[s]=``)}else u!==`dangerouslySetInnerHTML`&&u!==`children`&&u!==`suppressContentEditableWarning`&&u!==`suppressHydrationWarning`&&u!==`autoFocus`&&(a.hasOwnProperty(u)?o||=[]:(o||=[]).push(u,null))}for(u in r){var l=r[u];if(c=i?.[u],r.hasOwnProperty(u)&&l!==c&&(l!=null||c!=null)){if(u===`style`){if(c){for(s in c)!c.hasOwnProperty(s)||l&&l.hasOwnProperty(s)||(n||={},n[s]=``);for(s in l)l.hasOwnProperty(s)&&c[s]!==l[s]&&(n||={},n[s]=l[s])}else n||(o||=[],o.push(u,n)),n=l}else u===`dangerouslySetInnerHTML`?(l=l?l.__html:void 0,c=c?c.__html:void 0,l!=null&&c!==l&&(o||=[]).push(u,l)):u===`children`?typeof l!=`string`&&typeof l!=`number`||(o||=[]).push(u,``+l):u!==`suppressContentEditableWarning`&&u!==`suppressHydrationWarning`&&(a.hasOwnProperty(u)?(l!=null&&u===`onScroll`&&G(`scroll`,e),o||c===l||(o=[])):(o||=[]).push(u,l))}}n&&(o||=[]).push(`style`,n);var u=o;(t.updateQueue=u)&&(t.flags|=4)}},ic=function(e,t,n,r){n!==r&&(t.flags|=4)};function ac(e,t){if(!_a)switch(e.tailMode){case`hidden`:t=e.tail;for(var n=null;t!==null;)t.alternate!==null&&(n=t),t=t.sibling;n===null?e.tail=null:n.sibling=null;break;case`collapsed`:n=e.tail;for(var r=null;n!==null;)n.alternate!==null&&(r=n),n=n.sibling;r===null?t||e.tail===null?e.tail=null:e.tail.sibling=null:r.sibling=null}}function oc(e){var t=e.alternate!==null&&e.alternate.child===e.child,n=0,r=0;if(t)for(var i=e.child;i!==null;)n|=i.lanes|i.childLanes,r|=i.subtreeFlags&14680064,r|=i.flags&14680064,i.return=e,i=i.sibling;else for(i=e.child;i!==null;)n|=i.lanes|i.childLanes,r|=i.subtreeFlags,r|=i.flags,i.return=e,i=i.sibling;return e.subtreeFlags|=r,e.childLanes=n,t}function sc(e,t,n){var i=t.pendingProps;switch(ma(t),t.tag){case 2:case 16:case 15:case 0:case 11:case 7:case 8:case 12:case 9:case 14:return oc(t),null;case 1:return Wi(t.type)&&Gi(),oc(t),null;case 3:return i=t.stateNode,lo(),X(Vi),X(Bi),go(),i.pendingContext&&(i.context=i.pendingContext,i.pendingContext=null),(e===null||e.child===null)&&(wa(t)?t.flags|=4:e===null||e.memoizedState.isDehydrated&&!(t.flags&256)||(t.flags|=1024,va!==null&&(vl(va),va=null))),oc(t),null;case 5:fo(t);var o=so(oo.current);if(n=t.type,e!==null&&t.stateNode!=null)rc(e,t,n,i,o),e.ref!==t.ref&&(t.flags|=512,t.flags|=2097152);else{if(!i){if(t.stateNode===null)throw Error(r(166));return oc(t),null}if(e=so(io.current),wa(t)){i=t.stateNode,n=t.type;var s=t.memoizedProps;switch(i[J]=t,i[Oi]=s,e=!!(t.mode&1),n){case`dialog`:G(`cancel`,i),G(`close`,i);break;case`iframe`:case`object`:case`embed`:G(`load`,i);break;case`video`:case`audio`:for(o=0;o<ei.length;o++)G(ei[o],i);break;case`source`:G(`error`,i);break;case`img`:case`image`:case`link`:G(`error`,i),G(`load`,i);break;case`details`:G(`toggle`,i);break;case`input`:me(i,s),G(`invalid`,i);break;case`select`:i._wrapperState={wasMultiple:!!s.multiple},G(`invalid`,i);break;case`textarea`:Se(i,s),G(`invalid`,i)}for(var c in Pe(n,s),o=null,s)if(s.hasOwnProperty(c)){var l=s[c];c===`children`?typeof l==`string`?i.textContent!==l&&(!0!==s.suppressHydrationWarning&&gi(i.textContent,l,e),o=[`children`,l]):typeof l==`number`&&i.textContent!==``+l&&(!0!==s.suppressHydrationWarning&&gi(i.textContent,l,e),o=[`children`,``+l]):a.hasOwnProperty(c)&&l!=null&&c===`onScroll`&&G(`scroll`,i)}switch(n){case`input`:ue(i),_e(i,s,!0);break;case`textarea`:ue(i),we(i);break;case`select`:case`option`:break;default:typeof s.onClick==`function`&&(i.onclick=K)}i=o,t.updateQueue=i,i!==null&&(t.flags|=4)}else{c=o.nodeType===9?o:o.ownerDocument,e===`http://www.w3.org/1999/xhtml`&&(e=Te(n)),e===`http://www.w3.org/1999/xhtml`?n===`script`?(e=c.createElement(`div`),e.innerHTML=`<script><\/script>`,e=e.removeChild(e.firstChild)):typeof i.is==`string`?e=c.createElement(n,{is:i.is}):(e=c.createElement(n),n===`select`&&(c=e,i.multiple?c.multiple=!0:i.size&&(c.size=i.size))):e=c.createElementNS(e,n),e[J]=t,e[Oi]=i,nc(e,t,!1,!1),t.stateNode=e;a:{switch(c=Fe(n,i),n){case`dialog`:G(`cancel`,e),G(`close`,e),o=i;break;case`iframe`:case`object`:case`embed`:G(`load`,e),o=i;break;case`video`:case`audio`:for(o=0;o<ei.length;o++)G(ei[o],e);o=i;break;case`source`:G(`error`,e),o=i;break;case`img`:case`image`:case`link`:G(`error`,e),G(`load`,e),o=i;break;case`details`:G(`toggle`,e),o=i;break;case`input`:me(e,i),o=pe(e,i),G(`invalid`,e);break;case`option`:o=i;break;case`select`:e._wrapperState={wasMultiple:!!i.multiple},o=I({},i,{value:void 0}),G(`invalid`,e);break;case`textarea`:Se(e,i),o=xe(e,i),G(`invalid`,e);break;default:o=i}for(s in Pe(n,o),l=o,l)if(l.hasOwnProperty(s)){var u=l[s];s===`style`?Ne(e,u):s===`dangerouslySetInnerHTML`?(u=u?u.__html:void 0,u!=null&&Oe(e,u)):s===`children`?typeof u==`string`?(n!==`textarea`||u!==``)&&ke(e,u):typeof u==`number`&&ke(e,``+u):s!==`suppressContentEditableWarning`&&s!==`suppressHydrationWarning`&&s!==`autoFocus`&&(a.hasOwnProperty(s)?u!=null&&s===`onScroll`&&G(`scroll`,e):u!=null&&x(e,s,u,c))}switch(n){case`input`:ue(e),_e(e,i,!1);break;case`textarea`:ue(e),we(e);break;case`option`:i.value!=null&&e.setAttribute(`value`,``+R(i.value));break;case`select`:e.multiple=!!i.multiple,s=i.value,s==null?i.defaultValue!=null&&be(e,!!i.multiple,i.defaultValue,!0):be(e,!!i.multiple,s,!1);break;default:typeof o.onClick==`function`&&(e.onclick=K)}switch(n){case`button`:case`input`:case`select`:case`textarea`:i=!!i.autoFocus;break a;case`img`:i=!0;break a;default:i=!1}}i&&(t.flags|=4)}t.ref!==null&&(t.flags|=512,t.flags|=2097152)}return oc(t),null;case 6:if(e&&t.stateNode!=null)ic(e,t,e.memoizedProps,i);else{if(typeof i!=`string`&&t.stateNode===null)throw Error(r(166));if(n=so(oo.current),so(io.current),wa(t)){if(i=t.stateNode,n=t.memoizedProps,i[J]=t,(s=i.nodeValue!==n)&&(e=ha,e!==null))switch(e.tag){case 3:gi(i.nodeValue,n,!!(e.mode&1));break;case 5:!0!==e.memoizedProps.suppressHydrationWarning&&gi(i.nodeValue,n,!!(e.mode&1))}s&&(t.flags|=4)}else i=(n.nodeType===9?n:n.ownerDocument).createTextNode(i),i[J]=t,t.stateNode=i}return oc(t),null;case 13:if(X(po),i=t.memoizedState,e===null||e.memoizedState!==null&&e.memoizedState.dehydrated!==null){if(_a&&ga!==null&&t.mode&1&&!(t.flags&128))Ta(),Ea(),t.flags|=98560,s=!1;else if(s=wa(t),i!==null&&i.dehydrated!==null){if(e===null){if(!s)throw Error(r(318));if(s=t.memoizedState,s=s===null?null:s.dehydrated,!s)throw Error(r(317));s[J]=t}else Ea(),!(t.flags&128)&&(t.memoizedState=null),t.flags|=4;oc(t),s=!1}else va!==null&&(vl(va),va=null),s=!0;if(!s)return t.flags&65536?t:null}return t.flags&128?(t.lanes=n,t):(i=i!==null,i!==(e!==null&&e.memoizedState!==null)&&i&&(t.child.flags|=8192,t.mode&1&&(e===null||po.current&1?Kc===0&&(Kc=3):Ol())),t.updateQueue!==null&&(t.flags|=4),oc(t),null);case 4:return lo(),e===null&&oi(t.stateNode.containerInfo),oc(t),null;case 10:return Ba(t.type._context),oc(t),null;case 17:return Wi(t.type)&&Gi(),oc(t),null;case 19:if(X(po),s=t.memoizedState,s===null)return oc(t),null;if(i=!!(t.flags&128),c=s.rendering,c===null){if(i)ac(s,!1);else{if(Kc!==0||e!==null&&e.flags&128)for(e=t.child;e!==null;){if(c=mo(e),c!==null){for(t.flags|=128,ac(s,!1),i=c.updateQueue,i!==null&&(t.updateQueue=i,t.flags|=4),t.subtreeFlags=0,i=n,n=t.child;n!==null;)s=n,e=i,s.flags&=14680066,c=s.alternate,c===null?(s.childLanes=0,s.lanes=e,s.child=null,s.subtreeFlags=0,s.memoizedProps=null,s.memoizedState=null,s.updateQueue=null,s.dependencies=null,s.stateNode=null):(s.childLanes=c.childLanes,s.lanes=c.lanes,s.child=c.child,s.subtreeFlags=0,s.deletions=null,s.memoizedProps=c.memoizedProps,s.memoizedState=c.memoizedState,s.updateQueue=c.updateQueue,s.type=c.type,e=c.dependencies,s.dependencies=e===null?null:{lanes:e.lanes,firstContext:e.firstContext}),n=n.sibling;return Z(po,po.current&1|2),t.child}e=e.sibling}s.tail!==null&&ht()>el&&(t.flags|=128,i=!0,ac(s,!1),t.lanes=4194304)}}else{if(!i){if(e=mo(c),e!==null){if(t.flags|=128,i=!0,n=e.updateQueue,n!==null&&(t.updateQueue=n,t.flags|=4),ac(s,!0),s.tail===null&&s.tailMode===`hidden`&&!c.alternate&&!_a)return oc(t),null}else 2*ht()-s.renderingStartTime>el&&n!==1073741824&&(t.flags|=128,i=!0,ac(s,!1),t.lanes=4194304)}s.isBackwards?(c.sibling=t.child,t.child=c):(n=s.last,n===null?t.child=c:n.sibling=c,s.last=c)}return s.tail===null?(oc(t),null):(t=s.tail,s.rendering=t,s.tail=t.sibling,s.renderingStartTime=ht(),t.sibling=null,n=po.current,Z(po,i?n&1|2:n&1),t);case 22:case 23:return wl(),i=t.memoizedState!==null,e!==null&&e.memoizedState!==null!==i&&(t.flags|=8192),i&&t.mode&1?Wc&1073741824&&(oc(t),t.subtreeFlags&6&&(t.flags|=8192)):oc(t),null;case 24:return null;case 25:return null}throw Error(r(156,t.tag))}function cc(e,t){switch(ma(t),t.tag){case 1:return Wi(t.type)&&Gi(),e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 3:return lo(),X(Vi),X(Bi),go(),e=t.flags,e&65536&&!(e&128)?(t.flags=e&-65537|128,t):null;case 5:return fo(t),null;case 13:if(X(po),e=t.memoizedState,e!==null&&e.dehydrated!==null){if(t.alternate===null)throw Error(r(340));Ea()}return e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 19:return X(po),null;case 4:return lo(),null;case 10:return Ba(t.type._context),null;case 22:case 23:return wl(),null;case 24:return null;default:return null}}var lc=!1,uc=!1,dc=typeof WeakSet==`function`?WeakSet:Set,Q=null;function fc(e,t){var n=e.ref;if(n!==null){if(typeof n==`function`)try{n(null)}catch(n){Rl(e,t,n)}else n.current=null}}function pc(e,t,n){try{n()}catch(n){Rl(e,t,n)}}var mc=!1;function hc(e,t){if(_i=fn,e=jr(),Mr(e)){if(`selectionStart`in e)var n={start:e.selectionStart,end:e.selectionEnd};else a:{n=(n=e.ownerDocument)&&n.defaultView||window;var i=n.getSelection&&n.getSelection();if(i&&i.rangeCount!==0){n=i.anchorNode;var a=i.anchorOffset,o=i.focusNode;i=i.focusOffset;try{n.nodeType,o.nodeType}catch{n=null;break a}var s=0,c=-1,l=-1,u=0,d=0,f=e,p=null;b:for(;;){for(var m;f!==n||a!==0&&f.nodeType!==3||(c=s+a),f!==o||i!==0&&f.nodeType!==3||(l=s+i),f.nodeType===3&&(s+=f.nodeValue.length),(m=f.firstChild)!==null;)p=f,f=m;for(;;){if(f===e)break b;if(p===n&&++u===a&&(c=s),p===o&&++d===i&&(l=s),(m=f.nextSibling)!==null)break;f=p,p=f.parentNode}f=m}n=c===-1||l===-1?null:{start:c,end:l}}else n=null}n||={start:0,end:0}}else n=null;for(vi={focusedElem:e,selectionRange:n},fn=!1,Q=t;Q!==null;)if(t=Q,e=t.child,t.subtreeFlags&1028&&e!==null)e.return=t,Q=e;else for(;Q!==null;){t=Q;try{var h=t.alternate;if(t.flags&1024)switch(t.tag){case 0:case 11:case 15:break;case 1:if(h!==null){var g=h.memoizedProps,_=h.memoizedState,v=t.stateNode;v.__reactInternalSnapshotBeforeUpdate=v.getSnapshotBeforeUpdate(t.elementType===t.type?g:hs(t.type,g),_)}break;case 3:var y=t.stateNode.containerInfo;y.nodeType===1?y.textContent=``:y.nodeType===9&&y.documentElement&&y.removeChild(y.documentElement);break;case 5:case 6:case 4:case 17:break;default:throw Error(r(163))}}catch(e){Rl(t,t.return,e)}if(e=t.sibling,e!==null){e.return=t.return,Q=e;break}Q=t.return}return h=mc,mc=!1,h}function gc(e,t,n){var r=t.updateQueue;if(r=r===null?null:r.lastEffect,r!==null){var i=r=r.next;do{if((i.tag&e)===e){var a=i.destroy;i.destroy=void 0,a!==void 0&&pc(t,n,a)}i=i.next}while(i!==r)}}function _c(e,t){if(t=t.updateQueue,t=t===null?null:t.lastEffect,t!==null){var n=t=t.next;do{if((n.tag&e)===e){var r=n.create;n.destroy=r()}n=n.next}while(n!==t)}}function vc(e){var t=e.ref;if(t!==null){var n=e.stateNode;switch(e.tag){case 5:e=n;break;default:e=n}typeof t==`function`?t(e):t.current=e}}function yc(e){var t=e.alternate;t!==null&&(e.alternate=null,yc(t)),e.child=null,e.deletions=null,e.sibling=null,e.tag===5&&(t=e.stateNode,t!==null&&(delete t[J],delete t[Oi],delete t[ki],delete t[Ai],delete t[ji])),e.stateNode=null,e.return=null,e.dependencies=null,e.memoizedProps=null,e.memoizedState=null,e.pendingProps=null,e.stateNode=null,e.updateQueue=null}function bc(e){return e.tag===5||e.tag===3||e.tag===4}function xc(e){a:for(;;){for(;e.sibling===null;){if(e.return===null||bc(e.return))return null;e=e.return}for(e.sibling.return=e.return,e=e.sibling;e.tag!==5&&e.tag!==6&&e.tag!==18;){if(e.flags&2||e.child===null||e.tag===4)continue a;e.child.return=e,e=e.child}if(!(e.flags&2))return e.stateNode}}function Sc(e,t,n){var r=e.tag;if(r===5||r===6)e=e.stateNode,t?n.nodeType===8?n.parentNode.insertBefore(e,t):n.insertBefore(e,t):(n.nodeType===8?(t=n.parentNode,t.insertBefore(e,n)):(t=n,t.appendChild(e)),n=n._reactRootContainer,n!=null||t.onclick!==null||(t.onclick=K));else if(r!==4&&(e=e.child,e!==null))for(Sc(e,t,n),e=e.sibling;e!==null;)Sc(e,t,n),e=e.sibling}function Cc(e,t,n){var r=e.tag;if(r===5||r===6)e=e.stateNode,t?n.insertBefore(e,t):n.appendChild(e);else if(r!==4&&(e=e.child,e!==null))for(Cc(e,t,n),e=e.sibling;e!==null;)Cc(e,t,n),e=e.sibling}var wc=null,Tc=!1;function Ec(e,t,n){for(n=n.child;n!==null;)Dc(e,t,n),n=n.sibling}function Dc(e,t,n){if(Ct&&typeof Ct.onCommitFiberUnmount==`function`)try{Ct.onCommitFiberUnmount(St,n)}catch{}switch(n.tag){case 5:uc||fc(n,t);case 6:var r=wc,i=Tc;wc=null,Ec(e,t,n),wc=r,Tc=i,wc!==null&&(Tc?(e=wc,n=n.stateNode,e.nodeType===8?e.parentNode.removeChild(n):e.removeChild(n)):wc.removeChild(n.stateNode));break;case 18:wc!==null&&(Tc?(e=wc,n=n.stateNode,e.nodeType===8?Ti(e.parentNode,n):e.nodeType===1&&Ti(e,n),un(e)):Ti(wc,n.stateNode));break;case 4:r=wc,i=Tc,wc=n.stateNode.containerInfo,Tc=!0,Ec(e,t,n),wc=r,Tc=i;break;case 0:case 11:case 14:case 15:if(!uc&&(r=n.updateQueue,r!==null&&(r=r.lastEffect,r!==null))){i=r=r.next;do{var a=i,o=a.destroy;a=a.tag,o!==void 0&&(a&2||a&4)&&pc(n,t,o),i=i.next}while(i!==r)}Ec(e,t,n);break;case 1:if(!uc&&(fc(n,t),r=n.stateNode,typeof r.componentWillUnmount==`function`))try{r.props=n.memoizedProps,r.state=n.memoizedState,r.componentWillUnmount()}catch(e){Rl(n,t,e)}Ec(e,t,n);break;case 21:Ec(e,t,n);break;case 22:n.mode&1?(uc=(r=uc)||n.memoizedState!==null,Ec(e,t,n),uc=r):Ec(e,t,n);break;default:Ec(e,t,n)}}function Oc(e){var t=e.updateQueue;if(t!==null){e.updateQueue=null;var n=e.stateNode;n===null&&(n=e.stateNode=new dc),t.forEach(function(t){var r=Hl.bind(null,e,t);n.has(t)||(n.add(t),t.then(r,r))})}}function kc(e,t){var n=t.deletions;if(n!==null)for(var i=0;i<n.length;i++){var a=n[i];try{var o=e,s=t,c=s;a:for(;c!==null;){switch(c.tag){case 5:wc=c.stateNode,Tc=!1;break a;case 3:wc=c.stateNode.containerInfo,Tc=!0;break a;case 4:wc=c.stateNode.containerInfo,Tc=!0;break a}c=c.return}if(wc===null)throw Error(r(160));Dc(o,s,a),wc=null,Tc=!1;var l=a.alternate;l!==null&&(l.return=null),a.return=null}catch(e){Rl(a,t,e)}}if(t.subtreeFlags&12854)for(t=t.child;t!==null;)Ac(t,e),t=t.sibling}function Ac(e,t){var n=e.alternate,i=e.flags;switch(e.tag){case 0:case 11:case 14:case 15:if(kc(t,e),jc(e),i&4){try{gc(3,e,e.return),_c(3,e)}catch(t){Rl(e,e.return,t)}try{gc(5,e,e.return)}catch(t){Rl(e,e.return,t)}}break;case 1:kc(t,e),jc(e),i&512&&n!==null&&fc(n,n.return);break;case 5:if(kc(t,e),jc(e),i&512&&n!==null&&fc(n,n.return),e.flags&32){var a=e.stateNode;try{ke(a,``)}catch(t){Rl(e,e.return,t)}}if(i&4&&(a=e.stateNode,a!=null)){var o=e.memoizedProps,s=n===null?o:n.memoizedProps,c=e.type,l=e.updateQueue;if(e.updateQueue=null,l!==null)try{c===`input`&&o.type===`radio`&&o.name!=null&&he(a,o),Fe(c,s);var u=Fe(c,o);for(s=0;s<l.length;s+=2){var d=l[s],f=l[s+1];d===`style`?Ne(a,f):d===`dangerouslySetInnerHTML`?Oe(a,f):d===`children`?ke(a,f):x(a,d,f,u)}switch(c){case`input`:ge(a,o);break;case`textarea`:Ce(a,o);break;case`select`:var p=a._wrapperState.wasMultiple;a._wrapperState.wasMultiple=!!o.multiple;var m=o.value;m==null?p!==!!o.multiple&&(o.defaultValue==null?be(a,!!o.multiple,o.multiple?[]:``,!1):be(a,!!o.multiple,o.defaultValue,!0)):be(a,!!o.multiple,m,!1)}a[Oi]=o}catch(t){Rl(e,e.return,t)}}break;case 6:if(kc(t,e),jc(e),i&4){if(e.stateNode===null)throw Error(r(162));a=e.stateNode,o=e.memoizedProps;try{a.nodeValue=o}catch(t){Rl(e,e.return,t)}}break;case 3:if(kc(t,e),jc(e),i&4&&n!==null&&n.memoizedState.isDehydrated)try{un(t.containerInfo)}catch(t){Rl(e,e.return,t)}break;case 4:kc(t,e),jc(e);break;case 13:kc(t,e),jc(e),a=e.child,a.flags&8192&&(o=a.memoizedState!==null,a.stateNode.isHidden=o,!o||a.alternate!==null&&a.alternate.memoizedState!==null||($c=ht())),i&4&&Oc(e);break;case 22:if(d=n!==null&&n.memoizedState!==null,e.mode&1?(uc=(u=uc)||d,kc(t,e),uc=u):kc(t,e),jc(e),i&8192){if(u=e.memoizedState!==null,(e.stateNode.isHidden=u)&&!d&&e.mode&1)for(Q=e,d=e.child;d!==null;){for(f=Q=d;Q!==null;){switch(p=Q,m=p.child,p.tag){case 0:case 11:case 14:case 15:gc(4,p,p.return);break;case 1:fc(p,p.return);var h=p.stateNode;if(typeof h.componentWillUnmount==`function`){i=p,n=p.return;try{t=i,h.props=t.memoizedProps,h.state=t.memoizedState,h.componentWillUnmount()}catch(e){Rl(i,n,e)}}break;case 5:fc(p,p.return);break;case 22:if(p.memoizedState!==null){Fc(f);continue}}m===null?Fc(f):(m.return=p,Q=m)}d=d.sibling}a:for(d=null,f=e;;){if(f.tag===5){if(d===null){d=f;try{a=f.stateNode,u?(o=a.style,typeof o.setProperty==`function`?o.setProperty(`display`,`none`,`important`):o.display=`none`):(c=f.stateNode,l=f.memoizedProps.style,s=l!=null&&l.hasOwnProperty(`display`)?l.display:null,c.style.display=Me(`display`,s))}catch(t){Rl(e,e.return,t)}}}else if(f.tag===6){if(d===null)try{f.stateNode.nodeValue=u?``:f.memoizedProps}catch(t){Rl(e,e.return,t)}}else if((f.tag!==22&&f.tag!==23||f.memoizedState===null||f===e)&&f.child!==null){f.child.return=f,f=f.child;continue}if(f===e)break a;for(;f.sibling===null;){if(f.return===null||f.return===e)break a;d===f&&(d=null),f=f.return}d===f&&(d=null),f.sibling.return=f.return,f=f.sibling}}break;case 19:kc(t,e),jc(e),i&4&&Oc(e);break;case 21:break;default:kc(t,e),jc(e)}}function jc(e){var t=e.flags;if(t&2){try{a:{for(var n=e.return;n!==null;){if(bc(n)){var i=n;break a}n=n.return}throw Error(r(160))}switch(i.tag){case 5:var a=i.stateNode;i.flags&32&&(ke(a,``),i.flags&=-33),Cc(e,xc(e),a);break;case 3:case 4:var o=i.stateNode.containerInfo;Sc(e,xc(e),o);break;default:throw Error(r(161))}}catch(t){Rl(e,e.return,t)}e.flags&=-3}t&4096&&(e.flags&=-4097)}function Mc(e,t,n){Q=e,Nc(e,t,n)}function Nc(e,t,n){for(var r=!!(e.mode&1);Q!==null;){var i=Q,a=i.child;if(i.tag===22&&r){var o=i.memoizedState!==null||lc;if(!o){var s=i.alternate,c=s!==null&&s.memoizedState!==null||uc;s=lc;var l=uc;if(lc=o,(uc=c)&&!l)for(Q=i;Q!==null;)o=Q,c=o.child,o.tag===22&&o.memoizedState!==null||c===null?Ic(i):(c.return=o,Q=c);for(;a!==null;)Q=a,Nc(a,t,n),a=a.sibling;Q=i,lc=s,uc=l}Pc(e,t,n)}else i.subtreeFlags&8772&&a!==null?(a.return=i,Q=a):Pc(e,t,n)}}function Pc(e){for(;Q!==null;){var t=Q;if(t.flags&8772){var n=t.alternate;try{if(t.flags&8772)switch(t.tag){case 0:case 11:case 15:uc||_c(5,t);break;case 1:var i=t.stateNode;if(t.flags&4&&!uc){if(n===null)i.componentDidMount();else{var a=t.elementType===t.type?n.memoizedProps:hs(t.type,n.memoizedProps);i.componentDidUpdate(a,n.memoizedState,i.__reactInternalSnapshotBeforeUpdate)}}var o=t.updateQueue;o!==null&&no(t,o,i);break;case 3:var s=t.updateQueue;if(s!==null){if(n=null,t.child!==null)switch(t.child.tag){case 5:n=t.child.stateNode;break;case 1:n=t.child.stateNode}no(t,s,n)}break;case 5:var c=t.stateNode;if(n===null&&t.flags&4){n=c;var l=t.memoizedProps;switch(t.type){case`button`:case`input`:case`select`:case`textarea`:l.autoFocus&&n.focus();break;case`img`:l.src&&(n.src=l.src)}}break;case 6:break;case 4:break;case 12:break;case 13:if(t.memoizedState===null){var u=t.alternate;if(u!==null){var d=u.memoizedState;if(d!==null){var f=d.dehydrated;f!==null&&un(f)}}}break;case 19:case 17:case 21:case 22:case 23:case 25:break;default:throw Error(r(163))}uc||t.flags&512&&vc(t)}catch(e){Rl(t,t.return,e)}}if(t===e){Q=null;break}if(n=t.sibling,n!==null){n.return=t.return,Q=n;break}Q=t.return}}function Fc(e){for(;Q!==null;){var t=Q;if(t===e){Q=null;break}var n=t.sibling;if(n!==null){n.return=t.return,Q=n;break}Q=t.return}}function Ic(e){for(;Q!==null;){var t=Q;try{switch(t.tag){case 0:case 11:case 15:var n=t.return;try{_c(4,t)}catch(e){Rl(t,n,e)}break;case 1:var r=t.stateNode;if(typeof r.componentDidMount==`function`){var i=t.return;try{r.componentDidMount()}catch(e){Rl(t,i,e)}}var a=t.return;try{vc(t)}catch(e){Rl(t,a,e)}break;case 5:var o=t.return;try{vc(t)}catch(e){Rl(t,o,e)}}}catch(e){Rl(t,t.return,e)}if(t===e){Q=null;break}var s=t.sibling;if(s!==null){s.return=t.return,Q=s;break}Q=t.return}}var Lc=Math.ceil,Rc=S.ReactCurrentDispatcher,zc=S.ReactCurrentOwner,Bc=S.ReactCurrentBatchConfig,$=0,Vc=null,Hc=null,Uc=0,Wc=0,Gc=Ri(0),Kc=0,qc=null,Jc=0,Yc=0,Xc=0,Zc=null,Qc=null,$c=0,el=1/0,tl=null,nl=!1,rl=null,il=null,al=!1,ol=null,sl=0,cl=0,ll=null,ul=-1,dl=0;function fl(){return $&6?ht():ul===-1?ul=ht():ul}function pl(e){return e.mode&1?$&2&&Uc!==0?Uc&-Uc:Oa.transition===null?(e=B,e===0?(e=window.event,e=e===void 0?16:vn(e.type),e):e):(dl===0&&(dl=It()),dl):1}function ml(e,t,n,i){if(50<cl)throw cl=0,ll=null,Error(r(185));Rt(e,n,i),(!($&2)||e!==Vc)&&(e===Vc&&(!($&2)&&(Yc|=n),Kc===4&&bl(e,Uc)),hl(e,i),n===1&&$===0&&!(t.mode&1)&&(el=ht()+500,Zi&&ta()))}function hl(e,t){var n=e.callbackNode;Pt(e,t);var r=Mt(e,e===Vc?Uc:0);if(r===0)n!==null&&ft(n),e.callbackNode=null,e.callbackPriority=0;else if(t=r&-r,e.callbackPriority!==t){if(n!=null&&ft(n),t===1)e.tag===0?ea(xl.bind(null,e)):$i(xl.bind(null,e)),Ci(function(){!($&6)&&ta()}),n=null;else{switch(Vt(r)){case 1:n=_t;break;case 4:n=vt;break;case 16:n=yt;break;case 536870912:n=xt;break;default:n=yt}n=Wl(n,gl.bind(null,e))}e.callbackPriority=t,e.callbackNode=n}}function gl(e,t){if(ul=-1,dl=0,$&6)throw Error(r(327));var n=e.callbackNode;if(Il()&&e.callbackNode!==n)return null;var i=Mt(e,e===Vc?Uc:0);if(i===0)return null;if(i&30||(i&e.expiredLanes)!==0||t)t=kl(e,i);else{t=i;var a=$;$|=2;var o=Dl();(Vc!==e||Uc!==t)&&(tl=null,el=ht()+500,Tl(e,t));do try{jl();break}catch(t){El(e,t)}while(1);za(),Rc.current=o,$=a,Hc===null?(Vc=null,Uc=0,t=Kc):t=0}if(t!==0){if(t===2&&(a=Ft(e),a!==0&&(i=a,t=_l(e,a))),t===1)throw n=qc,Tl(e,0),bl(e,i),hl(e,ht()),n;if(t===6)bl(e,i);else{if(a=e.current.alternate,!(i&30)&&!yl(a)&&(t=kl(e,i),t===2&&(o=Ft(e),o!==0&&(i=o,t=_l(e,o))),t===1))throw n=qc,Tl(e,0),bl(e,i),hl(e,ht()),n;switch(e.finishedWork=a,e.finishedLanes=i,t){case 0:case 1:throw Error(r(345));case 2:Pl(e,Qc,tl);break;case 3:if(bl(e,i),(i&130023424)===i&&(t=$c+500-ht(),10<t)){if(Mt(e,0)!==0)break;if(a=e.suspendedLanes,(a&i)!==i){fl(),e.pingedLanes|=e.suspendedLanes&a;break}e.timeoutHandle=bi(Pl.bind(null,e,Qc,tl),t);break}Pl(e,Qc,tl);break;case 4:if(bl(e,i),(i&4194240)===i)break;for(t=e.eventTimes,a=-1;0<i;){var s=31-Tt(i);o=1<<s,s=t[s],s>a&&(a=s),i&=~o}if(i=a,i=ht()-i,i=(120>i?120:480>i?480:1080>i?1080:1920>i?1920:3e3>i?3e3:4320>i?4320:1960*Lc(i/1960))-i,10<i){e.timeoutHandle=bi(Pl.bind(null,e,Qc,tl),i);break}Pl(e,Qc,tl);break;case 5:Pl(e,Qc,tl);break;default:throw Error(r(329))}}}return hl(e,ht()),e.callbackNode===n?gl.bind(null,e):null}function _l(e,t){var n=Zc;return e.current.memoizedState.isDehydrated&&(Tl(e,t).flags|=256),e=kl(e,t),e!==2&&(t=Qc,Qc=n,t!==null&&vl(t)),e}function vl(e){Qc===null?Qc=e:Qc.push.apply(Qc,e)}function yl(e){for(var t=e;;){if(t.flags&16384){var n=t.updateQueue;if(n!==null&&(n=n.stores,n!==null))for(var r=0;r<n.length;r++){var i=n[r],a=i.getSnapshot;i=i.value;try{if(!U(a(),i))return!1}catch{return!1}}}if(n=t.child,t.subtreeFlags&16384&&n!==null)n.return=t,t=n;else{if(t===e)break;for(;t.sibling===null;){if(t.return===null||t.return===e)return!0;t=t.return}t.sibling.return=t.return,t=t.sibling}}return!0}function bl(e,t){for(t&=~Xc,t&=~Yc,e.suspendedLanes|=t,e.pingedLanes&=~t,e=e.expirationTimes;0<t;){var n=31-Tt(t),r=1<<n;e[n]=-1,t&=~r}}function xl(e){if($&6)throw Error(r(327));Il();var t=Mt(e,0);if(!(t&1))return hl(e,ht()),null;var n=kl(e,t);if(e.tag!==0&&n===2){var i=Ft(e);i!==0&&(t=i,n=_l(e,i))}if(n===1)throw n=qc,Tl(e,0),bl(e,t),hl(e,ht()),n;if(n===6)throw Error(r(345));return e.finishedWork=e.current.alternate,e.finishedLanes=t,Pl(e,Qc,tl),hl(e,ht()),null}function Sl(e,t){var n=$;$|=1;try{return e(t)}finally{$=n,$===0&&(el=ht()+500,Zi&&ta())}}function Cl(e){ol!==null&&ol.tag===0&&!($&6)&&Il();var t=$;$|=1;var n=Bc.transition,r=B;try{if(Bc.transition=null,B=1,e)return e()}finally{B=r,Bc.transition=n,$=t,!($&6)&&ta()}}function wl(){Wc=Gc.current,X(Gc)}function Tl(e,t){e.finishedWork=null,e.finishedLanes=0;var n=e.timeoutHandle;if(n!==-1&&(e.timeoutHandle=-1,xi(n)),Hc!==null)for(n=Hc.return;n!==null;){var r=n;switch(ma(r),r.tag){case 1:r=r.type.childContextTypes,r!=null&&Gi();break;case 3:lo(),X(Vi),X(Bi),go();break;case 5:fo(r);break;case 4:lo();break;case 13:X(po);break;case 19:X(po);break;case 10:Ba(r.type._context);break;case 22:case 23:wl()}n=n.return}if(Vc=e,Hc=e=Yl(e.current,null),Uc=Wc=t,Kc=0,qc=null,Xc=Yc=Jc=0,Qc=Zc=null,Wa!==null){for(t=0;t<Wa.length;t++)if(n=Wa[t],r=n.interleaved,r!==null){n.interleaved=null;var i=r.next,a=n.pending;if(a!==null){var o=a.next;a.next=i,r.next=o}n.pending=r}Wa=null}return e}function El(e,t){do{var n=Hc;try{if(za(),_o.current=ds,Co){for(var i=bo.memoizedState;i!==null;){var a=i.queue;a!==null&&(a.pending=null),i=i.next}Co=!1}if(yo=0,So=xo=bo=null,wo=!1,To=0,zc.current=null,n===null||n.return===null){Kc=1,qc=t,Hc=null;break}a:{var o=e,s=n.return,c=n,l=t;if(t=Uc,c.flags|=32768,typeof l==`object`&&l&&typeof l.then==`function`){var u=l,d=c,f=d.tag;if(!(d.mode&1)&&(f===0||f===11||f===15)){var p=d.alternate;p?(d.updateQueue=p.updateQueue,d.memoizedState=p.memoizedState,d.lanes=p.lanes):(d.updateQueue=null,d.memoizedState=null)}var m=ks(s);if(m!==null){m.flags&=-257,As(m,s,c,o,t),m.mode&1&&Os(o,u,t),t=m,l=u;var h=t.updateQueue;if(h===null){var g=new Set;g.add(l),t.updateQueue=g}else h.add(l);break a}if(!(t&1)){Os(o,u,t),Ol();break a}l=Error(r(426))}else if(_a&&c.mode&1){var _=ks(s);if(_!==null){!(_.flags&65536)&&(_.flags|=256),As(_,s,c,o,t),Da(Ss(l,c));break a}}o=l=Ss(l,c),Kc!==4&&(Kc=2),Zc===null?Zc=[o]:Zc.push(o),o=s;do{switch(o.tag){case 3:o.flags|=65536,t&=-t,o.lanes|=t;var v=Es(o,l,t);eo(o,v);break a;case 1:c=l;var y=o.type,b=o.stateNode;if(!(o.flags&128)&&(typeof y.getDerivedStateFromError==`function`||b!==null&&typeof b.componentDidCatch==`function`&&(il===null||!il.has(b)))){o.flags|=65536,t&=-t,o.lanes|=t;var x=Ds(o,c,t);eo(o,x);break a}}o=o.return}while(o!==null)}Nl(n)}catch(e){t=e,Hc===n&&n!==null&&(Hc=n=n.return);continue}break}while(1)}function Dl(){var e=Rc.current;return Rc.current=ds,e===null?ds:e}function Ol(){(Kc===0||Kc===3||Kc===2)&&(Kc=4),Vc===null||!(Jc&268435455)&&!(Yc&268435455)||bl(Vc,Uc)}function kl(e,t){var n=$;$|=2;var i=Dl();(Vc!==e||Uc!==t)&&(tl=null,Tl(e,t));do try{Al();break}catch(t){El(e,t)}while(1);if(za(),$=n,Rc.current=i,Hc!==null)throw Error(r(261));return Vc=null,Uc=0,Kc}function Al(){for(;Hc!==null;)Ml(Hc)}function jl(){for(;Hc!==null&&!pt();)Ml(Hc)}function Ml(e){var t=Ul(e.alternate,e,Wc);e.memoizedProps=e.pendingProps,t===null?Nl(e):Hc=t,zc.current=null}function Nl(e){var t=e;do{var n=t.alternate;if(e=t.return,t.flags&32768){if(n=cc(n,t),n!==null){n.flags&=32767,Hc=n;return}if(e!==null)e.flags|=32768,e.subtreeFlags=0,e.deletions=null;else{Kc=6,Hc=null;return}}else if(n=sc(n,t,Wc),n!==null){Hc=n;return}if(t=t.sibling,t!==null){Hc=t;return}Hc=t=e}while(t!==null);Kc===0&&(Kc=5)}function Pl(e,t,n){var r=B,i=Bc.transition;try{Bc.transition=null,B=1,Fl(e,t,n,r)}finally{Bc.transition=i,B=r}return null}function Fl(e,t,n,i){do Il();while(ol!==null);if($&6)throw Error(r(327));n=e.finishedWork;var a=e.finishedLanes;if(n===null)return null;if(e.finishedWork=null,e.finishedLanes=0,n===e.current)throw Error(r(177));e.callbackNode=null,e.callbackPriority=0;var o=n.lanes|n.childLanes;if(zt(e,o),e===Vc&&(Hc=Vc=null,Uc=0),!(n.subtreeFlags&2064)&&!(n.flags&2064)||al||(al=!0,Wl(yt,function(){return Il(),null})),o=!!(n.flags&15990),n.subtreeFlags&15990||o){o=Bc.transition,Bc.transition=null;var s=B;B=1;var c=$;$|=4,zc.current=null,hc(e,n),Ac(n,e),Nr(vi),fn=!!_i,vi=_i=null,e.current=n,Mc(n,e,a),mt(),$=c,B=s,Bc.transition=o}else e.current=n;if(al&&(al=!1,ol=e,sl=a),o=e.pendingLanes,o===0&&(il=null),wt(n.stateNode,i),hl(e,ht()),t!==null)for(i=e.onRecoverableError,n=0;n<t.length;n++)a=t[n],i(a.value,{componentStack:a.stack,digest:a.digest});if(nl)throw nl=!1,e=rl,rl=null,e;return sl&1&&e.tag!==0&&Il(),o=e.pendingLanes,o&1?e===ll?cl++:(cl=0,ll=e):cl=0,ta(),null}function Il(){if(ol!==null){var e=Vt(sl),t=Bc.transition,n=B;try{if(Bc.transition=null,B=16>e?16:e,ol===null)var i=!1;else{if(e=ol,ol=null,sl=0,$&6)throw Error(r(331));var a=$;for($|=4,Q=e.current;Q!==null;){var o=Q,s=o.child;if(Q.flags&16){var c=o.deletions;if(c!==null){for(var l=0;l<c.length;l++){var u=c[l];for(Q=u;Q!==null;){var d=Q;switch(d.tag){case 0:case 11:case 15:gc(8,d,o)}var f=d.child;if(f!==null)f.return=d,Q=f;else for(;Q!==null;){d=Q;var p=d.sibling,m=d.return;if(yc(d),d===u){Q=null;break}if(p!==null){p.return=m,Q=p;break}Q=m}}}var h=o.alternate;if(h!==null){var g=h.child;if(g!==null){h.child=null;do{var _=g.sibling;g.sibling=null,g=_}while(g!==null)}}Q=o}}if(o.subtreeFlags&2064&&s!==null)s.return=o,Q=s;else b:for(;Q!==null;){if(o=Q,o.flags&2048)switch(o.tag){case 0:case 11:case 15:gc(9,o,o.return)}var v=o.sibling;if(v!==null){v.return=o.return,Q=v;break b}Q=o.return}}var y=e.current;for(Q=y;Q!==null;){s=Q;var b=s.child;if(s.subtreeFlags&2064&&b!==null)b.return=s,Q=b;else b:for(s=y;Q!==null;){if(c=Q,c.flags&2048)try{switch(c.tag){case 0:case 11:case 15:_c(9,c)}}catch(e){Rl(c,c.return,e)}if(c===s){Q=null;break b}var x=c.sibling;if(x!==null){x.return=c.return,Q=x;break b}Q=c.return}}if($=a,ta(),Ct&&typeof Ct.onPostCommitFiberRoot==`function`)try{Ct.onPostCommitFiberRoot(St,e)}catch{}i=!0}return i}finally{B=n,Bc.transition=t}}return!1}function Ll(e,t,n){t=Ss(n,t),t=Es(e,t,1),e=Qa(e,t,1),t=fl(),e!==null&&(Rt(e,1,t),hl(e,t))}function Rl(e,t,n){if(e.tag===3)Ll(e,e,n);else for(;t!==null;){if(t.tag===3){Ll(t,e,n);break}if(t.tag===1){var r=t.stateNode;if(typeof t.type.getDerivedStateFromError==`function`||typeof r.componentDidCatch==`function`&&(il===null||!il.has(r))){e=Ss(n,e),e=Ds(t,e,1),t=Qa(t,e,1),e=fl(),t!==null&&(Rt(t,1,e),hl(t,e));break}}t=t.return}}function zl(e,t,n){var r=e.pingCache;r!==null&&r.delete(t),t=fl(),e.pingedLanes|=e.suspendedLanes&n,Vc===e&&(Uc&n)===n&&(Kc===4||Kc===3&&(Uc&130023424)===Uc&&500>ht()-$c?Tl(e,0):Xc|=n),hl(e,t)}function Bl(e,t){t===0&&(e.mode&1?(t=At,At<<=1,!(At&130023424)&&(At=4194304)):t=1);var n=fl();e=qa(e,t),e!==null&&(Rt(e,t,n),hl(e,n))}function Vl(e){var t=e.memoizedState,n=0;t!==null&&(n=t.retryLane),Bl(e,n)}function Hl(e,t){var n=0;switch(e.tag){case 13:var i=e.stateNode,a=e.memoizedState;a!==null&&(n=a.retryLane);break;case 19:i=e.stateNode;break;default:throw Error(r(314))}i!==null&&i.delete(t),Bl(e,n)}var Ul=function(e,t,n){if(e!==null){if(e.memoizedProps!==t.pendingProps||Vi.current)Ms=!0;else{if((e.lanes&n)===0&&!(t.flags&128))return Ms=!1,tc(e,t,n);Ms=!!(e.flags&131072)}}else Ms=!1,_a&&t.flags&1048576&&fa(t,aa,t.index);switch(t.lanes=0,t.tag){case 2:var i=t.type;$s(e,t),e=t.pendingProps;var a=Ui(t,Bi.current);Ha(t,n),a=ko(null,t,i,e,a,n);var o=Ao();return t.flags|=1,typeof a==`object`&&a&&typeof a.render==`function`&&a.$$typeof===void 0?(t.tag=1,t.memoizedState=null,t.updateQueue=null,Wi(i)?(o=!0,Ji(t)):o=!1,t.memoizedState=a.state!==null&&a.state!==void 0?a.state:null,Ya(t),a.updater=_s,t.stateNode=a,a._reactInternals=t,xs(t,i,e,n),t=Vs(null,t,i,!0,o,n)):(t.tag=0,_a&&o&&pa(t),Ns(null,t,a,n),t=t.child),t;case 16:i=t.elementType;a:{switch($s(e,t),e=t.pendingProps,a=i._init,i=a(i._payload),t.type=i,a=t.tag=Jl(i),e=hs(i,e),a){case 0:t=zs(null,t,i,e,n);break a;case 1:t=Bs(null,t,i,e,n);break a;case 11:t=Ps(null,t,i,e,n);break a;case 14:t=Fs(null,t,i,hs(i.type,e),n);break a}throw Error(r(306,i,``))}return t;case 0:return i=t.type,a=t.pendingProps,a=t.elementType===i?a:hs(i,a),zs(e,t,i,a,n);case 1:return i=t.type,a=t.pendingProps,a=t.elementType===i?a:hs(i,a),Bs(e,t,i,a,n);case 3:a:{if(Hs(t),e===null)throw Error(r(387));i=t.pendingProps,o=t.memoizedState,a=o.element,Xa(e,t),to(t,i,null,n);var s=t.memoizedState;if(i=s.element,o.isDehydrated){if(o={element:i,isDehydrated:!1,cache:s.cache,pendingSuspenseBoundaries:s.pendingSuspenseBoundaries,transitions:s.transitions},t.updateQueue.baseState=o,t.memoizedState=o,t.flags&256){a=Ss(Error(r(423)),t),t=Us(e,t,i,n,a);break a}if(i!==a){a=Ss(Error(r(424)),t),t=Us(e,t,i,n,a);break a}for(ga=Ei(t.stateNode.containerInfo.firstChild),ha=t,_a=!0,va=null,n=Pa(t,null,i,n),t.child=n;n;)n.flags=n.flags&-3|4096,n=n.sibling}else{if(Ea(),i===a){t=ec(e,t,n);break a}Ns(e,t,i,n)}t=t.child}return t;case 5:return uo(t),e===null&&Sa(t),i=t.type,a=t.pendingProps,o=e===null?null:e.memoizedProps,s=a.children,yi(i,a)?s=null:o!==null&&yi(i,o)&&(t.flags|=32),Rs(e,t),Ns(e,t,s,n),t.child;case 6:return e===null&&Sa(t),null;case 13:return Ks(e,t,n);case 4:return co(t,t.stateNode.containerInfo),i=t.pendingProps,e===null?t.child=Na(t,null,i,n):Ns(e,t,i,n),t.child;case 11:return i=t.type,a=t.pendingProps,a=t.elementType===i?a:hs(i,a),Ps(e,t,i,a,n);case 7:return Ns(e,t,t.pendingProps,n),t.child;case 8:return Ns(e,t,t.pendingProps.children,n),t.child;case 12:return Ns(e,t,t.pendingProps.children,n),t.child;case 10:a:{if(i=t.type._context,a=t.pendingProps,o=t.memoizedProps,s=a.value,Z(Fa,i._currentValue),i._currentValue=s,o!==null){if(U(o.value,s)){if(o.children===a.children&&!Vi.current){t=ec(e,t,n);break a}}else for(o=t.child,o!==null&&(o.return=t);o!==null;){var c=o.dependencies;if(c!==null){s=o.child;for(var l=c.firstContext;l!==null;){if(l.context===i){if(o.tag===1){l=Za(-1,n&-n),l.tag=2;var u=o.updateQueue;if(u!==null){u=u.shared;var d=u.pending;d===null?l.next=l:(l.next=d.next,d.next=l),u.pending=l}}o.lanes|=n,l=o.alternate,l!==null&&(l.lanes|=n),Va(o.return,n,t),c.lanes|=n;break}l=l.next}}else if(o.tag===10)s=o.type===t.type?null:o.child;else if(o.tag===18){if(s=o.return,s===null)throw Error(r(341));s.lanes|=n,c=s.alternate,c!==null&&(c.lanes|=n),Va(s,n,t),s=o.sibling}else s=o.child;if(s!==null)s.return=o;else for(s=o;s!==null;){if(s===t){s=null;break}if(o=s.sibling,o!==null){o.return=s.return,s=o;break}s=s.return}o=s}}Ns(e,t,a.children,n),t=t.child}return t;case 9:return a=t.type,i=t.pendingProps.children,Ha(t,n),a=Ua(a),i=i(a),t.flags|=1,Ns(e,t,i,n),t.child;case 14:return i=t.type,a=hs(i,t.pendingProps),a=hs(i.type,a),Fs(e,t,i,a,n);case 15:return Is(e,t,t.type,t.pendingProps,n);case 17:return i=t.type,a=t.pendingProps,a=t.elementType===i?a:hs(i,a),$s(e,t),t.tag=1,Wi(i)?(e=!0,Ji(t)):e=!1,Ha(t,n),ys(t,i,a),xs(t,i,a,n),Vs(null,t,i,!0,e,n);case 19:return Qs(e,t,n);case 22:return Ls(e,t,n)}throw Error(r(156,t.tag))};function Wl(e,t){return dt(e,t)}function Gl(e,t,n,r){this.tag=e,this.key=n,this.sibling=this.child=this.return=this.stateNode=this.type=this.elementType=null,this.index=0,this.ref=null,this.pendingProps=t,this.dependencies=this.memoizedState=this.updateQueue=this.memoizedProps=null,this.mode=r,this.subtreeFlags=this.flags=0,this.deletions=null,this.childLanes=this.lanes=0,this.alternate=null}function Kl(e,t,n,r){return new Gl(e,t,n,r)}function ql(e){return e=e.prototype,!(!e||!e.isReactComponent)}function Jl(e){if(typeof e==`function`)return+!!ql(e);if(e!=null){if(e=e.$$typeof,e===A)return 11;if(e===N)return 14}return 2}function Yl(e,t){var n=e.alternate;return n===null?(n=Kl(e.tag,t,e.key,e.mode),n.elementType=e.elementType,n.type=e.type,n.stateNode=e.stateNode,n.alternate=e,e.alternate=n):(n.pendingProps=t,n.type=e.type,n.flags=0,n.subtreeFlags=0,n.deletions=null),n.flags=e.flags&14680064,n.childLanes=e.childLanes,n.lanes=e.lanes,n.child=e.child,n.memoizedProps=e.memoizedProps,n.memoizedState=e.memoizedState,n.updateQueue=e.updateQueue,t=e.dependencies,n.dependencies=t===null?null:{lanes:t.lanes,firstContext:t.firstContext},n.sibling=e.sibling,n.index=e.index,n.ref=e.ref,n}function Xl(e,t,n,i,a,o){var s=2;if(i=e,typeof e==`function`)ql(e)&&(s=1);else if(typeof e==`string`)s=5;else a:switch(e){case T:return Zl(n.children,a,o,t);case E:s=8,a|=8;break;case D:return e=Kl(12,n,t,a|2),e.elementType=D,e.lanes=o,e;case j:return e=Kl(13,n,t,a),e.elementType=j,e.lanes=o,e;case M:return e=Kl(19,n,t,a),e.elementType=M,e.lanes=o,e;case ee:return Ql(n,a,o,t);default:if(typeof e==`object`&&e)switch(e.$$typeof){case O:s=10;break a;case k:s=9;break a;case A:s=11;break a;case N:s=14;break a;case P:s=16,i=null;break a}throw Error(r(130,e==null?e:typeof e,``))}return t=Kl(s,n,t,a),t.elementType=e,t.type=i,t.lanes=o,t}function Zl(e,t,n,r){return e=Kl(7,e,r,t),e.lanes=n,e}function Ql(e,t,n,r){return e=Kl(22,e,r,t),e.elementType=ee,e.lanes=n,e.stateNode={isHidden:!1},e}function $l(e,t,n){return e=Kl(6,e,null,t),e.lanes=n,e}function eu(e,t,n){return t=Kl(4,e.children===null?[]:e.children,e.key,t),t.lanes=n,t.stateNode={containerInfo:e.containerInfo,pendingChildren:null,implementation:e.implementation},t}function tu(e,t,n,r,i){this.tag=t,this.containerInfo=e,this.finishedWork=this.pingCache=this.current=this.pendingChildren=null,this.timeoutHandle=-1,this.callbackNode=this.pendingContext=this.context=null,this.callbackPriority=0,this.eventTimes=Lt(0),this.expirationTimes=Lt(-1),this.entangledLanes=this.finishedLanes=this.mutableReadLanes=this.expiredLanes=this.pingedLanes=this.suspendedLanes=this.pendingLanes=0,this.entanglements=Lt(0),this.identifierPrefix=r,this.onRecoverableError=i,this.mutableSourceEagerHydrationData=null}function nu(e,t,n,r,i,a,o,s,c){return e=new tu(e,t,n,s,c),t===1?(t=1,!0===a&&(t|=8)):t=0,a=Kl(3,null,null,t),e.current=a,a.stateNode=e,a.memoizedState={element:r,isDehydrated:n,cache:null,transitions:null,pendingSuspenseBoundaries:null},Ya(a),e}function ru(e,t,n){var r=3<arguments.length&&arguments[3]!==void 0?arguments[3]:null;return{$$typeof:w,key:r==null?null:``+r,children:e,containerInfo:t,implementation:n}}function iu(e){if(!e)return zi;e=e._reactInternals;a:{if(at(e)!==e||e.tag!==1)throw Error(r(170));var t=e;do{switch(t.tag){case 3:t=t.stateNode.context;break a;case 1:if(Wi(t.type)){t=t.stateNode.__reactInternalMemoizedMergedChildContext;break a}}t=t.return}while(t!==null);throw Error(r(171))}if(e.tag===1){var n=e.type;if(Wi(n))return qi(e,n,t)}return t}function au(e,t,n,r,i,a,o,s,c){return e=nu(n,r,!0,e,i,a,o,s,c),e.context=iu(null),n=e.current,r=fl(),i=pl(n),a=Za(r,i),a.callback=t??null,Qa(n,a,i),e.current.lanes=i,Rt(e,i,r),hl(e,r),e}function ou(e,t,n,r){var i=t.current,a=fl(),o=pl(i);return n=iu(n),t.context===null?t.context=n:t.pendingContext=n,t=Za(a,o),t.payload={element:e},r=r===void 0?null:r,r!==null&&(t.callback=r),e=Qa(i,t,o),e!==null&&(ml(e,i,o,a),$a(e,i,o)),o}function su(e){if(e=e.current,!e.child)return null;switch(e.child.tag){case 5:return e.child.stateNode;default:return e.child.stateNode}}function cu(e,t){if(e=e.memoizedState,e!==null&&e.dehydrated!==null){var n=e.retryLane;e.retryLane=n!==0&&n<t?n:t}}function lu(e,t){cu(e,t),(e=e.alternate)&&cu(e,t)}function uu(){return null}var du=typeof reportError==`function`?reportError:function(e){console.error(e)};function fu(e){this._internalRoot=e}pu.prototype.render=fu.prototype.render=function(e){var t=this._internalRoot;if(t===null)throw Error(r(409));ou(e,t,null,null)},pu.prototype.unmount=fu.prototype.unmount=function(){var e=this._internalRoot;if(e!==null){this._internalRoot=null;var t=e.containerInfo;Cl(function(){ou(null,e,null,null)}),t[Y]=null}};function pu(e){this._internalRoot=e}pu.prototype.unstable_scheduleHydration=function(e){if(e){var t=Wt();e={blockedOn:null,target:e,priority:t};for(var n=0;n<$t.length&&t!==0&&t<$t[n].priority;n++);$t.splice(n,0,e),n===0&&an(e)}};function mu(e){return!(!e||e.nodeType!==1&&e.nodeType!==9&&e.nodeType!==11)}function hu(e){return!(!e||e.nodeType!==1&&e.nodeType!==9&&e.nodeType!==11&&(e.nodeType!==8||e.nodeValue!==` react-mount-point-unstable `))}function gu(){}function _u(e,t,n,r,i){if(i){if(typeof r==`function`){var a=r;r=function(){var e=su(o);a.call(e)}}var o=au(t,r,e,0,null,!1,!1,``,gu);return e._reactRootContainer=o,e[Y]=o.current,oi(e.nodeType===8?e.parentNode:e),Cl(),o}for(;i=e.lastChild;)e.removeChild(i);if(typeof r==`function`){var s=r;r=function(){var e=su(c);s.call(e)}}var c=nu(e,0,!1,null,null,!1,!1,``,gu);return e._reactRootContainer=c,e[Y]=c.current,oi(e.nodeType===8?e.parentNode:e),Cl(function(){ou(t,c,n,r)}),c}function vu(e,t,n,r,i){var a=n._reactRootContainer;if(a){var o=a;if(typeof i==`function`){var s=i;i=function(){var e=su(o);s.call(e)}}ou(t,o,e,i)}else o=_u(n,t,e,i,r);return su(o)}Ht=function(e){switch(e.tag){case 3:var t=e.stateNode;if(t.current.memoizedState.isDehydrated){var n=jt(t.pendingLanes);n!==0&&(Bt(t,n|1),hl(t,ht()),!($&6)&&(el=ht()+500,ta()))}break;case 13:Cl(function(){var t=qa(e,1);t!==null&&ml(t,e,1,fl())}),lu(e,1)}},V=function(e){if(e.tag===13){var t=qa(e,134217728);t!==null&&ml(t,e,134217728,fl()),lu(e,134217728)}},Ut=function(e){if(e.tag===13){var t=pl(e),n=qa(e,t);n!==null&&ml(n,e,t,fl()),lu(e,t)}},Wt=function(){return B},Gt=function(e,t){var n=B;try{return B=e,t()}finally{B=n}},Re=function(e,t,n){switch(t){case`input`:if(ge(e,n),t=n.name,n.type===`radio`&&t!=null){for(n=e;n.parentNode;)n=n.parentNode;for(n=n.querySelectorAll(`input[name=`+JSON.stringify(``+t)+`][type="radio"]`),t=0;t<n.length;t++){var i=n[t];if(i!==e&&i.form===e.form){var a=Fi(i);if(!a)throw Error(r(90));de(i),ge(i,a)}}}break;case`textarea`:Ce(e,n);break;case`select`:t=n.value,t!=null&&be(e,!!n.multiple,t,!1)}},We=Sl,Ge=Cl;var yu={usingClientEntryPoint:!1,Events:[Ni,Pi,Fi,He,Ue,Sl]},bu={findFiberByHostInstance:Mi,bundleType:0,version:`18.3.1`,rendererPackageName:`react-dom`},xu={bundleType:bu.bundleType,version:bu.version,rendererPackageName:bu.rendererPackageName,rendererConfig:bu.rendererConfig,overrideHookState:null,overrideHookStateDeletePath:null,overrideHookStateRenamePath:null,overrideProps:null,overridePropsDeletePath:null,overridePropsRenamePath:null,setErrorHandler:null,setSuspenseHandler:null,scheduleUpdate:null,currentDispatcherRef:S.ReactCurrentDispatcher,findHostInstanceByFiber:function(e){return e=lt(e),e===null?null:e.stateNode},findFiberByHostInstance:bu.findFiberByHostInstance||uu,findHostInstancesForRefresh:null,scheduleRefresh:null,scheduleRoot:null,setRefreshHandler:null,getCurrentFiber:null,reconcilerVersion:`18.3.1-next-f1338f8080-20240426`};if(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__<`u`){var Su=__REACT_DEVTOOLS_GLOBAL_HOOK__;if(!Su.isDisabled&&Su.supportsFiber)try{St=Su.inject(xu),Ct=Su}catch{}}e.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED=yu,e.createPortal=function(e,t){var n=2<arguments.length&&arguments[2]!==void 0?arguments[2]:null;if(!mu(t))throw Error(r(200));return ru(e,t,null,n)},e.createRoot=function(e,t){if(!mu(e))throw Error(r(299));var n=!1,i=``,a=du;return t!=null&&(!0===t.unstable_strictMode&&(n=!0),t.identifierPrefix!==void 0&&(i=t.identifierPrefix),t.onRecoverableError!==void 0&&(a=t.onRecoverableError)),t=nu(e,1,!1,null,null,n,!1,i,a),e[Y]=t.current,oi(e.nodeType===8?e.parentNode:e),new fu(t)},e.findDOMNode=function(e){if(e==null)return null;if(e.nodeType===1)return e;var t=e._reactInternals;if(t===void 0)throw typeof e.render==`function`?Error(r(188)):(e=Object.keys(e).join(`,`),Error(r(268,e)));return e=lt(t),e=e===null?null:e.stateNode,e},e.flushSync=function(e){return Cl(e)},e.hydrate=function(e,t,n){if(!hu(t))throw Error(r(200));return vu(null,e,t,!0,n)},e.hydrateRoot=function(e,t,n){if(!mu(e))throw Error(r(405));var i=n!=null&&n.hydratedSources||null,a=!1,o=``,s=du;if(n!=null&&(!0===n.unstable_strictMode&&(a=!0),n.identifierPrefix!==void 0&&(o=n.identifierPrefix),n.onRecoverableError!==void 0&&(s=n.onRecoverableError)),t=au(t,null,e,1,n??null,a,!1,o,s),e[Y]=t.current,oi(e),i)for(e=0;e<i.length;e++)n=i[e],a=n._getVersion,a=a(n._source),t.mutableSourceEagerHydrationData==null?t.mutableSourceEagerHydrationData=[n,a]:t.mutableSourceEagerHydrationData.push(n,a);return new pu(t)},e.render=function(e,t,n){if(!hu(t))throw Error(r(200));return vu(null,e,t,!1,n)},e.unmountComponentAtNode=function(e){if(!hu(e))throw Error(r(40));return e._reactRootContainer?(Cl(function(){vu(null,null,e,!1,function(){e._reactRootContainer=null,e[Y]=null})}),!0):!1},e.unstable_batchedUpdates=Sl,e.unstable_renderSubtreeIntoContainer=function(e,t,n,i){if(!hu(n))throw Error(r(200));if(e==null||e._reactInternals===void 0)throw Error(r(38));return vu(e,t,n,!1,i)},e.version=`18.3.1-next-f1338f8080-20240426`})),Ir=o(((e,t)=>{function n(){if(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__<`u`&&typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE==`function`)try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(n)}catch(e){console.error(e)}}n(),t.exports=Fr()})),Lr=o((e=>{var t=Ir();e.createRoot=t.createRoot,e.hydrateRoot=t.hydrateRoot}))();function W(e,t=250,n=``){return e==null?n:String(e).replace(/<[^>]*>/g,``).replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g,``).slice(0,t)}function Rr(e,t=600,n=``){return e==null?n:String(e).replace(/<[^>]*>/g,``).replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g,``).slice(0,t)}function zr(e,t=[`http:`,`https:`],n=``){if(typeof e!=`string`)return n;let r=e.trim();if(!r)return n;let i=r.toLowerCase().replace(/[\s\u0000-\u001F]/g,``);if(i.startsWith(`javascript:`)||i.startsWith(`data:`)||i.startsWith(`vbscript:`)||i.startsWith(`file:`))return n;try{let e=r;/^[a-zA-Z][a-zA-Z0-9+.-]*:/.test(r)||(e=`https://`+r);let n=new URL(e);if(t.includes(n.protocol))return n.toString()}catch{}return n}function Br(e,t=Yr[0]){if(typeof e!=`string`||!e.trim())return t;let n=e.trim();if(/^p:\d+$/.test(n)||Yr.includes(n)||/^data:image\/(png|jpeg|jpg|webp|gif|svg\+xml);base64,[A-Za-z0-9+/=]+$/i.test(n))return n;if(n.startsWith(`data:image/svg+xml`)){let e=decodeURIComponent(n);if(!/<script|javascript:|on\w+\s*=/i.test(e))return n}return zr(n,[`http:`,`https:`],``)||t}function Vr(e,t=`#25D366`){if(typeof e!=`string`)return t;let n=e.trim();return/^#([0-9a-fA-F]{3,4}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})$/.test(n)||/^(rgb|rgba|hsl|hsla)\(\s*[\d.%\s,/-]+\s*\)$/i.test(n)?n:/^[a-zA-Z]{3,20}$/.test(n)?n.toLowerCase():t}function Hr(e,t=Xr.whatsapp){if(typeof e!=`string`)return t;let n=e.trim();return!/^(linear-gradient|radial-gradient)\(/.test(n)||/[;{}"'<>`]|url\(|expression\(|javascript:/i.test(n)?t:n}function Ur(e,t,n,r){let i=Number(e);return Number.isFinite(i)?Math.min(Math.max(i,t),n):r}function Wr(e){return{id:e.id,enabled:!!e.enabled,label:W(e.label??e.id,40,e.id),value:W(e.value,150,``),message:e.message?Rr(e.message,300,``):void 0,emailSubject:e.emailSubject?W(e.emailSubject,150,``):void 0,color:Vr(e.color,`#25D366`),openInNewTab:e.openInNewTab!==!1}}function Gr(e){let t=W(e.value,150,``),n=e.message?Rr(e.message,300,``):void 0;return{id:W(e.id,50,`agent-`+Date.now()),name:W(e.name??`Support Agent`,60,`Support Agent`),role:W(e.role??`Customer Support`,80,`Customer Support`),avatar:Br(e.avatar),channelId:e.channelId||`whatsapp`,value:t||void 0,message:n,emailSubject:e.emailSubject?W(e.emailSubject,150,``):void 0,online:e.online!==!1}}function Kr(e){let t=e.modalTheme,n=[`whatsapp`,`messenger`,`telegram`,`instagram`,`tiktok`,`wechat`,`dark`,`custom`].includes(t)?t:`whatsapp`,r=[`bottom-right`,`bottom-left`,`top-right`,`top-left`].includes(e.position)?e.position:`bottom-right`,i=[`circle`,`rounded`,`pill`].includes(e.buttonShape)?e.buttonShape:`circle`,a=[`chat`,`whatsapp`,`messenger`,`telegram`,`instagram`,`phone`,`email`,`support`].includes(e.launcherIcon)?e.launcherIcon:`chat`,o=[`stack`,`grid`,`horizontal`].includes(e.layout)?e.layout:`stack`,s=[`none`,`pop`,`bounce`,`pulse`,`slide`].includes(e.animation)?e.animation:`pop`,c=[`modal`,`buttons`].includes(e.widgetMode)?e.widgetMode:`modal`,l=Array.isArray(e.channels)?e.channels.map(Wr):[],u=Array.isArray(e.agents)?e.agents.map(Gr):[],d=[`launcher`,`greeting`].includes(e.scrollTriggerTarget)?e.scrollTriggerTarget:`launcher`,f=[`modal`,`greeting`].includes(e.exitIntentAction)?e.exitIntentAction:`modal`,p=[`badge`,`hide`].includes(e.scheduleOfflineAction)?e.scheduleOfflineAction:`badge`,m=[`show`,`hide`].includes(e.targetingMode)?e.targetingMode:`show`,h=Array.isArray(e.scheduleDays)?e.scheduleDays.filter(e=>typeof e==`number`&&e>=0&&e<=6):[1,2,3,4,5];return{enabled:!!(e.enabled??!0),widgetMode:c,modalTheme:n,modalTitle:W(e.modalTitle,100,`Hi there!`),modalSubtitle:W(e.modalSubtitle,250,`Welcome to our live chat! Feel free to ask any questions.`),modalResponseTime:W(e.modalResponseTime,60,`We typically reply within a few minutes`),modalChatBubble:Rr(e.modalChatBubble,500,`We typically reply within a few minutes. How can we help you today?`),modalStartChatText:W(e.modalStartChatText,50,`Start chat`),modalCustomGradient:Hr(e.modalCustomGradient,`linear-gradient(135deg, #10b981 0%, #059669 100%)`),agents:u,channels:l,position:r,layout:o,buttonShape:i,launcherIcon:a,animation:s,iconStyle:e.iconStyle===`simple`?`simple`:`brand`,buttonSize:Ur(e.buttonSize,36,100,58),iconSize:Ur(e.iconSize,16,60,26),gap:Ur(e.gap,0,50,12),offsetX:Ur(e.offsetX,0,300,24),offsetY:Ur(e.offsetY,0,300,24),background:Vr(e.background,`#ffffff`),buttonColor:Vr(e.buttonColor,`#25D366`),labelColor:Vr(e.labelColor,`#ffffff`),labelBackground:Vr(e.labelBackground,`#111827`),panelBackground:Vr(e.panelBackground,`#ffffff`),panelText:Vr(e.panelText,`#111827`),shadow:W(e.shadow,100,`0 16px 40px rgba(0,0,0,.18)`),showLabels:!!(e.showLabels??!0),showChannelNames:!!(e.showChannelNames??!0),showBadge:!!(e.showBadge??!0),badgeText:W(e.badgeText,10,`1`),greetingEnabled:!!(e.greetingEnabled??!0),greetingText:W(e.greetingText,200,`Need help? Chat with us.`),greetingDelay:Ur(e.greetingDelay,0,6e4,2500),autoOpen:!!(e.autoOpen??!1),autoOpenDelay:Ur(e.autoOpenDelay,0,6e4,1200),enableSound:!!(e.enableSound??!1),enableAnalytics:!!(e.enableAnalytics??!0),openInNewTab:!!(e.openInNewTab??!0),closeAfterClick:!!(e.closeAfterClick??!0),closeOnOutsideClick:!!(e.closeOnOutsideClick??!0),closeOnEscape:!!(e.closeOnEscape??!0),mobileShowLabels:!!(e.mobileShowLabels??!1),mobileOffsetX:Ur(e.mobileOffsetX,0,200,16),mobileOffsetY:Ur(e.mobileOffsetY,0,200,16),mobileCapChannels:!!(e.mobileCapChannels??!0),ariaLabel:W(e.ariaLabel,80,`Open chat options`),scrollTriggerEnabled:!!(e.scrollTriggerEnabled??!1),scrollTriggerPercent:Ur(e.scrollTriggerPercent,1,100,25),scrollTriggerTarget:d,exitIntentEnabled:!!(e.exitIntentEnabled??!1),exitIntentAction:f,scheduleEnabled:!!(e.scheduleEnabled??!1),scheduleDays:h.length>0?h:[1,2,3,4,5],scheduleStart:W(e.scheduleStart,10,`09:00`),scheduleEnd:W(e.scheduleEnd,10,`18:00`),scheduleOfflineAction:p,scheduleOfflineText:W(e.scheduleOfflineText,100,`Back tomorrow at 9:00 AM`),targetingEnabled:!!(e.targetingEnabled??!0),showOn:W(e.showOn,100,`Every page`),targetingMode:m,targetingRules:Rr(e.targetingRules,1e3,``),widgetId:W(e.widgetId,100,``)}}function qr(e){return`data:image/svg+xml;utf8,${encodeURIComponent(e.trim())}`}var Jr=[qr(`
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 120 120" width="120" height="120">
  <defs>
    <linearGradient id="bg1" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#FCD34D"/>
      <stop offset="100%" stop-color="#F59E0B"/>
    </linearGradient>
    <linearGradient id="shirt1" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#3B82F6"/>
      <stop offset="100%" stop-color="#1D4ED8"/>
    </linearGradient>
  </defs>
  <rect width="120" height="120" rx="60" fill="url(#bg1)"/>
  <!-- Body/Shoulders -->
  <path d="M20 120 C20 90 40 82 60 82 C80 82 100 90 100 120 Z" fill="url(#shirt1)"/>
  <path d="M50 82 L70 82 L65 94 L55 94 Z" fill="#F87171"/>
  <!-- Neck -->
  <rect x="52" y="66" width="16" height="20" rx="8" fill="#FBBF24"/>
  <!-- Head -->
  <ellipse cx="60" cy="50" rx="24" ry="26" fill="#FDE68A"/>
  <!-- Hair -->
  <path d="M36 46 C36 28 46 22 60 22 C74 22 84 28 84 46 C84 38 78 30 60 30 C44 30 36 38 36 46 Z" fill="#1F2937"/>
  <path d="M36 46 C36 34 42 26 52 24 C44 28 40 36 40 46 Z" fill="#111827"/>
  <!-- Glasses -->
  <rect x="42" y="44" width="14" height="10" rx="3" fill="none" stroke="#1F2937" stroke-width="2.5"/>
  <rect x="64" y="44" width="14" height="10" rx="3" fill="none" stroke="#1F2937" stroke-width="2.5"/>
  <line x1="56" y1="48" x2="64" y2="48" stroke="#1F2937" stroke-width="2.5"/>
  <!-- Eyes -->
  <circle cx="49" cy="49" r="2" fill="#1F2937"/>
  <circle cx="71" cy="49" r="2" fill="#1F2937"/>
  <!-- Smile -->
  <path d="M52 62 Q60 69 68 62" fill="none" stroke="#B45309" stroke-width="2.5" stroke-linecap="round"/>
</svg>
`),qr(`
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 120 120" width="120" height="120">
  <defs>
    <linearGradient id="bg2" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#C7D2FE"/>
      <stop offset="100%" stop-color="#818CF8"/>
    </linearGradient>
    <linearGradient id="shirt2" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#6366F1"/>
      <stop offset="100%" stop-color="#4338CA"/>
    </linearGradient>
  </defs>
  <rect width="120" height="120" rx="60" fill="url(#bg2)"/>
  <!-- Hair back -->
  <path d="M32 50 C32 26 44 20 60 20 C76 20 88 26 88 50 C88 74 84 86 84 86 L36 86 C36 86 32 74 32 50 Z" fill="#312E81"/>
  <!-- Shoulders -->
  <path d="M22 120 C22 92 40 84 60 84 C80 84 98 92 98 120 Z" fill="url(#shirt2)"/>
  <!-- Neck -->
  <rect x="52" y="68" width="16" height="18" rx="7" fill="#FED7AA"/>
  <!-- Face -->
  <ellipse cx="60" cy="52" rx="22" ry="24" fill="#FFEDD5"/>
  <!-- Hair bangs -->
  <path d="M38 42 C44 32 54 30 68 30 C78 30 84 34 84 42 C78 36 68 34 58 35 C48 36 42 40 38 42 Z" fill="#4338CA"/>
  <!-- Eyes -->
  <circle cx="51" cy="50" r="2.2" fill="#1E1B4B"/>
  <circle cx="69" cy="50" r="2.2" fill="#1E1B4B"/>
  <!-- Blush -->
  <circle cx="46" cy="57" r="3.5" fill="#FDA4AF" opacity="0.6"/>
  <circle cx="74" cy="57" r="3.5" fill="#FDA4AF" opacity="0.6"/>
  <!-- Smile -->
  <path d="M53 61 Q60 67 67 61" fill="none" stroke="#EA580C" stroke-width="2" stroke-linecap="round"/>
  <!-- Support Headset -->
  <path d="M36 50 C36 34 46 25 60 25 C74 25 84 34 84 50" fill="none" stroke="#1E1B4B" stroke-width="3" stroke-linecap="round"/>
  <rect x="33" y="47" width="6" height="12" rx="3" fill="#10B981"/>
  <rect x="81" y="47" width="6" height="12" rx="3" fill="#10B981"/>
  <path d="M83 58 Q82 72 70 73" fill="none" stroke="#1E1B4B" stroke-width="2" stroke-linecap="round"/>
  <circle cx="68" cy="73" r="2.5" fill="#10B981"/>
</svg>
`),qr(`
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 120 120" width="120" height="120">
  <defs>
    <linearGradient id="bg3" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#A7F3D0"/>
      <stop offset="100%" stop-color="#34D399"/>
    </linearGradient>
    <linearGradient id="shirt3" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#0F766E"/>
      <stop offset="100%" stop-color="#115E59"/>
    </linearGradient>
  </defs>
  <rect width="120" height="120" rx="60" fill="url(#bg3)"/>
  <!-- Shoulders -->
  <path d="M22 120 C22 92 40 84 60 84 C80 84 98 92 98 120 Z" fill="url(#shirt3)"/>
  <!-- Neck -->
  <rect x="52" y="68" width="16" height="18" rx="8" fill="#FCD34D"/>
  <!-- Face -->
  <ellipse cx="60" cy="51" rx="23" ry="25" fill="#FDE68A"/>
  <!-- Hair (short modern cut) -->
  <path d="M37 45 C37 28 47 22 60 22 C73 22 83 28 83 45 C83 34 75 27 60 27 C45 27 37 34 37 45 Z" fill="#064E3B"/>
  <path d="M42 27 L60 24 L78 27 L70 31 L50 31 Z" fill="#047857"/>
  <!-- Eyes -->
  <circle cx="50" cy="50" r="2.2" fill="#064E3B"/>
  <circle cx="70" cy="50" r="2.2" fill="#064E3B"/>
  <!-- Eyebrows -->
  <path d="M46 44 Q50 42 54 44" fill="none" stroke="#064E3B" stroke-width="2" stroke-linecap="round"/>
  <path d="M66 44 Q70 42 74 44" fill="none" stroke="#064E3B" stroke-width="2" stroke-linecap="round"/>
  <!-- Beard subtle outline -->
  <path d="M42 54 C44 72 52 76 60 76 C68 76 76 72 78 54 C76 68 68 73 60 73 C52 73 44 68 42 54 Z" fill="#047857" opacity="0.4"/>
  <!-- Smile -->
  <path d="M53 62 Q60 68 67 62" fill="none" stroke="#B45309" stroke-width="2" stroke-linecap="round"/>
</svg>
`),qr(`
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 120 120" width="120" height="120">
  <defs>
    <linearGradient id="bg4" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#FECDD3"/>
      <stop offset="100%" stop-color="#FB7185"/>
    </linearGradient>
    <linearGradient id="shirt4" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#BE185D"/>
      <stop offset="100%" stop-color="#881337"/>
    </linearGradient>
  </defs>
  <rect width="120" height="120" rx="60" fill="url(#bg4)"/>
  <!-- Hair back -->
  <path d="M30 52 C30 25 43 18 60 18 C77 18 90 25 90 52 C90 76 84 90 84 90 L36 90 C36 90 30 76 30 52 Z" fill="#78350F"/>
  <!-- Shoulders -->
  <path d="M22 120 C22 92 40 84 60 84 C80 84 98 92 98 120 Z" fill="url(#shirt4)"/>
  <!-- Neck -->
  <rect x="52" y="68" width="16" height="18" rx="7" fill="#FED7AA"/>
  <!-- Face -->
  <ellipse cx="60" cy="52" rx="22" ry="24" fill="#FFEDD5"/>
  <!-- Hair front -->
  <path d="M35 44 C40 32 50 28 65 28 C76 28 85 33 85 45 C80 35 70 33 60 33 C48 33 40 38 35 44 Z" fill="#92400E"/>
  <!-- Eyes -->
  <circle cx="51" cy="51" r="2.2" fill="#451A03"/>
  <circle cx="69" cy="51" r="2.2" fill="#451A03"/>
  <!-- Blush -->
  <circle cx="45" cy="58" r="3.5" fill="#F43F5E" opacity="0.5"/>
  <circle cx="75" cy="58" r="3.5" fill="#F43F5E" opacity="0.5"/>
  <!-- Smile -->
  <path d="M53 62 Q60 68 67 62" fill="none" stroke="#BE123C" stroke-width="2" stroke-linecap="round"/>
</svg>
`)],Yr=Jr,Xr={whatsapp:`linear-gradient(135deg, #25D366 0%, #128C7E 100%)`,messenger:`linear-gradient(135deg, #0084FF 0%, #00C6FF 100%)`,telegram:`linear-gradient(135deg, #2AABEE 0%, #229ED9 100%)`,instagram:`linear-gradient(135deg, #833AB4 0%, #FD1D1D 50%, #FCB045 100%)`,tiktok:`linear-gradient(135deg, #111111 0%, #1f2937 60%, #FE2C55 100%)`,wechat:`linear-gradient(135deg, #07C160 0%, #048843 100%)`,dark:`linear-gradient(135deg, #1f2937 0%, #111827 100%)`,custom:`linear-gradient(135deg, #3b82f6 0%, #1d4ed8 100%)`},Zr=[{id:`whatsapp`,enabled:!0,label:`WhatsApp`,value:``,message:`Hello! I'd like to know more.`,color:`#25D366`,openInNewTab:!0},{id:`messenger`,enabled:!0,label:`Messenger`,value:``,color:`#0084FF`,openInNewTab:!0},{id:`instagram`,enabled:!1,label:`Instagram`,value:``,color:`#E1306C`,openInNewTab:!0},{id:`telegram`,enabled:!0,label:`Telegram`,value:``,message:`Hello!`,color:`#229ED9`,openInNewTab:!0},{id:`tiktok`,enabled:!1,label:`TikTok`,value:``,color:`#111111`,openInNewTab:!0},{id:`wechat`,enabled:!1,label:`WeChat`,value:``,color:`#07C160`,openInNewTab:!0},{id:`viber`,enabled:!1,label:`Viber`,value:``,color:`#7360F2`,openInNewTab:!0},{id:`line`,enabled:!1,label:`LINE`,value:``,color:`#06C755`,openInNewTab:!0},{id:`signal`,enabled:!1,label:`Signal`,value:``,color:`#3A76F0`,openInNewTab:!0},{id:`phone`,enabled:!1,label:`Phone`,value:``,color:`#111827`,openInNewTab:!1},{id:`sms`,enabled:!1,label:`SMS`,value:``,message:`Hello! I have a question about {title}.`,color:`#10B981`,openInNewTab:!1},{id:`email`,enabled:!1,label:`Email`,value:``,emailSubject:``,message:``,color:`#EA4335`,openInNewTab:!1},{id:`discord`,enabled:!1,label:`Discord`,value:``,color:`#5865F2`,openInNewTab:!0},{id:`slack`,enabled:!1,label:`Slack`,value:``,color:`#4A154B`,openInNewTab:!0},{id:`teams`,enabled:!1,label:`Microsoft Teams`,value:``,color:`#6264A7`,openInNewTab:!0},{id:`x`,enabled:!1,label:`X (Twitter)`,value:``,color:`#000000`,openInNewTab:!0},{id:`linkedin`,enabled:!1,label:`LinkedIn`,value:``,color:`#0A66C2`,openInNewTab:!0},{id:`maps`,enabled:!1,label:`Google Maps`,value:``,color:`#EA4335`,openInNewTab:!0},{id:`custom`,enabled:!1,label:`Custom`,value:``,color:`#111827`,openInNewTab:!0}],Qr=[{id:`agent-1`,name:`Alex`,role:`Support Manager`,avatar:Jr[0],channelId:`whatsapp`,online:!0},{id:`agent-2`,name:`Sarah`,role:`Customer Support`,avatar:Jr[1],channelId:`messenger`,online:!0},{id:`agent-3`,name:`David`,role:`Technical Team`,avatar:Jr[2],channelId:`telegram`,online:!0}],$r={enabled:!0,widgetMode:`modal`,modalTheme:`whatsapp`,modalTitle:`Hi there!`,modalSubtitle:`Welcome to our live chat! Feel free to ask any questions.`,modalResponseTime:`We typically reply within a few minutes`,modalChatBubble:`We typically reply within a few minutes. How can we help you today?`,modalStartChatText:`Start chat`,modalCustomGradient:`linear-gradient(135deg, #10b981 0%, #059669 100%)`,agents:Qr,channels:Zr,position:`bottom-right`,layout:`stack`,buttonShape:`circle`,launcherIcon:`chat`,animation:`pop`,iconStyle:`brand`,buttonSize:58,iconSize:26,gap:12,offsetX:24,offsetY:24,background:`#ffffff`,buttonColor:`#25D366`,labelColor:`#ffffff`,labelBackground:`#111827`,panelBackground:`#ffffff`,panelText:`#111827`,shadow:`0 16px 40px rgba(0,0,0,.18)`,showLabels:!0,showChannelNames:!0,showBadge:!0,badgeText:`1`,greetingEnabled:!0,greetingText:`Need help? Chat with us.`,greetingDelay:2500,autoOpen:!1,autoOpenDelay:1200,enableSound:!1,enableAnalytics:!0,forwardEventsToSiteAnalytics:!1,openInNewTab:!0,closeAfterClick:!0,closeOnOutsideClick:!0,closeOnEscape:!0,mobileShowLabels:!1,mobileOffsetX:16,mobileOffsetY:16,mobileCapChannels:!0,ariaLabel:`Open chat options`,scrollTriggerEnabled:!1,scrollTriggerPercent:25,scrollTriggerTarget:`launcher`,exitIntentEnabled:!1,exitIntentAction:`modal`,scheduleEnabled:!1,scheduleDays:[1,2,3,4,5],scheduleStart:`09:00`,scheduleEnd:`18:00`,scheduleOfflineAction:`badge`,scheduleOfflineText:`Back tomorrow at 9:00 AM`,targetingEnabled:!0,showOn:`Every page`,targetingMode:`show`,targetingRules:``,widgetId:``};function ei(e){let t=e??{},n=new Map((t.channels||[]).map(e=>[e.id,e])),r=new Set(Zr.map(e=>e.id)),i=(t.channels||[]).filter(e=>!r.has(e.id)),a=[...Zr.map(e=>{let t=n.get(e.id);return t?{...e,...t}:e}),...i],o=Array.isArray(t.agents)&&t.agents.length?t.agents:Qr,s=t.widgetId&&typeof t.widgetId==`string`&&t.widgetId.trim()?t.widgetId.trim():`cb_`+Date.now().toString(36)+Math.random().toString(36).slice(2,8);return Kr({...$r,...t,widgetId:s,channels:a,agents:o})}function ti(){return JSON.parse(JSON.stringify($r))}var ni=`scb_config_v1`,ri=[`token`,`auth_token`,`authToken`,`bearer_token`,`chat_bubbles_auth_token`,`jwt`,`session`,`auth_session`,`scb_token`];async function G(){try{await oi(`setPluginData`);for(let e of ri)try{await U.setPluginData(e,null)}catch{}}catch{}}function ii(e){let t=new Map(Zr.map(e=>[e.id,e])),n=(e.channels||[]).filter(e=>{let n=t.get(e.id);return!n||e.enabled!==n.enabled||!!e.value.trim()||!!(e.message&&e.message.trim()!==(n.message||``))||e.color!==n.color}).map(e=>({id:e.id,enabled:e.enabled,value:e.value,...e.message?{message:e.message}:{},color:e.color})),r=(e.agents||[]).map(e=>{let t=e.avatar,n=Yr.indexOf(t);return n!==-1&&(t=`p:`+n),{id:e.id,name:e.name,role:e.role,avatar:t,channelId:e.channelId,...e.value?{value:e.value}:{},...e.message?{message:e.message}:{},...e.online===void 0?{}:{online:e.online}}});return{enabled:e.enabled,widgetMode:e.widgetMode,modalTheme:e.modalTheme,...e.modalCustomGradient?{modalCustomGradient:e.modalCustomGradient}:{},modalTitle:e.modalTitle,modalSubtitle:e.modalSubtitle,modalResponseTime:e.modalResponseTime,modalChatBubble:e.modalChatBubble,modalStartChatText:e.modalStartChatText,position:e.position,layout:e.layout,animation:e.animation,buttonShape:e.buttonShape,launcherIcon:e.launcherIcon,buttonSize:e.buttonSize,buttonColor:e.buttonColor,showBadge:e.showBadge,badgeText:e.badgeText,showLabels:e.showLabels,offsetX:e.offsetX,offsetY:e.offsetY,mobileShowLabels:e.mobileShowLabels,mobileOffsetX:e.mobileOffsetX,mobileOffsetY:e.mobileOffsetY,mobileCapChannels:e.mobileCapChannels,closeOnOutsideClick:e.closeOnOutsideClick,closeOnEscape:e.closeOnEscape,closeAfterClick:e.closeAfterClick,ariaLabel:e.ariaLabel,greetingEnabled:e.greetingEnabled,greetingText:e.greetingText,greetingDelay:e.greetingDelay,autoOpen:e.autoOpen,autoOpenDelay:e.autoOpenDelay,openInNewTab:e.openInNewTab,enableSound:e.enableSound,enableAnalytics:e.enableAnalytics,...e.forwardEventsToSiteAnalytics===void 0?{}:{forwardEventsToSiteAnalytics:e.forwardEventsToSiteAnalytics},scrollTriggerEnabled:e.scrollTriggerEnabled,scrollTriggerPercent:e.scrollTriggerPercent,scrollTriggerTarget:e.scrollTriggerTarget,exitIntentEnabled:e.exitIntentEnabled,exitIntentAction:e.exitIntentAction,scheduleEnabled:e.scheduleEnabled,scheduleDays:e.scheduleDays,scheduleStart:e.scheduleStart,scheduleEnd:e.scheduleEnd,scheduleOfflineAction:e.scheduleOfflineAction,scheduleOfflineText:e.scheduleOfflineText,targetingEnabled:e.targetingEnabled,targetingMode:e.targetingMode,targetingRules:e.targetingRules,...e.widgetId?{widgetId:e.widgetId}:{},agents:r,channels:n}}function ai(e){if(!e||typeof e!=`object`)return{};let t=Array.isArray(e.agents)?e.agents.map(e=>{let t=e.avatar;if(typeof t==`string`&&t.startsWith(`p:`)){let e=parseInt(t.slice(2),10);!isNaN(e)&&Yr[e]&&(t=Yr[e])}return{...e,avatar:t}}):void 0;return{...e,...t?{agents:t}:{}}}async function oi(e){try{typeof U.isAllowedTo==`function`&&await U.isAllowedTo(e)}catch{}}async function si(){try{G(),await oi(`getPluginData`);let e=await U.getPluginData(ni);if(!e){try{if(typeof localStorage<`u`){let e=localStorage.getItem(`chat_bubbles_project_config_backup`);if(e)return ei(ai(JSON.parse(e)))}}catch{}return ei(null)}let t=JSON.parse(e);if(t&&typeof t.chunks==`number`){let e=``;for(let n=0;n<t.chunks;n++){let t=await U.getPluginData(`${ni}_c${n}`);t&&(e+=t)}if(e)return ei(ai(JSON.parse(e)))}return ei(ai(t))}catch(e){console.warn(`Could not load config from plugin data:`,e);try{if(typeof localStorage<`u`){let e=localStorage.getItem(`chat_bubbles_project_config_backup`);if(e)return ei(ai(JSON.parse(e)))}}catch{}return ei(null)}}async function ci(e){await oi(`setPluginData`);let t=ii(ei(e)),n=JSON.stringify(t),r=8192;if(n.length>r)throw Error(`Configuration size exceeds Framer project data limit (${n.length} bytes / max ${r} bytes). Please shorten custom greeting text, reduce custom targeting URLs, or remove unused channels.`);try{typeof localStorage<`u`&&localStorage.setItem(`chat_bubbles_project_config_backup`,n)}catch{}let i=1400;try{if(n.length<=i){await U.setPluginData(ni,n);for(let e=0;e<10;e++)try{await U.setPluginData(`${ni}_c${e}`,null)}catch{}}else{let e=[];for(let t=0;t<n.length;t+=i)e.push(n.slice(t,t+i));for(let t=0;t<e.length;t++)await U.setPluginData(`${ni}_c${t}`,e[t]);await U.setPluginData(ni,JSON.stringify({chunks:e.length}));for(let t=e.length;t<10;t++)try{await U.setPluginData(`${ni}_c${t}`,null)}catch{}}}catch(e){throw console.error(`Framer setPluginData failed:`,e),Error(`Failed to save to Framer plugin storage: `+(e?.message||`Storage quota exceeded.`))}}var li={whatsapp:`M20.5 3.5A11.7 11.7 0 0 0 12.1 0C5.7 0 .5 5.2.5 11.6c0 2 .5 4 1.5 5.7L.4 23.9l6.8-1.8a11.6 11.6 0 0 0 4.9 1.1h.1c6.4 0 11.6-5.2 11.6-11.6 0-3.1-1.2-6-3.3-8.1Zm-8.4 17.7h-.1c-1.5 0-3-.4-4.3-1.1l-.3-.2-4 1 1.1-3.9-.2-.3a9.6 9.6 0 0 1-1.5-5.1C2.8 6.3 7 2 12.2 2c2.5 0 4.9 1 6.7 2.8 1.8 1.8 2.8 4.2 2.8 6.7 0 5.3-4.3 9.7-9.6 9.7Zm5.3-7.2c-.3-.2-1.8-.9-2.1-1-.3-.1-.5-.2-.7.2-.2.3-.8 1-1 1.2-.2.2-.4.2-.7.1-.3-.2-1.3-.5-2.5-1.6-.9-.8-1.6-1.8-1.8-2.1-.2-.3 0-.5.2-.7.2-.2.3-.4.5-.6.2-.2.2-.3.3-.5.1-.2.1-.4 0-.6-.1-.2-.7-1.7-.9-2.3-.2-.6-.5-.5-.7-.5h-.6c-.2 0-.6.1-.9.4-.3.3-1.2 1.2-1.2 2.9s1.2 3.3 1.4 3.5c.2.2 2.3 3.6 5.7 5 .8.3 1.4.5 1.9.6.8.3 1.5.2 2.1.1.7-.1 1.8-.7 2-1.4.3-.7.3-1.3.2-1.4-.1-.2-.3-.3-.6-.4Z`,messenger:`M12 1C5.8 1 1 5.5 1 11.4c0 3.3 1.6 6.2 4.2 8.1V23l3.9-2.1c.9.2 1.9.3 2.9.3 6.2 0 11-4.5 11-10.4S18.2 1 12 1Zm1.1 13.9-2.8-3-5.5 3 6.1-6.5 2.8 3 5.4-3-6 6.5Z`,instagram:`M7 2h10a5 5 0 0 1 5 5v10a5 5 0 0 1-5 5H7a5 5 0 0 1-5-5V7a5 5 0 0 1 5-5Zm0 2a3 3 0 0 0-3 3v10a3 3 0 0 0 3 3h10a3 3 0 0 0 3-3V7a3 3 0 0 0-3-3H7Zm5 3.5A4.5 4.5 0 1 1 7.5 12 4.5 4.5 0 0 1 12 7.5Zm0 2A2.5 2.5 0 1 0 14.5 12 2.5 2.5 0 0 0 12 9.5ZM17.3 6.2a1.1 1.1 0 1 1-1.1 1.1 1.1 0 0 1 1.1-1.1Z`,telegram:`m21.5 3.5-3.2 16.1c-.2 1.1-.8 1.3-1.7.8l-4.7-3.5-2.3 2.2c-.3.3-.5.5-1 .5l.3-4.8 8.7-7.9c.4-.4-.1-.6-.6-.2L6.3 13.7 1.7 12.2c-1-.3-1-1 .2-1.5L20 3.2c.8-.3 1.8.2 1.5.3Z`,tiktok:`M15 2h3c.2 1.9 1.3 3.5 3 4.4v3.1c-1.7-.1-3.3-.7-4.6-1.7v7.4a6.8 6.8 0 1 1-5.8-6.7v3.3a3.5 3.5 0 1 0 2.5 3.4V2h1.9Z`,wechat:`M8.6 4C4.4 4 1 6.9 1 10.5c0 2 1 3.8 2.8 5L3 18l3.4-1.8c.7.2 1.4.3 2.2.3 4.2 0 7.6-2.9 7.6-6.5S12.8 4 8.6 4Zm-2.2 5.1a1 1 0 1 1 0-2 1 1 0 0 1 0 2Zm4.4 0a1 1 0 1 1 0-2 1 1 0 0 1 0 2Zm5.1 1.1c0 2.5-2.3 4.7-5.4 5.2 1 2.5 3.8 4.2 7 4.2.8 0 1.6-.1 2.3-.3L23 21l-.8-2.9c1.1-.9 1.8-2.2 1.8-3.6 0-2.8-2.4-5.1-5.5-5.3-.1-.1-.2-.1-.4-.1-.6 0-1.2 0-1.8.1Z`,viber:`M17.9 1.8C14.3.5 7.3.7 4.1 2.4 1.7 3.8 1.2 7.5 1 10.6c-.2 3.8.2 8.2 3.3 10.1l1.9 1.1-.7 1.8c-.2.6.4 1.1.9.8l2.9-1.7c3.6.7 8.2.2 10.3-2.2 1.9-2.1 2.3-7.3 1.9-10.6-.3-3.2-1.3-7-3.6-8.1ZM7.2 7.4c.4-.4.9-.4 1.3-.1.7.6 1.4 1.3 1.9 2.1.3.4.2.9-.1 1.2l-.8.8c.5 1 1.3 1.8 2.3 2.4l.8-.8c.3-.3.8-.4 1.2-.1.8.5 1.5 1.1 2.1 1.9.3.4.3.9-.1 1.3l-.7.7c-.7.7-1.7.8-2.5.4-2.1-1-4.7-3.6-5.7-5.7-.4-.8-.3-1.8.4-2.5l-.1-.1.0-.0-.0-.0Z`,line:`M21.5 10.8c0-4.5-4.5-8.1-10-8.1S1.5 6.3 1.5 10.8c0 4 3.6 7.3 8.5 8 .3.1.7.2.8.5.1.3 0 .8 0 1.1l-.1.7c0 .2-.2 1 .8.5 1-.4 5.4-3.2 7.4-5.5 1.7-1.7 2.6-3.9 2.6-6.2ZM7.8 13.2H5.6c-.3 0-.5-.2-.5-.5V9.1c0-.3.2-.5.5-.5s.5.2.5.5v3h1.7c.3 0 .5.2.5.5s-.2.6-.5.6Zm2.2-.5c0 .3-.2.5-.5.5s-.5-.2-.5-.5V9.1c0-.3.2-.5.5-.5s.5.2.5.5v3.6Zm3.9 0c0 .2-.1.4-.3.5-.2.1-.4.1-.6-.1l-1.8-2.2v1.8c0 .3-.2.5-.5.5s-.5-.2-.5-.5V9.1c0-.2.1-.4.3-.5.2-.1.4-.1.6.1l1.8 2.2V9.1c0-.3.2-.5.5-.5s.5.2.5.5v3.6Zm3.2.5h-2.2c-.3 0-.5-.2-.5-.5V9.1c0-.3.2-.5.5-.5h2.2c.3 0 .5.2.5.5s-.2.5-.5.5h-1.7v.8h1.5c.3 0 .5.2-.0.5s-.2.5-.5.5h-1.5v.8h1.7c.3 0 .5.2.5.5s-.2.5-.5.5Z`,signal:`M12 2C6 2 1.2 5.9 1.2 10.8c0 2.4 1.2 4.6 3.2 6.2l-.9 3.7 3.7-2c1.4.5 3.1.8 4.8.8 5.9 0 10.8-3.9 10.8-8.7S18 2 12 2Zm-4 9.7H6.5a.9.9 0 0 1 0-1.8H8a.9.9 0 0 1 0 1.8Zm4 0h-1.5a.9.9 0 0 1 0-1.8H12a.9.9 0 0 1 0 1.8Zm4 0h-1.5a.9.9 0 0 1 0-1.8h1.5a.9.9 0 0 1 0 1.8Z`,phone:`M6.7 2.2 9 1.7c.6-.1 1.1.2 1.3.7l1.1 2.7c.2.5.1 1-.3 1.4L9.7 7.9c1.1 2.2 2.7 3.9 4.9 4.9l1.4-1.4c.4-.4.9-.5 1.4-.3l2.7 1.1c.5.2.8.7.7 1.3l-.5 2.3c-.1.6-.7 1-1.3 1-8.1-.2-14.5-6.6-14.7-14.7 0-.6.4-1.2 1-1.3Z`,sms:`M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2Zm0 14H5.2L4 17.2V4h16v12Zm-13-7h10v2H7V9Zm0-3h10v2H7V6Z`,email:`M3 4h18c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H3c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2Zm0 3.1v.3l9 5.6 9-5.6v-.3H3Zm18 2.6-8.5 5.3a1 1 0 0 1-1 0L3 9.7V18h18V9.7Z`,discord:`M20.3 4.4a19.8 19.8 0 0 0-4.9-1.5.1.1 0 0 0-.1.1c-.2.4-.4.9-.6 1.4-1.9-.3-3.8-.3-5.6 0-.2-.5-.4-1-.6-1.4a.1.1 0 0 0-.1-.1 19.8 19.8 0 0 0-4.9 1.5.1.1 0 0 0-.1.1C.4 9.1-.4 13.6.1 18a.1.1 0 0 0 .1.1 19.9 19.9 0 0 0 6 3 .1.1 0 0 0 .1 0c.5-.7.9-1.4 1.3-2.1a.1.1 0 0 0-.1-.1c-.7-.3-1.3-.6-1.9-1a.1.1 0 0 1 0-.2c.1-.1.3-.2.4-.3a14.2 14.2 0 0 0 12.1 0c.1.1.3.2.4.3a.1.1 0 0 1 0 .2c-.6.4-1.2.7-1.9 1a.1.1 0 0 0-.1.1c.4.7.8 1.4 1.3 2.1a.1.1 0 0 0 .1 0 19.8 19.8 0 0 0 6-3 .1.1 0 0 0 .1-.1c.6-5.1-.9-9.5-3.3-13.5a.1.1 0 0 0-.1-.1ZM8.5 15.3c-1.2 0-2.1-1.1-2.1-2.4s.9-2.4 2.1-2.4 2.1 1.1 2.1 2.4-.9 2.4-2.1 2.4Zm7 0c-1.2 0-2.1-1.1-2.1-2.4s.9-2.4 2.1-2.4 2.1 1.1 2.1 2.4-.9 2.4-2.1 2.4Z`,slack:`M5.04 14.26a2.52 2.52 0 0 1-2.52-2.52c0-1.39 1.13-2.52 2.52-2.52h2.52v2.52c0 1.39-1.13 2.52-2.52 2.52zm1.26 1.26a2.52 2.52 0 0 1 2.52-2.52h2.52v2.52a2.52 2.52 0 1 1-5.04 0zm3.42-9.18a2.52 2.52 0 0 1 2.52-2.52c1.39 0 2.52 1.13 2.52 2.52v2.52h-2.52a2.52 2.52 0 0 1-2.52-2.52zm1.26 1.26a2.52 2.52 0 0 1 2.52 2.52v2.52h-2.52a2.52 2.52 0 0 1 0-5.04zm9.18 3.42a2.52 2.52 0 0 1 2.52 2.52c0 1.39-1.13 2.52-2.52 2.52h-2.52V11.02c0-1.39 1.13-2.52 2.52-2.52zm-1.26-1.26a2.52 2.52 0 0 1-2.52 2.52h-2.52V9.76a2.52 2.52 0 0 1 5.04 0zm-3.42 9.18a2.52 2.52 0 0 1-2.52 2.52c-1.39 0-2.52-1.13-2.52-2.52v-2.52h2.52c1.39 0 2.52 1.13 2.52 2.52zm-1.26-1.26a2.52 2.52 0 0 1-2.52-2.52v-2.52h2.52a2.52 2.52 0 0 1 0 5.04z`,teams:`M19.5 7.5a2 2 0 1 0 0-4 2 2 0 0 0 0 4ZM17 9.5a3 3 0 0 1 3-3h1a2.5 2.5 0 0 1 2.5 2.5V11a2 2 0 0 1-2 2h-.5v3.5a1.5 1.5 0 0 1-3 0v-7ZM13 6a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5Zm-3 2.5A3.5 3.5 0 0 1 13.5 5h1A3.5 3.5 0 0 1 18 8.5V13a2.5 2.5 0 0 1-2.5 2.5h-.5V19a2 2 0 0 1-4 0v-3.5h-.5A2.5 2.5 0 0 1 8 13V8.5ZM7.5 10a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3ZM5 11.5a2 2 0 0 1 2-2h1a2 2 0 0 1 2 2V14a1.5 1.5 0 0 1-1.5 1.5H8V18a1 1 0 0 1-2 0v-2.5h-.5A1.5 1.5 0 0 1 4 14v-2.5Z`,x:`M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z`,linkedin:`M19 3a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h14m-.5 15.5v-5.3a3.26 3.26 0 0 0-3.26-3.26c-.85 0-1.84.52-2.28 1.3v-1.11h-2.79v8.37h2.79v-4.93c0-.77.62-1.4 1.39-1.4a1.4 1.4 0 0 1 1.4 1.4v4.93h2.75M6.88 8.56a1.68 1.68 0 0 0 1.68-1.68c0-.93-.75-1.69-1.68-1.69a1.69 1.69 0 0 0-1.69 1.69c0 .93.76 1.68 1.69 1.68m1.39 9.94v-8.37H5.5v8.37h2.77Z`,maps:`M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7Zm0 9.5a2.5 2.5 0 1 1 0-5 2.5 2.5 0 0 1 0 5Z`,custom:`M14 3h7v7h-2V6.4l-8.3 8.3-1.4-1.4L17.6 5H14V3ZM5 5h5v2H6.9v10H17v-3h2v5H4.9C3.8 19 3 18.2 3 17.1V6.9C3 5.8 3.8 5 5 5Z`};function ui(e,t=22){let n=li[e]||li.whatsapp;return d.createElement(`svg`,{viewBox:`0 0 24 24`,width:t,height:t,fill:`currentColor`,"aria-hidden":`true`,style:{width:t,height:t,display:`block`}},d.createElement(`path`,{fill:`currentColor`,d:n}))}var di=Object.fromEntries(Object.entries(li).map(([e,t])=>[e,`<svg viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="${t}"/></svg>`]));di.whatsapp,di.messenger,di.telegram,di.instagram,di.phone,di.email;var fi=async()=>{try{return{siteId:(await U.getProjectInfo().catch(()=>null))?.id??`chat_bubbles_local_site`,siteUrl:null,userId:null}}catch{return{siteId:`chat_bubbles_local_site`,siteUrl:null,userId:null}}},pi=!1,mi=!1;function hi(e,t,n){pi=e,mi=t}function gi(e){if(!e||typeof e!=`string`)return``;let t=e.trim(),n=t.toLowerCase();return n.indexOf(`url(`)!==-1||n.indexOf(`javascript:`)!==-1||n.indexOf(`<`)!==-1||n.indexOf(`>`)!==-1||n.indexOf(`;`)!==-1||n.indexOf(`"`)!==-1||n.indexOf(`'`)!==-1?``:n.indexOf(`linear-gradient(`)===0||n.indexOf(`radial-gradient(`)===0||n.indexOf(`#`)===0||n.indexOf(`rgb`)===0?t:``}function K(e,t){let n=e.channels?.find(e=>e.id===t);return n&&n.enabled&&n.value||``}function _i(e,t,n,r=mi,i=!pi){let a=Object.entries(li).map(([e,t])=>`  ${JSON.stringify(e)}: ${JSON.stringify(t)},`).join(`
`),o=gi(e.modalCustomGradient),s=e.modalTheme===`custom`&&o?o:Xr[e.modalTheme]||Xr.whatsapp,c=JSON.stringify(e.agents&&e.agents.length>0?e.agents:[{id:`agent-1`,name:`Alex`,role:`Support Manager`,avatar:Jr[0],channelId:`whatsapp`},{id:`agent-2`,name:`Sarah`,role:`Customer Support`,avatar:Jr[1],channelId:`messenger`},{id:`agent-3`,name:`David`,role:`Technical Team`,avatar:Jr[2],channelId:`telegram`}]);return`import * as React from "react"
import { addPropertyControls, ControlType, RenderTarget } from "framer"

const CHANNEL_PATHS: Record<string, string> = {
${a}
}

function sanitizeGradient(val?: string | null): string {
    if (!val || typeof val !== "string") return ""
    const trimmed = val.trim()
    const lower = trimmed.toLowerCase()
    if (
        lower.indexOf("url(") !== -1 ||
        lower.indexOf("javascript:") !== -1 ||
        lower.indexOf("<") !== -1 ||
        lower.indexOf(">") !== -1 ||
        lower.indexOf(";") !== -1 ||
        lower.indexOf('"') !== -1 ||
        lower.indexOf("'") !== -1
    ) {
        return ""
    }
    if (
        lower.indexOf("linear-gradient(") === 0 ||
        lower.indexOf("radial-gradient(") === 0 ||
        lower.indexOf("#") === 0 ||
        lower.indexOf("rgb") === 0
    ) {
        return trimmed
    }
    return ""
}

function renderChannelIcon(channelId: string, size: number = 22): React.ReactElement {
    const d = CHANNEL_PATHS[channelId] || CHANNEL_PATHS.whatsapp
    return (
        <svg
            viewBox="0 0 24 24"
            width={size}
            height={size}
            fill="currentColor"
            aria-hidden="true"
            className="cf-channel-icon-svg"
        >
            <path fill="currentColor" d={d} />
        </svg>
    )
}

function renderLauncherIcon(launcherIcon: string, isOpen: boolean, isLocked: boolean): React.ReactElement {
    if (isOpen) {
        return (
            <svg viewBox="0 0 24 24" width={22} height={22} fill="none" stroke="currentColor" strokeWidth={2.5} strokeLinecap="round">
                <path d="M12 5v14M5 12h14" />
            </svg>
        )
    }
    if (isLocked) {
        return (
            <svg viewBox="0 0 24 24" width={22} height={22} fill="none" stroke="currentColor" strokeWidth={2.5} strokeLinecap="round" strokeLinejoin="round">
                <rect x="3" y="11" width="18" height="11" rx="2" ry="2" />
                <path d="M7 11V7a5 5 0 0 1 10 0v4" />
            </svg>
        )
    }
    if (launcherIcon === "support") {
        return (
            <svg viewBox="0 0 24 24" width={24} height={24} fill="currentColor" aria-hidden="true">
                <path d="M12 2a9 9 0 0 0-9 9v4a3 3 0 0 0 3 3h1v-6H5v-1a7 7 0 1 1 14 0v1h-2v6h1a3 3 0 0 0 3-3v-4a9 9 0 0 0-9-9Zm-5 13v3H6a1 1 0 0 1-1-1v-2h2Zm12 2a1 1 0 0 1-1 1h-1v-3h2v2Z" />
            </svg>
        )
    }
    if (launcherIcon === "chat" || !CHANNEL_PATHS[launcherIcon]) {
        return (
            <svg viewBox="0 0 24 24" width={24} height={24} fill="currentColor" aria-hidden="true">
                <path d="M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2Zm0 14H5.2L4 17.2V4h16v12Z" />
                <circle cx="8" cy="10" r="1.5" />
                <circle cx="12" cy="10" r="1.5" />
                <circle cx="16" cy="10" r="1.5" />
            </svg>
        )
    }
    return (
        <svg viewBox="0 0 24 24" width={24} height={24} fill="currentColor" aria-hidden="true">
            <path fill="currentColor" d={CHANNEL_PATHS[launcherIcon]} />
        </svg>
    )
}

const GRADIENTS: Record<string, string> = {
  whatsapp: "linear-gradient(135deg, #25D366 0%, #128C7E 100%)",
  messenger: "linear-gradient(135deg, #0084FF 0%, #00C6FF 100%)",
  telegram: "linear-gradient(135deg, #2AABEE 0%, #229ED9 100%)",
  instagram: "linear-gradient(135deg, #833AB4 0%, #FD1D1D 50%, #FCB045 100%)",
  tiktok: "linear-gradient(135deg, #111111 0%, #1f2937 60%, #FE2C55 100%)",
  wechat: "linear-gradient(135deg, #07C160 0%, #048843 100%)",
  dark: "linear-gradient(135deg, #1f2937 0%, #111827 100%)",
  custom: ${JSON.stringify(s)},
}

interface ChatBubblesProps {
    style?: React.CSSProperties
    canvasPreview?: "modal" | "chat" | "closed"
    widgetMode?: "modal" | "buttons"
    modalTheme?: "whatsapp" | "messenger" | "telegram" | "instagram" | "tiktok" | "wechat" | "dark" | "custom"
    modalCustomGradient?: string
    modalTitle?: string
    modalSubtitle?: string
    modalResponseTime?: string
    modalChatBubble?: string
    modalStartChatText?: string
    position?: "bottom-right" | "bottom-left" | "top-right" | "top-left"
    layout?: "stack" | "grid" | "horizontal"
    animation?: "pop" | "bounce" | "slide" | "pulse" | "none"
    buttonColor?: string
    buttonShape?: "circle" | "rounded" | "pill"
    launcherText?: string
    launcherIcon?: "chat" | "whatsapp" | "messenger" | "telegram" | "instagram" | "phone" | "email" | "support"
    showLabels?: boolean
    mobileShowLabels?: boolean
    mobileOffsetX?: number
    mobileOffsetY?: number
    mobileCapChannels?: boolean
    closeOnOutsideClick?: boolean
    closeOnEscape?: boolean
    closeAfterClick?: boolean
    autoOpen?: boolean
    autoOpenDelay?: number
    ariaLabel?: string
    greetingEnabled?: boolean
    greetingText?: string
    greetingDelay?: number
    enableSound?: boolean
    showBadge?: boolean
    badgeText?: string
    whatsapp?: string
    whatsappMessage?: string
    messenger?: string
    telegram?: string
    telegramMessage?: string
    instagram?: string
    tiktok?: string
    wechat?: string
    viber?: string
    line?: string
    signal?: string
    phone?: string
    sms?: string
    smsMessage?: string
    email?: string
    emailSubject?: string
    emailMessage?: string
    discord?: string
    slack?: string
    teams?: string
    x?: string
    linkedin?: string
    maps?: string
    custom?: string
    customLabel?: string
    enableAnalytics?: boolean
    scrollTriggerEnabled?: boolean
    scrollTriggerPercent?: number
    scrollTriggerTarget?: "launcher" | "greeting"
    exitIntentEnabled?: boolean
    exitIntentAction?: "modal" | "greeting"
    scheduleEnabled?: boolean
    scheduleDays?: number[]
    scheduleStart?: string
    scheduleEnd?: string
    scheduleOfflineAction?: "badge" | "hide"
    scheduleOfflineText?: string
    targetingEnabled?: boolean
    showOn?: string
    canvasPagePath?: string
    targetingMode?: "show" | "hide"
    targetingRules?: string
    agentsData?: string
    scheduleDaysData?: string
}

// Web Audio Synthesizer singleton & gesture unlocker
let sharedChatAudioCtx: AudioContext | null = null
let pendingChimeQueued = false
let pendingChimeExpireTime = 0
let globalLastChimeTime = 0

function isFramerStudioCanvas(): boolean {
    if (typeof window === "undefined") return false
    try {
        if (typeof RenderTarget !== "undefined" && typeof RenderTarget.current === "function") {
            return RenderTarget.current() === RenderTarget.canvas
        }
    } catch {}
    return false
}

function getSharedAudioContext(): AudioContext | null {
    if (typeof window === "undefined") return null
    const AudioCtx = window.AudioContext || (window as any).webkitAudioContext
    if (!AudioCtx) return null
    if (!sharedChatAudioCtx || sharedChatAudioCtx.state === "closed") {
        try {
            sharedChatAudioCtx = new AudioCtx()
        } catch {
            return null
        }
    }
    return sharedChatAudioCtx
}

function unlockSharedAudioContext(ctx: AudioContext | null) {
    if (!ctx) return
    if (ctx.state === "suspended") {
        ctx.resume().catch(() => {})
    }
    // iOS Safari silent buffer unlock to ensure hardware audio routing is activated
    try {
        const buffer = ctx.createBuffer(1, 1, 22050)
        const source = ctx.createBufferSource()
        source.buffer = buffer
        source.connect(ctx.destination)
        source.start(0)
    } catch {}
}

function playSynthesizedTone(ctx: AudioContext) {
    try {
        const now = ctx.currentTime

        // Crisp 2-tone melodic chime: Note 1 D5 (587.33 Hz) -> Note 2 A5 (880 Hz)
        const osc1 = ctx.createOscillator()
        const gain1 = ctx.createGain()
        osc1.type = "sine"
        osc1.frequency.setValueAtTime(587.33, now)
        gain1.gain.setValueAtTime(0.0001, now)
        gain1.gain.linearRampToValueAtTime(0.24, now + 0.015)
        gain1.gain.exponentialRampToValueAtTime(0.0001, now + 0.22)
        osc1.connect(gain1)
        gain1.connect(ctx.destination)
        osc1.start(now)
        osc1.stop(now + 0.22)

        const osc2 = ctx.createOscillator()
        const gain2 = ctx.createGain()
        osc2.type = "sine"
        osc2.frequency.setValueAtTime(880, now + 0.08)
        gain2.gain.setValueAtTime(0.0001, now + 0.08)
        gain2.gain.linearRampToValueAtTime(0.28, now + 0.095)
        gain2.gain.exponentialRampToValueAtTime(0.0001, now + 0.40)
        osc2.connect(gain2)
        gain2.connect(ctx.destination)
        osc2.start(now + 0.08)
        osc2.stop(now + 0.40)
    } catch {}
}

function playNotificationChimeDirect(force: boolean = false) {
    try {
        if (typeof window === "undefined") return
        // Never play chime when in Framer design canvas mode
        if (isFramerStudioCanvas()) return

        const now = Date.now()
        // Framer mounts multiple variant breakpoints (Desktop, Tablet, Mobile) in the DOM simultaneously.
        // A 1200ms debounce prevents simultaneous breakpoint mounts from echoing without silencing real notifications.
        if (!force && now - globalLastChimeTime < 1200) {
            return
        }

        const ctx = getSharedAudioContext()
        if (!ctx) return

        if (ctx.state === "running") {
            playSynthesizedTone(ctx)
            globalLastChimeTime = now
            pendingChimeQueued = false
            pendingChimeExpireTime = 0
        } else {
            // AudioContext is suspended (browser autoplay policy on live sites)
            // Mark pending so the first user interaction immediately flushes the chime
            pendingChimeQueued = true
            pendingChimeExpireTime = now + 15000 // Valid for 15s while greeting is active
            ctx.resume().then(() => {
                if (ctx.state === "running") {
                    const currentNow = Date.now()
                    if (!force && currentNow - globalLastChimeTime < 1200) {
                        return
                    }
                    playSynthesizedTone(ctx)
                    globalLastChimeTime = currentNow
                    pendingChimeQueued = false
                    pendingChimeExpireTime = 0
                }
            }).catch(() => {
                pendingChimeQueued = true
            })
        }
    } catch {
        pendingChimeQueued = true
    }
}

function flushPendingChimeIfQueued() {
    if (!pendingChimeQueued) return
    const now = Date.now()
    if (pendingChimeExpireTime && now > pendingChimeExpireTime) {
        pendingChimeQueued = false
        pendingChimeExpireTime = 0
        return
    }
    if (now - globalLastChimeTime < 1200) return

    const ctx = getSharedAudioContext()
    if (!ctx) return

    unlockSharedAudioContext(ctx)

    if (ctx.state === "running") {
        playSynthesizedTone(ctx)
        globalLastChimeTime = now
        pendingChimeQueued = false
        pendingChimeExpireTime = 0
    } else {
        ctx.resume().then(() => {
            if (ctx.state === "running") {
                const currentNow = Date.now()
                if (currentNow - globalLastChimeTime < 1200) return
                playSynthesizedTone(ctx)
                globalLastChimeTime = currentNow
                pendingChimeQueued = false
                pendingChimeExpireTime = 0
            }
        }).catch(() => {})
    }
}

function cancelPendingChime() {
    pendingChimeQueued = false
    pendingChimeExpireTime = 0
}

function resolveBreakpointKey(el: HTMLElement | null): string {
    if (!el || typeof window === "undefined") return "desktop"
    try {
        let cur: HTMLElement | null = el.parentElement
        while (cur && cur !== document.body) {
            const nameAttr = (cur.getAttribute("data-framer-name") || cur.getAttribute("name") || "").toLowerCase().trim()
            if (nameAttr.includes("phone") || nameAttr.includes("mobile") || nameAttr.includes("iphone") || nameAttr.includes("android")) {
                return "phone"
            }
            if (nameAttr.includes("tablet") || nameAttr.includes("ipad")) {
                return "tablet"
            }
            if (nameAttr.includes("desktop") || nameAttr.includes("laptop") || nameAttr.includes("screen") || nameAttr.includes("macbook")) {
                return "desktop"
            }
            const bpAttr = (cur.getAttribute("data-framer-breakpoint") || cur.getAttribute("data-breakpoint") || "").toLowerCase().trim()
            if (bpAttr) {
                if (bpAttr.includes("phone") || bpAttr.includes("mobile")) return "phone"
                if (bpAttr.includes("tablet")) return "tablet"
                if (bpAttr.includes("desktop")) return "desktop"
                return bpAttr
            }
            cur = cur.parentElement
        }

        cur = el.parentElement
        while (cur && cur !== document.body) {
            const rect = cur.getBoundingClientRect()
            if (rect.width >= 100 && rect.width < 10000) {
                if (rect.width < 600) return "phone"
                if (rect.width < 1000) return "tablet"
                return "desktop"
            }
            cur = cur.parentElement
        }

        const winW = window.innerWidth
        if (winW < 600) return "phone"
        if (winW < 1000) return "tablet"
        return "desktop"
    } catch {
        return "desktop"
    }
}

export default function ChatBubbles(props: ChatBubblesProps) {
    const {
        style,
        canvasPreview = "modal",
        widgetMode = ${JSON.stringify(e.widgetMode||`modal`)},
        modalTheme = ${JSON.stringify(e.modalTheme||`whatsapp`)},
        modalCustomGradient = ${JSON.stringify(e.modalCustomGradient||``)},
        modalTitle = ${JSON.stringify(e.modalTitle||`Hi there!`)},
        modalSubtitle = ${JSON.stringify(e.modalSubtitle||`Welcome to our live chat! Feel free to ask any questions.`)},
        modalResponseTime = ${JSON.stringify(e.modalResponseTime||`We typically reply within a few minutes`)},
        modalChatBubble = ${JSON.stringify(e.modalChatBubble||`We typically reply within a few minutes. How can we help you today?`)},
        modalStartChatText = ${JSON.stringify(e.modalStartChatText||`Start chat`)},
        position = ${JSON.stringify(e.position||`bottom-right`)},
        layout = ${JSON.stringify(e.layout||`stack`)},
        animation = ${JSON.stringify(e.animation||`pop`)},
        buttonColor = ${JSON.stringify(e.buttonColor||`#25D366`)},
        buttonShape = ${JSON.stringify(e.buttonShape||`circle`)},
        launcherText = "Chat",
        launcherIcon = ${JSON.stringify(e.launcherIcon||`chat`)},
        showLabels = ${!!e.showLabels},
        mobileShowLabels = ${!!(e.mobileShowLabels??!1)},
        mobileOffsetX = ${Number(e.mobileOffsetX??16)},
        mobileOffsetY = ${Number(e.mobileOffsetY??16)},
        mobileCapChannels = ${!!(e.mobileCapChannels??!0)},
        closeOnOutsideClick = ${!!(e.closeOnOutsideClick??!0)},
        closeOnEscape = ${!!(e.closeOnEscape??!0)},
        closeAfterClick = ${!!(e.closeAfterClick??!0)},
        autoOpen = ${!!e.autoOpen},
        autoOpenDelay = ${Number(e.autoOpenDelay??1200)},
        ariaLabel = ${JSON.stringify(e.ariaLabel||`Open chat options`)},
        greetingEnabled = ${!!e.greetingEnabled},
        greetingText = ${JSON.stringify(e.greetingText||`Need help? Chat with us.`)},
        greetingDelay = ${Number(e.greetingDelay??2e3)},
        enableSound = ${!!e.enableSound},
        showBadge = ${!!e.showBadge},
        badgeText = ${JSON.stringify(e.badgeText||`1`)},
        enableAnalytics = ${e.enableAnalytics!==!1},
        scrollTriggerEnabled = ${!!e.scrollTriggerEnabled},
        scrollTriggerPercent = ${Number(e.scrollTriggerPercent??25)},
        scrollTriggerTarget = ${JSON.stringify(e.scrollTriggerTarget||`launcher`)},
        exitIntentEnabled = ${!!e.exitIntentEnabled},
        exitIntentAction = ${JSON.stringify(e.exitIntentAction||`modal`)},
        scheduleEnabled = ${!!e.scheduleEnabled},
        scheduleDays = ${JSON.stringify(e.scheduleDays||[1,2,3,4,5])},
        scheduleStart = ${JSON.stringify(e.scheduleStart||`09:00`)},
        scheduleEnd = ${JSON.stringify(e.scheduleEnd||`18:00`)},
        scheduleOfflineAction = ${JSON.stringify(e.scheduleOfflineAction||`badge`)},
        scheduleOfflineText = ${JSON.stringify(e.scheduleOfflineText||`Back tomorrow at 9:00 AM`)},
        targetingEnabled = true,
        showOn = ${JSON.stringify(e.showOn||`Every page`)},
        canvasPagePath = "",
        targetingMode = ${JSON.stringify(e.targetingMode||`show`)},
        targetingRules = ${JSON.stringify(e.targetingRules||``)},
        agentsData = ${JSON.stringify(JSON.stringify(e.agents||[]))},
        scheduleDaysData = ${JSON.stringify(JSON.stringify(e.scheduleDays||[1,2,3,4,5]))},
        whatsapp = ${JSON.stringify(K(e,`whatsapp`))},
        whatsappMessage = ${JSON.stringify(e.channels.find(e=>e.id===`whatsapp`)?.message||`Hello! I would like to know more.`)},
        messenger = ${JSON.stringify(K(e,`messenger`))},
        telegram = ${JSON.stringify(K(e,`telegram`))},
        telegramMessage = ${JSON.stringify(e.channels.find(e=>e.id===`telegram`)?.message||`Hello!`)},
        instagram = ${JSON.stringify(K(e,`instagram`))},
        tiktok = ${JSON.stringify(K(e,`tiktok`))},
        wechat = ${JSON.stringify(K(e,`wechat`))},
        viber = ${JSON.stringify(K(e,`viber`))},
        line = ${JSON.stringify(K(e,`line`))},
        signal = ${JSON.stringify(K(e,`signal`))},
        phone = ${JSON.stringify(K(e,`phone`))},
        sms = ${JSON.stringify(K(e,`sms`))},
        smsMessage = ${JSON.stringify(e.channels.find(e=>e.id===`sms`)?.message||``)},
        email = ${JSON.stringify(K(e,`email`))},
        emailSubject = ${JSON.stringify(e.channels.find(e=>e.id===`email`)?.emailSubject||``)},
        emailMessage = ${JSON.stringify(e.channels.find(e=>e.id===`email`)?.message||``)},
        discord = ${JSON.stringify(K(e,`discord`))},
        slack = ${JSON.stringify(K(e,`slack`))},
        teams = ${JSON.stringify(K(e,`teams`))},
        x = ${JSON.stringify(K(e,`x`))},
        linkedin = ${JSON.stringify(K(e,`linkedin`))},
        maps = ${JSON.stringify(K(e,`maps`))},
        custom = ${JSON.stringify(K(e,`custom`))},
        customLabel = ${JSON.stringify(e.channels.find(e=>e.id===`custom`)?.label||`Custom`)},
    } = props

    const isCanvas = typeof RenderTarget !== "undefined" && typeof RenderTarget.current === "function" && RenderTarget.current() === RenderTarget.canvas
    // @chat-bubbles-lock-state: ${i?`locked`:`unlocked`}
    const IS_LOCKED = ${!!i}
    const showBranding = ${!!r}
    const ANALYTICS_ENABLED = ${e.enableAnalytics!==!1}
    const FORWARD_THIRD_PARTY_ANALYTICS = ${!!e.forwardEventsToSiteAnalytics}
    const WIDGET_ID = ${JSON.stringify(e.widgetId||`chat-bubbles-default`)}
    const containerRef = React.useRef<HTMLDivElement>(null)
    const [isOpen, setIsOpen] = React.useState(isCanvas ? canvasPreview !== "closed" : false)
    const [greetingDismissed, setGreetingDismissed] = React.useState(false)
    const [selectedAgent, setSelectedAgent] = React.useState<any | null>(null)
    const [navDirection, setNavDirection] = React.useState<"forward" | "backward">("forward")
    const [customMessage, setCustomMessage] = React.useState("")
    const [mobileExpanded, setMobileExpanded] = React.useState(false)

    // Single-instance duplicate protection: allows 1 instance per responsive breakpoint (Desktop, Tablet, Mobile)
    const instanceId = React.useMemo(() => Math.random().toString(36).slice(2, 9), [])
    const [isDuplicate, setIsDuplicate] = React.useState(false)

    React.useEffect(() => {
        if (typeof window === "undefined") return
        const w = window as any
        w.__chat_bubbles_instances_by_bp__ = w.__chat_bubbles_instances_by_bp__ || {}

        let registeredBp = ""
        function register() {
            const el = containerRef.current
            const bpKey = resolveBreakpointKey(el)
            if (registeredBp && registeredBp !== bpKey) {
                const oldArr = w.__chat_bubbles_instances_by_bp__[registeredBp]
                if (oldArr) {
                    const idx = oldArr.indexOf(instanceId)
                    if (idx >= 0) oldArr.splice(idx, 1)
                }
            }
            registeredBp = bpKey
            w.__chat_bubbles_instances_by_bp__[bpKey] = w.__chat_bubbles_instances_by_bp__[bpKey] || []
            const reg: string[] = w.__chat_bubbles_instances_by_bp__[bpKey]
            if (reg.indexOf(instanceId) === -1) {
                reg.push(instanceId)
            }
            setIsDuplicate(reg.indexOf(instanceId) > 0)
        }

        register()
        const timer1 = setTimeout(register, 50)
        const timer2 = setTimeout(register, 250)

        return () => {
            clearTimeout(timer1)
            clearTimeout(timer2)
            if (registeredBp && w.__chat_bubbles_instances_by_bp__ && w.__chat_bubbles_instances_by_bp__[registeredBp]) {
                const arr: string[] = w.__chat_bubbles_instances_by_bp__[registeredBp]
                const idx = arr.indexOf(instanceId)
                if (idx >= 0) {
                    arr.splice(idx, 1)
                }
            }
        }
    }, [instanceId])

    // Delays normalization (supports milliseconds or seconds)
    const finalGreetingDelay = Number(greetingDelay ?? 2000) > 60 ? Number(greetingDelay ?? 2000) : Number(greetingDelay ?? 2) * 1000
    const finalAutoOpenDelay = Number(autoOpenDelay ?? 1200) > 60 ? Number(autoOpenDelay ?? 1200) : Number(autoOpenDelay ?? 1.2) * 1000

    // 1. Operating Hours & Days Schedule Calculation
    const activeScheduleDays = React.useMemo(() => {
        if (typeof scheduleDaysData === "string" && scheduleDaysData.trim()) {
            try {
                const parsed = JSON.parse(scheduleDaysData)
                if (Array.isArray(parsed)) return parsed
            } catch {}
        }
        return Array.isArray(scheduleDays) ? scheduleDays : [1, 2, 3, 4, 5]
    }, [scheduleDaysData, scheduleDays])

    const isOffline = React.useMemo(() => {
        if (isCanvas || !scheduleEnabled) return false
        try {
            const now = new Date()
            const curDay = now.getDay()
            if (!activeScheduleDays.includes(curDay)) return true
            const curMins = now.getHours() * 60 + now.getMinutes()
            const sParts = String(scheduleStart || "09:00").split(":")
            const eParts = String(scheduleEnd || "18:00").split(":")
            const sMins = (parseInt(sParts[0], 10) || 9) * 60 + (parseInt(sParts[1], 10) || 0)
            const eMins = (parseInt(eParts[0], 10) || 18) * 60 + (parseInt(eParts[1], 10) || 0)
            if (sMins <= eMins) {
                return curMins < sMins || curMins >= eMins
            } else {
                return curMins < sMins && curMins >= eMins
            }
        } catch {
            return false
        }
    }, [isCanvas, scheduleEnabled, activeScheduleDays, scheduleStart, scheduleEnd])

    // 2. Event-Driven Location Tracker for Page Targeting & SPA Navigation in Framer
    const [currentLocationPath, setCurrentLocationPath] = React.useState(() => {
        return typeof window !== "undefined" && window.location && window.location.pathname ? window.location.pathname : "/"
    })

    React.useEffect(() => {
        if (typeof window === "undefined" || isCanvas) return
        function syncLocationPath() {
            try {
                const next = window.location && window.location.pathname ? window.location.pathname : "/"
                setCurrentLocationPath((prev: string) => (prev !== next ? next : prev))
            } catch {}
        }

        window.addEventListener("popstate", syncLocationPath)
        window.addEventListener("hashchange", syncLocationPath)

        // Event-driven navigation tracking: intercept pushState and replaceState without polling timers
        const originalPush = window.history ? window.history.pushState : null
        const originalReplace = window.history ? window.history.replaceState : null

        if (originalPush && typeof originalPush === "function") {
            try {
                window.history.pushState = function(...args: any[]) {
                    const ret = originalPush.apply(this, args)
                    syncLocationPath()
                    return ret
                }
            } catch {}
        }

        if (originalReplace && typeof originalReplace === "function") {
            try {
                window.history.replaceState = function(...args: any[]) {
                    const ret = originalReplace.apply(this, args)
                    syncLocationPath()
                    return ret
                }
            } catch {}
        }

        return () => {
            window.removeEventListener("popstate", syncLocationPath)
            window.removeEventListener("hashchange", syncLocationPath)
            if (originalPush) {
                try {
                    window.history.pushState = originalPush
                } catch {}
            }
            if (originalReplace) {
                try {
                    window.history.replaceState = originalReplace
                } catch {}
            }
        }
    }, [isCanvas])

    // Page / URL Targeting Filter (supports dropdown page selection, custom paths, subpaths, trailing slashes, and wildcards)
    const isTargetingAllowed = React.useMemo(() => {
        const effectiveShowOn = showOn || "Every page"
        if (effectiveShowOn === "Every page") return true

        const normPath = (p: string) => {
            let s = (p || "").trim().toLowerCase()
            if (s === "home page") return ""
            while (s.startsWith("/")) s = s.substring(1)
            while (s.endsWith("/")) s = s.slice(0, -1)
            return s
        }

        // On Canvas Studio
        if (isCanvas) {
            if (!canvasPagePath) return true
            const canvasNorm = normPath(canvasPagePath)
            if (effectiveShowOn === "Home page") {
                return canvasNorm === "" || canvasNorm === "index" || canvasNorm === "home"
            }
            if (effectiveShowOn !== "custom") {
                return canvasNorm === normPath(effectiveShowOn)
            }
            if (!targetingRules) return true
            const curPath = (canvasPagePath.startsWith("/") ? canvasPagePath : "/" + canvasPagePath).toLowerCase().trim()
            try {
                const rawRules = String(targetingRules)
                    .split(",")
                    .flatMap((part: string) => part.split(String.fromCharCode(10)))
                    .flatMap((part: string) => part.split(";"))
                const rules = rawRules.map((r: string) => r.trim().toLowerCase()).filter(Boolean)
                if (rules.length === 0) return true
                const isMatch = rules.some((ruleInput: string) => {
                    let rule = ruleInput
                    if (rule === "*" || rule === "/*") return true
                    if (rule.includes("://") || rule.includes(".")) {
                        try {
                            const parsed = new URL(rule.includes("://") ? rule : "https://" + rule)
                            rule = parsed.pathname
                        } catch {}
                    }
                    const cleanRule = rule.startsWith("/") ? rule : "/" + rule
                    const isHomeRule = cleanRule === "/" || cleanRule === "/home" || cleanRule === "/index"
                    const isHomePath = curPath === "/" || curPath === "" || curPath === "/home" || curPath === "/index"
                    if (isHomeRule && isHomePath) return true
                    if (cleanRule.endsWith("/*")) {
                        const prefix = cleanRule.slice(0, -2)
                        return curPath === prefix || curPath === prefix + "/" || curPath.startsWith(prefix + "/")
                    }
                    if (cleanRule.endsWith("*")) {
                        const prefix = cleanRule.slice(0, -1)
                        return curPath.startsWith(prefix)
                    }
                    let ruleNoSlash = cleanRule
                    while (ruleNoSlash.endsWith("/")) ruleNoSlash = ruleNoSlash.slice(0, -1)
                    let pathNoSlash = curPath
                    while (pathNoSlash.endsWith("/")) pathNoSlash = pathNoSlash.slice(0, -1)
                    return curPath === cleanRule || pathNoSlash === ruleNoSlash
                })
                return targetingMode === "hide" ? !isMatch : isMatch
            } catch {
                return true
            }
        }

        // Live published site or preview mode
        const curPath = (currentLocationPath || "/").toLowerCase().trim()
        const currentNorm = normPath(curPath)

        if (effectiveShowOn === "Home page") {
            return currentNorm === "" || currentNorm === "index" || currentNorm === "index.html" || currentNorm === "home"
        }
        if (effectiveShowOn !== "custom") {
            const targetNorm = normPath(effectiveShowOn)
            return currentNorm === targetNorm
        }

        // Custom URL rules & wildcards
        if (!targetingRules) return true
        try {
            const curHref = (typeof window !== "undefined" && window.location && window.location.href ? window.location.href : "").toLowerCase()
            const rawRules = String(targetingRules)
                .split(",")
                .flatMap((part: string) => part.split(String.fromCharCode(10)))
                .flatMap((part: string) => part.split(";"))
            const rules = rawRules.map((r: string) => r.trim().toLowerCase()).filter(Boolean)
            if (rules.length === 0) return true

            const isMatch = rules.some((ruleInput: string) => {
                let rule = ruleInput
                if (rule === "*" || rule === "/*") return true

                // Full URL match if protocol or host provided
                if (rule.includes("://") || rule.includes(".")) {
                    if (curHref === rule || curHref === rule + "/") return true
                    if (rule.endsWith("*") && curHref.startsWith(rule.slice(0, -1))) return true
                    try {
                        const parsed = new URL(rule.includes("://") ? rule : "https://" + rule)
                        rule = parsed.pathname
                    } catch {}
                }

                const cleanRule = rule.startsWith("/") ? rule : "/" + rule

                const isHomeRule = cleanRule === "/" || cleanRule === "/home" || cleanRule === "/index"
                const isHomePath = curPath === "/" || curPath === "" || curPath === "/home" || curPath === "/index"
                if (isHomeRule && isHomePath) return true

                if (cleanRule.endsWith("/*")) {
                    const prefix = cleanRule.slice(0, -2)
                    return curPath === prefix || curPath === prefix + "/" || curPath.startsWith(prefix + "/")
                }
                if (cleanRule.endsWith("*")) {
                    const prefix = cleanRule.slice(0, -1)
                    return curPath.startsWith(prefix)
                }

                let ruleNoSlash = cleanRule
                while (ruleNoSlash.endsWith("/")) ruleNoSlash = ruleNoSlash.slice(0, -1)
                let pathNoSlash = curPath
                while (pathNoSlash.endsWith("/")) pathNoSlash = pathNoSlash.slice(0, -1)
                return curPath === cleanRule || pathNoSlash === ruleNoSlash
            })

            return targetingMode === "hide" ? !isMatch : isMatch
        } catch {
            return true
        }
    }, [isCanvas, showOn, canvasPagePath, targetingRules, targetingMode, currentLocationPath])

    // Strict visibility guard: if hidden by targeting or operating schedule, widget returns null & suppresses sound
    const isWidgetHidden = !isTargetingAllowed || (!isCanvas && scheduleEnabled && isOffline && scheduleOfflineAction === "hide")

    // Local anonymous deduplicated aggregate view tracking for live site visitors (CRO)
    React.useEffect(() => {
        if (isCanvas || !enableAnalytics || !ANALYTICS_ENABLED || isWidgetHidden) return
        try {
            const sessionKey = "cb_viewed_" + WIDGET_ID
            if (typeof sessionStorage !== "undefined" && !sessionStorage.getItem(sessionKey)) {
                sessionStorage.setItem(sessionKey, "true")
            }
            if (FORWARD_THIRD_PARTY_ANALYTICS) {
                if (Array.isArray((window as any).dataLayer)) {
                    (window as any).dataLayer.push({ event: "chat_bubbles_view", event_category: "Chat Bubbles" })
                }
                if (typeof (window as any).gtag === "function") {
                    (window as any).gtag("event", "chat_bubbles_view", { event_category: "Chat Bubbles", event_label: "widget_view" })
                }
            }
        } catch {}
    }, [isCanvas, enableAnalytics, isWidgetHidden])

    const trackChannelClick = React.useCallback((channelId: string) => {
        if (isCanvas || !enableAnalytics || !ANALYTICS_ENABLED) return
        try {
            if (FORWARD_THIRD_PARTY_ANALYTICS) {
                if (Array.isArray((window as any).dataLayer)) {
                    (window as any).dataLayer.push({ event: "chat_bubbles_click", event_category: "Chat Bubbles", channel_id: channelId })
                }
                if (typeof (window as any).gtag === "function") {
                    (window as any).gtag("event", "chat_bubbles_click", { event_category: "Chat Bubbles", event_label: channelId })
                }
            }
        } catch {}
    }, [isCanvas, enableAnalytics])

    // Web Audio Synthesizer chime for notifications (never plays on Canvas design preview or when hidden or locked)
    const playNotificationChime = React.useCallback((force: boolean = false) => {
        if (isCanvas || !enableSound || isWidgetHidden || IS_LOCKED) return
        playNotificationChimeDirect(force)
    }, [isCanvas, enableSound, isWidgetHidden, IS_LOCKED])

    // Unlock audio on real user gesture (click/tap/scroll/key) and immediately flush pending chime
    React.useEffect(() => {
        if (isCanvas || isWidgetHidden || !enableSound) return

        function handleUserInteraction() {
            if (isCanvas || isWidgetHidden || !enableSound) return
            const ctx = getSharedAudioContext()
            if (ctx) {
                unlockSharedAudioContext(ctx)
            }
            flushPendingChimeIfQueued()
        }

        const gestureEvents = ["pointerdown", "mousedown", "touchstart", "click", "keydown", "scroll", "wheel"]
        gestureEvents.forEach((evt) => {
            window.addEventListener(evt, handleUserInteraction, { passive: true, capture: true })
        })

        return () => {
            gestureEvents.forEach((evt) => {
                window.removeEventListener(evt, handleUserInteraction, { capture: true })
            })
        }
    }, [isCanvas, isWidgetHidden, enableSound])

    // 3. Scroll Depth Trigger State (checks if configured Depth % is already within the visible screen viewpoint)
    const [scrollPassed, setScrollPassed] = React.useState(() => {
        if (isCanvas || !scrollTriggerEnabled) return true
        if (typeof window === "undefined") return false
        try {
            const clientHeight = window.innerHeight || (document.documentElement ? document.documentElement.clientHeight : 0)
            const scrollHeight = Math.max(
                document.documentElement ? document.documentElement.scrollHeight : 0,
                document.body ? document.body.scrollHeight : 0,
                clientHeight
            )
            if (scrollHeight <= 0) return true
            const scrollTop = window.scrollY || window.pageYOffset || (document.documentElement ? document.documentElement.scrollTop : 0) || 0
            const visibleScreenDepth = ((scrollTop + clientHeight) / scrollHeight) * 100
            return visibleScreenDepth >= scrollTriggerPercent
        } catch {
            return false
        }
    })

    React.useEffect(() => {
        if (isCanvas || !scrollTriggerEnabled || isWidgetHidden) {
            setScrollPassed(true)
            return
        }
        function checkScroll(e?: Event) {
            try {
                let targetEl: HTMLElement | null = null
                if (e && e.target && e.target !== document && (e.target as HTMLElement).scrollHeight) {
                    targetEl = e.target as HTMLElement
                }
                const scrollTop = targetEl
                    ? targetEl.scrollTop
                    : (window.scrollY || window.pageYOffset || (document.documentElement ? document.documentElement.scrollTop : 0) || (document.scrollingElement ? (document.scrollingElement as HTMLElement).scrollTop : 0) || (document.body ? document.body.scrollTop : 0))
                const scrollHeight = targetEl
                    ? targetEl.scrollHeight
                    : Math.max(
                        document.documentElement ? document.documentElement.scrollHeight : 0,
                        document.body ? document.body.scrollHeight : 0,
                        document.scrollingElement ? (document.scrollingElement as HTMLElement).scrollHeight : 0
                    )
                const clientHeight = targetEl
                    ? targetEl.clientHeight
                    : (window.innerHeight || (document.documentElement ? document.documentElement.clientHeight : 0))
                const docHeight = scrollHeight - clientHeight
                if (docHeight <= 50) {
                    setScrollPassed(true)
                    return
                }
                // Visible screen depth: percentage of total document that has entered the visible viewpoint
                const visibleScreenDepth = scrollHeight > 0 ? ((scrollTop + clientHeight) / scrollHeight) * 100 : 100
                // Scroll travel: percentage of the scrollable track that has been scrolled
                const scrollTravel = docHeight > 0 ? (scrollTop / docHeight) * 100 : 100
                const currentDepth = Math.max(visibleScreenDepth, scrollTravel)

                if (currentDepth >= scrollTriggerPercent) {
                    setScrollPassed(true)
                }
            } catch {}
        }
        window.addEventListener("scroll", checkScroll, { passive: true, capture: true })
        window.addEventListener("resize", checkScroll, { passive: true })
        checkScroll()

        const frameId = requestAnimationFrame(() => checkScroll())

        return () => {
            cancelAnimationFrame(frameId)
            window.removeEventListener("scroll", checkScroll, { capture: true })
            window.removeEventListener("resize", checkScroll)
        }
    }, [isCanvas, scrollTriggerEnabled, scrollTriggerPercent, isWidgetHidden])

    // 4. Greeting Bubble Visibility (syncs with greetingDelay, sound, and scrollTrigger)
    const [greetingVisible, setGreetingVisible] = React.useState(isCanvas ? greetingEnabled : false)

    React.useEffect(() => {
        if (isCanvas) {
            setGreetingVisible(greetingEnabled)
            return
        }
        if (isWidgetHidden || !greetingEnabled || greetingDismissed) {
            setGreetingVisible(false)
            return
        }

        if (scrollTriggerEnabled && scrollTriggerTarget === "greeting") {
            if (scrollPassed) {
                setGreetingVisible(true)
                if (enableSound && !isWidgetHidden) playNotificationChime()
            }
            return
        }

        const timer = setTimeout(() => {
            if (!isWidgetHidden && !greetingDismissed) {
                setGreetingVisible(true)
                if (enableSound && !isWidgetHidden) playNotificationChime()
            }
        }, finalGreetingDelay)
        return () => clearTimeout(timer)
    }, [isCanvas, isWidgetHidden, greetingEnabled, greetingDismissed, scrollTriggerEnabled, scrollTriggerTarget, scrollPassed, finalGreetingDelay, enableSound, playNotificationChime])

    // 5. Desktop Exit-Intent Trigger (fires when cursor moves towards browser tabs / address bar)
    const exitIntentFiredRef = React.useRef(false)
    React.useEffect(() => {
        if (isCanvas || !exitIntentEnabled || isWidgetHidden) return

        function triggerExitIntent() {
            if (exitIntentFiredRef.current || isWidgetHidden) return
            exitIntentFiredRef.current = true
            if (exitIntentAction === "modal") {
                setIsOpen(true)
            } else if (exitIntentAction === "greeting") {
                setGreetingVisible(true)
                if (enableSound && !isWidgetHidden) playNotificationChime()
            }
        }

        // 1. Mouse leaving html document root towards browser chrome (tabs / address bar)
        function handleHtmlMouseLeave(e: MouseEvent) {
            if (e.clientY <= 30 || !e.relatedTarget) {
                triggerExitIntent()
            }
        }

        // 2. Window mouseout when leaving viewport into browser chrome
        function handleWindowMouseOut(e: MouseEvent) {
            const from = e.relatedTarget || (e as any).toElement
            if (!from && (e.clientY <= 40 || e.clientY <= 0)) {
                triggerExitIntent()
            }
        }

        // 3. Fast upward flick towards top boundary (tabs / close button)
        function handleWindowMouseMove(e: MouseEvent) {
            if (e.clientY <= 20) {
                triggerExitIntent()
            }
        }

        document.documentElement.addEventListener("mouseleave", handleHtmlMouseLeave)
        window.addEventListener("mouseout", handleWindowMouseOut)
        window.addEventListener("mousemove", handleWindowMouseMove, { passive: true })

        return () => {
            document.documentElement.removeEventListener("mouseleave", handleHtmlMouseLeave)
            window.removeEventListener("mouseout", handleWindowMouseOut)
            window.removeEventListener("mousemove", handleWindowMouseMove)
        }
    }, [isCanvas, exitIntentEnabled, exitIntentAction, enableSound, playNotificationChime, isWidgetHidden])

    // 6. Behavioral Auto-Open
    React.useEffect(() => {
        if (!isCanvas && !isWidgetHidden && autoOpen) {
            const timer = setTimeout(() => {
                if (!isWidgetHidden) setIsOpen(true)
            }, finalAutoOpenDelay)
            return () => clearTimeout(timer)
        }
    }, [isCanvas, isWidgetHidden, autoOpen, finalAutoOpenDelay])

    React.useEffect(() => {
        if (!isOpen) return
        if (isCanvas) return
        function handleKeyDown(e: KeyboardEvent) {
            if (closeOnEscape && e.key === "Escape") {
                setIsOpen(false)
                setSelectedAgent(null)
                setNavDirection("forward")
            }
        }
        function handleClickOutside(e: MouseEvent) {
            if (!containerRef.current) return
            const path = typeof e.composedPath === "function" ? e.composedPath() : []
            if (path.length > 0) {
                if (path.includes(containerRef.current)) return
            } else {
                const target = e.target as Node | null
                if (target && (containerRef.current.contains(target) || !document.contains(target))) return
            }
            if (closeOnOutsideClick) {
                setIsOpen(false)
                setSelectedAgent(null)
                setNavDirection("forward")
            }
        }

        const timer = setTimeout(() => {
            window.addEventListener("click", handleClickOutside)
        }, 0)
        window.addEventListener("keydown", handleKeyDown)

        return () => {
            clearTimeout(timer)
            window.removeEventListener("keydown", handleKeyDown)
            window.removeEventListener("click", handleClickOutside)
        }
    }, [isOpen, closeOnEscape, closeOnOutsideClick])

    const rawAgents = React.useMemo(() => {
        if (typeof agentsData === "string" && agentsData.trim()) {
            try {
                const parsed = JSON.parse(agentsData)
                if (Array.isArray(parsed) && parsed.length > 0) return parsed
            } catch {}
        }
        return ${c}
    }, [agentsData])

    // Synchronize canvas preview state in Framer design canvas mode
    React.useEffect(() => {
        if (isCanvas) {
            setIsOpen(canvasPreview !== "closed")
            if (canvasPreview === "chat" && rawAgents.length > 0) {
                setNavDirection("forward")
                setSelectedAgent(rawAgents[0])
            } else if (canvasPreview !== "chat") {
                setNavDirection("backward")
                setSelectedAgent(null)
            }
        }
    }, [isCanvas, canvasPreview, rawAgents])

    const channels = React.useMemo(() => {
        const list: Array<{ id: string; label: string; url: string; color: string; value: string; message: string }> = []
        if (whatsapp && whatsapp.trim()) {
            const clean = whatsapp.replace(/[^0-9]/g, "")
            const msg = whatsappMessage ? "?text=" + encodeURIComponent(whatsappMessage) : ""
            list.push({ id: "whatsapp", label: "WhatsApp", url: "https://wa.me/" + clean + msg, color: "#25D366", value: whatsapp, message: whatsappMessage })
        }
        if (messenger && messenger.trim()) {
            const handle = messenger.replace(/^@/, "").replace(/[^a-zA-Z0-9._-]/g, "")
            list.push({ id: "messenger", label: "Messenger", url: "https://m.me/" + handle, color: "#0084FF", value: messenger, message: "" })
        }
        if (telegram && telegram.trim()) {
            const handle = telegram.replace(/^@/, "").replace(/[^a-zA-Z0-9._-]/g, "")
            const msg = telegramMessage ? "?text=" + encodeURIComponent(telegramMessage) : ""
            list.push({ id: "telegram", label: "Telegram", url: "https://t.me/" + handle + msg, color: "#229ED9", value: telegram, message: telegramMessage })
        }
        if (instagram && instagram.trim()) {
            const handle = instagram.replace(/^@/, "").replace(/[^a-zA-Z0-9._-]/g, "")
            list.push({ id: "instagram", label: "Instagram", url: "https://instagram.com/" + handle, color: "#E1306C", value: instagram, message: "" })
        }
        if (tiktok && tiktok.trim()) {
            const handle = tiktok.replace(/^@/, "").replace(/[^a-zA-Z0-9._-]/g, "")
            list.push({ id: "tiktok", label: "TikTok", url: "https://www.tiktok.com/@" + handle, color: "#111111", value: tiktok, message: "" })
        }
        if (wechat && wechat.trim()) {
            const url = (wechat.startsWith("http://") || wechat.startsWith("https://")) ? wechat : "https://u.wechat.com/" + wechat.replace(/[^a-zA-Z0-9._-]/g, "")
            list.push({ id: "wechat", label: "WeChat", url, color: "#07C160", value: wechat, message: "" })
        }
        if (viber && viber.trim()) {
            const clean = viber.replace(/[^0-9+]/g, "")
            list.push({ id: "viber", label: "Viber", url: "viber://chat?number=" + encodeURIComponent(clean), color: "#7360F2", value: viber, message: "" })
        }
        if (line && line.trim()) {
            const handle = line.replace(/^@/, "").replace(/[^a-zA-Z0-9._-]/g, "")
            list.push({ id: "line", label: "LINE", url: "https://line.me/R/ti/p/~" + handle, color: "#06C755", value: line, message: "" })
        }
        if (signal && signal.trim()) {
            const url = (signal.startsWith("http://") || signal.startsWith("https://")) ? signal : "https://signal.me/#p/" + encodeURIComponent(signal)
            list.push({ id: "signal", label: "Signal", url, color: "#3A76F0", value: signal, message: "" })
        }
        if (phone && phone.trim()) {
            list.push({ id: "phone", label: "Phone", url: "tel:" + phone.replace(/[^0-9+]/g, ""), color: "#111827", value: phone, message: "" })
        }
        if (sms && sms.trim()) {
            const clean = sms.replace(/[^0-9+]/g, "")
            const msg = smsMessage ? "?body=" + encodeURIComponent(smsMessage) : ""
            list.push({ id: "sms", label: "SMS", url: "sms:" + clean + msg, color: "#10B981", value: sms, message: smsMessage })
        }
        if (email && email.trim()) {
            const cleanEmail = email.replace(/[^a-zA-Z0-9._%+\-@]/g, "")
            const emailParams: string[] = []
            if (emailSubject && emailSubject.trim()) emailParams.push("subject=" + encodeURIComponent(emailSubject.trim()))
            if (emailMessage && emailMessage.trim()) emailParams.push("body=" + encodeURIComponent(emailMessage.trim()))
            const emailQuery = emailParams.length > 0 ? "?" + emailParams.join("&") : ""
            list.push({
                id: "email",
                label: "Email",
                url: cleanEmail ? "mailto:" + cleanEmail + emailQuery : "mailto:",
                color: "#EA4335",
                value: email,
                message: emailMessage || "",
                emailSubject: emailSubject || ""
            })
        }
        if (discord && discord.trim()) {
            const url = (discord.startsWith("http://") || discord.startsWith("https://")) ? discord : "https://discord.gg/" + discord.replace(/[^a-zA-Z0-9._-]/g, "")
            list.push({ id: "discord", label: "Discord", url, color: "#5865F2", value: discord, message: "" })
        }
        if (slack && slack.trim()) {
            const url = (slack.startsWith("http://") || slack.startsWith("https://")) ? slack : "https://" + slack
            list.push({ id: "slack", label: "Slack", url, color: "#4A154B", value: slack, message: "" })
        }
        if (teams && teams.trim()) {
            const url = (teams.startsWith("http://") || teams.startsWith("https://")) ? teams : "https://teams.microsoft.com/l/chat/0/0?users=" + encodeURIComponent(teams)
            list.push({ id: "teams", label: "Microsoft Teams", url, color: "#6264A7", value: teams, message: "" })
        }
        if (x && x.trim()) {
            const handle = x.replace(/^@/, "").replace(/[^a-zA-Z0-9._-]/g, "")
            list.push({ id: "x", label: "X (Twitter)", url: "https://x.com/" + handle, color: "#000000", value: x, message: "" })
        }
        if (linkedin && linkedin.trim()) {
            const clean = linkedin.replace(/^@/, "").trim()
            const url = (clean.startsWith("http://") || clean.startsWith("https://"))
                ? clean
                : (clean.startsWith("in/") || clean.startsWith("company/"))
                ? "https://www.linkedin.com/" + clean
                : "https://www.linkedin.com/in/" + encodeURIComponent(clean)
            list.push({ id: "linkedin", label: "LinkedIn", url, color: "#0A66C2", value: linkedin, message: "" })
        }
        if (maps && maps.trim()) {
            const url = (maps.startsWith("http://") || maps.startsWith("https://")) ? maps : "https://www.google.com/maps/search/?api=1&query=" + encodeURIComponent(maps)
            list.push({ id: "maps", label: "Google Maps", url, color: "#EA4335", value: maps, message: "" })
        }
        if (custom && custom.trim()) {
            list.push({ id: "custom", label: (customLabel && customLabel.trim()) || "Custom", url: custom, color: "#111827", value: custom, message: "" })
        }
        if (list.length === 0) {
            list.push({ id: "whatsapp", label: "WhatsApp", url: "https://wa.me/", color: "#25D366", value: "", message: "Hello!" })
        }
        return list
    }, [whatsapp, whatsappMessage, messenger, telegram, telegramMessage, instagram, tiktok, wechat, viber, line, signal, phone, sms, smsMessage, email, emailSubject, emailMessage, discord, slack, teams, x, linkedin, maps, custom, customLabel])

    const agents = React.useMemo(() => {
        return rawAgents.map((ag: any) => {
            const ch = channels.find((c) => c.id === ag.channelId) || channels[0]
            const rawAv = ag.avatar || ""
            const safeAvatar = (rawAv.startsWith("http://") || rawAv.startsWith("https://") || rawAv.startsWith("data:image/"))
                ? rawAv
                : ${JSON.stringify(Jr[0])}
            const rawVal = ag.value || (ch ? ch.value : "")
            const rawMsg = ag.message || (ch ? ch.message : "")
            let directUrl = ch ? ch.url : "https://wa.me/"
            if (ag.channelId === "whatsapp") {
                const clean = rawVal.replace(/[^0-9]/g, "")
                directUrl = clean ? "https://wa.me/" + clean + (rawMsg ? "?text=" + encodeURIComponent(rawMsg) : "") : "https://wa.me/"
            } else if (ag.channelId === "telegram") {
                const handle = rawVal.replace(/^@/, "").replace(/[^a-zA-Z0-9._-]/g, "")
                directUrl = handle ? "https://t.me/" + handle + (rawMsg ? "?text=" + encodeURIComponent(rawMsg) : "") : "https://t.me/"
            } else if (ag.channelId === "messenger") {
                const handle = rawVal.replace(/^@/, "").replace(/[^a-zA-Z0-9._-]/g, "")
                directUrl = handle ? "https://m.me/" + handle : "https://m.me/"
            } else if (ag.channelId === "instagram") {
                const handle = rawVal.replace(/^@/, "").replace(/[^a-zA-Z0-9._-]/g, "")
                directUrl = handle ? "https://instagram.com/" + handle : "https://instagram.com/"
            } else if (ag.channelId === "tiktok") {
                const handle = rawVal.replace(/^@/, "").replace(/[^a-zA-Z0-9._-]/g, "")
                directUrl = handle ? "https://www.tiktok.com/@" + handle : "https://www.tiktok.com/"
            } else if (ag.channelId === "wechat") {
                directUrl = (rawVal.startsWith("http://") || rawVal.startsWith("https://")) ? rawVal : "https://u.wechat.com/" + rawVal.replace(/[^a-zA-Z0-9._-]/g, "")
            } else if (ag.channelId === "viber") {
                directUrl = "viber://chat?number=" + encodeURIComponent(rawVal.replace(/[^0-9+]/g, ""))
            } else if (ag.channelId === "line") {
                directUrl = "https://line.me/R/ti/p/~" + rawVal.replace(/^@/, "")
            } else if (ag.channelId === "signal") {
                directUrl = (rawVal.startsWith("http://") || rawVal.startsWith("https://")) ? rawVal : "https://signal.me/#p/" + encodeURIComponent(rawVal)
            } else if (ag.channelId === "phone") {
                directUrl = "tel:" + rawVal.replace(/[^0-9+]/g, "")
            } else if (ag.channelId === "sms") {
                const cleanDigits = rawVal.replace(/[^0-9+]/g, "")
                directUrl = cleanDigits ? "sms:" + cleanDigits + (rawMsg ? "?body=" + encodeURIComponent(rawMsg) : "") : "sms:"
            } else if (ag.channelId === "email") {
                directUrl = "mailto:" + rawVal.replace(/[^a-zA-Z0-9._%+\-@]/g, "") + (rawMsg ? "?body=" + encodeURIComponent(rawMsg) : "")
            } else if (ag.channelId === "discord") {
                directUrl = (rawVal.startsWith("http://") || rawVal.startsWith("https://")) ? rawVal : "https://discord.gg/" + rawVal.replace(/[^a-zA-Z0-9._-]/g, "")
            } else if (ag.channelId === "slack") {
                directUrl = (rawVal.startsWith("http://") || rawVal.startsWith("https://")) ? rawVal : "https://" + rawVal
            } else if (ag.channelId === "teams") {
                directUrl = (rawVal.startsWith("http://") || rawVal.startsWith("https://")) ? rawVal : "https://teams.microsoft.com/l/chat/0/0?users=" + encodeURIComponent(rawVal)
            } else if (ag.channelId === "x") {
                directUrl = (rawVal.startsWith("http://") || rawVal.startsWith("https://")) ? rawVal : "https://x.com/" + rawVal.replace(/^@/, "").replace(/[^a-zA-Z0-9._-]/g, "")
            } else if (ag.channelId === "linkedin") {
                const clean = rawVal.replace(/^@/, "").trim()
                directUrl = (clean.startsWith("http://") || clean.startsWith("https://"))
                    ? clean
                    : (clean.startsWith("in/") || clean.startsWith("company/"))
                    ? "https://www.linkedin.com/" + clean
                    : "https://www.linkedin.com/in/" + encodeURIComponent(clean)
            } else if (ag.channelId === "maps") {
                directUrl = (rawVal.startsWith("http://") || rawVal.startsWith("https://")) ? rawVal : "https://www.google.com/maps/search/?api=1&query=" + encodeURIComponent(rawVal)
            } else if (ag.channelId === "custom") {
                directUrl = (rawVal && !rawVal.trim().toLowerCase().startsWith("javascript:") && !rawVal.trim().toLowerCase().startsWith("data:")) ? rawVal : "#"
            }
            return {
                ...ag,
                avatar: safeAvatar,
                color: ch ? ch.color : "#25D366",
                url: directUrl,
                value: rawVal,
                message: rawMsg,
                channelLabel: ch ? ch.label : "WhatsApp",
            }
        })
    }, [rawAgents, channels])

    const isPill = buttonShape === "pill"
    const isRounded = buttonShape === "rounded"
    const radius = isPill ? "999px" : isRounded ? "16px" : "50%"
    const hasPillLabel = isPill && Boolean(launcherText && launcherText.trim())
    const btnWidth = isPill ? (hasPillLabel ? "auto" : 84) : 58
    const btnHeight = 58
    const isBottom = position.startsWith("bottom")
    const isRight = position.endsWith("right")
    const safeModalGradient = sanitizeGradient(modalCustomGradient)
    const headerGradient = modalTheme === "custom" && safeModalGradient
        ? safeModalGradient
        : (GRADIENTS[modalTheme] || GRADIENTS.whatsapp)

    const btnAnimation = animation === "bounce"
        ? "cfBounce 1.6s ease infinite"
        : animation === "pulse"
        ? "cfPulse 2s ease infinite"
        : animation === "pop"
        ? "cfPopIn 0.35s cubic-bezier(0.175, 0.885, 0.32, 1.275) both"
        : animation === "slide"
        ? "cfSlideUp 0.35s ease both"
        : "none"

    const isLauncherHiddenByScroll = !isCanvas && scrollTriggerEnabled && scrollTriggerTarget === "launcher" && !scrollPassed

    const containerStyle: React.CSSProperties = {
        ...style,
        width: btnWidth,
        height: btnHeight,
        position: "relative",
        overflow: "visible",
        display: "inline-flex",
        alignItems: isBottom ? "flex-end" : "flex-start",
        justifyContent: isRight ? "flex-end" : "flex-start",
        fontFamily: "Inter, -apple-system, BlinkMacSystemFont, sans-serif",
        boxSizing: "border-box",
        opacity: isLauncherHiddenByScroll ? 0 : 1,
        pointerEvents: isLauncherHiddenByScroll ? "none" : "auto",
        transform: isLauncherHiddenByScroll ? "scale(0.8) translateY(12px)" : "scale(1) translateY(0)",
        transition: "opacity 0.35s ease, transform 0.35s cubic-bezier(0.16, 1, 0.3, 1)",
    }

    const mainBtnStyle: React.CSSProperties = {
        width: btnWidth,
        minWidth: isPill ? (hasPillLabel ? 92 : 84) : 58,
        height: btnHeight,
        borderRadius: radius,
        backgroundColor: buttonColor,
        color: "#ffffff",
        border: "none",
        cursor: "pointer",
        display: "inline-flex",
        alignItems: "center",
        justifyContent: "center",
        gap: 8,
        padding: hasPillLabel ? "0 18px" : 0,
        boxShadow: "0 12px 30px rgba(0, 0, 0, 0.25)",
        position: "relative",
        flexShrink: 0,
        zIndex: 50,
        outline: "none",
        animation: isOpen ? "none" : btnAnimation,
        fontFamily: "Inter, -apple-system, BlinkMacSystemFont, sans-serif",
        fontSize: 14,
        fontWeight: 600,
    }

    const launcherWatermarkWrapStyle: React.CSSProperties = {
        position: "relative",
        display: "inline-flex",
        alignItems: "center",
        justifyContent: "center",
        zIndex: 50,
        userSelect: "none",
        width: btnWidth,
        height: btnHeight,
    }

    const modalStyle: React.CSSProperties = {
        position: "absolute",
        bottom: isBottom ? 70 : "auto",
        top: !isBottom ? 70 : "auto",
        right: isRight ? 0 : "auto",
        left: !isRight ? 0 : "auto",
        width: 350,
        maxWidth: "calc(100vw - 32px)",
        maxHeight: "calc(100vh - 120px)",
        backgroundColor: "#ffffff",
        borderRadius: 24,
        boxShadow: "0 24px 60px rgba(0,0,0,0.22), 0 8px 20px rgba(0,0,0,0.08)",
        overflow: "hidden",
        display: "flex",
        flexDirection: "column",
        zIndex: 100,
        animation: "cfFadeIn .22s ease both",
    }

    const headerWrapStyle: React.CSSProperties = {
        background: headerGradient,
    }
    const greetingPosStyle: React.CSSProperties = {
        bottom: isBottom ? 70 : "auto",
        top: !isBottom ? 70 : "auto",
        right: isRight ? 0 : "auto",
        left: !isRight ? 0 : "auto",
    }
    const buttonsContainerStyle: React.CSSProperties = {
        bottom: isBottom ? 68 : "auto",
        top: !isBottom ? 68 : "auto",
        right: isRight ? 0 : "auto",
        left: !isRight ? 0 : "auto",
        gap: 10,
        ...(layout === "grid"
            ? {
                  display: "grid",
                  gridTemplateColumns: "repeat(2, auto)",
                  alignItems: "center",
              }
            : layout === "horizontal"
            ? {
                  display: "flex",
                  flexDirection: isRight ? "row-reverse" : "row",
                  alignItems: "center",
              }
            : {
                  display: "flex",
                  flexDirection: "column",
                  alignItems: isRight ? "flex-end" : "flex-start",
              }),
    }

    // Pro licensing & lock state
    const isLocked = IS_LOCKED

    const lockedBlurContentStyle: React.CSSProperties = {
        filter: "blur(6px)",
        WebkitFilter: "blur(6px)",
        opacity: 0.45,
        pointerEvents: "none",
        userSelect: "none",
        width: "100%",
        display: "flex",
        flexDirection: "column",
        transition: "filter 0.3s ease, opacity 0.3s ease",
    }
    const modalInnerContentStyle: React.CSSProperties = {
        width: "100%",
        height: "100%",
        display: "flex",
        flexDirection: "column",
        flex: 1,
        minHeight: 0,
        ...(isLocked ? lockedBlurContentStyle : undefined),
    }
    const buttonsContainerWithLockStyle: React.CSSProperties = {
        ...buttonsContainerStyle,
        ...(isLocked
            ? {
                  filter: "blur(6px)",
                  WebkitFilter: "blur(6px)",
                  opacity: 0.45,
                  pointerEvents: "none",
                  userSelect: "none",
              }
            : undefined),
    }
    const proLockedModalOverlayStyle: React.CSSProperties = {
        position: "absolute",
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        zIndex: 100,
        borderRadius: 24,
        background: "rgba(10, 10, 12, 0.65)",
        backdropFilter: "blur(8px)",
        WebkitBackdropFilter: "blur(8px)",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        padding: "24px",
        textAlign: "center",
        color: "#ffffff",
        fontFamily: "-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif",
        userSelect: "none",
        boxSizing: "border-box",
    }
    const proLockedButtonsOverlayStyle: React.CSSProperties = {
        position: "absolute",
        bottom: isBottom ? 68 : "auto",
        top: !isBottom ? 68 : "auto",
        right: isRight ? 0 : "auto",
        left: !isRight ? 0 : "auto",
        zIndex: 100,
        minWidth: 200,
        minHeight: 120,
        borderRadius: 16,
        background: "rgba(10, 10, 12, 0.75)",
        backdropFilter: "blur(6px)",
        WebkitBackdropFilter: "blur(6px)",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        padding: "16px",
        textAlign: "center",
        color: "#ffffff",
        fontFamily: "-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif",
        userSelect: "none",
        boxSizing: "border-box",
    }
    const proLockedIconWrapStyle: React.CSSProperties = {
        background: "rgba(255, 255, 255, 0.1)",
        border: "1px solid rgba(255, 255, 255, 0.2)",
        borderRadius: "50%",
        width: 48,
        height: 48,
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        marginBottom: 12,
        boxShadow: "0 4px 16px rgba(0, 0, 0, 0.2)",
    }
    const proLockedTitleStyle: React.CSSProperties = {
        fontSize: 14,
        fontWeight: 700,
        marginBottom: 6,
        color: "#ffffff",
    }
    const proLockedDescStyle: React.CSSProperties = {
        fontSize: 12,
        opacity: 0.85,
        maxWidth: 260,
        lineHeight: 1.5,
        color: "#94a3b8",
    }

    if (isWidgetHidden) return null

    if (isLocked) {
        return (
            <div className="cf-canvas-pro-locked-container">
                <div className="cf-canvas-pro-locked-icon-wrapper">
                    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#708AFF" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                        <rect x="3" y="11" width="18" height="11" rx="2" ry="2" />
                        <path d="M7 11V7a5 5 0 0 1 10 0v4" />
                    </svg>
                </div>
                <div className="cf-canvas-pro-locked-title">
                    PRO Feature Locked
                </div>
                <div className="cf-canvas-pro-locked-desc">
                    Upgrade to the PRO plan in the Chat Bubbles plugin to activate this widget.
                </div>
            </div>
        )
    }

    // Duplicate component blocker: renders warning and disables chat interaction if cloned or duplicated
    const duplicateBoxStyle: React.CSSProperties = {
        width: "100%",
        minHeight: 140,
        borderRadius: 16,
        border: "2px dashed #EF4444",
        background: "rgba(239, 68, 68, 0.08)",
        backdropFilter: "blur(8px)",
        WebkitBackdropFilter: "blur(8px)",
        boxSizing: "border-box",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        padding: "20px 16px",
        textAlign: "center",
        fontFamily: "-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif",
        color: "#ffffff",
        userSelect: "none",
    }
    const duplicateIconStyle: React.CSSProperties = {
        width: 42,
        height: 42,
        borderRadius: "50%",
        background: "rgba(239, 68, 68, 0.2)",
        border: "1px solid rgba(239, 68, 68, 0.4)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        marginBottom: 10,
        color: "#EF4444",
    }
    const duplicateTitleStyle: React.CSSProperties = {
        fontSize: 14,
        fontWeight: 700,
        color: "#EF4444",
        marginBottom: 6,
    }
    const duplicateDescStyle: React.CSSProperties = {
        fontSize: 12,
        opacity: 0.85,
        maxWidth: 260,
        lineHeight: 1.45,
        color: "#94a3b8",
    }

    if (isDuplicate) {
        if (!isCanvas) {
            return null
        }
        return (
            <div
                className="framefic-duplicate-limit-container"
                style={duplicateBoxStyle}
            >
                <div style={duplicateIconStyle}>
                    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                        <circle cx="12" cy="12" r="10" />
                        <line x1="4.93" y1="4.93" x2="19.07" y2="19.07" />
                    </svg>
                </div>
                <div style={duplicateTitleStyle}>
                    Duplicate Component Detected
                </div>
                <div style={duplicateDescStyle}>
                    Chat Bubbles cannot be copied or duplicated via Ctrl+C / Ctrl+V or Alt+Drag within the same layout. Only 1 floating widget instance is supported per breakpoint.
                </div>
            </div>
        )
    }

    return (
        <div
            ref={containerRef}
            style={containerStyle}
            draggable={false}
            onDragStart={(e) => {
                e.preventDefault()
                e.stopPropagation()
            }}
            onCopy={(e) => {
                e.preventDefault()
                e.stopPropagation()
            }}
        >
            <style>{\`
              @keyframes cfFadeIn { from { opacity: 0; transform: translateY(10px) scale(0.97); } to { opacity: 1; transform: translateY(0) scale(1); } }
              @keyframes cfPopIn { 0% { transform: scale(0.7); opacity: 0; } 70% { transform: scale(1.06); } 100% { transform: scale(1); opacity: 1; } }
              @keyframes cfBounce { 0%, 100% { transform: translateY(0); } 50% { transform: translateY(-8px); } }
              @keyframes cfPulse { 0%, 100% { transform: scale(1); box-shadow: 0 12px 30px rgba(0,0,0,0.25); } 50% { transform: scale(1.05); box-shadow: 0 16px 36px rgba(0,0,0,0.35); } }
              @keyframes cfSlideUp { from { transform: translateY(20px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }
              @keyframes cfSlideInRight { from { opacity: 0; transform: translateX(24px); } to { opacity: 1; transform: translateX(0); } }
              @keyframes cfSlideInLeft { from { opacity: 0; transform: translateX(-24px); } to { opacity: 1; transform: translateX(0); } }
              @keyframes cfFadeScale { from { opacity: 0; transform: scale(0.75); } to { opacity: 1; transform: scale(1); } }

              .cf-view-slide-forward {
                animation: cfSlideInRight 0.28s cubic-bezier(0.16, 1, 0.3, 1) both !important;
                will-change: transform, opacity !important;
              }
              .cf-view-slide-backward {
                animation: cfSlideInLeft 0.28s cubic-bezier(0.16, 1, 0.3, 1) both !important;
                will-change: transform, opacity !important;
              }
              button.cf-header-btn.cf-header-back-btn {
                animation: cfFadeScale 0.22s cubic-bezier(0.16, 1, 0.3, 1) both !important;
              }
              button.cf-header-btn.cf-header-close-btn {
                margin-left: auto !important;
              }

              a.cf-channel-btn, .cf-channel-btn, a.cf-channel-btn:link, a.cf-channel-btn:visited, a.cf-channel-btn:hover, a.cf-channel-btn:active {
                width: 44px !important;
                height: 44px !important;
                display: flex !important;
                align-items: center !important;
                justify-content: center !important;
                overflow: hidden !important;
                color: #ffffff !important;
                text-decoration: none !important;
              }
              a.cf-channel-btn svg, .cf-channel-btn svg, .cf-canvas-icon-inner svg {
                width: 22px !important;
                height: 22px !important;
                max-width: 22px !important;
                max-height: 22px !important;
                min-width: 22px !important;
                min-height: 22px !important;
                display: block !important;
                margin: auto !important;
                fill: #ffffff !important;
                color: #ffffff !important;
              }
              a.cf-channel-btn svg path, .cf-channel-btn svg path, .cf-canvas-icon-inner svg path {
                fill: #ffffff !important;
              }
              button.cf-main-btn svg {
                width: 24px !important;
                height: 24px !important;
                max-width: 24px !important;
                max-height: 24px !important;
                display: block !important;
                margin: auto !important;
              }

              button.cf-header-btn {
                width: 28px !important;
                height: 28px !important;
                min-width: 28px !important;
                min-height: 28px !important;
                border-radius: 50% !important;
                background: rgba(255, 255, 255, 0.22) !important;
                border: none !important;
                color: #ffffff !important;
                cursor: pointer !important;
                display: flex !important;
                align-items: center !important;
                justify-content: center !important;
                padding: 0 !important;
                margin: 0 !important;
                line-height: 0 !important;
                box-sizing: border-box !important;
                transition: background 0.15s ease !important;
              }
              button.cf-header-btn:hover {
                background: rgba(255, 255, 255, 0.35) !important;
              }
              button.cf-header-btn svg {
                width: 11px !important;
                height: 11px !important;
                max-width: 11px !important;
                max-height: 11px !important;
                min-width: 11px !important;
                min-height: 11px !important;
                display: block !important;
                margin: 0 !important;
              }

              .cf-icon-rotator {
                width: 24px !important;
                height: 24px !important;
                display: grid !important;
                place-items: center !important;
                transition: transform 0.25s ease !important;
                flex-shrink: 0 !important;
              }
              .cf-icon-rotator.is-open {
                transform: rotate(45deg) !important;
              }
              .cf-pill-text {
                font-size: 14px !important;
                font-weight: 600 !important;
                white-space: nowrap !important;
              }
              .cf-badge-counter {
                position: absolute !important;
                top: -2px !important;
                right: -2px !important;
                min-width: 18px !important;
                height: 18px !important;
                padding: 0 4px !important;
                border-radius: 999px !important;
                background: #ef4444 !important;
                color: #ffffff !important;
                border: 2px solid #ffffff !important;
                font-size: 10px !important;
                font-weight: 700 !important;
                display: grid !important;
                place-items: center !important;
              }
              .cf-canvas-greeting {
                position: absolute !important;
                background-color: #ffffff !important;
                color: #111827 !important;
                padding: 10px 14px !important;
                border-radius: 14px !important;
                font-size: 13px !important;
                font-weight: 500 !important;
                box-shadow: 0 10px 30px rgba(0,0,0,0.18) !important;
                display: inline-flex !important;
                align-items: center !important;
                gap: 10px !important;
                white-space: nowrap !important;
                width: max-content !important;
                max-width: 320px !important;
                z-index: 100 !important;
                cursor: pointer !important;
                user-select: none !important;
                animation: cfFadeIn .22s ease both !important;
              }
              .cf-canvas-greeting-close {
                border: none !important;
                background: transparent !important;
                cursor: pointer !important;
                display: inline-flex !important;
                align-items: center !important;
                justify-content: center !important;
                width: 16px !important;
                height: 16px !important;
                line-height: 1 !important;
                color: #9ca3af !important;
                padding: 0 !important;
                opacity: 0.75 !important;
                transition: opacity 0.15s ease, color 0.15s ease !important;
              }
              .cf-canvas-greeting-close:hover {
                opacity: 1 !important;
                color: #4b5563 !important;
              }
              .cf-canvas-greeting-close svg {
                display: block !important;
              }
              .cf-canvas-modal-header {
                color: #ffffff !important;
                padding: 20px 18px !important;
                display: flex !important;
                flex-direction: column !important;
                gap: 6px !important;
              }
              .cf-canvas-modal-top {
                display: flex !important;
                align-items: center !important;
                justify-content: space-between !important;
                width: 100% !important;
                margin-bottom: 12px !important;
              }
              .cf-canvas-header-info {
                display: flex !important;
                flex-direction: column !important;
                gap: 6px !important;
              }
              .cf-canvas-modal-h3 {
                margin: 0 !important;
                font-size: 18px !important;
                font-weight: 700 !important;
                line-height: 1.2 !important;
              }
              .cf-canvas-modal-p {
                margin: 0 !important;
                font-size: 13px !important;
                color: #ffffff !important;
                opacity: 0.92 !important;
                line-height: 1.4 !important;
              }
              .cf-canvas-response-badge {
                display: inline-flex !important;
                align-items: center !important;
                gap: 6px !important;
                background: rgba(255,255,255,0.22) !important;
                padding: 3px 10px !important;
                border-radius: 999px !important;
                font-size: 11px !important;
                font-weight: 600 !important;
                width: max-content !important;
                margin-top: 4px !important;
              }
              .cf-canvas-response-badge.offline {
                background: rgba(0, 0, 0, 0.3) !important;
                color: rgba(255, 255, 255, 0.9) !important;
              }
              .cf-canvas-agent-av-badge.offline {
                background: #6b7280 !important;
              }
              .cf-canvas-agents-wrap {
                padding: 14px !important;
                display: flex !important;
                flex-direction: column !important;
                gap: 8px !important;
                max-height: 340px !important;
                overflow-y: auto !important;
              }
              .cf-canvas-agent-card {
                display: flex !important;
                align-items: center !important;
                gap: 12px !important;
                padding: 10px 12px !important;
                border-radius: 14px !important;
                background-color: #f9fafb !important;
                border: 1px solid #f3f4f6 !important;
                cursor: pointer !important;
                transition: background-color 0.18s ease, transform 0.18s ease, border-color 0.18s ease !important;
              }
              .cf-canvas-agent-card:hover {
                background-color: #f3f4f6 !important;
                border-color: #e5e7eb !important;
                transform: translateY(-1px) !important;
              }
              .cf-canvas-agent-arrow {
                transition: transform 0.18s ease !important;
                display: flex !important;
                align-items: center !important;
              }
              .cf-canvas-agent-card:hover .cf-canvas-agent-arrow {
                transform: translateX(2px) !important;
              }
              .cf-canvas-agent-av-wrap {
                position: relative !important;
                width: 42px !important;
                height: 42px !important;
                flex-shrink: 0 !important;
              }
              .cf-canvas-agent-av-img {
                width: 42px !important;
                height: 42px !important;
                border-radius: 50% !important;
                object-fit: cover !important;
              }
              .cf-canvas-agent-name-row {
                display: flex !important;
                align-items: center !important;
                gap: 6px !important;
              }
              .cf-canvas-agent-online-dot {
                width: 7px !important;
                height: 7px !important;
                border-radius: 50% !important;
                background-color: #22c55e !important;
                box-shadow: 0 0 0 2px rgba(34, 197, 94, 0.25) !important;
                flex-shrink: 0 !important;
                display: inline-block !important;
              }
              .cf-canvas-agent-av-badge {
                position: absolute !important;
                bottom: -2px !important;
                right: -2px !important;
                width: 17px !important;
                height: 17px !important;
                border-radius: 50% !important;
                display: grid !important;
                place-items: center !important;
                border: 2px solid #ffffff !important;
                color: #ffffff !important;
              }
              .cf-canvas-agent-av-badge svg {
                width: 10px !important;
                height: 10px !important;
                display: block !important;
                fill: #ffffff !important;
                color: #ffffff !important;
              }
              .cf-canvas-agent-av-badge svg path {
                fill: #ffffff !important;
              }
              .cf-canvas-agent-info {
                flex: 1 !important;
                min-width: 0 !important;
              }
              .cf-canvas-agent-name {
                font-size: 14px !important;
                font-weight: 600 !important;
                color: #111827 !important;
              }
              .cf-canvas-agent-role {
                font-size: 12px !important;
                color: #6b7280 !important;
                white-space: nowrap !important;
                overflow: hidden !important;
                text-overflow: ellipsis !important;
              }
              .cf-canvas-chat-wrap {
                padding: 16px !important;
                display: flex !important;
                flex-direction: column !important;
                gap: 14px !important;
              }
              .cf-canvas-chat-bubble {
                background-color: #f3f4f6 !important;
                color: #1f2937 !important;
                padding: 12px 14px !important;
                border-radius: 16px 16px 16px 4px !important;
                font-size: 13px !important;
                line-height: 1.45 !important;
              }
              .cf-canvas-chat-input {
                width: 100% !important;
                padding: 10px 12px !important;
                border-radius: 12px !important;
                border: 1px solid #e5e7eb !important;
                font-size: 13px !important;
                outline: none !important;
                box-sizing: border-box !important;
              }
              .cf-canvas-start-btn {
                color: #ffffff !important;
                border-radius: 999px !important;
                padding: 12px 20px !important;
                font-size: 14px !important;
                font-weight: 600 !important;
                text-align: center !important;
                text-decoration: none !important;
                box-shadow: 0 8px 20px rgba(0,0,0,0.16) !important;
                display: block !important;
              }
              .cf-canvas-buttons-container {
                position: absolute !important;
                z-index: 90 !important;
                gap: 10px !important;
              }
              .cf-canvas-channel-item {
                display: flex !important;
                align-items: center !important;
                gap: 8px !important;
              }
              .cf-canvas-channel-label {
                background-color: #ffffff !important;
                color: #111827 !important;
                padding: 4px 9px !important;
                border-radius: 6px !important;
                font-size: 11px !important;
                font-weight: 600 !important;
                box-shadow: 0 4px 12px rgba(0,0,0,0.12) !important;
                white-space: nowrap !important;
              }
              .cf-canvas-icon-inner {
                width: 22px !important;
                height: 22px !important;
                display: flex !important;
                align-items: center !important;
                justify-content: center !important;
                flex-shrink: 0 !important;
                overflow: hidden !important;
              }

              @media (max-width: 640px) {
                .cf-canvas-buttons-container {
                  max-height: calc(100vh - 130px) !important;
                  overflow-y: auto !important;
                  overflow-x: hidden !important;
                  -webkit-overflow-scrolling: touch !important;
                  padding-right: 4px !important;
                  scrollbar-width: thin !important;
                }
                .cf-canvas-channel-item.is-overflow-hidden {
                  display: none !important;
                }
                .cf-canvas-more-btn {
                  width: 44px !important;
                  height: 44px !important;
                  display: flex !important;
                  align-items: center !important;
                  justify-content: center !important;
                  background-color: #374151 !important;
                  color: #ffffff !important;
                  font-size: 13px !important;
                  font-weight: 700 !important;
                  cursor: pointer !important;
                  border: none !important;
                  box-shadow: 0 4px 12px rgba(0,0,0,0.18) !important;
                  transition: transform 0.15s ease, background-color 0.15s ease !important;
                }
                .cf-canvas-more-btn:hover {
                  transform: scale(1.06) !important;
                  background-color: #1f2937 !important;
                }
                .cf-canvas-more-btn.is-expanded {
                  background-color: #5271ff !important;
                }
              }
              @media (min-width: 641px) {
                .cf-canvas-more-item {
                  display: none !important;
                }
              }

              /* Framefic Watermark Badge - Under Toggle Button */
              .cf-canvas-wm-wrap {
                position: absolute !important;
                top: calc(100% + 6px) !important;
                left: 50% !important;
                transform: translateX(-50%) !important;
                display: flex !important;
                align-items: center !important;
                justify-content: center !important;
                padding: 0 !important;
                margin: 0 !important;
                width: max-content !important;
                max-width: max-content !important;
                box-sizing: border-box !important;
                background: transparent !important;
                user-select: none !important;
                pointer-events: auto !important;
                overflow: visible !important;
                z-index: 60 !important;
              }
              .framefic-wm-link {
                display: inline-flex !important;
                align-items: center !important;
                justify-content: center !important;
                gap: 4px !important;
                padding: 3px 8px 3px 5px !important;
                border-radius: 999px !important;
                background: rgba(255, 255, 255, 0.94) !important;
                border: 1px solid rgba(0, 0, 0, 0.08) !important;
                box-shadow: 0 2px 6px rgba(0, 0, 0, 0.08), 0 1px 2px rgba(0, 0, 0, 0.04) !important;
                text-decoration: none !important;
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Inter', Helvetica, Arial, sans-serif !important;
                font-size: 10px !important;
                line-height: 1 !important;
                cursor: pointer !important;
                transition: all 0.2s cubic-bezier(0.16, 1, 0.3, 1) !important;
                white-space: nowrap !important;
                flex-shrink: 0 !important;
                box-sizing: border-box !important;
                width: max-content !important;
                max-width: max-content !important;
                overflow: visible !important;
                backdrop-filter: blur(8px) !important;
                -webkit-backdrop-filter: blur(8px) !important;
              }
              .framefic-wm-link:hover {
                transform: translateY(-1px) scale(1.02) !important;
                border-color: rgba(82, 113, 255, 0.5) !important;
                background: #ffffff !important;
                box-shadow: 0 4px 12px rgba(82, 113, 255, 0.22) !important;
              }
              .framefic-wm-icon {
                width: 12px !important;
                height: 12px !important;
                min-width: 12px !important;
                min-height: 12px !important;
                max-width: 12px !important;
                max-height: 12px !important;
                border-radius: 3px !important;
                background: linear-gradient(135deg, #5271ff 0%, #3557ff 100%) !important;
                display: inline-flex !important;
                align-items: center !important;
                justify-content: center !important;
                box-shadow: 0 1px 2px rgba(82, 113, 255, 0.35) !important;
                flex-shrink: 0 !important;
                margin: 0 !important;
                padding: 0 !important;
                overflow: hidden !important;
              }
              .framefic-wm-icon svg {
                width: 7.5px !important;
                height: 7.5px !important;
                min-width: 7.5px !important;
                min-height: 7.5px !important;
                max-width: 7.5px !important;
                max-height: 7.5px !important;
                display: block !important;
                margin: 0 !important;
                padding: 0 !important;
              }
              .framefic-wm-text {
                color: #64748b !important;
                font-size: 10px !important;
                font-weight: 500 !important;
                letter-spacing: 0.1px !important;
                white-space: nowrap !important;
                word-break: keep-all !important;
                line-height: 1 !important;
                display: inline-block !important;
                flex-shrink: 0 !important;
                transition: color 0.2s ease !important;
                text-shadow: none !important;
              }
              .framefic-wm-link:hover .framefic-wm-text {
                color: #3b82f6 !important;
              }
              .framefic-wm-brand {
                color: #0f172a !important;
                font-size: 10px !important;
                font-weight: 700 !important;
                letter-spacing: 0.15px !important;
                white-space: nowrap !important;
                word-break: keep-all !important;
                line-height: 1 !important;
                display: inline-block !important;
                flex-shrink: 0 !important;
                transition: color 0.2s ease !important;
                text-shadow: none !important;
              }
              .framefic-wm-link:hover .framefic-wm-brand {
                color: #1d4ed8 !important;
              }

              /* Framer Dark Theme Compatibility */
              body[data-framer-theme="dark"] .framefic-wm-link,
              [data-theme="dark"] .framefic-wm-link,
              .dark .framefic-wm-link {
                background: rgba(15, 23, 42, 0.88) !important;
                border-color: rgba(255, 255, 255, 0.16) !important;
                box-shadow: 0 2px 8px rgba(0, 0, 0, 0.35) !important;
              }

              body[data-framer-theme="dark"] .framefic-wm-link:hover,
              [data-theme="dark"] .framefic-wm-link:hover,
              .dark .framefic-wm-link:hover {
                background: rgba(30, 41, 59, 0.95) !important;
                border-color: rgba(82, 113, 255, 0.6) !important;
                box-shadow: 0 4px 14px rgba(82, 113, 255, 0.3) !important;
              }

              body[data-framer-theme="dark"] .framefic-wm-text,
              [data-theme="dark"] .framefic-wm-text,
              .dark .framefic-wm-text {
                color: #94a3b8 !important;
                text-shadow: none !important;
              }

              body[data-framer-theme="dark"] .framefic-wm-link:hover .framefic-wm-text,
              [data-theme="dark"] .framefic-wm-link:hover .framefic-wm-text,
              .dark .framefic-wm-link:hover .framefic-wm-text {
                color: #93c5fd !important;
              }

              body[data-framer-theme="dark"] .framefic-wm-brand,
              [data-theme="dark"] .framefic-wm-brand,
              .dark .framefic-wm-brand {
                color: #ffffff !important;
                text-shadow: none !important;
              }

              body[data-framer-theme="dark"] .framefic-wm-link:hover .framefic-wm-brand,
              [data-theme="dark"] .framefic-wm-link:hover .framefic-wm-brand,
              .dark .framefic-wm-link:hover .framefic-wm-brand {
                color: #ffffff !important;
              }
            \`}</style>
            <div className="cf-launcher-watermark-wrap" style={launcherWatermarkWrapStyle}>
                <button
                    type="button"
                    className="cf-main-btn"
                    style={mainBtnStyle}
                    onClick={(e) => {
                        e.stopPropagation()
                        flushPendingChimeIfQueued()
                        const nextOpen = !isOpen
                        setIsOpen(nextOpen)
                        if (isOpen) {
                            setSelectedAgent(null)
                            setNavDirection("forward")
                        }
                    }}
                    aria-label={ariaLabel}
                    aria-expanded={isOpen}
                >
                    <div className={"cf-icon-rotator" + (isOpen ? " is-open" : "")}>
                        {renderLauncherIcon(launcherIcon, isOpen, isLocked)}
                    </div>
                    {hasPillLabel ? (
                        <span className="cf-pill-text">
                            {isOpen ? "Close" : launcherText}
                        </span>
                    ) : null}
                    {showBadge && !isOpen ? (
                        <span className="cf-badge-counter">
                            {badgeText}
                        </span>
                    ) : null}
                </button>

                {showBranding && !isLocked ? (
                    <div
                        className="cf-canvas-wm-wrap"
                        onClick={(e) => e.stopPropagation()}
                    >
                        <a
                            href="https://framefic.com/chat-bubbles"
                            target="_blank"
                            rel="noopener noreferrer"
                            className="framefic-wm-link"
                            title="Made with Chat Bubbles"
                        >
                            <span className="framefic-wm-icon">
                                <svg width="7" height="7" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M2.2 5V3.4C2.2 2.74 2.74 2.2 3.4 2.2H5" stroke="#ffffff" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
                                    <path d="M11 2.2H12.6C13.26 2.2 13.8 2.74 13.8 3.4V5" stroke="#ffffff" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
                                    <path d="M2.2 11V12.6C2.2 13.26 2.74 13.8 3.4 13.8H5" stroke="#ffffff" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
                                    <path d="M11 13.8H12.6C13.26 13.8 13.8 13.26 13.8 12.6V11" stroke="#ffffff" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
                                    <rect x="4.4" y="4.6" width="7.2" height="6.8" rx="1.6" fill="#ffffff" />
                                </svg>
                            </span>
                            <span className="framefic-wm-text">Made with</span>
                            <span className="framefic-wm-brand">Chat Bubbles</span>
                        </a>
                    </div>
                ) : null}
            </div>

            {!isLocked && greetingEnabled && greetingVisible && !greetingDismissed && !isOpen ? (
                <div
                    className="cf-canvas-greeting"
                    style={greetingPosStyle}
                    onClick={() => {
                        flushPendingChimeIfQueued()
                        setIsOpen(true)
                    }}
                >
                    <span>{greetingText}</span>
                    <button
                        type="button"
                        className="cf-canvas-greeting-close"
                        aria-label="Close"
                        onClick={(e) => {
                            e.stopPropagation()
                            cancelPendingChime()
                            setGreetingDismissed(true)
                        }}
                    >
                        <svg width="10" height="10" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
                            <path d="M4 4l8 8M12 4l-8 8" />
                        </svg>
                    </button>
                </div>
            ) : null}

            {isOpen && widgetMode === "modal" ? (
                <div style={modalStyle} onClick={(e) => e.stopPropagation()}>
                    <div style={modalInnerContentStyle}>
                        <div className="cf-canvas-modal-header" style={headerWrapStyle}>
                            <div className="cf-canvas-modal-top">
                                {selectedAgent ? (
                                    <button
                                        type="button"
                                        className="cf-header-btn cf-header-back-btn"
                                        onClick={(e) => {
                                            e.stopPropagation()
                                            setNavDirection("backward")
                                            setSelectedAgent(null)
                                        }}
                                        aria-label="Back to agent list"
                                    >
                                        <svg
                                            width="11"
                                            height="11"
                                            viewBox="0 0 16 16"
                                            fill="none"
                                            stroke="currentColor"
                                            strokeWidth="2.2"
                                            strokeLinecap="round"
                                            strokeLinejoin="round"
                                        >
                                            <path d="M9.5 4L5.5 8l4 4" />
                                        </svg>
                                    </button>
                                ) : null}
                                <button
                                    type="button"
                                    className="cf-header-btn cf-header-close-btn"
                                    onClick={(e) => {
                                        e.stopPropagation()
                                        setIsOpen(false)
                                        setSelectedAgent(null)
                                        setNavDirection("forward")
                                    }}
                                    aria-label="Close chat"
                                >
                                    <svg
                                        width="11"
                                        height="11"
                                        viewBox="0 0 16 16"
                                        fill="none"
                                        stroke="currentColor"
                                        strokeWidth="2.2"
                                        strokeLinecap="round"
                                        strokeLinejoin="round"
                                    >
                                        <path d="M4.5 4.5l7 7M11.5 4.5l-7 7" />
                                    </svg>
                                </button>
                            </div>
                            <div
                                key={selectedAgent ? "header-agent-" + selectedAgent.id : "header-main"}
                                className={"cf-canvas-header-info" + (selectedAgent ? " cf-view-slide-forward" : (navDirection === "backward" ? " cf-view-slide-backward" : ""))}
                            >
                                <h3 className="cf-canvas-modal-h3">
                                    {selectedAgent ? selectedAgent.name : modalTitle}
                                </h3>
                                <p className="cf-canvas-modal-p">
                                    {selectedAgent ? selectedAgent.role : modalSubtitle}
                                </p>
                                {!selectedAgent && (modalResponseTime || (scheduleEnabled && isOffline)) ? (
                                    <span className={"cf-canvas-response-badge" + (isOffline ? " offline" : "")}>
                                        <svg width="12" height="12" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><circle cx="8" cy="8" r="6"/><path d="M8 5v3.2l2.2 1.3"/></svg>
                                        <span>{isOffline ? (scheduleOfflineText || "Back tomorrow at 9:00 AM") : modalResponseTime}</span>
                                    </span>
                                ) : null}
                            </div>
                        </div>

                        {!selectedAgent ? (
                            <div
                                key="agents-list"
                                className={"cf-canvas-agents-wrap" + (navDirection === "backward" ? " cf-view-slide-backward" : "")}
                            >
                                {agents.map((agent: any) => {
                                    const agentBadgeBgStyle: React.CSSProperties = {
                                        background: agent.color,
                                    }
                                    return (
                                        <div
                                            key={agent.id}
                                            className="cf-canvas-agent-card"
                                            onClick={(e) => {
                                                e.stopPropagation()
                                                setNavDirection("forward")
                                                setSelectedAgent(agent)
                                                setCustomMessage(agent.message || "")
                                            }}
                                        >
                                            <div className="cf-canvas-agent-av-wrap">
                                                <img
                                                    src={agent.avatar}
                                                    alt={agent.name}
                                                    className="cf-canvas-agent-av-img"
                                                />
                                                <span
                                                    className={"cf-canvas-agent-av-badge" + (isOffline ? " offline" : "")}
                                                    style={isOffline ? { background: "#6b7280" } : agentBadgeBgStyle}
                                                >
                                                    {renderChannelIcon(agent.channelId, 11)}
                                                </span>
                                            </div>
                                            <div className="cf-canvas-agent-info">
                                                <div className="cf-canvas-agent-name-row">
                                                    <span className="cf-canvas-agent-name">{agent.name}</span>
                                                    {agent.online !== false && !isOffline ? (
                                                        <span className="cf-canvas-agent-online-dot" />
                                                    ) : null}
                                                </div>
                                                <div className="cf-canvas-agent-role">
                                                    {agent.role}{isOffline ? " • Offline" : ""}
                                                </div>
                                            </div>
                                            <span className="cf-canvas-agent-arrow">
                                                <svg width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="#9ca3af" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M6 3.5L10.5 8L6 12.5"/></svg>
                                            </span>
                                        </div>
                                    )
                                })}
                            </div>
                        ) : (
                            <div
                                key={"chat-view-" + selectedAgent.id}
                                className="cf-canvas-chat-wrap cf-view-slide-forward"
                            >
                                <div className="cf-canvas-chat-bubble">
                                    {modalChatBubble || selectedAgent.message || "We typically reply within a few minutes. How can we help you today?"}
                                </div>
                                <input
                                    type="text"
                                    className="cf-canvas-chat-input"
                                    placeholder={selectedAgent.message ? selectedAgent.message : "Type your message..."}
                                    maxLength={500}
                                    value={customMessage}
                                    onChange={(e) => setCustomMessage(e.target.value)}
                                />
                                <a
                                    href={(() => {
                                        const msg = customMessage.trim() || (selectedAgent.message || "").trim()
                                        const rawVal = String(selectedAgent.value || "").trim()
                                        if (selectedAgent.channelId === "whatsapp") {
                                            const clean = rawVal.replace(/[^0-9]/g, "")
                                            return clean ? "https://wa.me/" + clean + (msg ? "?text=" + encodeURIComponent(msg) : "") : "https://wa.me/"
                                        }
                                        if (selectedAgent.channelId === "telegram") {
                                            const handle = rawVal.replace(/^@/, "").replace(/[^a-zA-Z0-9._-]/g, "")
                                            return handle ? "https://t.me/" + handle + (msg ? "?text=" + encodeURIComponent(msg) : "") : "https://t.me/"
                                        }
                                        if (selectedAgent.channelId === "email") {
                                            const cleanEmail = rawVal.replace(/[^a-zA-Z0-9._%+\-@]/g, "")
                                            const emailParams: string[] = []
                                            const activeSub = (selectedAgent as any).emailSubject || emailSubject || ""
                                            if (activeSub && activeSub.trim()) emailParams.push("subject=" + encodeURIComponent(activeSub.trim()))
                                            if (msg) emailParams.push("body=" + encodeURIComponent(msg))
                                            const emailQuery = emailParams.length > 0 ? "?" + emailParams.join("&") : ""
                                            return cleanEmail ? "mailto:" + cleanEmail + emailQuery : "mailto:"
                                        }
                                        return selectedAgent.url || "#"
                                    })()}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    className="cf-canvas-start-btn"
                                    style={headerWrapStyle}
                                    onClick={(e) => {
                                        e.stopPropagation()
                                        trackChannelClick(selectedAgent ? selectedAgent.channelId : "whatsapp")
                                        if (FORWARD_THIRD_PARTY_ANALYTICS && enableAnalytics && typeof window !== "undefined") {
                                            try {
                                                if (Array.isArray((window as any).dataLayer)) {
                                                    (window as any).dataLayer.push({
                                                        event: "chat_bubbles_click",
                                                        channel: selectedAgent.channelId,
                                                        channel_label: selectedAgent.channelLabel || selectedAgent.channelId,
                                                        agent_name: selectedAgent.name,
                                                    })
                                                }
                                                if (typeof (window as any).gtag === "function") {
                                                    (window as any).gtag("event", "chat_bubbles_click", {
                                                        channel: selectedAgent.channelId,
                                                        channel_label: selectedAgent.channelLabel || selectedAgent.channelId,
                                                        agent_name: selectedAgent.name,
                                                    })
                                                }
                                                window.dispatchEvent(new CustomEvent("chat_bubbles_interaction", {
                                                    detail: {
                                                        channel: selectedAgent.channelId,
                                                        channelLabel: selectedAgent.channelLabel || selectedAgent.channelId,
                                                        agentName: selectedAgent.name,
                                                    }
                                                }))
                                            } catch {}
                                        }
                                        if (closeAfterClick) {
                                            setIsOpen(false)
                                            setSelectedAgent(null)
                                            setNavDirection("forward")
                                        }
                                    }}
                                >
                                    {modalStartChatText}
                                </a>
                            </div>
                        )}
                    </div>

                    {isLocked ? (
                        <div className="cf-canvas-pro-locked-overlay" style={proLockedModalOverlayStyle}>
                            <div style={proLockedIconWrapStyle}>
                                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#708AFF" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                                    <rect x="3" y="11" width="18" height="11" rx="2" ry="2" />
                                    <path d="M7 11V7a5 5 0 0 1 10 0v4" />
                                </svg>
                            </div>
                            <div style={proLockedTitleStyle}>PRO Feature Locked</div>
                            <div style={proLockedDescStyle}>
                                Upgrade this site to a PRO plan in the Chat Bubbles plugin to activate.
                            </div>
                        </div>
                    ) : null}
                </div>
            ) : null}

            {isOpen && widgetMode === "buttons" ? (
                <>
                    <div className="cf-canvas-buttons-container" style={buttonsContainerWithLockStyle}>
                        {channels.map((channel, idx) => {
                            const channelItemStyle: React.CSSProperties = {
                                flexDirection: isRight ? "row-reverse" : "row",
                            }
                            const channelBtnStyle: React.CSSProperties = {
                                borderRadius: radius,
                                backgroundColor: channel.color,
                                color: "#ffffff",
                            }
                            const isCapped = Boolean(mobileCapChannels ?? true) && channels.length > 4 && !mobileExpanded && idx >= 4
                            return (
                                <div
                                    key={channel.id}
                                    className={"cf-canvas-channel-item" + (isCapped ? " is-overflow-hidden" : "")}
                                    style={channelItemStyle}
                                >
                                    <a
                                        href={channel.url}
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        onClick={() => {
                                            trackChannelClick(channel.id)
                                            if (FORWARD_THIRD_PARTY_ANALYTICS && enableAnalytics && typeof window !== "undefined") {
                                                try {
                                                    if (Array.isArray((window as any).dataLayer)) {
                                                        (window as any).dataLayer.push({ event: "chat_bubbles_click", channel: channel.id, channel_label: channel.label })
                                                    }
                                                    if (typeof (window as any).gtag === "function") {
                                                        (window as any).gtag("event", "chat_bubbles_click", { channel: channel.id, channel_label: channel.label })
                                                    }
                                                    window.dispatchEvent(new CustomEvent("chat_bubbles_interaction", { detail: { channel: channel.id, channelLabel: channel.label } }))
                                                } catch {}
                                            }
                                            if (closeAfterClick) setIsOpen(false)
                                        }}
                                        className="cf-channel-btn"
                                        style={channelBtnStyle}
                                    >
                                        <div className="cf-canvas-icon-inner">
                                            {renderChannelIcon(channel.id, 22)}
                                        </div>
                                    </a>
                                    {showLabels ? (
                                        <span className="cf-canvas-channel-label">
                                            {channel.label}
                                        </span>
                                    ) : null}
                                </div>
                            )
                        })}

                        {Boolean(mobileCapChannels ?? true) && channels.length > 4 ? (
                            (() => {
                                const moreItemStyle: React.CSSProperties = {
                                    flexDirection: isRight ? "row-reverse" : "row",
                                }
                                const moreBtnStyle: React.CSSProperties = {
                                    borderRadius: radius,
                                }
                                return (
                                    <div
                                        className="cf-canvas-channel-item cf-canvas-more-item"
                                        style={moreItemStyle}
                                    >
                                        <button
                                            type="button"
                                            className={"cf-canvas-more-btn" + (mobileExpanded ? " is-expanded" : "")}
                                            style={moreBtnStyle}
                                            onClick={(e) => {
                                                e.stopPropagation()
                                                setMobileExpanded(!mobileExpanded)
                                            }}
                                            aria-label={mobileExpanded ? "Show less channels" : "Show more channels"}
                                        >
                                            {mobileExpanded ? "−" : "+" + (channels.length - 4)}
                                        </button>
                                        {showLabels ? (
                                            <span className="cf-canvas-channel-label">
                                                {mobileExpanded ? "Show Less" : "+" + (channels.length - 4) + " More"}
                                            </span>
                                        ) : null}
                                    </div>
                                )
                            })()
                        ) : null}
                    </div>

                    {isLocked ? (
                        <div className="cf-canvas-pro-locked-overlay" style={proLockedButtonsOverlayStyle}>
                            <div style={proLockedIconWrapStyle}>
                                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#708AFF" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                                    <rect x="3" y="11" width="18" height="11" rx="2" ry="2" />
                                    <path d="M7 11V7a5 5 0 0 1 10 0v4" />
                                </svg>
                            </div>
                            <div style={proLockedTitleStyle}>PRO Feature Locked</div>
                            <div style={proLockedDescStyle}>
                                Upgrade this site to a PRO plan in the Chat Bubbles plugin to activate.
                            </div>
                        </div>
                    ) : null}
                </>
            ) : null}
        </div>
    )
}

ChatBubbles.defaultProps = {
    width: 60,
    height: 60,
    canvasPreview: "modal",
    widgetMode: ${JSON.stringify(e.widgetMode||`modal`)},
}

addPropertyControls(ChatBubbles, {
    canvasPreview: {
        type: ControlType.Enum,
        title: "Canvas State",
        options: ["modal", "chat", "closed"],
        optionTitles: ["Open Modal", "Agent Chat", "Launcher Button"],
        defaultValue: "modal",
            },
    widgetMode: {
        type: ControlType.Enum,
        title: "Widget Mode",
        options: ["modal", "buttons"],
        optionTitles: ["Live Chat Modal", "Icon Buttons"],
        defaultValue: ${JSON.stringify(e.widgetMode||`modal`)},
            },
    modalTheme: {
        type: ControlType.Enum,
        title: "Modal Theme",
        options: ["whatsapp", "messenger", "telegram", "instagram", "tiktok", "wechat", "dark", "custom"],
        optionTitles: ["WhatsApp Green", "Messenger Blue", "Telegram Sky", "Instagram Gradient", "TikTok Dark", "WeChat Green", "Modern Dark", "Custom"],
        defaultValue: ${JSON.stringify(e.modalTheme||`whatsapp`)},
        hidden(props: any) {
            return props.widgetMode === "buttons"
        },
    },
    modalCustomGradient: {
        type: ControlType.String,
        title: "Custom Gradient",
        defaultValue: ${JSON.stringify(e.modalCustomGradient||`linear-gradient(135deg, #6366f1 0%, #a855f7 100%)`)},
        hidden(props: any) {
            return props.widgetMode === "buttons" || props.modalTheme !== "custom"
        },
    },
    modalTitle: {
        type: ControlType.String,
        title: "Modal Title",
        defaultValue: ${JSON.stringify(e.modalTitle||`Hi there!`)},
        hidden(props: any) {
            return props.widgetMode === "buttons"
        },
    },
    modalSubtitle: {
        type: ControlType.String,
        title: "Subtitle",
        defaultValue: ${JSON.stringify(e.modalSubtitle||`Welcome to our live chat! Feel free to ask any questions.`)},
        hidden(props: any) {
            return props.widgetMode === "buttons"
        },
    },
    modalResponseTime: {
        type: ControlType.String,
        title: "Response Tag",
        defaultValue: ${JSON.stringify(e.modalResponseTime||`We typically reply within a few minutes`)},
        hidden(props: any) {
            return props.widgetMode === "buttons"
        },
    },
    modalChatBubble: {
        type: ControlType.String,
        title: "Greeting Msg",
        defaultValue: ${JSON.stringify(e.modalChatBubble||`We typically reply within a few minutes. How can we help you today?`)},
        hidden(props: any) {
            return props.widgetMode === "buttons"
        },
    },
    modalStartChatText: {
        type: ControlType.String,
        title: "Button Text",
        defaultValue: ${JSON.stringify(e.modalStartChatText||`Start chat`)},
        hidden(props: any) {
            return props.widgetMode === "buttons"
        },
    },
    position: {
        type: ControlType.Enum,
        title: "Position",
        options: ["bottom-right", "bottom-left", "top-right", "top-left"],
        optionTitles: ["Bottom Right", "Bottom Left", "Top Right", "Top Left"],
        defaultValue: ${JSON.stringify(e.position||`bottom-right`)},
            },
    layout: {
        type: ControlType.Enum,
        title: "Layout",
        options: ["stack", "grid", "horizontal"],
        optionTitles: ["Stack (Vertical)", "Grid (2 Columns)", "Horizontal"],
        defaultValue: ${JSON.stringify(e.layout||`stack`)},
        hidden(props: any) {
            return props.widgetMode === "modal"
        },
    },
    animation: {
        type: ControlType.Enum,
        title: "Animation",
        options: ["pop", "bounce", "slide", "pulse", "none"],
        optionTitles: ["Pop In", "Bounce", "Slide Up", "Pulse Glow", "None"],
        defaultValue: ${JSON.stringify(e.animation||`pop`)},
            },
    buttonColor: {
        type: ControlType.Color,
        title: "Launcher Color",
        defaultValue: ${JSON.stringify(e.buttonColor||`#25D366`)},
            },
    buttonShape: {
        type: ControlType.Enum,
        title: "Button Shape",
        options: ["circle", "rounded", "pill"],
        optionTitles: ["Circle", "Rounded", "Pill"],
        defaultValue: ${JSON.stringify(e.buttonShape||`circle`)},
            },
    launcherText: {
        type: ControlType.String,
        title: "Button Label",
        defaultValue: "Chat",
        hidden(props: any) {
            return props.buttonShape !== "pill"
        },
    },
    launcherIcon: {
        type: ControlType.Enum,
        title: "Button Icon",
        options: ["chat", "whatsapp", "messenger", "telegram", "instagram", "phone", "email", "support"],
        optionTitles: ["Live Chat", "WhatsApp", "Messenger", "Telegram", "Instagram", "Phone", "Email", "Headset Support"],
        defaultValue: ${JSON.stringify(e.launcherIcon||`chat`)},
            },
    showLabels: {
        type: ControlType.Boolean,
        title: "Show Labels",
        defaultValue: ${!!e.showLabels},
        hidden(props: any) {
            return props.widgetMode === "modal"
        },
    },
    mobileCapChannels: {
        type: ControlType.Boolean,
        title: "Mobile Cap (4+)",
        defaultValue: ${!!(e.mobileCapChannels??!0)},
        hidden(props: any) {
            return props.widgetMode === "modal"
        },
    },
    closeOnOutsideClick: {
        type: ControlType.Boolean,
        title: "Outside Click",
        defaultValue: ${!!(e.closeOnOutsideClick??!0)},
            },
    closeOnEscape: {
        type: ControlType.Boolean,
        title: "Escape Key",
        defaultValue: ${!!(e.closeOnEscape??!0)},
            },
    closeAfterClick: {
        type: ControlType.Boolean,
        title: "Close on Click",
        defaultValue: ${!!(e.closeAfterClick??!0)},
            },
    autoOpen: {
        type: ControlType.Boolean,
        title: "Auto Open",
        defaultValue: ${!!e.autoOpen},
            },
    autoOpenDelay: {
        type: ControlType.Number,
        title: "Auto Open Delay (ms)",
        defaultValue: ${Number(e.autoOpenDelay??1200)},
        min: 0,
        max: 30000,
        step: 500,
        hidden(props: any) {
            return !props.autoOpen
        },
    },
    ariaLabel: {
        type: ControlType.String,
        title: "Aria Label",
        defaultValue: ${JSON.stringify(e.ariaLabel||`Open chat options`)},
            },
    showBadge: {
        type: ControlType.Boolean,
        title: "Badge",
        defaultValue: ${!!e.showBadge},
            },
    badgeText: {
        type: ControlType.String,
        title: "Badge Text",
        defaultValue: ${JSON.stringify(e.badgeText||`1`)},
        hidden(props: any) {
            return !props.showBadge
        },
    },
    greetingEnabled: {
        type: ControlType.Boolean,
        title: "Greeting Bubble",
        defaultValue: ${!!e.greetingEnabled},
            },
    greetingText: {
        type: ControlType.String,
        title: "Greeting Text",
        defaultValue: ${JSON.stringify(e.greetingText||`Need help? Chat with us.`)},
        hidden(props: any) {
            return !props.greetingEnabled
        },
    },
    enableSound: {
        type: ControlType.Boolean,
        title: "Notification Sound",
        defaultValue: ${!!e.enableSound},
            },
    greetingDelay: {
        type: ControlType.Number,
        title: "Greeting Delay (ms)",
        min: 0,
        max: 30000,
        step: 500,
        defaultValue: ${Number(e.greetingDelay??2e3)},
        hidden: (props: any) => !props.greetingEnabled,
    },
    whatsapp: {
        type: ControlType.String,
        title: "WhatsApp",
        placeholder: "+1234567890",
        defaultValue: ${JSON.stringify(K(e,`whatsapp`))},
            },
    whatsappMessage: {
        type: ControlType.String,
        title: "WA Message",
        defaultValue: ${JSON.stringify(e.channels.find(e=>e.id===`whatsapp`)?.message||`Hello! I would like to know more.`)},
            },
    messenger: {
        type: ControlType.String,
        title: "Messenger",
        placeholder: "username",
        defaultValue: ${JSON.stringify(K(e,`messenger`))},
            },
    telegram: {
        type: ControlType.String,
        title: "Telegram",
        placeholder: "username",
        defaultValue: ${JSON.stringify(K(e,`telegram`))},
            },
    telegramMessage: {
        type: ControlType.String,
        title: "TG Message",
        defaultValue: ${JSON.stringify(e.channels.find(e=>e.id===`telegram`)?.message||`Hello!`)},
            },
    instagram: {
        type: ControlType.String,
        title: "Instagram",
        placeholder: "username",
        defaultValue: ${JSON.stringify(K(e,`instagram`))},
            },
    tiktok: {
        type: ControlType.String,
        title: "TikTok",
        placeholder: "username",
        defaultValue: ${JSON.stringify(K(e,`tiktok`))},
            },
    wechat: {
        type: ControlType.String,
        title: "WeChat",
        placeholder: "wechat_id",
        defaultValue: ${JSON.stringify(K(e,`wechat`))},
            },
    viber: {
        type: ControlType.String,
        title: "Viber",
        placeholder: "+1234567890",
        defaultValue: ${JSON.stringify(K(e,`viber`))},
            },
    line: {
        type: ControlType.String,
        title: "LINE",
        placeholder: "line_id",
        defaultValue: ${JSON.stringify(K(e,`line`))},
            },
    signal: {
        type: ControlType.String,
        title: "Signal",
        placeholder: "username or link",
        defaultValue: ${JSON.stringify(K(e,`signal`))},
            },
    phone: {
        type: ControlType.String,
        title: "Phone",
        placeholder: "+1234567890",
        defaultValue: ${JSON.stringify(K(e,`phone`))},
            },
    sms: {
        type: ControlType.String,
        title: "SMS",
        placeholder: "+1234567890",
        defaultValue: ${JSON.stringify(K(e,`sms`))},
            },
    smsMessage: {
        type: ControlType.String,
        title: "SMS Default Text",
        placeholder: "Hello! I have a question.",
        defaultValue: ${JSON.stringify(e.channels.find(e=>e.id===`sms`)?.message||``)},
            },
    email: {
        type: ControlType.String,
        title: "Email",
        placeholder: "hello@example.com",
        defaultValue: ${JSON.stringify(K(e,`email`))},
            },
    emailSubject: {
        type: ControlType.String,
        title: "Email Subject",
        placeholder: "Inquiry from website",
        defaultValue: ${JSON.stringify(e.channels.find(e=>e.id===`email`)?.emailSubject||``)},
            },
    emailMessage: {
        type: ControlType.String,
        title: "Email Message",
        placeholder: "Hello! I have a question...",
        defaultValue: ${JSON.stringify(e.channels.find(e=>e.id===`email`)?.message||``)},
            },
    discord: {
        type: ControlType.String,
        title: "Discord",
        placeholder: "https://discord.gg/yourserver",
        defaultValue: ${JSON.stringify(K(e,`discord`))},
            },
    slack: {
        type: ControlType.String,
        title: "Slack",
        placeholder: "https://join.slack.com/...",
        defaultValue: ${JSON.stringify(K(e,`slack`))},
            },
    teams: {
        type: ControlType.String,
        title: "Teams",
        placeholder: "user@company.com",
        defaultValue: ${JSON.stringify(K(e,`teams`))},
            },
    x: {
        type: ControlType.String,
        title: "X (Twitter)",
        placeholder: "username",
        defaultValue: ${JSON.stringify(K(e,`x`))},
            },
    linkedin: {
        type: ControlType.String,
        title: "LinkedIn",
        placeholder: "in/username or company/name",
        defaultValue: ${JSON.stringify(K(e,`linkedin`))},
            },
    maps: {
        type: ControlType.String,
        title: "Google Maps",
        placeholder: "Store address or maps link",
        defaultValue: ${JSON.stringify(K(e,`maps`))},
            },
    custom: {
        type: ControlType.String,
        title: "Custom URL",
        placeholder: "https://example.com/chat",
        defaultValue: ${JSON.stringify(K(e,`custom`))},
            },
    customLabel: {
        type: ControlType.String,
        title: "Custom Label",
        placeholder: "Custom",
        defaultValue: ${JSON.stringify(e.channels.find(e=>e.id===`custom`)?.label||`Custom`)},
            },
    scrollTriggerEnabled: {
        type: ControlType.Boolean,
        title: "Scroll Trigger",
        defaultValue: ${!!e.scrollTriggerEnabled},
            },
    scrollTriggerPercent: {
        type: ControlType.Number,
        title: "Scroll Depth %",
        min: 5,
        max: 95,
        step: 5,
        defaultValue: ${Number(e.scrollTriggerPercent??25)},
        hidden: (props: any) => !props.scrollTriggerEnabled,
    },
    scrollTriggerTarget: {
        type: ControlType.Enum,
        title: "Scroll Target",
        options: ["launcher", "greeting"],
        optionTitles: ["Reveal Launcher", "Reveal Greeting"],
        defaultValue: ${JSON.stringify(e.scrollTriggerTarget||`launcher`)},
        hidden: (props: any) => !props.scrollTriggerEnabled,
    },
    exitIntentEnabled: {
        type: ControlType.Boolean,
        title: "Exit-Intent (Desktop)",
        defaultValue: ${!!e.exitIntentEnabled},
            },
    exitIntentAction: {
        type: ControlType.Enum,
        title: "Exit Action",
        options: ["modal", "greeting"],
        optionTitles: ["Pop Open Chat", "Show Greeting"],
        defaultValue: ${JSON.stringify(e.exitIntentAction||`modal`)},
        hidden: (props: any) => !props.exitIntentEnabled,
    },
    scheduleEnabled: {
        type: ControlType.Boolean,
        title: "Operating Hours",
        defaultValue: ${!!e.scheduleEnabled},
            },
    scheduleStart: {
        type: ControlType.String,
        title: "Opening Time",
        defaultValue: ${JSON.stringify(e.scheduleStart||`09:00`)},
        hidden: (props: any) => !props.scheduleEnabled,
    },
    scheduleEnd: {
        type: ControlType.String,
        title: "Closing Time",
        defaultValue: ${JSON.stringify(e.scheduleEnd||`18:00`)},
        hidden: (props: any) => !props.scheduleEnabled,
    },
    scheduleOfflineAction: {
        type: ControlType.Enum,
        title: "Offline Action",
        options: ["badge", "hide"],
        optionTitles: ["Offline Badge", "Hide Widget"],
        defaultValue: ${JSON.stringify(e.scheduleOfflineAction||`badge`)},
        hidden: (props: any) => !props.scheduleEnabled,
    },
    scheduleOfflineText: {
        type: ControlType.String,
        title: "Offline Message",
        defaultValue: ${JSON.stringify(e.scheduleOfflineText||`Back tomorrow at 9:00 AM`)},
        hidden: (props: any) => !props.scheduleEnabled || props.scheduleOfflineAction === "hide",
    },
    showOn: {
        type: ControlType.String,
        title: "Where To Show",
        defaultValue: ${JSON.stringify(e.showOn||`Every page`)},
            },
    canvasPagePath: {
        type: ControlType.String,
        title: "Canvas Page Path",
        defaultValue: "",
        hidden: () => true,
    },
    targetingMode: {
        type: ControlType.Enum,
        title: "Targeting Mode",
        options: ["show", "hide"],
        optionTitles: ["Show Only on Paths", "Hide on Paths"],
        defaultValue: ${JSON.stringify(e.targetingMode||`show`)},
        hidden: (props: any) => props.showOn !== "custom",
    },
    targetingRules: {
        type: ControlType.String,
        title: "Targeting Paths",
        placeholder: "/pricing, /checkout, /blog/*",
        defaultValue: ${JSON.stringify(e.targetingRules||``)},
        hidden: (props: any) => props.showOn !== "custom",
    },
    agentsData: {
        type: ControlType.String,
        title: "Agents Data",
        defaultValue: ${JSON.stringify(JSON.stringify(e.agents||[]))},
        hidden: () => true,
    },
    scheduleDaysData: {
        type: ControlType.String,
        title: "Schedule Days Data",
        defaultValue: ${JSON.stringify(JSON.stringify(e.scheduleDays||[1,2,3,4,5]))},
        hidden: () => true,
    },
    enableAnalytics: {
        type: ControlType.Boolean,
        title: "Widget Analytics",
        defaultValue: ${e.enableAnalytics!==!1},
            },
    customizationNote: {
        type: ControlType.Enum,
        title: "Note",
        options: ["explore"],
        optionTitles: ["Explore more customization with our plugin editor panel"],
        defaultValue: "explore",
        description: "Explore more customization with our plugin editor panel",
            },
})
`}function vi(e){return{canvasPreview:`modal`,widgetMode:e.widgetMode||`modal`,modalTheme:e.modalTheme||`whatsapp`,modalCustomGradient:e.modalCustomGradient||`linear-gradient(135deg, #6366f1 0%, #a855f7 100%)`,modalTitle:e.modalTitle||`Hi there!`,modalSubtitle:e.modalSubtitle||`Welcome to our live chat! Feel free to ask any questions.`,modalResponseTime:e.modalResponseTime||`We typically reply within a few minutes`,modalChatBubble:e.modalChatBubble||`We typically reply within a few minutes. How can we help you today?`,modalStartChatText:e.modalStartChatText||`Start chat`,position:e.position||`bottom-right`,layout:e.layout||`stack`,animation:e.animation||`pop`,buttonColor:e.buttonColor||`#25D366`,buttonShape:e.buttonShape||`circle`,launcherText:`Chat`,launcherIcon:e.launcherIcon||`chat`,showLabels:!!e.showLabels,mobileShowLabels:!!(e.mobileShowLabels??!1),mobileOffsetX:Number(e.mobileOffsetX??16),mobileOffsetY:Number(e.mobileOffsetY??16),mobileCapChannels:!!(e.mobileCapChannels??!0),closeOnOutsideClick:!!(e.closeOnOutsideClick??!0),closeOnEscape:!!(e.closeOnEscape??!0),closeAfterClick:!!(e.closeAfterClick??!0),autoOpen:!!e.autoOpen,greetingEnabled:!!e.greetingEnabled,greetingText:e.greetingText||`Need help? Chat with us.`,enableSound:!!e.enableSound,showBadge:!!e.showBadge,badgeText:e.badgeText||`1`,enableAnalytics:e.enableAnalytics!==!1,scrollTriggerEnabled:!!e.scrollTriggerEnabled,scrollTriggerPercent:Number(e.scrollTriggerPercent??25),scrollTriggerTarget:e.scrollTriggerTarget||`launcher`,exitIntentEnabled:!!e.exitIntentEnabled,exitIntentAction:e.exitIntentAction||`modal`,scheduleEnabled:!!e.scheduleEnabled,scheduleStart:e.scheduleStart||`09:00`,scheduleEnd:e.scheduleEnd||`18:00`,scheduleOfflineAction:e.scheduleOfflineAction||`badge`,scheduleOfflineText:e.scheduleOfflineText||`Back tomorrow at 9:00 AM`,targetingEnabled:!!e.targetingEnabled,showOn:e.showOn||`Every page`,targetingMode:e.targetingMode||`show`,targetingRules:e.targetingRules||``,whatsapp:K(e,`whatsapp`),whatsappMessage:e.channels.find(e=>e.id===`whatsapp`)?.message||`Hello! I would like to know more.`,messenger:K(e,`messenger`),telegram:K(e,`telegram`),telegramMessage:e.channels.find(e=>e.id===`telegram`)?.message||`Hello!`,instagram:K(e,`instagram`),tiktok:K(e,`tiktok`),wechat:K(e,`wechat`),viber:K(e,`viber`),line:K(e,`line`),signal:K(e,`signal`),phone:K(e,`phone`),sms:K(e,`sms`),smsMessage:e.channels.find(e=>e.id===`sms`)?.message||``,email:K(e,`email`),emailSubject:e.channels.find(e=>e.id===`email`)?.emailSubject||``,emailMessage:e.channels.find(e=>e.id===`email`)?.message||``,discord:K(e,`discord`),slack:K(e,`slack`),teams:K(e,`teams`),x:K(e,`x`),linkedin:K(e,`linkedin`),maps:K(e,`maps`),custom:K(e,`custom`),customLabel:e.channels.find(e=>e.id===`custom`)?.label||`Custom`,agentsData:JSON.stringify(e.agents||[]),scheduleDaysData:JSON.stringify(e.scheduleDays||[1,2,3,4,5])}}var yi=null;function bi(e){yi&&clearTimeout(yi),yi=setTimeout(async()=>{await xi(e)},2e3)}async function xi(e){yi&&=(clearTimeout(yi),null);try{if(typeof U.isAllowedTo==`function`&&!await U.isAllowedTo(`CodeFile.setFileContent`))return;let t=await fi().catch(()=>null),n=_i(e,t?.siteId,t?.siteUrl,mi,!pi),r=(await U.getCodeFiles()).find(e=>e.name===`ChatBubbles.tsx`||e.name===`ChatBubbles`||e.name===`Chatfic`);r&&await r.setFileContent(n)}catch{}}async function Si(e,t=!1){try{if(typeof U.isAllowedTo==`function`)try{await U.isAllowedTo(`setAttributes`,`getNodesWithType`,`getNode`)}catch{}let n=(await U.getNodesWithType(`ComponentInstanceNode`))?.filter(wi)||[],r=vi(e);if(n.length>0)for(let e of n)typeof e.setAttributes==`function`&&await e.setAttributes({controls:r});return t?await xi(e):bi(e),!0}catch{return!1}}async function Ci(e,t=pi,n=mi){pi=t,mi=n;let r=await fi().catch(()=>null),i=_i(e,r?.siteId,r?.siteUrl,n,!t),a=`ChatBubbles.tsx`;try{if(typeof U.isAllowedTo==`function`)try{await U.isAllowedTo(`CodeFile.setFileContent`,`createCodeFile`,`addComponentInstance`,`setSelection`,`setAttributes`,`getNodesWithType`,`getNode`,`setParent`,`removeNodes2`,`Node.remove`)}catch{}let t=(await U.getCodeFiles()).find(e=>e.name===a||e.name===`ChatBubbles`||e.name===`Chatfic`);t?await t.setFileContent(i):t=await U.createCodeFile(a,i,{editViaPlugin:!0});let n=vi(e),r=await U.getNodesWithType(`WebPageNode`)||[],o=await U.getNodesWithType(`DesignPageNode`)||[],s=[...r,...o],c=(await U.getNodesWithType(`ComponentInstanceNode`)||[]).filter(wi),l=t.exports.find(e=>e.type===`component`);if(!l||!(`insertURL`in l))return{success:!0,message:`Chat Bubbles component created in your Code Assets! You can drag it onto any page.`};let u=e.showOn||`Every page`,d=[];if(u===`Every page`)d=s;else if(u===`Home page`){let e=s.find(e=>`path`in e&&e.path?e.path===`/`||e.path===``:`name`in e&&e.name?e.name.toLowerCase()===`home`||e.name.toLowerCase()===`index`:!1)||s[0];e&&(d=[e])}else if(u===`custom`){let t=String(e.targetingRules||``).split(`,`).flatMap(e=>e.split(`
`)).flatMap(e=>e.split(`;`)).map(e=>e.trim().toLowerCase()).filter(Boolean);d=t.length===0?s:s.filter(e=>{let n=(`path`in e&&e.path?e.path:`/`+(e.name||``)).toLowerCase();return t.some(e=>{if(e===`*`||e===`/*`)return!0;let t=e.startsWith(`/`)?e:`/`+e;return!!(t===n||t.endsWith(`/*`)&&n.startsWith(t.slice(0,-2)+`/`)||t.endsWith(`*`)&&n.startsWith(t.slice(0,-1)))})})}else{let e=u.toLowerCase().replace(/^\/+/,``),t=s.find(t=>{if(`path`in t&&t.path){let n=String(t.path).toLowerCase().replace(/^\/+/,``);if(t.path===u||n===e)return!0}if(`name`in t&&t.name){let n=String(t.name).toLowerCase().replace(/^\/+/,``);if(t.name===u||`/`+n===u||n===e)return!0}return`id`in t&&t.id===u});if(t)d=[t];else try{let e=await U.getSelection();if(e&&e.length>0){let t=e[0].id;for(;t;){let e=await U.getNode(t);if(!e)break;if(e.type===`WebPageNode`||e.type===`DesignPageNode`){d=[e];break}t=e.parentId}}}catch{}}let f=new Map,p=new Set;for(let e of c){let t=e.id,n=null,r=`/`;for(;t;){let e=await U.getNode(t);if(!e)break;if(e.type===`WebPageNode`||e.type===`DesignPageNode`){n=e.id,r=`path`in e&&e.path?e.path:`/`+(e.name||``).replace(/^\/+/,``);break}t=e.parentId}n&&p.add(n),f.set(e,{pageId:n,pagePath:r})}let m=[...c],h=d.filter(e=>!p.has(e.id)),g=0;for(let e of h){let t=`path`in e&&e.path?e.path:`/`+(e.name||``).replace(/^\/+/,``);try{let r=await U.addComponentInstance({url:l.insertURL,parentId:e.id,attributes:{controls:n}});r?.id&&(m.push(r),f.set(r,{pageId:e.id,pagePath:t}),p.add(e.id),g++)}catch(t){console.warn(`[ChatBubbles] Failed to insert component onto page:`,e.name||e.id,t)}}if(m.length===0){let e;try{let t=await U.getSelection();t&&t.length>0&&(e=t[0].id)}catch{}let t=await U.addComponentInstance({url:l.insertURL,parentId:e,attributes:{controls:n}});t?.id&&(m.push(t),g++)}for(let e of m){let t=f.get(e)?.pagePath||`/`;typeof e.setAttributes==`function`&&await e.setAttributes({controls:{...n,canvasPagePath:t}})}if(m[0]?.id)try{await U.setSelection([m[0].id])}catch{}let _=`Chat Bubbles component updated on canvas!`;return g>0?_=u===`Every page`?`Chat Bubbles component inserted onto ${g} page(s)!`:`Chat Bubbles component inserted on ${u}!`:m.length>0&&(_=u===`Every page`?`Chat Bubbles component updated across your pages!`:`Chat Bubbles component targeting updated to ${u}!`),{success:!0,message:_}}catch(e){return{success:!1,message:e instanceof Error?e.message:`Failed to insert component onto canvas.`}}}function wi(e){return e?!!(e.componentName===`ChatBubbles`||e.componentName===`Chatfic`||typeof e.name==`string`&&(e.name.includes(`ChatBubbles`)||e.name.includes(`Chatfic`))||typeof e.insertURL==`string`&&(e.insertURL.includes(`ChatBubbles`)||e.insertURL.includes(`Chatfic`))||typeof e.componentIdentifier==`string`&&(e.componentIdentifier.includes(`ChatBubbles`)||e.componentIdentifier.includes(`Chatfic`))):!1}var Ti=`https://app.framefic.com/chat-bubbles`,Ei=e=>{let t=e.startsWith(`/`)?e:`/${e}`;return`${Ti.replace(/\/+$/,``)}${t}`},Di=o((e=>{var t=u(),n=Symbol.for(`react.element`),r=Symbol.for(`react.fragment`),i=Object.prototype.hasOwnProperty,a=t.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner,o={key:!0,ref:!0,__self:!0,__source:!0};function s(e,t,r){var s,c={},l=null,u=null;for(s in r!==void 0&&(l=``+r),t.key!==void 0&&(l=``+t.key),t.ref!==void 0&&(u=t.ref),t)i.call(t,s)&&!o.hasOwnProperty(s)&&(c[s]=t[s]);if(e&&e.defaultProps)for(s in t=e.defaultProps,t)c[s]===void 0&&(c[s]=t[s]);return{$$typeof:n,type:e,key:l,ref:u,props:c,_owner:a.current}}e.Fragment=r,e.jsx=s,e.jsxs=s})),q=o(((e,t)=>{t.exports=Di()}))();function J({label:e,hint:t,children:n,full:r=!1}){return(0,q.jsxs)(`div`,{className:`cf-field ${r?`full`:``}`,children:[(0,q.jsx)(`label`,{className:`cf-field-label`,children:e}),(0,q.jsx)(`div`,{className:`cf-field-control`,children:n}),t?(0,q.jsx)(`span`,{className:`cf-field-hint`,children:t}):null]})}function Oi({title:e,description:t,badge:n,action:r,children:i}){return(0,q.jsxs)(`section`,{className:`cf-section`,children:[(0,q.jsxs)(`div`,{className:`cf-section-header${r?` has-action`:``}`,children:[(0,q.jsxs)(`div`,{className:`cf-section-header-info`,children:[(0,q.jsxs)(`div`,{className:`cf-section-title-row`,children:[(0,q.jsx)(`h2`,{className:`cf-section-title`,children:e}),n]}),t?(0,q.jsx)(`p`,{className:`cf-section-desc`,children:t}):null]}),r?(0,q.jsx)(`div`,{className:`cf-section-action`,children:r}):null]}),i?(0,q.jsx)(`div`,{className:`cf-section-body`,children:i}):null]})}function Y({checked:e,onChange:t,id:n,disabled:r=!1}){return(0,q.jsx)(`button`,{id:n,type:`button`,role:`switch`,"aria-checked":e,disabled:r,className:`cf-switch ${e?`is-on`:``}`,onClick:n=>{n.preventDefault(),n.stopPropagation(),r||t(!e)},children:(0,q.jsx)(`span`,{className:`cf-switch-thumb`})})}function ki({size:e=14,...t}){return(0,q.jsxs)(`svg`,{width:e,height:e,viewBox:`0 0 24 24`,fill:`none`,stroke:`currentColor`,strokeWidth:`2`,strokeLinecap:`round`,strokeLinejoin:`round`,...t,children:[(0,q.jsx)(`circle`,{cx:`12`,cy:`12`,r:`3`}),(0,q.jsx)(`path`,{d:`M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z`})]})}function Ai({size:e=14,...t}){return(0,q.jsx)(`svg`,{width:e,height:e,viewBox:`0 0 16 16`,fill:`none`,stroke:`currentColor`,strokeWidth:`1.8`,strokeLinecap:`round`,strokeLinejoin:`round`,...t,children:(0,q.jsx)(`path`,{d:`M4 4l8 8M12 4l-8 8`})})}function ji({size:e=14,...t}){return(0,q.jsxs)(`svg`,{width:e,height:e,viewBox:`0 0 16 16`,fill:`none`,stroke:`currentColor`,strokeWidth:`1.5`,strokeLinecap:`round`,strokeLinejoin:`round`,...t,children:[(0,q.jsx)(`path`,{d:`M2.5 5.5A1.5 1.5 0 0 1 4 4h1.5l1-1.5h3l1 1.5H12a1.5 1.5 0 0 1 1.5 1.5v6.5a1.5 1.5 0 0 1-1.5 1.5H4a1.5 1.5 0 0 1-1.5-1.5V5.5z`}),(0,q.jsx)(`circle`,{cx:`8`,cy:`8.7`,r:`2.2`})]})}function Mi({size:e=14,...t}){return(0,q.jsxs)(`svg`,{width:e,height:e,viewBox:`0 0 16 16`,fill:`none`,stroke:`currentColor`,strokeWidth:`1.6`,strokeLinecap:`round`,strokeLinejoin:`round`,...t,children:[(0,q.jsx)(`path`,{d:`M8 10V2M5 5l3-3 3 3`}),(0,q.jsx)(`path`,{d:`M2.5 10v3a1 1 0 0 0 1 1h9a1 1 0 0 0 1-1v-3`})]})}function Ni({size:e=14,...t}){return(0,q.jsxs)(`svg`,{width:e,height:e,viewBox:`0 0 16 16`,fill:`none`,stroke:`currentColor`,strokeWidth:`1.6`,strokeLinecap:`round`,strokeLinejoin:`round`,...t,children:[(0,q.jsx)(`circle`,{cx:`8`,cy:`5`,r:`3`}),(0,q.jsx)(`path`,{d:`M2.5 14a5.5 5.5 0 0 1 11 0`})]})}function Pi({size:e=14,...t}){return(0,q.jsxs)(`svg`,{width:e,height:e,viewBox:`0 0 16 16`,fill:`none`,stroke:`currentColor`,strokeWidth:`1.6`,strokeLinecap:`round`,strokeLinejoin:`round`,...t,children:[(0,q.jsx)(`path`,{d:`M6.5 9.5l3-3`}),(0,q.jsx)(`path`,{d:`M9 5l1.5-1.5a2.5 2.5 0 0 1 3.5 3.5L12.5 8.5a2.5 2.5 0 0 1-3.5 0`}),(0,q.jsx)(`path`,{d:`M7 11l-1.5 1.5a2.5 2.5 0 0 1-3.5-3.5L3.5 7.5a2.5 2.5 0 0 1 3.5 0`})]})}function Fi({size:e=14,...t}){return(0,q.jsxs)(`svg`,{width:e,height:e,viewBox:`0 0 16 16`,fill:`none`,stroke:`currentColor`,strokeWidth:`1.6`,strokeLinecap:`round`,strokeLinejoin:`round`,...t,children:[(0,q.jsx)(`path`,{d:`M2 7.5A6 6 0 1 1 3.8 12`}),(0,q.jsx)(`path`,{d:`M2 3.5v4h4`})]})}function Ii({size:e=14,...t}){return(0,q.jsx)(`svg`,{width:e,height:e,viewBox:`0 0 16 16`,fill:`none`,stroke:`currentColor`,strokeWidth:`1.8`,strokeLinecap:`round`,strokeLinejoin:`round`,...t,children:(0,q.jsx)(`path`,{d:`M5.5 3.5L10 8l-4.5 4.5`})})}function Li({size:e=14,...t}){return(0,q.jsxs)(`svg`,{width:e,height:e,viewBox:`0 0 16 16`,fill:`none`,stroke:`currentColor`,strokeWidth:`1.8`,strokeLinecap:`round`,strokeLinejoin:`round`,className:`cf-spinner`,...t,children:[(0,q.jsx)(`path`,{d:`M8 2a6 6 0 1 0 6 6`,strokeOpacity:`0.3`}),(0,q.jsx)(`path`,{d:`M14 8a6 6 0 0 0-6-6`})]})}function Ri({size:e=16,...t}){return(0,q.jsxs)(`svg`,{width:e,height:e,viewBox:`0 0 16 16`,fill:`none`,stroke:`currentColor`,strokeWidth:`1.5`,strokeLinecap:`round`,strokeLinejoin:`round`,...t,children:[(0,q.jsx)(`rect`,{x:`2`,y:`2`,width:`12`,height:`12`,rx:`2.5`}),(0,q.jsx)(`path`,{d:`M2 6h12M10.5 4h1`})]})}function X({size:e=16,...t}){return(0,q.jsxs)(`svg`,{width:e,height:e,viewBox:`0 0 16 16`,fill:`none`,stroke:`currentColor`,strokeWidth:`1.5`,strokeLinecap:`round`,strokeLinejoin:`round`,...t,children:[(0,q.jsx)(`circle`,{cx:`4`,cy:`4`,r:`2`}),(0,q.jsx)(`circle`,{cx:`4`,cy:`9`,r:`2`}),(0,q.jsx)(`circle`,{cx:`4`,cy:`14`,r:`2`}),(0,q.jsx)(`path`,{d:`M8 4h6M8 9h6M8 14h4`})]})}function Z({size:e=14,...t}){return(0,q.jsx)(`svg`,{width:e,height:e,viewBox:`0 0 16 16`,fill:`none`,stroke:`currentColor`,strokeWidth:`1.8`,strokeLinecap:`round`,strokeLinejoin:`round`,...t,children:(0,q.jsx)(`path`,{d:`M8 3v10M3 8h10`})})}function zi({size:e=16,...t}){return(0,q.jsx)(`svg`,{width:e,height:e,viewBox:`0 0 24 24`,fill:`none`,stroke:`currentColor`,strokeWidth:`2`,strokeLinecap:`round`,strokeLinejoin:`round`,...t,children:(0,q.jsx)(`path`,{d:`m12 3-1.9 5.8a2 2 0 0 1-1.3 1.3L3 12l5.8 1.9a2 2 0 0 1 1.3 1.3L12 21l1.9-5.8a2 2 0 0 1 1.3-1.3L21 12l-5.8-1.9a2 2 0 0 1-1.3-1.3Z`})})}function Bi({size:e=14,...t}){return(0,q.jsx)(`svg`,{width:e,height:e,viewBox:`0 0 16 16`,fill:`none`,stroke:`currentColor`,strokeWidth:`1.8`,strokeLinecap:`round`,strokeLinejoin:`round`,...t,children:(0,q.jsx)(`path`,{d:`M3.5 6L8 10.5 12.5 6`})})}function Vi({size:e=14,...t}){return(0,q.jsxs)(`svg`,{width:e,height:e,viewBox:`0 0 24 24`,fill:`none`,stroke:`currentColor`,strokeWidth:`2`,strokeLinecap:`round`,strokeLinejoin:`round`,...t,children:[(0,q.jsx)(`line`,{x1:`7`,y1:`17`,x2:`17`,y2:`7`}),(0,q.jsx)(`polyline`,{points:`7 7 17 7 17 17`})]})}function Hi({size:e=14,...t}){return(0,q.jsxs)(`svg`,{width:e,height:e,viewBox:`0 0 24 24`,fill:`none`,stroke:`currentColor`,strokeWidth:`2`,strokeLinecap:`round`,strokeLinejoin:`round`,...t,children:[(0,q.jsx)(`polygon`,{points:`11 5 6 9 2 9 2 15 6 15 11 19 11 5`}),(0,q.jsx)(`path`,{d:`M15.54 8.46a5 5 0 0 1 0 7.07`}),(0,q.jsx)(`path`,{d:`M19.07 4.93a10 10 0 0 1 0 14.14`})]})}function Ui({size:e=18,...t}){return(0,q.jsxs)(`svg`,{width:e,height:e,viewBox:`0 0 24 24`,fill:`none`,stroke:`currentColor`,strokeWidth:`2`,strokeLinecap:`round`,strokeLinejoin:`round`,...t,children:[(0,q.jsx)(`circle`,{cx:`12`,cy:`12`,r:`10`}),(0,q.jsx)(`line`,{x1:`12`,y1:`16`,x2:`12`,y2:`12`}),(0,q.jsx)(`line`,{x1:`12`,y1:`8`,x2:`12.01`,y2:`8`})]})}function Wi({size:e=18,...t}){return(0,q.jsxs)(`svg`,{width:e,height:e,viewBox:`0 0 24 24`,fill:`none`,stroke:`currentColor`,strokeWidth:`2`,strokeLinecap:`round`,strokeLinejoin:`round`,...t,children:[(0,q.jsx)(`circle`,{cx:`12`,cy:`12`,r:`10`}),(0,q.jsx)(`path`,{d:`M8 12l2.8 2.8L16.5 9`})]})}function Gi({size:e=18,...t}){return(0,q.jsxs)(`svg`,{width:e,height:e,viewBox:`0 0 24 24`,fill:`none`,stroke:`currentColor`,strokeWidth:`2`,strokeLinecap:`round`,strokeLinejoin:`round`,...t,children:[(0,q.jsx)(`path`,{d:`M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z`}),(0,q.jsx)(`line`,{x1:`12`,y1:`9`,x2:`12`,y2:`13`}),(0,q.jsx)(`line`,{x1:`12`,y1:`17`,x2:`12.01`,y2:`17`})]})}function Ki({size:e=18,...t}){return(0,q.jsxs)(`svg`,{width:e,height:e,viewBox:`0 0 24 24`,fill:`none`,stroke:`currentColor`,strokeWidth:`2`,strokeLinecap:`round`,strokeLinejoin:`round`,...t,children:[(0,q.jsx)(`circle`,{cx:`12`,cy:`12`,r:`10`}),(0,q.jsx)(`line`,{x1:`15`,y1:`9`,x2:`9`,y2:`15`}),(0,q.jsx)(`line`,{x1:`9`,y1:`9`,x2:`15`,y2:`15`})]})}function qi({size:e=14,...t}){return(0,q.jsxs)(`svg`,{width:e,height:e,viewBox:`0 0 24 24`,fill:`none`,stroke:`currentColor`,strokeWidth:`2`,strokeLinecap:`round`,strokeLinejoin:`round`,...t,children:[(0,q.jsx)(`line`,{x1:`18`,y1:`20`,x2:`18`,y2:`10`}),(0,q.jsx)(`line`,{x1:`12`,y1:`20`,x2:`12`,y2:`4`}),(0,q.jsx)(`line`,{x1:`6`,y1:`20`,x2:`6`,y2:`14`})]})}function Ji({size:e=14,...t}){return(0,q.jsxs)(`svg`,{width:e,height:e,viewBox:`0 0 24 24`,fill:`none`,stroke:`currentColor`,strokeWidth:`2`,strokeLinecap:`round`,strokeLinejoin:`round`,...t,children:[(0,q.jsx)(`polyline`,{points:`23 6 13.5 15.5 8.5 10.5 1 18`}),(0,q.jsx)(`polyline`,{points:`17 6 23 6 23 12`})]})}function Yi({size:e=14,...t}){return(0,q.jsxs)(`svg`,{width:e,height:e,viewBox:`0 0 24 24`,fill:`none`,stroke:`currentColor`,strokeWidth:`2`,strokeLinecap:`round`,strokeLinejoin:`round`,...t,children:[(0,q.jsx)(`path`,{d:`M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z`}),(0,q.jsx)(`circle`,{cx:`12`,cy:`12`,r:`3`})]})}function Xi({size:e=14,...t}){return(0,q.jsxs)(`svg`,{width:e,height:e,viewBox:`0 0 24 24`,fill:`none`,stroke:`currentColor`,strokeWidth:`2`,strokeLinecap:`round`,strokeLinejoin:`round`,...t,children:[(0,q.jsx)(`path`,{d:`M3 3l7.07 16.97 2.51-7.39 7.39-2.51L3 3z`}),(0,q.jsx)(`path`,{d:`M13 13l6 6`})]})}function Zi({size:e=24,...t}){return(0,q.jsxs)(`svg`,{width:e,height:e,viewBox:`0 0 24 24`,fill:`none`,stroke:`currentColor`,strokeWidth:`2`,strokeLinecap:`round`,strokeLinejoin:`round`,...t,children:[(0,q.jsx)(`line`,{x1:`18`,y1:`6`,x2:`6`,y2:`18`}),(0,q.jsx)(`line`,{x1:`6`,y1:`6`,x2:`18`,y2:`18`})]})}function Qi({title:e,description:t,badgeLabel:n,badgeType:r=`brand`,badgeIcon:i,statusBadge:a,ctaLabel:o,ctaIcon:s=(0,q.jsx)(zi,{size:16}),onCtaClick:c,disabled:l=!1,illustration:u,children:d}){return(0,q.jsxs)(`div`,{className:`cf-hero-card`,children:[n||a||u?(0,q.jsxs)(`div`,{className:`cf-hero-card-header`,children:[n?(0,q.jsx)(`div`,{className:`cf-hero-card-badges`,children:(0,q.jsxs)(`span`,{className:`cf-badge cf-badge-${r}`,children:[i,(0,q.jsx)(`span`,{children:n})]})}):(0,q.jsx)(`div`,{}),a||u]}):null,(0,q.jsxs)(`div`,{className:`cf-hero-card-content`,children:[(0,q.jsx)(`h2`,{className:`cf-hero-card-title`,children:e}),(0,q.jsx)(`p`,{className:`cf-hero-card-desc`,children:t})]}),d?(0,q.jsx)(`div`,{className:`cf-hero-card-extra`,children:d}):null,o&&c?(0,q.jsxs)(`button`,{type:`button`,className:`primary-cta cf-hero-cta`,onClick:c,disabled:l,children:[(0,q.jsx)(`span`,{children:o}),s]}):null]})}var $i=e=>e?.replace(/([a-z0-9])([A-Z])/g,`$1-$2`).toLowerCase();function ea(e,t,n=[]){if(t==null)throw Error(`[lucide]: iconNode is required when icon name is used`);return{name:$i(e),size:24,node:t,...n.length>0?{aliases:n}:{}}}var ta=e=>{let t=``,n=!1;for(let r of e){if(r===`-`||r===`_`||r<=` `){n=t.length>0;continue}t.length===0?t+=r.toLowerCase():t+=n?r.toUpperCase():r,n=!1}return t},na=e=>{let t=ta(e);return t.charAt(0).toUpperCase()+t.slice(1)},ra=(...e)=>e.filter((e,t,n)=>!!e&&e.trim()!==``&&n.indexOf(e)===t).join(` `).trim(),ia={xmlns:`http://www.w3.org/2000/svg`,width:24,height:24,viewBox:`0 0 24 24`,fill:`none`,stroke:`currentColor`,"stroke-width":2,"stroke-linecap":`round`,"stroke-linejoin":`round`};function aa(e){return e!=null}function oa(e,t={}){let n=t.attributeNames??{},r=e=>n[e]??e,i=e.size??e.width??ia.width,a=e.size??e.height??ia.height,o=e.aliases?.filter(e=>typeof e==`string`&&e.trim()!==``).map(e=>`lucide-${e}`)??[],s=[...e.name?[`lucide-${e.name}`]:[],...o],c=t.className?.split(` `).filter(Boolean)??[],l=t.includeDefaultClasses===!1?ra(...c):ra(`lucide`,...s,...c),u=t.absoluteStrokeWidth?Number(t.strokeWidth??ia[`stroke-width`])*Number(e.size??e.width??ia.width)/Number(t.size??t.width??ia.width):t.strokeWidth??ia[`stroke-width`];return[`svg`,{...Object.entries(ia).reduce((e,[t,n])=>(e[r(t)]=n,e),{}),...`color`in t&&t.color&&{[r(`stroke`)]:t.color},...`size`in t&&aa(t.size)&&{[r(`width`)]:t.size,[r(`height`)]:t.size},...`width`in t&&aa(t.width)&&{[r(`width`)]:t.width},...`height`in t&&aa(t.height)&&{[r(`height`)]:t.height},[r(`stroke-width`)]:u,...l&&{[r(`class`)]:l},[r(`viewBox`)]:`0 0 ${i} ${a}`,...t.hasA11yProp===!1?{[r(`aria-hidden`)]:`true`}:{},...`attributes`in t&&t.attributes},e.node.map(e=>{let[n,i,a]=e,o=t.nonScalingStroke?{[r(`vector-effect`)]:`non-scaling-stroke`,...i}:i;return a?[n,o,a]:[n,o]})]}function sa(e,t={}){return oa(e,{...t,attributeNames:{...t.attributeNames,class:`className`,"stroke-width":`strokeWidth`,"stroke-linecap":`strokeLinecap`,"stroke-linejoin":`strokeLinejoin`,"vector-effect":`vectorEffect`}})}var ca=e=>{for(let t in e)if(t.startsWith(`aria-`)||t===`role`||t===`title`)return!0;return!1},la=(0,d.createContext)({}),ua=()=>(0,d.useContext)(la),da=(0,d.forwardRef)(({color:e,size:t,width:n,height:r,strokeWidth:i,absoluteStrokeWidth:a,nonScalingStroke:o,className:s=``,children:c,iconNode:l=[],icon:u={node:l,aliases:[],size:24},...f},p)=>{let{size:m=24,strokeWidth:h=2,absoluteStrokeWidth:g=!1,nonScalingStroke:_=!1,color:v=`currentColor`,className:y=``}=ua()??{},b=!!c||ca(f),[x,S,C=[]]=sa(u,{color:e??v,width:n??t??m,height:r??t??m,strokeWidth:i??h,absoluteStrokeWidth:a??g,nonScalingStroke:o??_,className:ra(y,s),hasA11yProp:b,attributes:f});return(0,d.createElement)(x,{ref:p,...S},[...C.map(([e,t])=>(0,d.createElement)(e,t)),...Array.isArray(c)?c:[c]])});function fa(e,t=[],n=[]){let r=typeof e==`string`?ea(e,t,n):e,i=(0,d.forwardRef)(({className:e,...t},n)=>(0,d.createElement)(da,{ref:n,icon:r,className:e,...t}));return r.name&&(i.displayName=na(r.name)),i}var pa={name:`arrow-left`,size:24,node:[[`path`,{d:`m12 19-7-7 7-7`,key:`1l729n`}],[`path`,{d:`M19 12H5`,key:`x3x0zl`}]]};pa.node;var ma=fa(pa),ha={name:`check`,size:24,node:[[`path`,{d:`M20 6 9 17l-5-5`,key:`1gmf2c`}]]};ha.node;var ga=fa(ha),_a={name:`clock`,size:24,node:[[`circle`,{cx:`12`,cy:`12`,r:`10`,key:`1mglay`}],[`path`,{d:`M12 6v6l4 2`,key:`mmk7yg`}]]};_a.node;var va=fa(_a),ya={name:`copy`,size:24,node:[[`rect`,{width:`14`,height:`14`,x:`8`,y:`8`,rx:`2`,ry:`2`,key:`17jyea`}],[`path`,{d:`M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2`,key:`zix9uf`}]]};ya.node;var ba=fa(ya),xa={name:`crown`,size:24,node:[[`path`,{d:`M11.562 3.266a.5.5 0 0 1 .876 0L15.39 8.87a1 1 0 0 0 1.516.294L21.183 5.5a.5.5 0 0 1 .798.519l-2.834 10.246a1 1 0 0 1-.956.734H5.81a1 1 0 0 1-.957-.734L2.02 6.02a.5.5 0 0 1 .798-.519l4.276 3.664a1 1 0 0 0 1.516-.294z`,key:`1vdc57`}],[`path`,{d:`M5 21h14`,key:`11awu3`}]]};xa.node;var Sa=fa(xa),Ca={name:`lock-keyhole`,size:24,node:[[`circle`,{cx:`12`,cy:`16`,r:`1`,key:`1au0dj`}],[`rect`,{x:`3`,y:`10`,width:`18`,height:`12`,rx:`2`,key:`6s8ecr`}],[`path`,{d:`M7 10V7a5 5 0 0 1 10 0v3`,key:`1pqi11`}]]};Ca.node;var wa=fa(Ca),Ta={name:`lock`,size:24,node:[[`rect`,{width:`18`,height:`11`,x:`3`,y:`11`,rx:`2`,ry:`2`,key:`1w4ew1`}],[`path`,{d:`M7 11V7a5 5 0 0 1 10 0v4`,key:`fwvmzm`}]]};Ta.node;var Ea=fa(Ta),Da={name:`x`,size:24,node:[[`path`,{d:`M18 6 6 18`,key:`1bl5f8`}],[`path`,{d:`m6 6 12 12`,key:`d8bk6v`}]]};Da.node;var Oa=fa(Da),ka={monthly:{key:`monthly`,title:`Monthly Plan`,price:`$4.99`,suffix:`Monthly`,amount:4.99,label:`Monthly`,mode:`subscription`},yearly:{key:`yearly`,title:`Yearly Plan`,price:`$49.99`,suffix:`Annually`,amount:49.99,label:`Yearly`,mode:`subscription`},lifetime:{key:`lifetime`,title:`Lifetime Plan`,price:`$99.99`,suffix:`One time`,amount:99.99,label:`Lifetime`,mode:`payment`,badge:`🔥 Limited`}},Aa=[`19 channels widget`,`Unlimited multi-agent support team`,`Full custom themes & color gradients`,`Canvas style controls & zero watermarks`,`Real-time analytics & click tracking`],ja=`chat_bubbles_auth_token`,Ma=`chat_bubbles_auth_user`,Na=`chat_bubbles_auth_has_account`,Pa=`chat_bubbles_known_site_id`,Fa=()=>{try{localStorage.setItem(Na,`1`)}catch{}},Ia=(e,t)=>{try{localStorage.setItem(ja,e),localStorage.setItem(Ma,JSON.stringify(t))}catch{}},La=()=>{try{return localStorage.getItem(ja)}catch{return null}},Ra=()=>{try{let e=localStorage.getItem(Ma);return e?JSON.parse(e):null}catch{return null}},za=()=>{try{localStorage.removeItem(ja),localStorage.removeItem(Ma)}catch{}},Ba=()=>!!La(),Va=e=>{try{e&&localStorage.setItem(Pa,e)}catch{}},Ha=()=>{try{localStorage.removeItem(Pa)}catch{}},Ua=async(e,t={})=>{let n=La(),r={"Content-Type":`application/json`,...t.headers||{}};n&&(r.Authorization=`Bearer ${n}`);let i=await fetch(Ei(e),{...t,headers:r}),a=await i.json().catch(()=>({}));if(!i.ok)throw Error(a.message||a.error||`Request failed with status ${i.status}`);return a},Wa=async({email:e,username:t=null,siteId:n=null})=>Ua(`/api/auth/send-otp`,{method:`POST`,body:JSON.stringify({email:e,username:t,siteId:n})}),Ga=async({email:e,code:t,username:n=null,siteId:r=null})=>{let i=await Ua(`/api/auth/verify-otp`,{method:`POST`,body:JSON.stringify({email:e,code:t,username:n,siteId:r})});return i.token&&i.user&&(Ia(i.token,i.user),Fa()),i},Ka=async()=>{try{let e=await Ua(`/api/auth/me`);if(e.user){let t=La();return t&&Ia(t,e.user),e.user}return null}catch(e){return(e.message?.includes(`401`)||e.message?.includes(`unauthorized`)||e.message?.includes(`token`))&&za(),null}},qa=async e=>{try{return await Ua(`/api/auth/social-status?sessionId=${encodeURIComponent(e)}`)}catch{return{status:`pending`}}},Ja=async(e,t)=>{let n=(e.headers.get(`content-type`)||``).includes(`application/json`),r=n?await e.json():await e.text();if(!e.ok){let i=Error(n?r?.message||t:typeof r==`string`&&r.trim()?r:t);throw i.status=e.status,i}if(!n){let n=Error(t);throw n.status=e.status,n}return r},Ya=async(e,t,n={})=>await Ja(await fetch(Ei(e),n),t),Xa=e=>{let t=ka;return t[e]??t.monthly},Za=async()=>Ya(`/api/payment-config`,`Failed to fetch payment config`),Qa=async()=>Ya(`/api/lifetime-availability`,`Failed to check lifetime availability`),$a=async(e,t,n)=>Ya(`/api/create-payment-intent`,`Payment creation failed`,{method:`POST`,headers:{"Content-Type":`application/json`},body:JSON.stringify({plan:e,siteId:t,couponCode:n||void 0})}),eo=async(e,t,n,r)=>Ya(`/api/apply-coupon`,`Failed to apply coupon`,{method:`POST`,headers:{"Content-Type":`application/json`},body:JSON.stringify({subscriptionId:e,couponCode:t,paymentIntentId:n,plan:r})}),to=async({paymentIntentId:e,siteId:t,email:n,plan:r,subscriptionId:i=null})=>Ya(`/api/verify-payment`,`Payment verification failed`,{method:`POST`,headers:{"Content-Type":`application/json`},body:JSON.stringify({paymentIntentId:e,siteId:t,email:n,plan:r,subscriptionId:i})}),no=async(e,t)=>{let n=new URLSearchParams({siteId:e});return t&&n.append(`email`,t),Ya(`/api/subscription-status?${n.toString()}`,`Failed to check subscription status`)},ro=async(e,t)=>{let n=new URLSearchParams({siteId:e});return t&&n.append(`email`,t),Ya(`/api/check-trial-eligibility?${n.toString()}`,`Failed to check trial eligibility`)},io=async e=>{let t=La();return Ya(`/api/start-trial`,`Failed to start free trial`,{method:`POST`,headers:{"Content-Type":`application/json`,...t?{Authorization:`Bearer ${t}`}:{}},body:JSON.stringify({siteId:e})})},ao=async(e,t)=>Ya(`/api/subscription/cancel`,`Failed to cancel subscription`,{method:`POST`,headers:{"Content-Type":`application/json`},body:JSON.stringify({siteId:e,feedback:t})}),oo=async(e,t)=>Ya(`/api/subscription/change-plan`,`Failed to change subscription plan`,{method:`POST`,headers:{"Content-Type":`application/json`},body:JSON.stringify({siteId:e,targetPlan:t})}),so=async e=>Ya(`/api/billing-portal-url?${`siteId=${encodeURIComponent(e)}`}`,`Failed to load billing portal`),co=async(e,t,n)=>null,lo={enabled:!0,campaignId:`bfcm26`,title:`Black Friday Offer`,subtitle:`Get 50% Off Plan.`,buttonText:`Get Now`,couponCode:`60LTDBFCM26`,countdownEnabled:!0,durationMinutes:3,countdownVisibleMinutes:3,linkUrl:``,action:`modal`,icon:`bell-ring`,showTo:`free`},uo=null,fo=null,po=()=>uo,mo=async(e,t)=>uo||fo||(fo=(async()=>{try{let e=await Ya(`/api/announcement`,`Failed to load announcement`,{signal:t});return e&&typeof e==`object`?(uo={enabled:!!e.enabled,campaignId:String(e.campaignId||`bfcm26`),title:String(e.title||`Black Friday Offer`),subtitle:String(e.subtitle||`Get 50% Off Plan.`),buttonText:String(e.buttonText||`Get Now`),couponCode:e.couponCode?String(e.couponCode):null,countdownEnabled:!!e.countdownEnabled,durationMinutes:Number(e.durationMinutes)||3,countdownVisibleMinutes:Number(e.countdownVisibleMinutes)||3,linkUrl:String(e.linkUrl||``),action:e.action||`modal`,icon:String(e.icon||`bell-ring`),showTo:e.showTo||`free`},uo):lo}catch{return lo}finally{fo=null}})(),fo),ho={monthly:{key:`monthly`,configured:!0,enabled:!0,amount:4.99,currency:`usd`,label:`Monthly Pro`,interval:`month`,formattedPrice:`$4.99`,discount:null},yearly:{key:`yearly`,configured:!0,enabled:!1,amount:49.99,currency:`usd`,label:`Yearly Pro`,interval:`year`,formattedPrice:`$49.99`,discount:null},lifetime:{key:`lifetime`,configured:!0,enabled:!0,amount:99.99,currency:`usd`,label:`Lifetime Access`,interval:null,formattedPrice:`$99.99`,discount:{code:`60LTDBFCM26`,type:`percentage`,amount:60,currencyCode:`usd`,formattedDiscount:`60% OFF`,discountedAmount:39.99,discountedFormattedPrice:`$39.99`,couponId:`Ylup0ipJ`},formattedDiscountedPrice:`$39.99`,defaultCouponCode:`60LTDBFCM26`}},go=null,_o=null,vo=()=>go||ho,yo=async e=>go||_o||(_o=(async()=>{for(let t of[`/api/plans`,`/plans`,`/chat-bubbles/api/plans`,`/api/plan-availability`])try{let n=await Ya(t,`Failed to fetch plans`,{signal:e}),r=n?.plans||n;if(r&&typeof r==`object`&&(r.monthly||r.lifetime)){let e={};for(let t of[`monthly`,`yearly`,`lifetime`]){let n=r[t];n&&typeof n==`object`?e[t]={...n,key:t,configured:n.configured!==!1,enabled:typeof n.enabled==`boolean`?n.enabled:t!==`yearly`,formattedDiscountedPrice:n.formattedDiscountedPrice||n.discount?.discountedFormattedPrice||null,defaultCouponCode:n.defaultCouponCode||n.discount?.code||null}:ho[t]&&(e[t]={...ho[t]})}return go=e,e}}catch{}return go||ho})().finally(()=>{_o=null}),_o),bo=async e=>yo(e),xo=`./gift-box-3d.gif`,So=`chatbubbles_promo`,Co=6048e5;function wo(e,t,n){return`${So}_${(e||`default`).trim().toLowerCase().replace(/[^a-z0-9_-]/g,``)}_${(t||`anon`).trim().toLowerCase().replace(/[^a-z0-9_-]/g,``)}_${(n||`unknown_site`).trim().toLowerCase().replace(/[^a-z0-9_-]/g,``)}`}function To(e){return e?.id?`uid_${e.id}`:e?.email?`email_${e.email.toLowerCase().trim()}`:`anon`}function Eo(e){let t=Date.now(),n=t+Co;return typeof e==`number`&&Number.isFinite(e)&&e>t?e:n}var Do=({isLoggedIn:e=!1,isPaidUser:t=!1,hasActiveTrial:n=!1,user:r,siteId:i,trialEndTimestamp:a,onUpgrade:o})=>{let s=po(),[c,l]=(0,d.useState)(s),[u,f]=(0,d.useState)(i||`chatbubbles_local_site`),[p,m]=(0,d.useState)(!s),[h,g]=(0,d.useState)(!1),[_,v]=(0,d.useState)(null),[y,b]=(0,d.useState)(!1),[x,S]=(0,d.useState)(null),C=(0,d.useRef)(``),w=(0,d.useRef)(null);(0,d.useEffect)(()=>{let e=!0,t=new AbortController;async function n(){s||m(!0);try{let n=i||``;if(!n)try{n=(await fi())?.siteId||``}catch{}e&&f(n||`chatbubbles_local_site`);let r=await mo(void 0,t.signal);e&&r&&l(r)}catch(e){e?.name!==`AbortError`&&console.warn(`[Announcement] Failed to fetch announcement config:`,e)}finally{e&&m(!1)}}return n(),()=>{e=!1,t.abort()}},[i]),(0,d.useEffect)(()=>{if(p||!c||!c.enabled||!u)return;let i=!!(e&&t&&!n);if(c.showTo===`free`&&i)return;let o=To(r),s=wo(c.campaignId,o,u);C.current=s;let l=Date.now(),d=null;try{let e=localStorage.getItem(s);if(e){let t=JSON.parse(e);t&&typeof t.startTime==`number`&&typeof t.expiresAt==`number`&&(d=t)}}catch(e){console.warn(`[Announcement] Could not read localStorage:`,e)}let f=Math.max(.1,c.durationMinutes||3)*60*1e3;if(d?.dismissedUntil){if(a&&l>=a){d.manuallyClosed=!1,d.dismissedUntil=null,d.startTime=l,d.expiresAt=l+f;try{localStorage.setItem(s,JSON.stringify(d))}catch{}g(!1)}else if(l<d.dismissedUntil){g(!0);return}else d=null}if(d&&c.countdownEnabled&&l>=d.expiresAt){let e=Eo(a);try{localStorage.setItem(s,JSON.stringify({...d,dismissedUntil:e}))}catch{}g(!0);return}if(d){w.current=d.expiresAt,b(!!d.copied);let e=Math.max(0,Math.ceil((d.expiresAt-l)/1e3));v(e),g(!1)}else{let e=l+f;w.current=e;let t={campaignId:c.campaignId,startTime:l,expiresAt:e,copied:!1,dismissedUntil:null,manuallyClosed:!1};try{localStorage.setItem(s,JSON.stringify(t))}catch{}v(Math.ceil(f/1e3)),b(!1),g(!1)}},[p,c,u,e,t,n,r,a]),(0,d.useEffect)(()=>{if(h||!c?.countdownEnabled||!w.current)return;let e=window.setInterval(()=>{let t=Date.now(),n=w.current||t,r=Math.max(0,Math.ceil((n-t)/1e3));if(v(r),r<=0){clearInterval(e);let t=Eo(a),n=C.current;if(n)try{let e=localStorage.getItem(n),r=e?JSON.parse(e):{};localStorage.setItem(n,JSON.stringify({...r,dismissedUntil:t}))}catch{}g(!0)}},1e3);return()=>{clearInterval(e)}},[h,c?.countdownEnabled,a]);let T=(0,d.useCallback)(()=>{let e=Date.now(),t=a&&a>e?a:e+Co,n=C.current;if(n)try{let e=localStorage.getItem(n),r=e?JSON.parse(e):{};localStorage.setItem(n,JSON.stringify({...r,manuallyClosed:!0,dismissedUntil:t}))}catch{}g(!0)},[a]),E=async e=>{e.stopPropagation();let t=c?.couponCode;if(t)try{if(typeof navigator<`u`&&navigator.clipboard&&navigator.clipboard.writeText)await navigator.clipboard.writeText(t);else{let e=document.createElement(`textarea`);e.value=t,e.setAttribute(`readonly`,``),e.className=`cf-promo-clipboard-hidden`,document.body.appendChild(e),e.select(),document.execCommand(`copy`),document.body.removeChild(e)}b(!0),S(`Copied!`),setTimeout(()=>S(null),1800);let e=C.current;if(e)try{let t=localStorage.getItem(e),n=t?JSON.parse(t):{};localStorage.setItem(e,JSON.stringify({...n,copied:!0}))}catch{}}catch{window.prompt(`Copy promotional code:`,t),b(!0);let e=C.current;if(e)try{let t=localStorage.getItem(e),n=t?JSON.parse(t):{};localStorage.setItem(e,JSON.stringify({...n,copied:!0}))}catch{}}},D=()=>{if(c?.linkUrl&&/^https?:\/\//i.test(c.linkUrl.trim())){window.open(c.linkUrl.trim(),`_blank`,`noopener,noreferrer`);return}o&&o()};if(p)return(0,q.jsxs)(`div`,{className:`cf-promo-skeleton`,role:`status`,"aria-label":`Loading promotion`,children:[(0,q.jsxs)(`div`,{className:`cf-promo-skeleton-content`,children:[(0,q.jsx)(`div`,{className:`cf-promo-skeleton-line cf-promo-sk-timer`}),(0,q.jsx)(`div`,{className:`cf-promo-skeleton-line cf-promo-sk-title`}),(0,q.jsx)(`div`,{className:`cf-promo-skeleton-line cf-promo-sk-sub`}),(0,q.jsx)(`div`,{className:`cf-promo-skeleton-pill`})]}),(0,q.jsx)(`div`,{className:`cf-promo-skeleton-art`})]});if(!c||!c.enabled||!u)return null;let O=!!(e&&t&&!n);if(c.showTo===`free`&&O||h)return null;let k=_===null?(c.durationMinutes||3)*60:_,A=`Offer closes in ${Math.floor(Math.max(0,k)/60)}:${(Math.max(0,k)%60).toString().padStart(2,`0`)}`,j=!c.couponCode||y;return(0,q.jsxs)(`section`,{className:`cf-promo-card`,role:`region`,"aria-label":c.title||`Promotional Announcement`,children:[(0,q.jsxs)(`svg`,{className:`cf-promo-bg-shapes`,viewBox:`0 0 380 180`,fill:`none`,"aria-hidden":`true`,preserveAspectRatio:`none`,children:[(0,q.jsx)(`circle`,{cx:`340`,cy:`90`,r:`130`,stroke:`rgba(255, 255, 255, 0.08)`,strokeWidth:`1.5`}),(0,q.jsx)(`circle`,{cx:`340`,cy:`90`,r:`180`,stroke:`rgba(255, 255, 255, 0.05)`,strokeWidth:`1.5`}),(0,q.jsx)(`path`,{d:`M190 -30 Q 280 90 390 120`,stroke:`rgba(255, 255, 255, 0.09)`,strokeWidth:`1.5`,fill:`none`})]}),(0,q.jsx)(`button`,{type:`button`,className:`cf-promo-close-btn`,onClick:T,"aria-label":`Dismiss offer`,title:`Dismiss offer`,children:(0,q.jsx)(Oa,{size:16,strokeWidth:2.2,"aria-hidden":`true`})}),(0,q.jsxs)(`div`,{className:`cf-promo-content`,children:[c.countdownEnabled&&(0,q.jsx)(`div`,{className:`cf-promo-countdown`,"aria-live":`polite`,children:A}),(0,q.jsx)(`h2`,{className:`cf-promo-title`,children:c.title}),(0,q.jsx)(`p`,{className:`cf-promo-subtitle`,children:c.subtitle}),(0,q.jsx)(`div`,{className:`cf-promo-action-row`,children:j?(0,q.jsx)(`button`,{type:`button`,className:`cf-promo-pill-btn cf-promo-pill-btn--action`,onClick:D,"aria-label":c.buttonText||`Get Now`,children:x?(0,q.jsxs)(`span`,{className:`cf-promo-btn-copied`,children:[(0,q.jsx)(ga,{size:13,strokeWidth:2.5,"aria-hidden":`true`}),(0,q.jsx)(`span`,{children:x})]}):(0,q.jsx)(`span`,{className:`cf-promo-btn-text`,children:c.buttonText||`Get Now`})}):(0,q.jsxs)(`button`,{type:`button`,className:`cf-promo-pill-btn`,onClick:E,"aria-label":`Copy discount code ${c.couponCode}`,title:`Click to copy coupon code`,children:[(0,q.jsx)(`span`,{className:`cf-promo-btn-text`,children:c.couponCode}),(0,q.jsx)(ba,{size:13,strokeWidth:2.2,className:`cf-promo-copy-icon`,"aria-hidden":`true`})]})})]}),(0,q.jsx)(`div`,{className:`cf-promo-art`,"aria-hidden":`true`,children:(0,q.jsx)(`img`,{src:xo,alt:`3D Animated Gift Box`,className:`cf-promo-box-img`,loading:`eager`,decoding:`async`})})]})};function Oo({label:e,icon:t,onClick:n,href:r}){let i=(0,q.jsxs)(q.Fragment,{children:[(0,q.jsx)(`div`,{className:`help-card-icon`,children:t}),(0,q.jsx)(`h4`,{children:e})]});return r?(0,q.jsx)(`a`,{href:r,target:`_blank`,rel:`noopener noreferrer`,className:`help-card`,children:i}):(0,q.jsx)(`button`,{type:`button`,className:`help-card`,onClick:n,children:i})}function ko({onOpenGuide:e,onContactUs:t,onFeatureRequest:n}){return(0,q.jsxs)(`div`,{className:`help-categories`,children:[(0,q.jsx)(Oo,{label:`Guide`,icon:(0,q.jsx)(`svg`,{width:`18`,height:`18`,viewBox:`0 0 24 24`,fill:`none`,xmlns:`http://www.w3.org/2000/svg`,children:(0,q.jsx)(`path`,{d:`M7 18H17V16H7V18ZM7 14H17V12H7V14ZM7 10H11V8H7V10ZM3 22V2C3 1.45 3.19583 0.979167 3.5875 0.5875C3.97917 0.195833 4.45 0 5 0H15L21 6V22C21 22.55 20.8042 23.0208 20.4125 23.4125C20.0208 23.8042 19.55 24 19 24H5C4.45 24 3.97917 23.8042 3.5875 23.4125C3.19583 23.0208 3 22.55 3 22ZM14 7V2H5V22H19V7H14Z`,fill:`#5271FF`})}),onClick:e,href:`https://framefic.com/docs/chat-bubbles/`}),(0,q.jsx)(Oo,{label:`Get Support`,icon:(0,q.jsx)(`svg`,{width:`18`,height:`18`,viewBox:`0 0 24 24`,fill:`none`,xmlns:`http://www.w3.org/2000/svg`,children:(0,q.jsx)(`path`,{d:`M20 4H4C2.9 4 2.01 4.9 2.01 6L2 18C2 19.1 2.9 20 4 20H20C21.1 20 22 19.1 22 18V6C22 4.9 21.1 4 20 4ZM20 18H4V8L12 13L20 8V18ZM12 11L4 6H20L12 11Z`,fill:`#5271FF`})}),onClick:t,href:`https://framefic.com/support/`}),(0,q.jsx)(Oo,{label:`Feature Request`,icon:(0,q.jsx)(`svg`,{width:`18`,height:`18`,viewBox:`0 0 24 24`,fill:`none`,xmlns:`http://www.w3.org/2000/svg`,children:(0,q.jsx)(`path`,{d:`M3 13H5V11H3V13ZM3 17H5V15H3V17ZM3 9H5V7H3V9ZM7 13H21V11H7V13ZM7 17H21V15H7V17ZM7 7V9H21V7H7Z`,fill:`#5271FF`})}),onClick:n,href:`https://framefic.com/feature-requests/`})]})}function Ao({onBack:e,onManageSubscription:t,paymentEmail:n,authUser:r,onLogout:i,onSignUp:a,onSignIn:o,hasSubscription:s,planDetails:c,onRefreshSubscription:l,onStartTrial:u}){let[f,p]=(0,d.useState)(!1),[m,h]=(0,d.useState)(!1),[g,_]=(0,d.useState)(!1),v=!!(c?.isTrial||g),y=s&&!c?.isTrial,b=s&&!!c?.isTrial;(0,d.useEffect)(()=>{l?.()},[l]),(0,d.useEffect)(()=>{let e=!0;return r?.email&&!s&&!g&&(async()=>{try{let t=await ro((await fi()).siteId,r.email);if(!e)return;t.eligible||_(!0)}catch{}})(),()=>{e=!1}},[r?.email,s,g]);let x=r?.username||`User`,S=r?.email||n||`-`,C=(0,d.useMemo)(()=>{let e=x.trim().split(/\s+/).filter(Boolean);return e.length===0?`U`:e.length===1?e[0].slice(0,2).toUpperCase():`${e[0][0]}${e[1][0]}`.toUpperCase()},[x]);if(!r)return(0,q.jsxs)(`div`,{className:`framefic-profile-page`,children:[e&&(0,q.jsxs)(`button`,{type:`button`,className:`framefic-subpage-back-button-wide`,onClick:e,"aria-label":`Back`,children:[(0,q.jsx)(`svg`,{width:`16`,height:`16`,viewBox:`0 0 24 24`,fill:`none`,xmlns:`http://www.w3.org/2000/svg`,children:(0,q.jsx)(`path`,{d:`M19 12H5M5 12L12 19M5 12L12 5`,stroke:`currentColor`,strokeWidth:`2`,strokeLinecap:`round`,strokeLinejoin:`round`})}),(0,q.jsx)(`span`,{children:`Back`})]}),(0,q.jsx)(`div`,{className:`connections-panel--locked`,children:(0,q.jsxs)(`div`,{className:`pro-lock-card`,children:[(0,q.jsx)(`div`,{className:`pro-lock-icon-wrapper`,children:(0,q.jsx)(Ea,{className:`pro-lock-icon`,width:28,height:28})}),(0,q.jsx)(`h2`,{children:`Unlock Profile`}),(0,q.jsx)(`p`,{children:`Sign in to check your subscription status, manage your account details, and review active sessions.`}),(0,q.jsx)(`button`,{className:`primary-cta pro-unlock-btn`,type:`button`,onClick:a||o,children:`Sign Up to Unlock`})]})})]});let w=e=>{switch(e){case`monthly`:return`Pro Monthly`;case`yearly`:return`Pro Yearly`;case`lifetime`:return`Lifetime Deal`;case`trial`:return`Free Trial`;default:return`Free`}},T=e=>v&&!s?`Trial Claimed`:e?e.charAt(0).toUpperCase()+e.slice(1).replaceAll(`_`,` `):s?`Active`:`Inactive`,E=w(c?.plan),D=T(c?.status),O=s?`framefic-profile-plan-status framefic-profile-plan-status--active`:`framefic-profile-plan-status framefic-profile-plan-status--inactive`;return(0,q.jsxs)(`div`,{className:`framefic-profile-page`,children:[e&&(0,q.jsxs)(`button`,{type:`button`,className:`framefic-subpage-back-button-wide`,onClick:e,"aria-label":`Back`,children:[(0,q.jsx)(`svg`,{width:`16`,height:`16`,viewBox:`0 0 24 24`,fill:`none`,xmlns:`http://www.w3.org/2000/svg`,children:(0,q.jsx)(`path`,{d:`M19 12H5M5 12L12 19M5 12L12 5`,stroke:`currentColor`,strokeWidth:`2`,strokeLinecap:`round`,strokeLinejoin:`round`})}),(0,q.jsx)(`span`,{children:`Back`})]}),(0,q.jsx)(`h3`,{className:`framefic-subpage-title-left`,children:`Profile`}),(0,q.jsxs)(`div`,{className:`framefic-profile-hero`,children:[(0,q.jsxs)(`div`,{className:`framefic-profile-avatar-container`,children:[(y||b)&&(0,q.jsxs)(`svg`,{className:`framefic-avatar-segmented-ring`,viewBox:`0 0 100 100`,shapeRendering:`geometricPrecision`,children:[(0,q.jsxs)(`defs`,{children:[(0,q.jsxs)(`linearGradient`,{id:`crestbar-pro-ring-grad`,x1:`0%`,y1:`0%`,x2:`100%`,y2:`100%`,children:[(0,q.jsx)(`stop`,{offset:`0%`,stopColor:`#5271FF`}),(0,q.jsx)(`stop`,{offset:`50%`,stopColor:`#708AFF`}),(0,q.jsx)(`stop`,{offset:`100%`,stopColor:`#3B58FF`})]}),(0,q.jsxs)(`linearGradient`,{id:`crestbar-trial-ring-grad`,x1:`0%`,y1:`0%`,x2:`100%`,y2:`100%`,children:[(0,q.jsx)(`stop`,{offset:`0%`,stopColor:`#d1a918`}),(0,q.jsx)(`stop`,{offset:`50%`,stopColor:`#a07801`}),(0,q.jsx)(`stop`,{offset:`100%`,stopColor:`#ebce2b`})]})]}),(0,q.jsx)(`circle`,{cx:`50`,cy:`50`,r:`43`,fill:`none`,stroke:y?`url(#crestbar-pro-ring-grad)`:`url(#crestbar-trial-ring-grad)`,strokeWidth:`3`,strokeLinecap:`round`,strokeDasharray:`60 8`,transform:`rotate(-60 50 50)`})]}),(0,q.jsx)(`div`,{className:`framefic-profile-avatar-circle`,children:r?.avatar_url&&!m?(0,q.jsx)(`img`,{src:r.avatar_url,alt:x,className:`framefic-profile-avatar-img`,referrerPolicy:`no-referrer`,onError:()=>h(!0)}):C}),y?(0,q.jsxs)(`div`,{className:`framefic-avatar-badge framefic-avatar-badge--pro`,title:`Pro Member`,children:[(0,q.jsx)(Sa,{fill:`currentColor`,width:13,height:13}),(0,q.jsx)(`span`,{children:`PRO`})]}):b?(0,q.jsxs)(`div`,{className:`framefic-avatar-badge framefic-avatar-badge--trial`,title:`Free Trial Active`,children:[(0,q.jsx)(va,{width:13,height:13,color:`black`}),(0,q.jsx)(`span`,{children:`TRIAL`})]}):null]}),(0,q.jsxs)(`div`,{className:`framefic-profile-identity`,children:[(0,q.jsx)(`div`,{className:`framefic-profile-name`,children:x}),(0,q.jsx)(`div`,{className:`framefic-profile-email`,children:S})]})]}),(0,q.jsxs)(`div`,{className:`framefic-profile-plan-card`,children:[(0,q.jsxs)(`div`,{className:`framefic-profile-plan-top`,children:[(0,q.jsxs)(`div`,{className:`framefic-profile-plan-info`,children:[(0,q.jsx)(`span`,{className:`framefic-profile-plan-label`,children:`Plan Type`}),(0,q.jsx)(`span`,{className:`framefic-profile-plan-name`,children:E})]}),(0,q.jsx)(`span`,{className:O,children:D})]}),(0,q.jsx)(`div`,{className:`framefic-profile-plan-divider`}),(0,q.jsx)(`button`,{type:`button`,className:`primary-cta`,onClick:t,children:`Manage Subscription`})]}),!s&&(0,q.jsxs)(`div`,{className:`framefic-profile-trial-card`,children:[(0,q.jsx)(`h4`,{className:`framefic-trial-heading`,children:`Start Your Free Trial`}),(0,q.jsx)(`p`,{className:`framefic-trial-desc`,children:`Get full access to all Pro features, multi-agent support teams, and premium bubble styles during your trial. No credit card required.`}),v?(0,q.jsx)(`button`,{type:`button`,className:`trial-activate-btn trial-activate-btn--claimed`,disabled:!0,children:`Trial already claimed`}):(0,q.jsx)(`button`,{type:`button`,className:`primary-cta trial-activate-btn${r?``:` trial-activate-btn--disabled`}`,disabled:f||!r,title:r?void 0:`Sign in to start your free trial`,onClick:async()=>{if(r&&u){p(!0);try{await u()}catch(e){let t=e?.message||String(e||``);/already claimed/i.test(t)&&(_(!0),l?.()),console.error(`Failed to start trial:`,e)}finally{p(!1)}}},children:f?`Starting Trial...`:r?`Start Free Trial`:`Sign in to Start Trial`})]}),(0,q.jsxs)(`div`,{className:`framefic-profile-section`,children:[(0,q.jsx)(`h4`,{className:`framefic-profile-section-title`,children:`Personal Info`}),(0,q.jsxs)(`div`,{className:`framefic-profile-fields-card`,children:[(0,q.jsxs)(`div`,{className:`framefic-profile-field`,children:[(0,q.jsx)(`label`,{children:`Name`}),(0,q.jsxs)(`div`,{className:`framefic-profile-input-wrapper`,children:[(0,q.jsxs)(`svg`,{width:`16`,height:`16`,viewBox:`0 0 24 24`,fill:`none`,xmlns:`http://www.w3.org/2000/svg`,children:[(0,q.jsx)(`path`,{d:`M20 21C20 18.2386 16.4183 16 12 16C7.58172 16 4 18.2386 4 21`,stroke:`currentColor`,strokeWidth:`1.5`,strokeLinecap:`round`,strokeLinejoin:`round`}),(0,q.jsx)(`path`,{d:`M12 13C14.2091 13 16 11.2091 16 9C16 6.79086 14.2091 5 12 5C9.79086 5 8 6.79086 8 9C8 11.2091 9.79086 13 12 13Z`,stroke:`currentColor`,strokeWidth:`1.5`,strokeLinecap:`round`,strokeLinejoin:`round`})]}),(0,q.jsx)(`input`,{type:`text`,value:x,readOnly:!0})]})]}),(0,q.jsxs)(`div`,{className:`framefic-profile-field`,children:[(0,q.jsx)(`label`,{children:`Email`}),(0,q.jsxs)(`div`,{className:`framefic-profile-input-wrapper`,children:[(0,q.jsxs)(`svg`,{width:`16`,height:`16`,viewBox:`0 0 24 24`,fill:`none`,xmlns:`http://www.w3.org/2000/svg`,children:[(0,q.jsx)(`path`,{d:`M4 4H20C21.1 4 22 4.9 22 6V18C22 19.1 21.1 20 20 20H4C2.9 20 2 19.1 2 18V6C2 4.9 2.9 4 4 4Z`,stroke:`currentColor`,strokeWidth:`1.5`,strokeLinecap:`round`,strokeLinejoin:`round`}),(0,q.jsx)(`path`,{d:`M22 6L12 13L2 6`,stroke:`currentColor`,strokeWidth:`1.5`,strokeLinecap:`round`,strokeLinejoin:`round`})]}),(0,q.jsx)(`input`,{type:`email`,value:S,readOnly:!0})]})]})]})]}),r&&i&&(0,q.jsxs)(`button`,{type:`button`,className:`framefic-profile-logout-btn`,onClick:i,children:[`Sign Out`,(0,q.jsxs)(`svg`,{className:`framefic-logout-icon`,width:`16`,height:`16`,viewBox:`0 0 24 24`,fill:`none`,xmlns:`http://www.w3.org/2000/svg`,children:[(0,q.jsx)(`path`,{className:`framefic-logout-door`,d:`M9 21H5C4.46957 21 3.96086 20.7893 3.58579 20.4142C3.21071 20.0391 3 19.5304 3 19V5C3 4.46957 3.21071 3.96086 3.58579 3.58579C3.96086 3.21071 4.46957 3 5 3H9`,stroke:`currentColor`,strokeWidth:`1.5`,strokeLinecap:`round`,strokeLinejoin:`round`}),(0,q.jsx)(`path`,{className:`framefic-logout-arrow`,d:`M16 17L21 12L16 7`,stroke:`currentColor`,strokeWidth:`1.5`,strokeLinecap:`round`,strokeLinejoin:`round`}),(0,q.jsx)(`path`,{className:`framefic-logout-arrow`,d:`M21 12H9`,stroke:`currentColor`,strokeWidth:`1.5`,strokeLinecap:`round`,strokeLinejoin:`round`})]})]})]})}function jo(e){let[t,n]=(0,d.useState)(()=>{let t=e&&Object.keys(e).length>0?e:ho;return{monthly:t.monthly?.enabled!==!1,yearly:t.yearly?.enabled===!0,lifetime:t.lifetime?.enabled!==!1}}),[r,i]=(0,d.useState)(()=>{let t=e&&Object.keys(e).length>0?e:ho,n={};for(let e of[`monthly`,`yearly`,`lifetime`]){let r=t[e]||ho[e],i=r?.formattedDiscountedPrice||r?.discount?.discountedFormattedPrice||null,a=i===`$39.98`?`$39.99`:i;n[e]={...r,key:e,enabled:typeof r?.enabled==`boolean`?r.enabled:e!==`yearly`,formattedDiscountedPrice:a,defaultCouponCode:r?.defaultCouponCode||r?.discount?.code||null}}return n}),[a,o]=(0,d.useState)(``),[s,c]=(0,d.useState)(0);return(0,d.useEffect)(()=>{let e=!0,t=()=>yo().then(t=>{if(!e)return;if(!t||typeof t!=`object`)throw Error(`Invalid plan configuration`);let r={};for(let e of[`monthly`,`yearly`,`lifetime`]){let n=t[e]||ho[e],i=n?.formattedDiscountedPrice||n?.discount?.discountedFormattedPrice||null,a=i===`$39.98`?`$39.99`:i;r[e]={...n,key:e,enabled:typeof n?.enabled==`boolean`?n.enabled:e!==`yearly`,formattedDiscountedPrice:a,defaultCouponCode:n?.defaultCouponCode||n?.discount?.code||null}}i(r),n({monthly:r.monthly?.enabled!==!1,yearly:r.yearly?.enabled===!0,lifetime:r.lifetime?.enabled!==!1}),o(``)}).catch(t=>{e&&console.warn(`Failed to update plan prices from backend:`,t)});t();let r=setInterval(t,6e4);return window.addEventListener(`focus`,t),()=>{e=!1,clearInterval(r),window.removeEventListener(`focus`,t)}},[s]),{enabled:t,plans:r,error:a,retry:()=>c(e=>e+1)}}function Mo(e){return e?(typeof e==`string`?e:e.formattedDiscount||``).replace(/\bUSD\s*/gi,`$`).replace(/\bEUR\s*/gi,`€`).replace(/\bGBP\s*/gi,`£`).replace(/\bCAD\s*/gi,`CA$`).replace(/\bAUD\s*/gi,`AU$`):``}function No(){return(0,q.jsxs)(`div`,{className:`framefic-plans-container pricing-skeleton beaf-plans-container beaf-plans-skeleton-wrapper`,role:`status`,"aria-label":`Loading plans and pricing`,"aria-busy":`true`,children:[(0,q.jsxs)(`div`,{className:`pricing-skeleton-toggle beaf-skeleton-toggle-container`,children:[(0,q.jsx)(`div`,{className:`beaf-skeleton-toggle-pill`}),(0,q.jsx)(`div`,{className:`beaf-skeleton-toggle-pill`})]}),[0,1].map(e=>(0,q.jsxs)(`div`,{className:`framefic-plan-card beaf-plan-card pricing-skeleton-card beaf-skeleton-card`,"aria-hidden":`true`,children:[(0,q.jsxs)(`div`,{className:`plan-header beaf-skeleton-header`,children:[(0,q.jsx)(`span`,{className:`pricing-skeleton-title beaf-skeleton-line beaf-skeleton-title`}),(0,q.jsx)(`span`,{className:`pricing-skeleton-price beaf-skeleton-line beaf-skeleton-price`})]}),(0,q.jsx)(`div`,{className:`plan-features beaf-skeleton-features`,children:[0,1,2,3].map(e=>(0,q.jsx)(`span`,{className:`pricing-skeleton-line beaf-skeleton-line beaf-skeleton-text-long`},e))}),(0,q.jsx)(`span`,{className:`pricing-skeleton-button beaf-skeleton-btn`})]},e))]})}var Po=({isCreatingPayment:e,payingPlan:t,lifetimeAvailability:n,onPay:r,currentPlan:i,plans:a=null})=>{let{enabled:o,plans:s,error:c,retry:l}=jo(a),[u,f]=(0,d.useState)(i===`yearly`?`yearly`:`monthly`);if((0,d.useEffect)(()=>{i===`yearly`?f(`yearly`):i===`monthly`&&f(`monthly`)},[i]),!o||!s)return c?(0,q.jsxs)(`div`,{role:`alert`,className:`framefic-plans-empty`,children:[(0,q.jsx)(`p`,{children:c}),(0,q.jsx)(`button`,{type:`button`,className:`plan-action-btn primary-cta`,onClick:l,children:`Retry`})]}):(0,q.jsx)(No,{});let p=o[u]?u:o.monthly?`monthly`:`yearly`,m=o.monthly&&o.yearly&&s.monthly?.currency===s.yearly?.currency&&(s.monthly?.amount||0)>0?Math.round((1-(s.yearly?.amount||0)/((s.monthly?.amount||0)*12))*100):17,h=p===`monthly`?s.monthly:s.yearly,g=e&&t===h?.key,_=!!(i&&h?.key===i),v=i===`yearly`&&h?.key===`monthly`||i===`lifetime`&&h?.key!==`lifetime`,y=e||_||v,b=s.lifetime?.lifetimeAvailability??n,x=s.lifetime,S=e&&t===x?.key,C=!!b?.soldOut,w=b?.remaining===void 0?b?.spotsLeft===void 0?null:b.spotsLeft:b.remaining,T=b?.total||b?.totalSpots||20,E=!!(i&&x?.key===i),D=i===`lifetime`&&x?.key!==`lifetime`,O=e||C||E||D,k=x?.discount||null,A=Mo(k)||(x?.formattedDiscountedPrice?`60% OFF`:`Best Deal`);return(0,q.jsxs)(`div`,{className:`framefic-plans-container beaf-plans-container`,children:[!o.monthly&&!o.yearly&&!o.lifetime&&(0,q.jsx)(`div`,{className:`framefic-plans-empty`,role:`status`,children:(0,q.jsx)(`p`,{children:`Paid plans are currently unavailable. Please try again later.`})}),o.lifetime&&x&&(0,q.jsxs)(`div`,{className:`framefic-plan-card beaf-plan-card lifetime${E?` current`:``}`,children:[(0,q.jsxs)(`div`,{className:`plan-header`,children:[(0,q.jsxs)(`div`,{className:`lifetime-title-row`,children:[(0,q.jsx)(`span`,{className:`plan-name`,children:`Lifetime`}),(0,q.jsx)(`span`,{className:k?`lifetime-auto-discount-badge`:`lifetime-save-badge`,children:A})]}),(0,q.jsx)(`div`,{className:`plan-price`,children:x.formattedDiscountedPrice?(0,q.jsxs)(`div`,{className:`plan-discounted-price-container`,children:[(0,q.jsx)(`del`,{className:`plan-original-price plan-original-price-strikethrough`,children:x.formattedPrice}),(0,q.jsx)(`span`,{className:`plan-discounted-price`,children:x.formattedDiscountedPrice})]}):x.formattedPrice})]}),(0,q.jsxs)(`div`,{className:`plan-features`,children:[Aa.map(e=>(0,q.jsxs)(`div`,{className:`feature-item`,children:[(0,q.jsx)(ga,{className:`checkmark`,size:14,strokeWidth:2.5,"aria-hidden":`true`}),(0,q.jsx)(`span`,{children:e.replace(/\.$/,``)})]},e)),w!==null&&(0,q.jsxs)(`div`,{className:`feature-item spots-remaining`,children:[(0,q.jsx)(ga,{className:`checkmark`,size:14,strokeWidth:2.5,"aria-hidden":`true`}),(0,q.jsx)(`span`,{children:C?`All spots taken!`:`${w}/${T} spots left`})]})]}),(0,q.jsx)(`button`,{type:`button`,onClick:e=>!O&&r(e,x.key,x.defaultCouponCode||x.discount?.code||null),disabled:O,"aria-busy":S,className:`plan-action-btn subscription-action-btn${S?` loading`:``}${E?` current`:``}`,children:E?`Current Plan`:D?`Not Available`:C?`Sold Out`:S?`Loading...`:`Get Lifetime Access`})]}),o.lifetime&&(o.monthly||o.yearly)&&(0,q.jsx)(`div`,{className:`framefic-plans-divider beaf-plans-divider`,children:`or, subscribe recurring`}),o.monthly&&o.yearly&&(0,q.jsxs)(`div`,{className:`framefic-interval-toggle-container beaf-interval-toggle-container`,children:[(0,q.jsx)(`button`,{type:`button`,className:`framefic-interval-btn beaf-interval-btn${p===`monthly`?` active`:``}`,onClick:()=>f(`monthly`),children:`Monthly`}),(0,q.jsxs)(`button`,{type:`button`,className:`framefic-interval-btn beaf-interval-btn${p===`yearly`?` active`:``}`,onClick:()=>f(`yearly`),children:[(0,q.jsx)(`span`,{children:`Yearly`}),(0,q.jsxs)(`span`,{className:`save-badge`,children:[`Save `,m,`%`]})]})]}),(o.monthly||o.yearly)&&h&&(0,q.jsxs)(`div`,{className:`framefic-plan-card beaf-plan-card${_?` current`:``}`,children:[(0,q.jsxs)(`div`,{className:`plan-header`,children:[(0,q.jsx)(`span`,{className:`plan-name`,children:p===`monthly`?`Monthly`:`Yearly`}),(0,q.jsxs)(`div`,{className:`plan-price`,children:[h.formattedDiscountedPrice&&(0,q.jsx)(`del`,{className:`plan-original-price plan-original-price-strikethrough`,children:h.formattedPrice}),h.formattedDiscountedPrice||h.formattedPrice,(0,q.jsx)(`span`,{className:`plan-suffix`,children:p===`monthly`?`/mo`:`/yr`})]})]}),(0,q.jsx)(`div`,{className:`plan-features`,children:Aa.map(e=>(0,q.jsxs)(`div`,{className:`feature-item`,children:[(0,q.jsx)(ga,{className:`checkmark`,size:14,strokeWidth:2.5,"aria-hidden":`true`}),(0,q.jsx)(`span`,{children:e.replace(/\.$/,``)})]},e))}),(0,q.jsx)(`button`,{type:`button`,onClick:e=>!y&&r(e,h.key,h.defaultCouponCode||h.discount?.code||null),disabled:y,"aria-busy":g,className:`plan-action-btn subscription-action-btn${g?` loading`:``}${_?` current`:``}`,children:_?`Current Plan`:v?`Not Available`:g?`Loading...`:`Upgrade Subscription`})]})]})};function Fo({onClose:e,hasSubscription:t,planDetails:n,isCreatingPayment:r,payingPlan:i,lifetimeAvailability:a,onPay:o,onRefreshSubscription:s,notify:c,defaultShowPlans:l=0}){let[u,f]=(0,d.useState)(vo()),[p,m]=(0,d.useState)(!1),[h,g]=(0,d.useState)(!1),[_,v]=(0,d.useState)(!1),[y,b]=(0,d.useState)(null),[x,S]=(0,d.useState)(null),[C,w]=(0,d.useState)(l>0),[T,E]=(0,d.useState)(null),[D,O]=(0,d.useState)(null),[k,A]=(0,d.useState)(``);(0,d.useEffect)(()=>{let e=!0,t=new AbortController;async function n(){try{let n=await bo(t.signal);e&&n&&f(n)}catch(e){console.warn(`Failed to load plans in SubscriptionPage:`,e)}}return n(),()=>{e=!1,t.abort()}},[]),(0,d.useEffect)(()=>{l>0&&w(!0)},[l]);let j=()=>{t&&C?w(!1):e()},M=e=>{switch(e){case`monthly`:return`Pro Monthly`;case`yearly`:return`Pro Yearly`;case`lifetime`:return`Lifetime Deal`;case`trial`:return`Free Trial`;default:return e?e.charAt(0).toUpperCase()+e.slice(1):`-`}},N=e=>e?e.charAt(0).toUpperCase()+e.slice(1):``,P=e=>{if(!e)return`-`;let t;if(typeof e==`number`)t=new Date(e>1e11?e:e*1e3);else if(typeof e==`string`&&!isNaN(Number(e))&&e.trim()!==``){let n=Number(e);t=new Date(n>1e11?n:n*1e3)}else t=new Date(e);return isNaN(t.getTime())?String(e):n?.isTrial?t.toLocaleString(`en-US`,{year:`numeric`,month:`short`,day:`numeric`,hour:`numeric`,minute:`2-digit`}):t.toLocaleDateString(`en-US`,{year:`numeric`,month:`short`,day:`numeric`})},ee=(e,t)=>n?.isTrial?`No`:e===`lifetime`?`Never`:t===`Scheduled to cancel`||t===`canceled`||t===`cancelled`?`No`:t===`active`||t===`paid`||t===`trialing`?`Automatically`:`No`,F=async()=>{try{m(!0),b(null),S(null);let e=await so((await fi()).siteId),t=window.open(e.url,`_blank`,`noopener,noreferrer`);(!t||t.closed||t.closed===void 0)&&S(e.url)}catch(e){console.error(`Error loading billing portal:`,e),b(e.message||`Failed to open billing portal. Please try again.`)}finally{m(!1)}},te=async(e=null)=>{try{g(!0),b(null);let t=await ao((await fi()).siteId,e);await s?.(),c?.({type:`Success`,message:t.currentPeriodEnd?`Subscription will end on ${P(t.currentPeriodEnd)}.`:`Subscription cancellation scheduled.`})}catch(e){console.error(`Error cancelling subscription:`,e),b(e.message||`Failed to cancel subscription. Please try again.`),c?.({type:`Error`,message:e.message||`Failed to cancel subscription.`})}finally{g(!1)}},I=!t||n?.status===`cancelled`||n?.status===`canceled`||(n?.expiresAt?new Date(n.expiresAt)<=new Date&&n.plan!==`lifetime`:!1),ne=async e=>{try{v(!0),b(null);let t=await oo((await fi()).siteId,e);await s?.(),c?.({type:`Success`,message:t.message||`Plan changed to ${M(t.plan)}.`})}catch(t){console.error(`Error changing subscription plan:`,t);let n=String(t?.message||``);if(t?.requiresNewCheckout||n.includes(`canceled subscription`)||n.includes(`cancelled subscription`)||n.includes(`has ended`)||n.includes(`cannot be updated`)){E(null),w(!1),c?.({type:`Success`,message:`Please enter your payment details to start your new subscription.`}),o(null,e);return}b(t.message||`Failed to change plan. Please try again.`),c?.({type:`Error`,message:t.message||`Failed to change plan.`})}finally{v(!1)}},re=t&&n?.plan?n.plan:null,ie=p||h||_;return(0,q.jsxs)(`div`,{className:`framefic-subscription-page`,children:[(0,q.jsxs)(`button`,{type:`button`,className:`framefic-subpage-back-button-wide`,onClick:j,"aria-label":`Back`,children:[(0,q.jsx)(`svg`,{width:`16`,height:`16`,viewBox:`0 0 24 24`,fill:`none`,xmlns:`http://www.w3.org/2000/svg`,children:(0,q.jsx)(`path`,{d:`M19 12H5M5 12L12 19M5 12L12 5`,stroke:`currentColor`,strokeWidth:`2`,strokeLinecap:`round`,strokeLinejoin:`round`})}),(0,q.jsx)(`span`,{children:`Back`})]}),(0,q.jsx)(`h3`,{className:`framefic-subpage-title-left`,children:`Manage Subscription`}),(0,q.jsx)(`div`,{className:`framefic-subscription-content`,children:!t||C?(0,q.jsx)(Po,{isCreatingPayment:r,payingPlan:i,lifetimeAvailability:a,plans:u,onPay:(e,r,i)=>{t&&!I&&!n?.isTrial&&(r===`monthly`||r===`yearly`||r===`lifetime`)?E(r):o(e,r,i)},currentPlan:re}):(0,q.jsxs)(q.Fragment,{children:[(0,q.jsxs)(`div`,{className:`framefic-subscription-card`,children:[(0,q.jsxs)(`div`,{className:`framefic-subscription-detail-item`,children:[(0,q.jsx)(`span`,{className:`framefic-subscription-label`,children:`PLAN`}),(0,q.jsx)(`span`,{className:`framefic-subscription-value`,children:M(n?.plan)})]}),(0,q.jsx)(`div`,{className:`framefic-subscription-divider`}),(0,q.jsxs)(`div`,{className:`framefic-subscription-detail-item`,children:[(0,q.jsx)(`span`,{className:`framefic-subscription-label`,children:`STATUS`}),(0,q.jsx)(`span`,{className:`framefic-subscription-status`,children:N(n?.status)})]}),(0,q.jsx)(`div`,{className:`framefic-subscription-divider`}),(0,q.jsxs)(`div`,{className:`framefic-subscription-detail-item`,children:[(0,q.jsx)(`span`,{className:`framefic-subscription-label`,children:`PURCHASE DATE`}),(0,q.jsx)(`span`,{className:`framefic-subscription-value`,children:P(n?.since)})]}),(0,q.jsx)(`div`,{className:`framefic-subscription-divider`}),(0,q.jsxs)(`div`,{className:`framefic-subscription-detail-item`,children:[(0,q.jsx)(`span`,{className:`framefic-subscription-label`,children:`END DATE`}),(0,q.jsx)(`span`,{className:`framefic-subscription-value`,children:n?.plan===`lifetime`?`Never`:P(n?.expiresAt||n?.trialEndsAt)})]}),(0,q.jsx)(`div`,{className:`framefic-subscription-divider`}),(0,q.jsxs)(`div`,{className:`framefic-subscription-detail-item`,children:[(0,q.jsx)(`span`,{className:`framefic-subscription-label`,children:`RENEWS`}),(0,q.jsx)(`span`,{className:`framefic-subscription-value`,children:ee(n?.plan,n?.status)})]})]}),y&&(0,q.jsx)(`div`,{className:`billing-error-box`,children:y}),n?.isTrial?(0,q.jsx)(`div`,{className:`framefic-subscription-actions`,children:(0,q.jsx)(`button`,{type:`button`,className:`primary-cta cancel-btn-full`,onClick:()=>w(!0),children:`Upgrade to Pro Plan`})}):n?.plan!==`lifetime`&&(0,q.jsxs)(`div`,{className:`framefic-subscription-actions`,children:[(0,q.jsx)(`button`,{type:`button`,className:`framefic-subscription-secondary-btn`,onClick:F,disabled:ie,children:p?`Loading...`:`Manage Billing`}),(0,q.jsx)(`button`,{type:`button`,className:`framefic-subscription-cancel-btn`,onClick:()=>O(1),disabled:ie,children:`Cancel Subscription`}),(0,q.jsx)(`button`,{type:`button`,className:`framefic-subscription-upgrade-btn`,onClick:()=>w(!0),disabled:ie,children:`Upgrade Plan`}),x&&(0,q.jsxs)(`div`,{className:`billing-portal-blocked`,children:[`Pop-up was blocked. `,(0,q.jsx)(`a`,{href:x,target:`_blank`,rel:`noopener noreferrer`,className:`billing-portal-link`,onClick:()=>S(null),children:`Click here to open billing portal`})]})]})]})}),T&&(0,q.jsx)(`div`,{className:`payment-modal`,children:(0,q.jsxs)(`div`,{className:`payment-box payment-box-pad20`,children:[(0,q.jsx)(`h3`,{children:`Confirm Plan Change`}),(0,q.jsxs)(`p`,{children:[`You are about to switch to the `,(0,q.jsx)(`strong`,{children:M(T)}),` plan.`,(0,q.jsx)(`br`,{}),(0,q.jsx)(`br`,{}),T===`yearly`?`Your unused monthly time will be credited, and you'll be billed the prorated yearly amount today.`:T===`lifetime`?`Your unused subscription time will be calculated as a discount, and you'll be billed the prorated lifetime amount today.`:`Your unused yearly time will be credited to your account, and you will be switched to monthly immediately.`]}),(0,q.jsxs)(`div`,{className:`plan-change-btn-row`,children:[(0,q.jsx)(`button`,{type:`button`,onClick:()=>E(null),className:`secondary-cta plan-change-btn`,children:`Cancel`}),(0,q.jsx)(`button`,{type:`button`,onClick:async()=>{T===`lifetime`?(E(null),w(!1),o(null,`lifetime`)):(await ne(T),E(null),w(!1))},disabled:_,className:`primary-cta plan-change-btn`,children:_?`Processing...`:`Pay Now`})]})]})}),D&&(0,q.jsx)(`div`,{className:`payment-modal`,children:(0,q.jsxs)(`div`,{className:`payment-box payment-box-cancel`,children:[D===1&&(0,q.jsxs)(`div`,{className:`cancel-step-content`,children:[(0,q.jsx)(`h3`,{className:`cancel-title`,children:`We're sorry to see you go`}),(0,q.jsx)(`p`,{className:`cancel-intro`,children:`Mind telling us why? It helps us improve.`}),(0,q.jsx)(`div`,{className:`cancel-options`,children:[`It's too expensive`,`I'm not using it enough`,`Missing a feature I need`,`Switching to another tool`,`Other`].map(e=>(0,q.jsxs)(`label`,{className:`cancel-option-label`,children:[(0,q.jsx)(`input`,{type:`radio`,name:`cancelReason`,value:e,checked:k===e,onChange:e=>A(e.target.value),className:`cancel-radio-input`}),(0,q.jsx)(`span`,{className:`cancel-radio-custom ${k===e?`checked`:``}`,children:k===e&&(0,q.jsx)(`span`,{className:`cancel-radio-dot`})}),(0,q.jsx)(`span`,{children:e})]},e))}),(0,q.jsxs)(`div`,{className:`cancel-actions-row`,children:[(0,q.jsx)(`button`,{type:`button`,className:`primary-cta cancel-btn-full`,disabled:!k,onClick:()=>O(2),children:`Continue`}),(0,q.jsx)(`button`,{type:`button`,className:`cancel-skip-btn`,onClick:()=>{A(`Skipped`),O(2)},children:`Skip and cancel anyway`})]})]}),D===2&&(0,q.jsxs)(`div`,{className:`cancel-step-content`,children:[(0,q.jsx)(`h3`,{className:`cancel-title`,children:`Confirm cancellation`}),(0,q.jsxs)(`p`,{className:`cancel-intro`,children:[`You'll keep full access until your billing period ends on`,` `,(0,q.jsx)(`strong`,{children:P(n?.expiresAt||n?.trialEndsAt)}),`. After that:`]}),(0,q.jsx)(`div`,{className:`cancel-warnings`,children:[`Your saved chat bubbles will be paused`,`No more priority support`,`Multi-agent routing turned off`].map(e=>(0,q.jsxs)(`div`,{className:`cancel-warning-item`,children:[(0,q.jsx)(`span`,{className:`cancel-warning-icon`,children:`✕`}),(0,q.jsx)(`span`,{children:e})]},e))}),(0,q.jsxs)(`div`,{className:`cancel-actions-row-mt8`,children:[(0,q.jsx)(`button`,{type:`button`,className:`primary-cta cancel-btn-full`,onClick:()=>{O(null),A(``)},children:`Keep My Plan`}),(0,q.jsx)(`button`,{type:`button`,className:`framefic-subscription-cancel-btn cancel-btn-full`,disabled:h,onClick:async()=>{await te(k),O(3)},children:h?`Cancelling...`:`Cancel My Subscription`})]})]}),D===3&&(0,q.jsxs)(`div`,{className:`cancel-step-center`,children:[(0,q.jsx)(`div`,{className:`cancel-icon-wrapper`,children:(0,q.jsxs)(`svg`,{width:`24`,height:`24`,viewBox:`0 0 24 24`,fill:`none`,stroke:`currentColor`,strokeWidth:`2.5`,strokeLinecap:`round`,strokeLinejoin:`round`,children:[(0,q.jsx)(`circle`,{cx:`12`,cy:`12`,r:`10`}),(0,q.jsx)(`line`,{x1:`4.93`,y1:`4.93`,x2:`19.07`,y2:`19.07`})]})}),(0,q.jsx)(`h3`,{className:`cancel-title`,children:`Subscription canceled`}),(0,q.jsxs)(`p`,{className:`cancel-intro`,children:[`You'll have full access until`,` `,(0,q.jsx)(`strong`,{children:P(n?.expiresAt||n?.trialEndsAt)}),`. We'd love to have you back anytime.`]}),(0,q.jsxs)(`div`,{className:`cancel-actions-row-mt8`,children:[(0,q.jsx)(`button`,{type:`button`,className:`primary-cta cancel-btn-h38`,onClick:async()=>{await s?.(),O(null),A(``)},children:`Go to Dashboard`}),(0,q.jsx)(`span`,{className:`cancel-resubscribe-text`,children:`Changed your mind? Resubscribe anytime`})]})]})]})})]})}function Io(){let[e,t]=(0,d.useState)(null),[n,r]=(0,d.useState)(!1),[i,a]=(0,d.useState)(!0),[o,s]=(0,d.useState)(!1),[c,l]=(0,d.useState)(`register`);(0,d.useEffect)(()=>{let e=!0;return(async()=>{try{if(Ba()){let n=Ra();n&&e&&(t(n),r(!0))}let n=null;try{n=(await fi()).siteId||null,n&&Va(n)}catch{}if(Ba()){let n=await Ka();e&&(n?(t(n),r(!0)):Ba()||(t(null),r(!1)))}}catch{}finally{e&&a(!1)}})(),()=>{e=!1}},[]);let u=(0,d.useCallback)(async({username:e,email:t,password:n=null,siteId:r=null})=>{let i=await fi().catch(()=>null);return await Wa({username:e,email:t,siteId:r||i?.siteId||null})},[]),f=(0,d.useCallback)(async({email:e,code:n})=>{let i=await Ga({email:e,code:n});return t(i.user),r(!0),s(!1),fi().then(e=>{e.siteId&&Va(e.siteId)}).catch(()=>{}),i},[]);return{user:e,isLoggedIn:n,isCheckingAuth:i,showAuthModal:o,authModalMode:c,register:u,verifySignup:f,login:(0,d.useCallback)(async({email:e,code:t=null,password:n=null})=>t?await f({email:e,code:t}):await Wa({email:e,siteId:(await fi().catch(()=>null))?.siteId||null}),[f]),logout:(0,d.useCallback)(()=>{za(),Ha(),t(null),r(!1);try{localStorage.removeItem(`chat_bubbles_subscription_override`)}catch{}},[]),openAuthModal:(0,d.useCallback)((e=`register`)=>{l(e===`login`?`login`:`register`),s(!0)},[]),closeAuthModal:(0,d.useCallback)(()=>{s(!1)},[]),socialLogin:(0,d.useCallback)((e,n)=>{Ia(e,n),t(n),r(!0),s(!1),fi().then(e=>{e.siteId&&Va(e.siteId)}).catch(()=>{})},[])}}function Lo({notify:e,authEmail:t}){let[n,r]=(0,d.useState)(null),[i,a]=(0,d.useState)(!1),[o,s]=(0,d.useState)(null),[c,l]=(0,d.useState)(null),[u,f]=(0,d.useState)(!1),[p,m]=(0,d.useState)(!0),[h,g]=(0,d.useState)(!1),[_,v]=(0,d.useState)(!1),[y,b]=(0,d.useState)(null),[x,S]=(0,d.useState)(null),[C,w]=(0,d.useState)(null),[T,E]=(0,d.useState)(null),[D,O]=(0,d.useState)(null),[k,A]=(0,d.useState)(null),[j,M]=(0,d.useState)(null),[N,P]=(0,d.useState)(`usd`),[ee,F]=(0,d.useState)(null),[te,I]=(0,d.useState)(null);(0,d.useEffect)(()=>{let e=!0;return(async()=>{try{let t=await Za();e&&t?.publishableKey&&I(t.publishableKey)}catch{}})(),()=>{e=!1}},[]),(0,d.useEffect)(()=>{t||(f(!1),S(null),w(null),m(!1))},[t]);let ne=(0,d.useCallback)(async e=>{try{let n=await fi(),r=e||t||null;if(!r){f(!1),S(null),w(null),m(!1);try{let e=await Qa();E(e)}catch{}return!1}let i=await no(n.siteId,r),a=i.expiresAt?new Date(i.expiresAt)<=new Date&&i.plan!==`lifetime`:!1,o=i.isPaid&&!a&&[`monthly`,`yearly`,`lifetime`,`trial`].includes(i.plan)&&[`active`,`trialing`,`paid`,`Scheduled to cancel`].includes(i.status);o?(f(!0),S(i.plan),w({plan:i.plan,status:i.status,expiresAt:i.expiresAt,since:i.since,email:i.email??null,isTrial:i.isTrial??!1,trialEndsAt:i.trialEndsAt??null,trialSecondsRemaining:i.trialSecondsRemaining??0,trialDaysRemaining:i.trialDaysRemaining??0,fetchTimestamp:Date.now()})):(f(!1),S(null),i.isTrial?w({plan:null,status:`expired`,isTrial:!0,trialEndsAt:i.trialEndsAt,trialSecondsRemaining:0,trialDaysRemaining:0,email:i.email??null,fetchTimestamp:Date.now()}):w(null));try{let e=await Qa();E(e)}catch{}return o}catch{return f(!1),S(null),w(null),!1}},[t]);(0,d.useEffect)(()=>{let e=!0;return(async()=>{try{await ne()}finally{e&&m(!1)}})(),()=>{e=!1}},[ne]);let re=(0,d.useCallback)(()=>{a(!1),r(null),b(null),O(null),A(null),F(null)},[]),ie=(0,d.useCallback)(e=>{f(!0),S(y);let n=new Date,r=new Date(n);y===`monthly`?r.setMonth(r.getMonth()+1):y===`yearly`&&r.setFullYear(r.getFullYear()+1);let i={plan:y,status:`active`,since:n.toISOString(),expiresAt:y===`lifetime`?null:r.toISOString(),email:t||null};w(i),a(!1),e?.(),g(!0),setTimeout(()=>{g(!1)},2500),setTimeout(()=>{ne().catch(()=>{})},1500),fi().then(e=>{if(y){let{amount:t}=Xa(y);return co(y,`${e.siteId}-${Date.now()}`,t)}}).catch(()=>{})},[y,ne,t]),L=(0,d.useCallback)(async(t,n,i)=>{t&&t.preventDefault&&t.preventDefault(),v(!0),b(n),F(null);let o=Xa(n);M(o.amount),s(o.amount),l(o.label),P(o.currency||`usd`);try{let t=await $a(n,(await fi()).siteId,i);if(t.originalAmount!=null&&M(t.originalAmount/100),t.finalAmount!=null&&s(t.finalAmount/100),t.couponCode?A(t.couponCode):A(i||null),t.isPaid===!0||t.status===`paid`||t.status===`active`||t.status===`trialing`||t.finalAmount===0&&!t.clientSecret){e({type:`Success`,message:n===`lifetime`?`Lifetime access is now active!`:`Subscription is now active!`}),await ie();return}if(t.clientSecret)r(t.clientSecret),t.publishableKey&&I(t.publishableKey),t.subscriptionId&&O(t.subscriptionId),a(!0);else if(t.url)window.open(t.url,`_blank`);else if(t.subscriptionId)await ie();else throw Error(`No client secret returned from payment server.`)}catch(t){let n=t instanceof Error?t.message:`Payment failed`;F(n),await e({type:`Error`,message:n})}finally{v(!1)}},[e,t,ie]),ae=(0,d.useCallback)(async()=>{try{let e=await io((await fi()).siteId);return await ne(),e}catch(e){throw console.error(`Error starting trial:`,e),e}},[ne]);return(0,d.useEffect)(()=>{if(!C?.isTrial||!u||!C?.trialEndsAt)return;let e=C.trialSecondsRemaining??0,t=C.fetchTimestamp??Date.now(),n=()=>{let n=Date.now()-t,r=Math.floor(n/1e3);return Math.max(0,e-r)};if(n()<=0){f(!1),S(null),w(e=>e?{...e,status:`expired`,trialSecondsRemaining:0,trialDaysRemaining:0}:null);return}let r=setInterval(()=>{let e=n();e<=0?(clearInterval(r),f(!1),S(null),w(e=>e?{...e,status:`expired`,trialSecondsRemaining:0,trialDaysRemaining:0}:null)):w(t=>t?{...t,trialSecondsRemaining:e,trialDaysRemaining:Math.ceil(e/86400)}:null)},1e3);return()=>clearInterval(r)},[C?.isTrial,C?.trialEndsAt,u,C?.fetchTimestamp]),{clientSecret:n,publishableKey:te,showPaymentModal:i,showAmount:o,originalAmount:j,showCurrency:N,paymentError:ee,showType:c,isPaid:u,isCheckingPayment:p,showPaymentSuccessModal:h,isCreatingPayment:_,payingPlan:y,currentPlan:x,planDetails:C,lifetimeAvailability:T,appliedCouponCode:k,closePaymentModal:re,handlePaymentSuccess:ie,makePayment:L,refreshSubscriptionStatus:ne,activeSubscriptionId:D,setClientSecret:r,setShowAmount:s,handleStartTrial:ae}}var Ro=[`Get Unlimited Chat Bubbles`,`Get Premium Customization Options`,`Get 19+ Social Channels (WhatsApp, Messenger, etc.)`,`Get Custom Triggers & Display Rules`,`Get Agent Profiles & Welcome Messages`,`Get Free Support`,`7 Days Free Trial`];function zo({isOpen:e,initialMode:t=`register`,onClose:n,onSocialAuthSuccess:r}){let[i,a]=(0,d.useState)(t===`login`?`login`:`register`),[o,s]=(0,d.useState)(`features`),[c,l]=(0,d.useState)(``),[u,f]=(0,d.useState)(``),[p,m]=(0,d.useState)(null),h=(0,d.useRef)(null),g=(0,d.useRef)(!1),_=(0,d.useCallback)(()=>{h.current&&=(clearInterval(h.current),null),s(`features`),m(null)},[]);(0,d.useEffect)(()=>{e?(a(t===`login`?`login`:`register`),s(`features`),m(null),g.current=!1):_()},[e,t,_]),(0,d.useEffect)(()=>{if(!e)return;let t=e=>{e.key===`Escape`&&n()};return window.addEventListener(`keydown`,t),()=>window.removeEventListener(`keydown`,t)},[e,n]),(0,d.useEffect)(()=>{if(!e||o!==`waiting`)return;let t=e=>{if(!e.data||e.data.type!==`social-auth-success`)return;let{token:t,user:i,trial:a}=e.data;t&&i&&(g.current=!0,h.current&&=(clearInterval(h.current),null),r({token:t,user:i,trial:a}),n())};return window.addEventListener(`message`,t),()=>window.removeEventListener(`message`,t)},[e,o,r,n]),(0,d.useEffect)(()=>{if(!e||o!==`waiting`||!c){h.current&&=(clearInterval(h.current),null);return}g.current=!1;let t=0,i=0,a=async()=>{if(!g.current&&(typeof document>`u`||document.visibilityState!==`hidden`))try{let e=await qa(c);i=0,e&&e.status===`authenticated`&&e.token&&e.user&&(g.current=!0,h.current&&=(clearInterval(h.current),null),r({token:e.token,user:e.user,trial:e.trial}),n())}catch{i++,i>=6&&h.current&&(clearInterval(h.current),h.current=null)}},s=()=>{!g.current&&typeof document<`u`&&document.visibilityState===`visible`&&a()};window.addEventListener(`focus`,s),document.addEventListener(`visibilitychange`,s);let l=setTimeout(()=>{a()},400);return h.current=window.setInterval(()=>{if(t++,t>=60){h.current&&=(clearInterval(h.current),null);return}a()},2e3),()=>{clearTimeout(l),h.current&&=(clearInterval(h.current),null),window.removeEventListener(`focus`,s),document.removeEventListener(`visibilitychange`,s)}},[e,o,c,r,n]);let v=async()=>{m(null),g.current=!1;let e=typeof crypto<`u`&&typeof crypto.randomUUID==`function`?crypto.randomUUID():Math.random().toString(36).substring(2,15)+Math.random().toString(36).substring(2,15);l(e);let t=``;try{t=(await fi())?.siteId||``}catch{}let n=`dark`;typeof document<`u`&&(document.documentElement.getAttribute(`data-framer-theme`)||document.body.getAttribute(`data-framer-theme`)||document.documentElement.getAttribute(`data-theme`)||document.body.getAttribute(`data-theme`))===`light`&&(n=`light`);let r=Ei(`/auth`),a=new URLSearchParams;a.set(`mode`,i),a.set(`sessionId`,e),a.set(`theme`,n),t&&a.set(`siteId`,t);let o=`${r}?${a.toString()}`;f(o),s(`waiting`),window.open(o,`_blank`,`noopener,noreferrer`)};return e?(0,q.jsx)(`div`,{className:`cb-auth-overlay`,onClick:n,children:(0,q.jsxs)(`div`,{className:`cb-auth-panel`,onClick:e=>e.stopPropagation(),role:`dialog`,"aria-modal":`true`,children:[(0,q.jsx)(`button`,{type:`button`,className:`cb-auth-close-btn`,onClick:n,"aria-label":`Close`,children:`✕`}),(0,q.jsxs)(`div`,{className:`cb-auth-icon-wrap`,children:[(0,q.jsx)(`div`,{className:`cb-auth-pulse-ring`}),(0,q.jsx)(`div`,{className:`cb-auth-icon-box`,children:(0,q.jsx)(`svg`,{width:`30`,height:`30`,viewBox:`0 0 56 56`,fill:`none`,xmlns:`http://www.w3.org/2000/svg`,className:`cb-auth-app-icon`,children:(0,q.jsx)(`path`,{d:`M28.4323 13C39.5865 13 48.6295 19.1933 48.6295 26.833C48.6295 34.4725 39.5865 40.666 28.4323 40.666C27.1413 40.666 25.8786 40.5825 24.6549 40.4238L26.2535 35.6826L21.984 39.9453L14.9196 47L14.484 36.8369C10.6343 34.318 8.23599 30.7672 8.23596 26.833C8.23596 19.1933 17.2781 13.0001 28.4323 13ZM24.1481 22.0088C23.5916 22.0088 23.0605 22.0945 22.5758 22.251C23.1643 22.5375 23.557 23.0498 23.5573 23.6338C23.5573 24.5317 22.6306 25.2597 21.4879 25.2598C20.9295 25.2598 20.4226 25.0861 20.0504 24.8037C20.0238 24.9527 20.0094 25.1049 20.0094 25.2598C20.0094 27.0556 21.8626 28.5117 24.1481 28.5117C26.4336 28.5117 28.2867 27.0556 28.2867 25.2598C28.2866 23.4643 26.4335 22.0088 24.1481 22.0088ZM37.0475 22.0127C37.1898 22.2332 37.27 22.4829 37.2701 22.7471C37.2701 23.6449 36.3434 24.3729 35.2008 24.373C34.5509 24.373 33.9708 24.1377 33.5914 23.7695C33.2978 24.216 33.1315 24.7225 33.1315 25.2598C33.1315 27.0556 34.9847 28.5117 37.2701 28.5117C39.5555 28.5115 41.4078 27.0555 41.4078 25.2598C41.4077 23.4644 39.5554 22.009 37.2701 22.0088C37.1956 22.0088 37.121 22.0097 37.0475 22.0127Z`,fill:`white`})})})]}),(0,q.jsxs)(`div`,{className:`cb-auth-header`,children:[(0,q.jsx)(`h3`,{className:`cb-auth-title`,children:i===`register`?`You Get Free Trial`:`Sign in to your account`}),(0,q.jsx)(`p`,{className:`cb-auth-desc`,children:i===`register`?`This plugin is full PRO. Start your free trial to unlock chat bubbles and all customizations.`:`Sign in with your email, password, or Google in your browser to continue.`})]}),i===`register`&&(0,q.jsx)(`div`,{className:`cb-auth-features-list`,children:Ro.map((e,t)=>(0,q.jsxs)(`div`,{className:`cb-auth-feature-row`,children:[(0,q.jsx)(`svg`,{width:`15`,height:`15`,viewBox:`0 0 24 24`,fill:`none`,stroke:`#22c55e`,strokeWidth:`2.8`,strokeLinecap:`round`,strokeLinejoin:`round`,className:`cb-auth-feature-check`,children:(0,q.jsx)(`polyline`,{points:`20 6 9 17 4 12`})}),(0,q.jsx)(`span`,{className:`cb-auth-feature-text`,children:e})]},t))}),o===`waiting`&&(0,q.jsxs)(`div`,{className:`cb-auth-waiting-card`,children:[(0,q.jsx)(`div`,{className:`cb-auth-waiting-spinner`}),(0,q.jsxs)(`div`,{className:`cb-auth-waiting-info`,children:[(0,q.jsx)(`div`,{className:`cb-auth-waiting-title`,children:`Waiting for browser completion...`}),(0,q.jsx)(`div`,{className:`cb-auth-waiting-desc`,children:i===`register`?`Complete your sign-up in the opened browser tab. Your plugin will automatically connect once finished.`:`Complete your sign-in in the opened browser tab. Your plugin will automatically connect once finished.`})]})]}),p&&(0,q.jsx)(`div`,{className:`cb-auth-error`,children:p}),(0,q.jsxs)(`div`,{className:`cb-auth-actions-stack`,children:[o===`features`?(0,q.jsx)(`button`,{type:`button`,className:`cb-auth-primary-btn primary-cta`,onClick:v,children:i===`register`?`Start Free Trial`:`Sign In with Browser`}):(0,q.jsx)(`button`,{type:`button`,className:`cb-auth-primary-btn primary-cta`,onClick:()=>{u?window.open(u,`_blank`,`noopener,noreferrer`):v()},children:`Re-open Browser Window`}),(0,q.jsx)(`button`,{type:`button`,className:`cb-auth-cancel-btn`,onClick:o===`waiting`?_:n,children:`Cancel`})]}),(0,q.jsxs)(`div`,{className:`cb-auth-footer`,children:[(0,q.jsx)(`span`,{className:`cb-auth-footer-text`,children:i===`register`?`Already have an account?`:`Don't have an account?`}),(0,q.jsx)(`button`,{type:`button`,className:`cb-auth-link-btn`,onClick:()=>{m(null),_(),a(i===`register`?`login`:`register`)},children:i===`register`?`Sign in`:`Start Free Trial`})]})]})}):null}var Bo=o(((e,t)=>{t.exports=`SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED`})),Vo=o(((e,t)=>{var n=Bo();function r(){}function i(){}i.resetWarningCache=r,t.exports=function(){function e(e,t,r,i,a,o){if(o!==n){var s=Error("Calling PropTypes validators directly is not supported by the `prop-types` package. Use PropTypes.checkPropTypes() to call them. Read more at http://fb.me/use-check-prop-types");throw s.name=`Invariant Violation`,s}}e.isRequired=e;function t(){return e}var a={array:e,bigint:e,bool:e,func:e,number:e,object:e,string:e,symbol:e,any:e,arrayOf:t,element:e,elementType:e,instanceOf:t,node:e,objectOf:t,oneOf:t,oneOfType:t,shape:t,exact:t,checkPropTypes:i,resetWarningCache:r};return a.PropTypes=a,a}})),Ho=c(o(((e,t)=>{t.exports=Vo()()}))(),1);function Uo(e,t){(t==null||t>e.length)&&(t=e.length);for(var n=0,r=Array(t);n<t;n++)r[n]=e[n];return r}function Wo(e){if(Array.isArray(e))return e}function Go(e,t,n){return(t=es(t))in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}function Ko(e,t){var n=e==null?null:typeof Symbol<`u`&&e[Symbol.iterator]||e[`@@iterator`];if(n!=null){var r,i,a,o,s=[],c=!0,l=!1;try{if(a=(n=n.call(e)).next,t!==0)for(;!(c=(r=a.call(n)).done)&&(s.push(r.value),s.length!==t);c=!0);}catch(e){l=!0,i=e}finally{try{if(!c&&n.return!=null&&(o=n.return(),Object(o)!==o))return}finally{if(l)throw i}}return s}}function qo(){throw TypeError(`Invalid attempt to destructure non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`)}function Jo(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);t&&(r=r.filter(function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable})),n.push.apply(n,r)}return n}function Yo(e){for(var t=1;t<arguments.length;t++){var n=arguments[t]==null?{}:arguments[t];t%2?Jo(Object(n),!0).forEach(function(t){Go(e,t,n[t])}):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(n)):Jo(Object(n)).forEach(function(t){Object.defineProperty(e,t,Object.getOwnPropertyDescriptor(n,t))})}return e}function Xo(e,t){if(e==null)return{};var n,r,i=Zo(e,t);if(Object.getOwnPropertySymbols){var a=Object.getOwnPropertySymbols(e);for(r=0;r<a.length;r++)n=a[r],t.indexOf(n)===-1&&{}.propertyIsEnumerable.call(e,n)&&(i[n]=e[n])}return i}function Zo(e,t){if(e==null)return{};var n={};for(var r in e)if({}.hasOwnProperty.call(e,r)){if(t.indexOf(r)!==-1)continue;n[r]=e[r]}return n}function Qo(e,t){return Wo(e)||Ko(e,t)||ns(e,t)||qo()}function $o(e,t){if(typeof e!=`object`||!e)return e;var n=e[Symbol.toPrimitive];if(n!==void 0){var r=n.call(e,t);if(typeof r!=`object`)return r;throw TypeError(`@@toPrimitive must return a primitive value.`)}return(t===`string`?String:Number)(e)}function es(e){var t=$o(e,`string`);return typeof t==`symbol`?t:t+``}function ts(e){"@babel/helpers - typeof";return ts=typeof Symbol==`function`&&typeof Symbol.iterator==`symbol`?function(e){return typeof e}:function(e){return e&&typeof Symbol==`function`&&e.constructor===Symbol&&e!==Symbol.prototype?`symbol`:typeof e},ts(e)}function ns(e,t){if(e){if(typeof e==`string`)return Uo(e,t);var n={}.toString.call(e).slice(8,-1);return n===`Object`&&e.constructor&&(n=e.constructor.name),n===`Map`||n===`Set`?Array.from(e):n===`Arguments`||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)?Uo(e,t):void 0}}var rs=function(e,t,n){var r=!!n,i=d.useRef(n);d.useEffect(function(){i.current=n},[n]),d.useEffect(function(){if(!r||!e)return function(){};var n=function(){if(i.current)return i.current.apply(i,arguments)};return e.on(t,n),function(){e.off(t,n)}},[r,t,e,i])},is=function(e){var t=d.useRef(e);return d.useEffect(function(){t.current=e},[e]),t.current},as=function(e){return e!==null&&ts(e)===`object`},os=function(e){return as(e)&&typeof e.then==`function`},ss=function(e){return as(e)&&typeof e.elements==`function`&&typeof e.createToken==`function`&&typeof e.createPaymentMethod==`function`&&typeof e.confirmCardPayment==`function`},cs=`[object Object]`,ls=function e(t,n){if(t===n)return!0;if(!as(t)||!as(n))return t===n;var r=Array.isArray(t);if(r!==Array.isArray(n))return!1;var i=Object.prototype.toString.call(t)===cs;if(i!==(Object.prototype.toString.call(n)===cs))return!1;if(!i&&!r)return t===n;var a=Object.keys(t),o=Object.keys(n);if(a.length!==o.length)return!1;for(var s={},c=0;c<a.length;c+=1)s[a[c]]=!0;for(var l=0;l<o.length;l+=1)s[o[l]]=!0;var u=Object.keys(s);if(u.length!==a.length)return!1;var d=t,f=n;return u.every(function(t){return e(d[t],f[t])})},us=function(e,t,n){return as(e)?Object.keys(e).reduce(function(r,i){var a=!as(t)||!ls(e[i],t[i]);return n.includes(i)?(a&&console.warn(`Unsupported prop change: options.${i} is not a mutable property.`),r):a?Yo(Yo({},r||{}),{},Go({},i,e[i])):r},null):null},ds="Invalid prop `stripe` supplied to `Elements`. We recommend using the `loadStripe` utility from `@stripe/stripe-js`. See https://stripe.com/docs/stripe-js/react#elements-props-stripe for details.",fs=function(e){var t=arguments.length>1&&arguments[1]!==void 0?arguments[1]:ds;if(e===null||ss(e))return e;throw Error(t)},ps=function(e){var t=arguments.length>1&&arguments[1]!==void 0?arguments[1]:ds;if(os(e))return{tag:`async`,stripePromise:Promise.resolve(e).then(function(e){return fs(e,t)})};var n=fs(e,t);return n===null?{tag:`empty`}:{tag:`sync`,stripe:n}},ms=function(e){e&&e._registerWrapper&&e.registerAppInfo&&(e._registerWrapper({name:`react-stripe-js`,version:`7.0.0`}),e.registerAppInfo({name:`react-stripe-js`,version:`7.0.0`,url:`https://stripe.com/docs/stripe-js/react`}))},hs=d.createContext(null);hs.displayName=`ElementsContext`;var gs=function(e,t){if(!e)throw Error(`Could not find Elements context; You need to wrap the part of your app that ${t} in an <Elements> provider.`);return e},_s=function(e){var t=e.stripe,n=e.options,r=e.children,i=d.useMemo(function(){return ps(t)},[t]),a=Qo(d.useState(function(){return{stripe:i.tag===`sync`?i.stripe:null,elements:i.tag===`sync`?i.stripe.elements(n):null}}),2),o=a[0],s=a[1],c=d.useRef(!1);d.useEffect(function(){var e=!0,t=function(e){s(function(t){return t.stripe||c.current?t:(c.current=!0,{stripe:e,elements:e.elements(n)})})};return i.tag===`async`&&!o.stripe?i.stripePromise.then(function(n){n&&e&&t(n)}):i.tag===`sync`&&!o.stripe&&t(i.stripe),function(){e=!1,c.current=!1}},[i,o,n]);var l=is(t);d.useEffect(function(){l!==null&&l!==t&&console.warn("Unsupported prop change on Elements: You cannot change the `stripe` prop after setting it.")},[l,t]);var u=is(n);return d.useEffect(function(){if(o.elements){var e=us(n,u,[`clientSecret`,`fonts`]);e&&o.elements.update(e)}},[n,u,o.elements]),d.useEffect(function(){ms(o.stripe)},[o.stripe]),d.createElement(hs.Provider,{value:o},r)};_s.propTypes={stripe:Ho.default.any,options:Ho.default.object};var vs=function(e){return gs(d.useContext(hs),e)},ys=function(){return vs(`calls useElements()`).elements};Ho.default.func.isRequired;var bs=d.createContext(null);bs.displayName=`CheckoutContext`;var xs=d.createContext(null);xs.displayName=`CheckoutSdkContext`;var Ss=function(e){var t=d.useContext(xs),n=d.useContext(hs);if(t){if(n)throw Error(`You cannot wrap the part of your app that ${e} in both a checkout provider and <Elements> provider.`);return t}return gs(n,e)},Cs=[`mode`],ws=function(e){return e.charAt(0).toUpperCase()+e.slice(1)},Ts=function(e,t,n){var r=`${ws(e)}Element`,i=t?function(e){Ss(`mounts <${r}>`);var t=e.id,n=e.className;return d.createElement(`div`,{id:t,className:n})}:function(t){var n=t.id,i=t.className,a=t.options,o=a===void 0?{}:a,s=t.onBlur,c=t.onFocus,l=t.onReady,u=t.onChange,f=t.onEscape,p=t.onClick,m=t.onLoadError,h=t.onLoaderStart,g=t.onNetworksChange,_=t.onConfirm,v=t.onCancel,y=t.onShippingAddressChange,b=t.onShippingRateChange,x=t.onSavedPaymentMethodRemove,S=t.onSavedPaymentMethodUpdate,C=t.onAvailablePaymentMethodsChange,w=Ss(`mounts <${r}>`),T=`elements`in w?w.elements:null,E=`checkoutSdk`in w?w.checkoutSdk:null,D=Qo(d.useState(null),2),O=D[0],k=D[1],A=d.useRef(null),j=d.useRef(null);rs(O,`blur`,s),rs(O,`focus`,c),rs(O,`escape`,f),rs(O,`click`,p),rs(O,`loaderror`,m),rs(O,`loaderstart`,h),rs(O,`networkschange`,g),rs(O,`confirm`,_),rs(O,`cancel`,v),rs(O,`shippingaddresschange`,y),rs(O,`shippingratechange`,b),rs(O,`savedpaymentmethodremove`,x),rs(O,`savedpaymentmethodupdate`,S),rs(O,`availablepaymentmethodschange`,C),rs(O,`change`,u);var M;l&&(M=e===`expressCheckout`?l:function(){l(O)}),rs(O,`ready`,M),d.useLayoutEffect(function(){if(A.current===null&&j.current!==null&&(T||E)){var t=null;if(E){var n=E,i=E;switch(e){case`paymentForm`:t=i.createForm(o);break;case`payment`:t=n.createPaymentElement(o);break;case`address`:if(`mode`in o){var a=o.mode,s=Xo(o,Cs);if(a===`shipping`)t=n.createShippingAddressElement(s);else if(a===`billing`)t=n.createBillingAddressElement(s);else throw Error(`Invalid options.mode. mode must be 'billing' or 'shipping'.`)}else throw Error(`You must supply options.mode. mode must be 'billing' or 'shipping'.`);break;case`expressCheckout`:t=n.createExpressCheckoutElement(o);break;case`currencySelector`:t=E.createCurrencySelectorElement();break;case`taxId`:t=n.createTaxIdElement(o);break;case`contactDetails`:t=n.createContactDetailsElement();break;case`linkSignup`:if(`createLinkSignupElement`in E)t=E.createLinkSignupElement(o);else throw Error(`<LinkSignupElement> requires <CheckoutElementsProvider> and is not supported inside <CheckoutFormProvider>.`);break;case`terms`:t=n.createTermsElement(o);break;default:throw Error(`<${r}> is not supported inside a checkout provider. Use an <Elements> provider instead.`)}}else T&&(t=T.create(e,o));A.current=t,k(t),t&&t.mount(j.current)}},[T,E,o]);var N=is(o);return d.useEffect(function(){if(A.current){var e=us(o,N,[]);e&&`update`in A.current&&A.current.update(e)}},[o,N]),d.useLayoutEffect(function(){return function(){if(A.current&&typeof A.current.destroy==`function`)try{A.current.destroy(),A.current=null}catch{}}},[]),d.createElement(`div`,{id:n,className:i,ref:j})};return i.propTypes={id:Ho.default.string,className:Ho.default.string,onChange:Ho.default.func,onBlur:Ho.default.func,onFocus:Ho.default.func,onReady:Ho.default.func,onEscape:Ho.default.func,onClick:Ho.default.func,onLoadError:Ho.default.func,onLoaderStart:Ho.default.func,onNetworksChange:Ho.default.func,onConfirm:Ho.default.func,onCancel:Ho.default.func,onShippingAddressChange:Ho.default.func,onShippingRateChange:Ho.default.func,onSavedPaymentMethodRemove:Ho.default.func,onSavedPaymentMethodUpdate:Ho.default.func,onAvailablePaymentMethodsChange:Ho.default.func,options:Ho.default.object},i.displayName=r,i.__elementType=e,i},Es=typeof window>`u`,Ds=d.createContext(null);Ds.displayName=`EmbeddedCheckoutProviderContext`;var Os=function(){return Ss(`calls useStripe()`).stripe};Ts(`auBankAccount`,Es),Ts(`card`,Es),Ts(`cardNumber`,Es),Ts(`cardExpiry`,Es),Ts(`cardCvc`,Es),Ts(`currencySelector`,Es),Ts(`iban`,Es);var ks=Ts(`payment`,Es);Ts(`expressCheckout`,Es),Ts(`linkAuthentication`,Es),Ts(`linkSignup`,Es),Ts(`contactDetails`,Es),Ts(`address`,Es),Ts(`shippingAddress`,Es),Ts(`paymentMethodMessaging`,Es),Ts(`taxId`,Es),Ts(`issuingCardNumberDisplay`,Es),Ts(`issuingCardCvcDisplay`,Es),Ts(`issuingCardExpiryDisplay`,Es),Ts(`issuingCardPinDisplay`,Es),Ts(`issuingCardCopyButton`,Es),Ts(`terms`,Es);var As=e=>e instanceof Error?e.message:`Payment failed`;function js({draft:e,setDraft:t,onClose:n,onSuccess:r,notify:i,plan:a,clientSecret:o,setClientSecret:s,setShowAmount:c,showAmount:l,showCurrency:u=`usd`,showType:f}){let[p,m]=(0,d.useState)(!1),[h,g]=(0,d.useState)(``);(0,d.useEffect)(()=>{if(p||h)return;let e=setTimeout(()=>g(`Payment fields could not load. Close checkout and try again.`),2e4);return()=>clearTimeout(e)},[p,h]);let _=Os(),v=ys(),[y,b]=(0,d.useState)(!1),{email:x,couponCode:S,appliedCode:C,originalAmount:w,subscriptionId:T}=e,E=(0,d.useRef)(!1),[D,O]=(0,d.useState)(!1),[k,A]=(0,d.useState)(!1),[j,M]=(0,d.useState)(``),N=e=>new Intl.NumberFormat(`en-US`,{style:`currency`,currency:u}).format(e),P=10**(new Intl.NumberFormat(`en`,{style:`currency`,currency:u}).resolvedOptions().maximumFractionDigits??2),ee=l??w,F=Math.max(0,w-ee),te=!!C&&S.trim()===C&&!j;(0,d.useEffect)(()=>{if(D){let e=setTimeout(()=>{O(!1)},8e3);return()=>clearTimeout(e)}},[D]);let I=a===`monthly`?`Billed monthly`:a===`yearly`?`Billed yearly`:a===`lifetime`?`Lifetime access · one-time payment`:f||`Pro Plan`;return(0,q.jsxs)(`form`,{onSubmit:async e=>{if(e.preventDefault(),_&&v&&!E.current){if(!x){O(!0);return}E.current=!0,b(!0);try{let{error:e,paymentIntent:t}=await _.confirmPayment({elements:v,confirmParams:{receipt_email:x,payment_method_data:{billing_details:{email:x}}},redirect:`if_required`});if(e){i({type:`Error`,message:e.message||`Payment failed`});return}if(t?.status===`succeeded`){try{let e=await fi();await to({paymentIntentId:t.id,siteId:e.siteId,email:x,plan:a||`lifetime`,subscriptionId:a===`lifetime`?null:T||null})}catch(e){console.error(`Backend verification error (non-blocking):`,e)}i({type:`Success`,message:`Your Payment Has Been Successful!`}),await r(t.id),n()}}catch(e){i({type:`Error`,message:As(e)})}finally{E.current=!1,b(!1)}}},className:`crestbar-card-form payment-form`,translate:`no`,children:[(0,q.jsxs)(`div`,{className:`crestbar-payment-summary`,children:[(0,q.jsx)(`h1`,{id:`crestbar-payment-title`,children:`Complete payment`}),(0,q.jsx)(`span`,{className:`crestbar-checkout-plan`,children:I}),(0,q.jsxs)(`div`,{className:`crestbar-checkout-total`,"aria-live":`polite`,children:[w>ee&&(0,q.jsx)(`del`,{className:`checkout-original-price`,children:N(w)}),(0,q.jsx)(`strong`,{children:N(ee)}),a===`monthly`&&(0,q.jsx)(`span`,{children:`/ month`}),a===`yearly`&&(0,q.jsx)(`span`,{children:`/ year`})]}),F>0&&(0,q.jsxs)(`div`,{children:[(0,q.jsxs)(`div`,{className:`crestbar-checkout-breakdown`,children:[(0,q.jsx)(`span`,{children:`Subtotal`}),(0,q.jsx)(`span`,{children:N(w)})]}),(0,q.jsxs)(`div`,{className:`crestbar-checkout-discount`,children:[(0,q.jsxs)(`span`,{children:[`Coupon discount (`,C,`)`]}),(0,q.jsxs)(`span`,{children:[`−`,N(F)]})]})]})]}),(0,q.jsxs)(`div`,{className:`framefic-email-wrapper`,children:[(0,q.jsx)(`label`,{className:`framefic-email-label`,htmlFor:`crestbar-payment-email`,children:`Email`}),(0,q.jsx)(`input`,{id:`crestbar-payment-email`,type:`email`,autoComplete:`email`,className:`framefic-email-input-field`,value:x,onChange:e=>{let n=e.target.value;t(e=>({...e,email:n}))},placeholder:`email@example.com`,disabled:y,required:!0})]}),(0,q.jsxs)(`div`,{className:`framefic-coupon-section`,children:[(0,q.jsx)(`label`,{className:`framefic-email-label`,htmlFor:`crestbar-coupon`,children:`Coupon code`}),(0,q.jsxs)(`div`,{className:`framefic-coupon-input-row`,children:[(0,q.jsx)(`input`,{id:`crestbar-coupon`,type:`text`,className:`framefic-coupon-input`,placeholder:`Enter coupon code`,value:S,onChange:e=>{let n=e.target.value.toUpperCase();t(e=>({...e,couponCode:n})),M(``)},disabled:k||y}),(0,q.jsx)(`button`,{type:`button`,className:`framefic-coupon-btn`,onClick:async()=>{let e=S.trim();if(!(!e||E.current||e===C&&!j)){E.current=!0,A(!0),M(``);try{let l=o?o.split(`_secret_`)[0]:null,u=a===`lifetime`?l:T||l;if(!u){M(`Cannot apply coupon to this payment session.`);return}let d=await eo(u,e,l,a),f=typeof d?.originalAmount==`number`?d.originalAmount/P:w,p=d.isPaid===!0||d.status===`paid`||d.status===`active`||d.status===`trialing`||d.discountedAmount===0;if(d?.success===!1||typeof d?.discountedAmount!=`number`||!Number.isFinite(d.discountedAmount)||d.discountedAmount<0||!p&&d.discountedAmount/P>=f)throw Error(d?.message||`This coupon is not valid for the selected plan. Please try another code.`);if(!p&&!d.clientSecret)throw Error(`Unable to apply this coupon. Please try again.`);if(!p&&d.clientSecret===o&&v){let{error:e}=await v.fetchUpdates();if(e)throw Error(e.message)}if(c(d.discountedAmount/P),t(t=>({...t,appliedCode:e,originalAmount:typeof d.originalAmount==`number`?d.originalAmount/P:t.originalAmount,subscriptionId:d.subscriptionId||u})),p){i({type:`Success`,message:a===`lifetime`?`Coupon applied! Lifetime access is now active.`:`Coupon applied! Subscription is now active.`}),await r(d.subscriptionId||u),n();return}d.clientSecret&&d.clientSecret!==o&&s(d.clientSecret),i({type:`Success`,message:`Coupon applied successfully!`})}catch(e){M(/prior transactions|first.time/i.test(e.message||``)?`This coupon is not valid for this account. It is limited to first-time customers; previous trials or payment attempts can affect eligibility.`:e.message||`Invalid or expired coupon code. Please try another code.`);let n=o?o.split(`_secret_`)[0]:null,r=a===`lifetime`?n:T||n;if(r&&C)try{let e=await eo(r,``,n,a),i=typeof e?.originalAmount==`number`?e.originalAmount/P:w;c(i),t(t=>({...t,appliedCode:``,originalAmount:i,subscriptionId:e?.subscriptionId||r})),e?.clientSecret&&e.clientSecret!==o?s(e.clientSecret):v&&await v.fetchUpdates().catch(()=>{})}catch{c(w),t(e=>({...e,appliedCode:``,originalAmount:w}))}else c(w),t(e=>({...e,appliedCode:``}))}finally{E.current=!1,A(!1)}}},disabled:k||y||!S.trim()||S.trim()===C&&!j,children:k?`Applying...`:`Apply`})]}),te&&(0,q.jsxs)(`div`,{className:`framefic-coupon-status-row`,children:[(0,q.jsx)(`span`,{className:`framefic-coupon-success`,children:`✓ Coupon applied successfully!`}),(0,q.jsx)(`button`,{type:`button`,className:`framefic-coupon-remove-btn`,onClick:async()=>{if(!E.current&&C){E.current=!0,A(!0),M(``);try{let e=o?o.split(`_secret_`)[0]:null,n=a===`lifetime`?e:T||e;if(!n)throw Error(`Cannot update this payment session.`);let r=await eo(n,``,e,a);if(r?.success===!1)throw Error(r?.message||`Failed to remove coupon.`);let l=typeof r?.originalAmount==`number`?r.originalAmount/P:w;c(l),t(e=>({...e,couponCode:``,appliedCode:``,originalAmount:l,subscriptionId:r.subscriptionId||n})),r.clientSecret&&r.clientSecret!==o?s(r.clientSecret):v&&await v.fetchUpdates().catch(()=>{}),i({type:`Success`,message:`Coupon removed. Original price restored.`})}catch(e){M(e.message||`Failed to remove coupon.`)}finally{E.current=!1,A(!1)}}},disabled:k||y,children:`Remove`})]}),j&&(0,q.jsx)(`div`,{className:`framefic-coupon-error`,role:`alert`,children:j})]}),h&&(0,q.jsx)(`p`,{role:`alert`,children:h}),(0,q.jsx)(ks,{onReady:()=>{m(!0),g(``)},onLoadError:()=>g(`Payment fields could not load. Close checkout and try again.`),options:{fields:{billingDetails:{name:`auto`,email:`never`,phone:`never`,address:`auto`}},terms:{card:`never`},wallets:{applePay:`never`,googlePay:`never`,link:`never`}}}),D&&(0,q.jsx)(`div`,{className:`email-error-banner`,children:(0,q.jsx)(`p`,{children:`Please enter your email address to proceed with payment.`})}),(0,q.jsxs)(`div`,{className:`crestbar-stripe-branding`,children:[(0,q.jsx)(wa,{size:12,"aria-hidden":`true`}),(0,q.jsx)(`span`,{children:`Payments processed by`}),(0,q.jsx)(`strong`,{children:`Stripe`})]}),(0,q.jsxs)(`div`,{className:`framefic-payment-button`,children:[(0,q.jsx)(`button`,{type:`button`,className:`payment-cancel`,onClick:n,disabled:y||k,children:`Cancel`}),(0,q.jsxs)(`button`,{type:`submit`,className:`primary-cta buy-now-button`,disabled:!_||!v||!p||!!h||y||k,"aria-busy":y||!p&&!h,children:[(0,q.jsx)(wa,{size:14,"aria-hidden":`true`}),y?`Processing...`:`Pay ${N(ee)}`]})]})]})}function Ms({isOpen:e,clientSecret:t,showPaymentSuccessModal:n,showAmount:r,originalAmount:i,showCurrency:a=`usd`,showType:o,plan:s,stripePromise:c,onClose:l,onSuccess:u,notify:f,defaultEmail:p,defaultCouponCode:m=``,subscriptionId:h,setClientSecret:g,setShowAmount:_,paymentError:v,onRetry:y}){let[b,x]=(0,d.useState)(()=>typeof document<`u`?document.body.dataset.framerTheme??null:null),[S,C]=(0,d.useState)(!1),[w,T]=(0,d.useState)(``),[E,D]=(0,d.useState)(()=>({email:p||``,couponCode:m,appliedCode:m,originalAmount:i??r??0,subscriptionId:h??null}));(0,d.useEffect)(()=>{if(typeof document>`u`)return;let e=document.body,t=new MutationObserver(()=>{x(e.dataset.framerTheme??null)});return t.observe(e,{attributes:!0,attributeFilter:[`data-framer-theme`]}),x(e.dataset.framerTheme??null),()=>t.disconnect()},[]),(0,d.useEffect)(()=>{e&&D({email:p||``,couponCode:m,appliedCode:m,originalAmount:i??r??0,subscriptionId:h??null})},[e,p,m]),(0,d.useEffect)(()=>{if(T(``),C(!1),!e)return;let n=!1,r=setTimeout(()=>{!n&&(!t||!c)&&T(`Payment could not initialize. Close and try again.`)},2e4);return c&&Promise.resolve(c).then(e=>{!n&&!e&&C(!0)}).catch(()=>{n||C(!0)}),()=>{n=!0,clearTimeout(r)}},[e,t,c]);let O=b===`light`;if(!e||n)return null;let k={clientSecret:t||void 0,appearance:{theme:O?`stripe`:`night`,variables:{colorPrimary:`#5271FF`,colorBackground:O?`#FFFFFF`:`#1a1a1a`,colorText:O?`#101828`:`#FCFCFD`,colorTextSecondary:O?`#5F6B7A`:`#BFBFBF`,colorDanger:`#F97066`,colorIcon:O?`#5F6B7A`:`#BFBFBF`,borderRadius:`6px`,spacingUnit:`4px`,fontSizeBase:`13px`,fontFamily:`Inter, sans-serif`}}},A=v||w||(S?`Stripe could not load. Check your internet connection and try again.`:``);return(0,q.jsxs)(`section`,{className:`crestbar-checkout-page`,"aria-labelledby":`crestbar-payment-title`,children:[(0,q.jsxs)(`header`,{className:`crestbar-checkout-header`,children:[(0,q.jsxs)(`button`,{type:`button`,className:`crestbar-checkout-back`,onClick:l,children:[(0,q.jsx)(ma,{size:14}),` Back to plans`]}),(0,q.jsxs)(`span`,{children:[(0,q.jsx)(wa,{size:12}),` Secure checkout`]})]}),(0,q.jsx)(`div`,{className:`stripe-checkout-box`,children:A?(0,q.jsxs)(`div`,{children:[(0,q.jsx)(`p`,{role:`alert`,className:`framefic-coupon-error checkout-error-mb`,children:A}),y&&(0,q.jsx)(`button`,{type:`button`,className:`primary-cta buy-now-button checkout-btn-full`,onClick:()=>{T(``),C(!1),D({email:p||``,couponCode:m,appliedCode:m,originalAmount:i??r??0,subscriptionId:h??null}),y()},children:`Retry checkout`}),(0,q.jsx)(`button`,{type:`button`,className:`payment-cancel checkout-btn-close`,onClick:l,children:`Close`})]}):t&&c?(0,q.jsx)(_s,{stripe:c,options:k,children:(0,q.jsx)(js,{draft:E,setDraft:D,onClose:l,onSuccess:u,notify:f,plan:s,defaultEmail:p,subscriptionId:h,clientSecret:t,setClientSecret:g,setShowAmount:_,showAmount:r,showCurrency:a,showType:o})},t):(0,q.jsxs)(`div`,{children:[(0,q.jsxs)(`div`,{className:`stripe-checkout-skeleton`,children:[(0,q.jsx)(`span`,{}),(0,q.jsx)(`span`,{}),(0,q.jsx)(`span`,{})]}),(0,q.jsx)(`button`,{type:`button`,className:`payment-cancel checkout-btn-cancel-skeleton`,onClick:l,children:`Cancel`})]})})]})}function Ns({isOpen:e}){return e?(0,q.jsx)(`div`,{className:`payment-modal success-modal`,children:(0,q.jsxs)(`div`,{className:`payment-box success-box`,children:[(0,q.jsxs)(`div`,{className:`success-icon-container`,children:[(0,q.jsx)(`div`,{className:`success-icon-glow`}),(0,q.jsxs)(`svg`,{className:`checkmark-svg`,xmlns:`http://www.w3.org/2000/svg`,viewBox:`0 0 52 52`,children:[(0,q.jsx)(`circle`,{className:`checkmark-circle`,cx:`26`,cy:`26`,r:`25`,fill:`none`}),(0,q.jsx)(`path`,{className:`checkmark-check`,fill:`none`,d:`M14.1 27.2l7.1 7.2 16.7-16.8`})]})]}),(0,q.jsx)(`h3`,{children:`Payment Completed`}),(0,q.jsx)(`p`,{children:`Your payment was successful. The watermark has been removed!`}),(0,q.jsxs)(`div`,{className:`success-loader-container`,children:[(0,q.jsx)(`div`,{className:`success-loader-spinner`}),(0,q.jsx)(`span`,{children:`Updating your subscription...`})]})]})}):null}function Ps({isOpen:e,status:t,onClose:n,onUpgrade:r,onLogout:i}){if(!e||!t)return null;let a=t===`started`;return(0,q.jsx)(`div`,{className:`framefic-trial-status-overlay`,onClick:a?n:void 0,children:(0,q.jsxs)(`div`,{className:`framefic-trial-status-panel`,onClick:e=>e.stopPropagation(),children:[(0,q.jsx)(`div`,{className:`framefic-trial-status-header`,children:a&&(0,q.jsx)(`button`,{type:`button`,className:`framefic-trial-status-close`,onClick:n,"aria-label":`Close`,children:(0,q.jsxs)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 24 24`,fill:`none`,stroke:`currentColor`,strokeWidth:`2.5`,strokeLinecap:`round`,strokeLinejoin:`round`,children:[(0,q.jsx)(`line`,{x1:`18`,y1:`6`,x2:`6`,y2:`18`}),(0,q.jsx)(`line`,{x1:`6`,y1:`6`,x2:`18`,y2:`18`})]})})}),(0,q.jsx)(`div`,{className:`framefic-trial-status-content`,children:a?(0,q.jsxs)(q.Fragment,{children:[(0,q.jsx)(`div`,{className:`framefic-trial-status-icon-bubble framefic-trial-status-icon-bubble--success`,children:(0,q.jsx)(`svg`,{width:`22`,height:`22`,viewBox:`0 0 24 24`,fill:`none`,stroke:`currentColor`,strokeWidth:`3.5`,strokeLinecap:`round`,strokeLinejoin:`round`,children:(0,q.jsx)(`polyline`,{points:`20 6 9 17 4 12`})})}),(0,q.jsx)(`h3`,{children:`You're all set!`}),(0,q.jsx)(`p`,{className:`framefic-trial-status-description`,children:`Your free trial has started`}),(0,q.jsx)(`button`,{className:`framefic-trial-status-btn`,onClick:n,children:`Start Exploring`}),(0,q.jsx)(`span`,{className:`framefic-trial-status-footnote`,children:`Enjoy full access to all Pro features during your trial`})]}):(0,q.jsxs)(q.Fragment,{children:[(0,q.jsx)(`div`,{className:`framefic-trial-status-icon-bubble framefic-trial-status-icon-bubble--locked`,children:(0,q.jsxs)(`svg`,{width:`20`,height:`20`,viewBox:`0 0 24 24`,fill:`none`,stroke:`currentColor`,strokeWidth:`2.5`,strokeLinecap:`round`,strokeLinejoin:`round`,children:[(0,q.jsx)(`rect`,{x:`3`,y:`11`,width:`18`,height:`11`,rx:`2`,ry:`2`}),(0,q.jsx)(`path`,{d:`M7 11V7a5 5 0 0 1 10 0v4`})]})}),(0,q.jsx)(`h3`,{children:`Your trial has ended`}),(0,q.jsx)(`p`,{className:`framefic-trial-status-description`,children:`Upgrade now to keep using. Your widgets are saved and waiting`}),(0,q.jsx)(`button`,{className:`framefic-trial-status-btn`,onClick:r,children:`Upgrade Now`}),(0,q.jsx)(`button`,{className:`framefic-trial-status-logout-link`,onClick:i,children:`Log out`})]})})]})})}function Fs(e){"@babel/helpers - typeof";return Fs=typeof Symbol==`function`&&typeof Symbol.iterator==`symbol`?function(e){return typeof e}:function(e){return e&&typeof Symbol==`function`&&e.constructor===Symbol&&e!==Symbol.prototype?`symbol`:typeof e},Fs(e)}var Is=`endive`,Ls=function(e){return e===3?`v3`:e},Rs=`https://js.stripe.com`,zs=`${Rs}/${Is}/stripe.js`,Bs=/^https:\/\/js\.stripe\.com\/v3\/?(\?.*)?$/,Vs=/^https:\/\/js\.stripe\.com\/(v3|[a-z]+)\/stripe\.js(\?.*)?$/,Hs=`loadStripe.setLoadParameters was called but an existing Stripe.js script already exists in the document; existing script parameters will be used`,Us=function(e){return Bs.test(e)||Vs.test(e)},Ws=function(){for(var e=document.querySelectorAll(`script[src^="${Rs}"]`),t=0;t<e.length;t++){var n=e[t];if(Us(n.src))return n}return null},Gs=function(e){var t=e&&!e.advancedFraudSignals?`?advancedFraudSignals=false`:``,n=document.createElement(`script`);n.src=`${zs}${t}`;var r=document.head||document.body;if(!r)throw Error(`Expected document.body not to be null. Stripe.js requires a <body> element.`);return r.appendChild(n),n},Ks=function(e,t){e&&e._registerWrapper&&e._registerWrapper({name:`stripe-js`,version:`10.1.0`,startTime:t})},qs=null,Js=null,Ys=null,Xs=function(e){return function(t){e(Error(`Failed to load Stripe.js`,{cause:t}))}},Zs=function(e,t){return function(){window.Stripe?e(window.Stripe):t(Error(`Stripe.js not available`))}},Qs=function(e){if(qs!==null)return qs;var t=function(){return new Promise(function(t,n){if(typeof window>`u`||typeof document>`u`){t(null);return}if(window.Stripe&&e&&console.warn(Hs),window.Stripe){t(window.Stripe);return}try{var r=Ws();if(r&&e)console.warn(Hs);else if(!r)r=Gs(e);else if(r&&Ys!==null&&Js!==null){var i;r.removeEventListener(`load`,Ys),r.removeEventListener(`error`,Js),(i=r.parentNode)==null||i.removeChild(r),r=Gs(e)}Ys=Zs(t,n),Js=Xs(n),r.addEventListener(`load`,Ys),r.addEventListener(`error`,Js)}catch(e){n(e);return}})};return qs=t().catch(function(){return t()}).catch(function(e){return qs=null,Promise.reject(e)}),qs},$s=function(e,t,n){if(e===null)return null;var r=t[0];if(typeof r!=`string`)throw Error(`Expected publishable key to be of type string, got type ${Fs(r)} instead.`);var i=r.match(/^pk_test/),a=Ls(e.version),o=Is;i&&a!==o&&console.warn(`Stripe.js@${a} was loaded on the page, but @stripe/stripe-js@10.1.0 expected Stripe.js@${o}. This may result in unexpected behavior. For more information, see https://docs.stripe.com/sdks/stripejs-versioning`);var s=e.apply(void 0,t);return Ks(s,n),s},ec,tc=!1,nc=function(){return ec||(ec=Qs(null).catch(function(e){return ec=null,Promise.reject(e)}),ec)};Promise.resolve().then(function(){return nc()}).catch(function(e){tc||console.warn(e)});var rc=function(){var e=[...arguments];tc=!0;var t=Date.now();return nc().then(function(n){return $s(n,e,t)})};function ic({name:e,description:t,logoSrc:n,logoIcon:r,marketplaceUrl:i}){return(0,q.jsxs)(`a`,{href:i,target:`_blank`,rel:`noopener noreferrer`,className:`help-product-card`,"aria-label":`Open ${e} on Framer Marketplace`,children:[(0,q.jsx)(`div`,{className:`product-icon`,children:n?(0,q.jsx)(`img`,{src:n,alt:e,className:`promo-logo`}):r}),(0,q.jsxs)(`div`,{className:`product-info`,children:[(0,q.jsx)(`h5`,{children:e}),(0,q.jsx)(`p`,{children:t})]}),(0,q.jsx)(`div`,{className:`product-arrow`,"aria-hidden":`true`,children:(0,q.jsx)(`svg`,{width:`16`,height:`16`,viewBox:`0 0 24 24`,fill:`none`,xmlns:`http://www.w3.org/2000/svg`,children:(0,q.jsx)(`path`,{d:`M7 17L17 7M17 7H7M17 7V17`,stroke:`currentColor`,strokeWidth:`2`,strokeLinecap:`round`,strokeLinejoin:`round`})})})]})}function ac(e,t=0,n=1){return Math.max(t,Math.min(n,e))}function oc(e,t=`#ffffff`){if(!e||typeof e!=`string`)return oc(t,`#ffffff`);let n=e.trim().toLowerCase();if(n===`transparent`)return{r:0,g:0,b:0,a:0};let r=n.match(/^rgba?\(\s*([\d.]+)\s*,\s*([\d.]+)\s*,\s*([\d.]+)\s*(?:,\s*([\d.]+)\s*)?\)$/);if(r)return{r:Math.round(ac(parseFloat(r[1]),0,255)),g:Math.round(ac(parseFloat(r[2]),0,255)),b:Math.round(ac(parseFloat(r[3]),0,255)),a:r[4]===void 0?1:ac(parseFloat(r[4]),0,1)};if(n.startsWith(`#`)){let e=n.slice(1);if(e.length===3)return{r:parseInt(e[0]+e[0],16),g:parseInt(e[1]+e[1],16),b:parseInt(e[2]+e[2],16),a:1};if(e.length===4)return{r:parseInt(e[0]+e[0],16),g:parseInt(e[1]+e[1],16),b:parseInt(e[2]+e[2],16),a:parseInt(e[3]+e[3],16)/255};if(e.length===6)return{r:parseInt(e.slice(0,2),16),g:parseInt(e.slice(2,4),16),b:parseInt(e.slice(4,6),16),a:1};if(e.length===8)return{r:parseInt(e.slice(0,2),16),g:parseInt(e.slice(2,4),16),b:parseInt(e.slice(4,6),16),a:parseInt(e.slice(6,8),16)/255}}return t&&t!==e?oc(t,`#ffffff`):{r:255,g:255,b:255,a:1}}function sc(e,t,n){let r=e/255,i=t/255,a=n/255,o=Math.max(r,i,a),s=o-Math.min(r,i,a),c=0,l=o===0?0:s/o,u=o;return s!==0&&(c=o===r?(i-a)/s+(i<a?6:0):o===i?(a-r)/s+2:(r-i)/s+4,c/=6),{h:Math.round(c*360),s:ac(l,0,1),v:ac(u,0,1)}}function cc(e,t,n){let r=e%360/360,i=Math.floor(r*6),a=r*6-i,o=n*(1-t),s=n*(1-a*t),c=n*(1-(1-a)*t),l=0,u=0,d=0;switch(i%6){case 0:l=n,u=c,d=o;break;case 1:l=s,u=n,d=o;break;case 2:l=o,u=n,d=c;break;case 3:l=o,u=s,d=n;break;case 4:l=c,u=o,d=n;break;case 5:l=n,u=o,d=s}return{r:Math.round(l*255),g:Math.round(u*255),b:Math.round(d*255)}}function lc(e,t,n){let r=e=>Math.round(ac(e,0,255)).toString(16).padStart(2,`0`).toUpperCase();return`#${r(e)}${r(t)}${r(n)}`}function uc(e,t,n,r=1){let i=Math.round(r*100)/100;return i<1?`rgba(${e}, ${t}, ${n}, ${i})`:lc(e,t,n)}function dc({size:e=14}){return(0,q.jsxs)(`svg`,{width:e,height:e,viewBox:`0 0 24 24`,fill:`none`,stroke:`currentColor`,strokeWidth:`2`,strokeLinecap:`round`,strokeLinejoin:`round`,children:[(0,q.jsx)(`path`,{d:`m2 22 1-1h3l9-9`}),(0,q.jsx)(`path`,{d:`M3 21v-3l9-9`}),(0,q.jsx)(`path`,{d:`m15 6 3.4-3.4a2.1 2.1 0 1 1 3 3L18 9l.4.4a2.1 2.1 0 1 1-3 3l-3.8-3.8a2.1 2.1 0 1 1 3-3l.4.4Z`})]})}var Q=[`#000000`,`#333333`,`#888888`,`#ffffff`,`#5271ff`,`#3E67EB`,`#22c55e`,`#ef4444`];function fc({value:e,fallback:t=`#ffffff`,onChange:n,disabled:r=!1,ariaLabel:i=`Color picker`}){let[a,o]=(0,d.useState)(!1),[s,c]=(0,d.useState)(!1),l=(0,d.useCallback)(e=>{let n=oc(e||t,t);return n.a<1?uc(n.r,n.g,n.b,n.a):lc(n.r,n.g,n.b)},[t]),u=oc(e||t,t),f=sc(u.r,u.g,u.b),[p,m]=(0,d.useState)(f.h),[h,g]=(0,d.useState)(f.s),[_,v]=(0,d.useState)(f.v),[y,b]=(0,d.useState)(u.a),[x,S]=(0,d.useState)(()=>l(e||t));(0,d.useEffect)(()=>{let n=oc(e||t,t),r=sc(n.r,n.g,n.b);m(r.h),g(r.s),v(r.v),b(n.a),S(l(e||t))},[e,t,l]);let C=(0,d.useRef)(null),w=(0,d.useRef)(null),T=(0,d.useRef)(null),E=(0,d.useRef)(null);(0,d.useEffect)(()=>{if(a&&C.current)try{let e=C.current.getBoundingClientRect(),t=window.innerWidth||document.documentElement.clientWidth||360;e.left+230>t-10||e.right>t-40?c(!0):c(!1)}catch{c(!1)}},[a]),(0,d.useEffect)(()=>{if(!a)return;let e=e=>{C.current&&!C.current.contains(e.target)&&o(!1)},t=e=>{e.key===`Escape`&&o(!1)};return window.addEventListener(`mousedown`,e),window.addEventListener(`touchstart`,e),window.addEventListener(`keydown`,t),()=>{window.removeEventListener(`mousedown`,e),window.removeEventListener(`touchstart`,e),window.removeEventListener(`keydown`,t)}},[a]);let D=cc(p,h,_),O=uc(D.r,D.g,D.b,y),k=lc(D.r,D.g,D.b),A=Math.round(y*100),j=(0,d.useCallback)((e,t,r,i)=>{let a=cc(e,t,r),o=uc(a.r,a.g,a.b,i);S(i<1?o:lc(a.r,a.g,a.b)),n?.(o)},[n]);(0,d.useEffect)(()=>{if(!a||!w.current)return;let e=w.current,t=e.getContext(`2d`);if(!t)return;let n=e.width,r=e.height;t.fillStyle=`hsl(${p}, 100%, 50%)`,t.fillRect(0,0,n,r);let i=t.createLinearGradient(0,0,n,0);i.addColorStop(0,`rgba(255, 255, 255, 1)`),i.addColorStop(1,`rgba(255, 255, 255, 0)`),t.fillStyle=i,t.fillRect(0,0,n,r);let o=t.createLinearGradient(0,0,0,r);o.addColorStop(0,`rgba(0, 0, 0, 0)`),o.addColorStop(1,`rgba(0, 0, 0, 1)`),t.fillStyle=o,t.fillRect(0,0,n,r);let s=ac(h*n,6,n-6),c=ac((1-_)*r,6,r-6);t.beginPath(),t.arc(s,c,6,0,Math.PI*2),t.strokeStyle=`#ffffff`,t.lineWidth=2.5,t.stroke(),t.beginPath(),t.arc(s,c,5,0,Math.PI*2),t.strokeStyle=`rgba(0, 0, 0, 0.4)`,t.lineWidth=1,t.stroke()},[a,p,h,_]),(0,d.useEffect)(()=>{if(!a||!T.current)return;let e=T.current,t=e.getContext(`2d`);if(!t)return;let n=e.width,r=e.height,i=t.createLinearGradient(0,0,n,0);i.addColorStop(0,`#ff0000`),i.addColorStop(.17,`#ffff00`),i.addColorStop(.33,`#00ff00`),i.addColorStop(.5,`#00ffff`),i.addColorStop(.67,`#0000ff`),i.addColorStop(.83,`#ff00ff`),i.addColorStop(1,`#ff0000`),t.fillStyle=i,t.fillRect(0,0,n,r);let o=ac(p/360*n,5,n-5);t.beginPath(),t.arc(o,r/2,5,0,Math.PI*2),t.fillStyle=`#ffffff`,t.fill(),t.strokeStyle=`rgba(0, 0, 0, 0.4)`,t.lineWidth=1.5,t.stroke()},[a,p]),(0,d.useEffect)(()=>{if(!a||!E.current)return;let e=E.current,t=e.getContext(`2d`);if(!t)return;let n=e.width,r=e.height;t.clearRect(0,0,n,r);for(let e=0;e<n;e+=4)for(let n=0;n<r;n+=4)t.fillStyle=(Math.floor(e/4)+Math.floor(n/4))%2==0?`#eeeeee`:`#bbbbbb`,t.fillRect(e,n,4,4);let i=t.createLinearGradient(0,0,n,0);i.addColorStop(0,`rgba(${D.r}, ${D.g}, ${D.b}, 0)`),i.addColorStop(1,`rgba(${D.r}, ${D.g}, ${D.b}, 1)`),t.fillStyle=i,t.fillRect(0,0,n,r);let o=ac(y*n,5,n-5);t.beginPath(),t.arc(o,r/2,5,0,Math.PI*2),t.fillStyle=`#ffffff`,t.fill(),t.strokeStyle=`rgba(0, 0, 0, 0.4)`,t.lineWidth=1.5,t.stroke()},[a,y,D.r,D.g,D.b]);let M=e=>{if(!w.current)return;let t=w.current.getBoundingClientRect(),n=ac((e.clientX-t.left)/t.width,0,1),r=ac((e.clientY-t.top)/t.height,0,1),i=n,a=1-r;g(i),v(a),j(p,i,a,y)},N=e=>{e.preventDefault(),M(e);let t=e=>M(e),n=()=>{window.removeEventListener(`pointermove`,t),window.removeEventListener(`pointerup`,n)};window.addEventListener(`pointermove`,t),window.addEventListener(`pointerup`,n)},P=e=>{if(!T.current)return;let t=T.current.getBoundingClientRect(),n=ac((e.clientX-t.left)/t.width,0,1),r=Math.round(n*360);m(r),j(r,h,_,y)},ee=e=>{e.preventDefault(),P(e);let t=e=>P(e),n=()=>{window.removeEventListener(`pointermove`,t),window.removeEventListener(`pointerup`,n)};window.addEventListener(`pointermove`,t),window.addEventListener(`pointerup`,n)},F=e=>{if(!E.current)return;let t=E.current.getBoundingClientRect(),n=ac((e.clientX-t.left)/t.width,0,1),r=Math.round(n*100)/100;b(r),j(p,h,_,r)},te=e=>{e.preventDefault(),F(e);let t=e=>F(e),n=()=>{window.removeEventListener(`pointermove`,t),window.removeEventListener(`pointerup`,n)};window.addEventListener(`pointermove`,t),window.addEventListener(`pointerup`,n)},I=async()=>{if(typeof window<`u`&&window.EyeDropper)try{let e=await new window.EyeDropper().open();if(e&&e.sRGBHex){let t=oc(e.sRGBHex),n=sc(t.r,t.g,t.b);m(n.h),g(n.s),v(n.v),b(1),j(n.h,n.s,n.v,1)}}catch{}},[ne,re]=(0,d.useState)(k);(0,d.useEffect)(()=>{re(k)},[k]);let ie=e=>{re(e);let t=e.trim();if(/^#?([0-9a-fA-F]{3}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})$/.test(t)){let e=oc(t.startsWith(`#`)?t:`#${t}`),n=sc(e.r,e.g,e.b);m(n.h),g(n.s),v(n.v);let r=t.length===8||t.length===9?e.a:y;b(r),j(n.h,n.s,n.v,r)}},L=()=>{re(k)},ae=e=>{let t=parseInt(e.replace(/\D/g,``),10);if(!isNaN(t)){let e=ac(t/100,0,1);b(e),j(p,h,_,e)}},oe=e=>{S(e);let t=oc(e),r=sc(t.r,t.g,t.b);m(r.h),g(r.s),v(r.v),b(t.a),n?.(e)},se=()=>{S(l(e||t))},R=e=>{let t=oc(e),n=sc(t.r,t.g,t.b);m(n.h),g(n.s),v(n.v),j(n.h,n.s,n.v,y)};return(0,q.jsxs)(`div`,{className:`framer-color-picker-wrap ${s?`align-right`:``}`,ref:C,children:[(0,q.jsxs)(`div`,{className:`framer-color-picker-row`,children:[(0,q.jsx)(`button`,{type:`button`,className:`framer-color-swatch-btn ${a?`open`:``}`,onClick:()=>!r&&o(e=>!e),disabled:r,title:i,"aria-label":i,"aria-expanded":a,children:(0,q.jsx)(`svg`,{width:`24`,height:`24`,viewBox:`0 0 28 28`,className:`framer-color-swatch-inner`,children:(0,q.jsx)(`circle`,{cx:`14`,cy:`14`,r:`14`,fill:O})})}),(0,q.jsx)(`input`,{type:`text`,className:`framer-color-text-input`,value:x,onChange:e=>oe(e.target.value),onBlur:se,disabled:r,placeholder:`#ffffff`,"aria-label":`${i} value`,spellCheck:!1,autoComplete:`off`,autoCorrect:`off`,autoCapitalize:`off`}),(0,q.jsxs)(`div`,{className:`framer-color-opacity-badge`,title:`Opacity`,children:[A,`%`]})]}),a&&(0,q.jsxs)(`div`,{className:`framer-color-popover ${s?`align-right`:``}`,role:`dialog`,"aria-modal":`true`,children:[(0,q.jsx)(`div`,{className:`framer-sv-canvas-wrap`,onPointerDown:N,children:(0,q.jsx)(`canvas`,{ref:w,width:260,height:130,className:`framer-sv-canvas`})}),(0,q.jsxs)(`div`,{className:`framer-color-sliders-row`,children:[typeof window<`u`&&`EyeDropper`in window&&(0,q.jsx)(`button`,{type:`button`,className:`framer-color-dropper-btn`,onClick:I,title:`Sample color from screen`,"aria-label":`Pick color from screen`,children:(0,q.jsx)(dc,{size:14})}),(0,q.jsx)(`div`,{className:`framer-color-circle-preview`,title:`Color: ${O}`,children:(0,q.jsx)(`svg`,{width:`28`,height:`28`,viewBox:`0 0 28 28`,className:`framer-color-circle-preview-svg`,children:(0,q.jsx)(`circle`,{cx:`14`,cy:`14`,r:`14`,fill:O})})}),(0,q.jsxs)(`div`,{className:`framer-color-sliders-col`,children:[(0,q.jsx)(`div`,{className:`framer-slider-canvas-wrap`,onPointerDown:ee,children:(0,q.jsx)(`canvas`,{ref:T,width:200,height:12,className:`framer-slider-canvas`})}),(0,q.jsx)(`div`,{className:`framer-slider-canvas-wrap`,onPointerDown:te,children:(0,q.jsx)(`canvas`,{ref:E,width:200,height:12,className:`framer-slider-canvas`})})]})]}),(0,q.jsxs)(`div`,{className:`framer-color-details-row`,children:[(0,q.jsx)(`span`,{className:`framer-color-format-label`,children:`HEX`}),(0,q.jsx)(`input`,{type:`text`,className:`framer-color-hex-subinput`,value:ne,onChange:e=>ie(e.target.value),onBlur:L,placeholder:`#FFFFFF`,"aria-label":`Hex color`,spellCheck:!1,autoComplete:`off`,autoCorrect:`off`,autoCapitalize:`off`}),(0,q.jsx)(`input`,{type:`text`,className:`framer-color-alpha-subinput`,value:`${A}%`,onChange:e=>ae(e.target.value),placeholder:`100%`,"aria-label":`Opacity percentage`,spellCheck:!1,autoComplete:`off`})]}),(0,q.jsx)(`div`,{className:`framer-color-palette`,children:Q.map(e=>(0,q.jsx)(`button`,{type:`button`,className:`framer-palette-btn`,onClick:()=>R(e),title:e,"aria-label":`Select ${e}`,children:(0,q.jsx)(`svg`,{width:`20`,height:`20`,viewBox:`0 0 20 20`,className:`framer-palette-swatch`,children:(0,q.jsx)(`circle`,{cx:`10`,cy:`10`,r:`10`,fill:e})})},e))})]})]})}var pc=[{label:`Sunset Violet`,value:`linear-gradient(135deg, #6366f1 0%, #a855f7 100%)`,start:`#6366f1`,end:`#a855f7`,angle:135},{label:`Coral Sunrise`,value:`linear-gradient(135deg, #f97316 0%, #ec4899 100%)`,start:`#f97316`,end:`#ec4899`,angle:135},{label:`Emerald Mint`,value:`linear-gradient(135deg, #10b981 0%, #059669 100%)`,start:`#10b981`,end:`#059669`,angle:135},{label:`Cyber Cyan`,value:`linear-gradient(135deg, #06b6d4 0%, #3b82f6 100%)`,start:`#06b6d4`,end:`#3b82f6`,angle:135},{label:`Midnight Glow`,value:`linear-gradient(135deg, #1e1e24 0%, #4c1d95 100%)`,start:`#1e1e24`,end:`#4c1d95`,angle:135},{label:`Ruby Amber`,value:`linear-gradient(135deg, #ef4444 0%, #f59e0b 100%)`,start:`#ef4444`,end:`#f59e0b`,angle:135},{label:`Neon Berry`,value:`linear-gradient(135deg, #ec4899 0%, #8b5cf6 100%)`,start:`#ec4899`,end:`#8b5cf6`,angle:135},{label:`Slate Minimal`,value:`linear-gradient(135deg, #334155 0%, #0f172a 100%)`,start:`#334155`,end:`#0f172a`,angle:135}];function mc(e){let t={start:`#6366f1`,end:`#a855f7`,angle:135};if(!e||typeof e!=`string`)return t;let n=135,r=e.match(/(\d+)deg/);r&&(n=parseInt(r[1],10)||135);let i=e.match(/(#[0-9a-fA-F]{3,8}|rgba?\([^)]+\))/g);return i&&i.length>=2?{start:i[0],end:i[1],angle:n}:i&&i.length===1?{start:i[0],end:i[0],angle:n}:t}function hc({value:e,onChange:t}){let n=mc(e),[r,i]=(0,d.useState)(n.start),[a,o]=(0,d.useState)(n.end),[s,c]=(0,d.useState)(n.angle),[l,u]=(0,d.useState)(e||`linear-gradient(135deg, #6366f1 0%, #a855f7 100%)`),f=(0,d.useRef)(null);(0,d.useEffect)(()=>{f.current&&(f.current.style.background=l)},[l]),(0,d.useEffect)(()=>{if(e&&e!==l){u(e);let t=mc(e);i(t.start),o(t.end),c(t.angle)}},[e]);function p(e){i(e);let n=`linear-gradient(${s}deg, ${e} 0%, ${a} 100%)`;u(n),t(n)}function m(e){o(e);let n=`linear-gradient(${s}deg, ${r} 0%, ${e} 100%)`;u(n),t(n)}function h(e){c(e);let n=`linear-gradient(${e}deg, ${r} 0%, ${a} 100%)`;u(n),t(n)}function g(e){i(e.start),o(e.end),c(e.angle),u(e.value),t(e.value)}function _(e){u(e),t(e);let n=mc(e);i(n.start),o(n.end),c(n.angle)}return(0,q.jsxs)(`div`,{className:`cf-gradient-picker-box`,children:[(0,q.jsxs)(`div`,{className:`cf-gradient-preview-wrap`,children:[(0,q.jsx)(`div`,{ref:f,className:`cf-gradient-preview-bar`}),(0,q.jsxs)(`span`,{className:`cf-gradient-angle-badge`,children:[s,`°`]})]}),(0,q.jsx)(`div`,{className:`cf-gradient-presets-label`,children:`Preset Gradients`}),(0,q.jsx)(`div`,{className:`cf-gradient-presets-grid`,children:pc.map(e=>{let t=l.trim()===e.value.trim();return(0,q.jsxs)(`button`,{type:`button`,className:`cf-gradient-preset-pill ${t?`active`:``}`,onClick:()=>g(e),title:e.label,children:[(0,q.jsx)(`span`,{className:`cf-gradient-preset-dot`,children:(0,q.jsxs)(`svg`,{width:`12`,height:`12`,viewBox:`0 0 12 12`,children:[(0,q.jsx)(`defs`,{children:(0,q.jsxs)(`linearGradient`,{id:`dot-${e.label.replace(/\s+/g,``)}`,x1:`0%`,y1:`0%`,x2:`100%`,y2:`100%`,children:[(0,q.jsx)(`stop`,{offset:`0%`,stopColor:e.start}),(0,q.jsx)(`stop`,{offset:`100%`,stopColor:e.end})]})}),(0,q.jsx)(`circle`,{cx:`6`,cy:`6`,r:`6`,fill:`url(#dot-${e.label.replace(/\s+/g,``)})`})]})}),(0,q.jsx)(`span`,{children:e.label})]},e.label)})}),(0,q.jsxs)(`div`,{className:`cf-field-grid`,children:[(0,q.jsx)(J,{label:`Start Color`,hint:`Initial gradient tone`,children:(0,q.jsx)(fc,{value:r,fallback:`#6366f1`,onChange:p,ariaLabel:`Gradient Start Color`})}),(0,q.jsx)(J,{label:`End Color`,hint:`Final gradient tone`,children:(0,q.jsx)(fc,{value:a,fallback:`#a855f7`,onChange:m,ariaLabel:`Gradient End Color`})})]}),(0,q.jsx)(J,{label:`Gradient Direction / Angle`,hint:`Rotate the gradient light angle`,children:(0,q.jsxs)(`div`,{className:`cf-flex-col-gap-8`,children:[(0,q.jsxs)(`div`,{className:`cf-flex-center-gap-10`,children:[(0,q.jsx)(`input`,{type:`range`,min:0,max:360,step:5,value:s,className:`cf-range-input`,onChange:e=>h(Number(e.target.value))}),(0,q.jsxs)(`span`,{className:`cf-badge-value`,children:[s,`°`]})]}),(0,q.jsx)(`div`,{className:`cf-angle-presets`,children:[{label:`90° (→)`,val:90},{label:`135° (↘)`,val:135},{label:`180° (↓)`,val:180},{label:`270° (←)`,val:270}].map(({label:e,val:t})=>(0,q.jsx)(`button`,{type:`button`,className:`cf-angle-preset-pill ${s===t?`active`:``}`,onClick:()=>h(t),children:e},t))})]})}),(0,q.jsx)(J,{label:`Custom CSS Gradient Rule`,hint:`Paste or fine-tune exact CSS gradient string`,children:(0,q.jsx)(`input`,{type:`text`,className:`cf-input`,value:l,onChange:e=>_(e.target.value),placeholder:`linear-gradient(135deg, #6366f1 0%, #a855f7 100%)`})})]})}var gc=`chat_bubbles_analytics_data_v1`;try{typeof window<`u`&&localStorage.removeItem(gc)}catch{}function _c(e){return e>=1e6?(e/1e6).toFixed(1).replace(/\.0$/,``)+`M`:e>=1e3?(e/1e3).toFixed(0)+`k`:e.toString()}function vc(e){return e.toLocaleString()}var yc=e=>{let t=[`Sun`,`Mon`,`Tue`,`Wed`,`Thu`,`Fri`,`Sat`],n=[`Jan`,`Feb`,`Mar`,`Apr`,`May`,`Jun`,`Jul`,`Aug`,`Sep`,`Oct`,`Nov`,`Dec`];if(e===`Last 7 days`){let e=[],n=new Date;for(let r=6;r>=0;r--){let i=new Date;i.setDate(n.getDate()-r),e.push(t[i.getDay()])}return e}if(e===`Last 30 days`){let e=[],t=new Date;for(let n=11;n>=0;n--){let r=new Date;r.setDate(t.getDate()-Math.round(n*2.5)),e.push(String(r.getDate()))}return e}if(e===`Last 6 months`){let e=[],t=new Date;for(let r=5;r>=0;r--){let i=new Date;i.setMonth(t.getMonth()-r),e.push(n[i.getMonth()].substring(0,3))}return e}return[]},bc=[`Last 7 days`,`Last 30 days`,`Last 6 months`];function xc({enabled:e,onToggleEnabled:t,channels:n,onNavigateToSettings:r,widgetId:i}){let[a,o]=(0,d.useState)(`Last 7 days`),[s,c]=(0,d.useState)(!1),[l,u]=(0,d.useState)(0),[f,p]=(0,d.useState)(null),m=(0,d.useRef)(null);(0,d.useEffect)(()=>{function e(){u(e=>e+1)}return window.addEventListener(`chat_bubbles_analytics_updated`,e),window.addEventListener(`chat_bubbles_interaction`,e),window.addEventListener(`chat_bubbles_view`,e),window.addEventListener(`storage`,e),()=>{window.removeEventListener(`chat_bubbles_analytics_updated`,e),window.removeEventListener(`chat_bubbles_interaction`,e),window.removeEventListener(`chat_bubbles_view`,e),window.removeEventListener(`storage`,e)}},[]),(0,d.useEffect)(()=>{if(!e)return;let t=setInterval(()=>{u(e=>e+1)},6e3);return()=>clearInterval(t)},[e]);let h=(0,d.useMemo)(()=>{let e=yc(a),t=n.filter(e=>e.enabled&&e.value.trim()!==``),r=t.length>0?t:n.slice(0,4);return{views:0,clicks:0,convRate:`0.0%`,bars:e.map(e=>({label:e,value:0,percentage:0,highlight:!1})),channelStats:r.map(e=>({id:e.id,label:e.label,color:e.color,clicks:0,percentage:0})),maxY:10,midY:5,isRealData:!0}},[a,n]);(0,d.useEffect)(()=>{let e=!0;async function t(){try{let t=await fi().catch(()=>({siteId:``})),r=i||t?.siteId||`chat-bubbles-default`,o=new URLSearchParams({period:a}),s=Ei(`/api/analytics/${encodeURIComponent(r)}?${o.toString()}`),c=await fetch(s),l=null;if(c.ok&&(l=await c.json()),(!l||!l.views&&!l.clicks)&&t?.siteId&&t.siteId!==r){let e=Ei(`/api/analytics/${encodeURIComponent(t.siteId)}?${o.toString()}`),n=await fetch(e).catch(()=>null);if(n&&n.ok){let e=await n.json();e&&(Number(e.views)>0||Number(e.clicks)>0)&&(l=e)}}if(!e)return;if(l){let e=yc(a),t=Array.isArray(l.bars)&&l.bars.length>0?l.bars:[],r=e.map((e,n)=>{let r=t[n];return{label:e,value:Number(r?.value||0),percentage:Number(r?.percentage||0),highlight:!!r?.highlight}}),i=Math.max(...r.map(e=>e.value),10),o=Math.ceil(i*1.15),s=Math.round(o/2),c=n.filter(e=>e.enabled&&e.value.trim()!==``),u=c.length>0?c:n.slice(0,4),d=Number(l.clicks||0),f=l.channels||{},m=u.map(e=>{let t=Number(f[e.id]||0);return{id:e.id,label:e.label,color:e.color,clicks:t,percentage:d>0?Math.round(t/d*100):0}});p({views:Number(l.views||0),clicks:Number(l.clicks||0),convRate:String(l.convRate||`0.0%`),bars:r,channelStats:m,maxY:o,midY:s,isRealData:!0})}}catch{}}return t(),()=>{e=!1}},[a,n,l]),(0,d.useEffect)(()=>{function e(e){m.current&&!m.current.contains(e.target)&&c(!1)}if(s)return document.addEventListener(`mousedown`,e),()=>document.removeEventListener(`mousedown`,e)},[s]);let g=(0,d.useMemo)(()=>f||h,[f,h]);return e?(0,q.jsxs)(`div`,{className:`cf-analytics-page`,children:[(0,q.jsxs)(`div`,{className:`cf-analytics-header`,children:[(0,q.jsxs)(`div`,{className:`cf-analytics-title-group`,children:[(0,q.jsx)(`h3`,{className:`cf-analytics-title`,children:`Widget Analytics`}),(0,q.jsx)(`span`,{className:`cf-analytics-subtitle`,children:`Real-time visitor interactions & conversion counts`})]}),(0,q.jsxs)(`div`,{className:`cf-analytics-filter`,ref:m,children:[(0,q.jsxs)(`button`,{type:`button`,className:`cf-analytics-dropdown-btn`,onClick:()=>c(!s),"aria-expanded":s,"aria-label":`Select analytics reporting period`,children:[(0,q.jsx)(`span`,{children:a}),(0,q.jsx)(Bi,{size:14,className:`cf-analytics-dropdown-chevron`+(s?` is-open`:``)})]}),s&&(0,q.jsx)(`ul`,{className:`cf-analytics-dropdown-menu`,children:bc.map(e=>(0,q.jsx)(`li`,{className:`cf-analytics-dropdown-item`+(e===a?` is-active`:``),onClick:()=>{o(e),c(!1)},children:e},e))})]})]}),(0,q.jsxs)(`div`,{className:`cf-analytics-kpi-grid`,children:[(0,q.jsxs)(`div`,{className:`cf-analytics-kpi-card`,children:[(0,q.jsxs)(`div`,{className:`cf-analytics-kpi-header`,children:[(0,q.jsx)(`span`,{className:`cf-analytics-kpi-label`,children:`Views`}),(0,q.jsx)(`span`,{className:`cf-analytics-kpi-icon cf-kpi-views`,children:(0,q.jsx)(Yi,{size:12})})]}),(0,q.jsx)(`div`,{className:`cf-analytics-kpi-val`,children:_c(g.views)}),(0,q.jsx)(`div`,{className:`cf-analytics-kpi-trend`,children:(0,q.jsx)(`span`,{children:`Total impressions`})})]}),(0,q.jsxs)(`div`,{className:`cf-analytics-kpi-card`,children:[(0,q.jsxs)(`div`,{className:`cf-analytics-kpi-header`,children:[(0,q.jsx)(`span`,{className:`cf-analytics-kpi-label`,children:`Clicks`}),(0,q.jsx)(`span`,{className:`cf-analytics-kpi-icon cf-kpi-clicks`,children:(0,q.jsx)(Xi,{size:12})})]}),(0,q.jsx)(`div`,{className:`cf-analytics-kpi-val`,children:vc(g.clicks)}),(0,q.jsx)(`div`,{className:`cf-analytics-kpi-trend`,children:(0,q.jsx)(`span`,{children:`Channel clicks`})})]}),(0,q.jsxs)(`div`,{className:`cf-analytics-kpi-card`,children:[(0,q.jsxs)(`div`,{className:`cf-analytics-kpi-header`,children:[(0,q.jsx)(`span`,{className:`cf-analytics-kpi-label`,children:`Conv. Rate`}),(0,q.jsx)(`span`,{className:`cf-analytics-kpi-icon cf-kpi-rate`,children:(0,q.jsx)(Ji,{size:12})})]}),(0,q.jsx)(`div`,{className:`cf-analytics-kpi-val`,children:g.convRate}),(0,q.jsx)(`div`,{className:`cf-analytics-kpi-trend`,children:(0,q.jsx)(`span`,{children:`Conversion rate`})})]})]}),(0,q.jsxs)(`div`,{className:`cf-analytics-chart-card`,children:[(0,q.jsxs)(`div`,{className:`cf-analytics-chart-header`,children:[(0,q.jsxs)(`div`,{className:`cf-analytics-chart-title`,children:[`Clicks over the `,a.toLowerCase()]}),(0,q.jsx)(`span`,{className:`cf-analytics-chart-badge`,children:`Daily Volume`})]}),(0,q.jsxs)(`div`,{className:`cf-analytics-chart-wrapper`,children:[(0,q.jsxs)(`div`,{className:`cf-chart-y-axis`,children:[(0,q.jsx)(`span`,{children:_c(g.maxY)}),(0,q.jsx)(`span`,{children:_c(g.midY)}),(0,q.jsx)(`span`,{children:`0`})]}),(0,q.jsxs)(`div`,{className:`cf-chart-stage`,children:[(0,q.jsx)(`div`,{className:`cf-chart-grid-line cf-grid-top`}),(0,q.jsx)(`div`,{className:`cf-chart-grid-line cf-grid-mid`}),(0,q.jsx)(`div`,{className:`cf-chart-grid-line cf-grid-bottom`}),(0,q.jsx)(`div`,{className:`cf-chart-bars-track`,children:g.bars.map((e,t)=>{let n={height:`${e.percentage}%`};return(0,q.jsx)(`div`,{className:`cf-chart-bar-column`,children:(0,q.jsx)(`div`,{className:`cf-chart-bar-fill`+(e.highlight?` is-highlight`:``),style:n,title:`${e.label}: ${vc(e.value)} clicks`,children:(0,q.jsx)(`div`,{className:`cf-chart-bar-tooltip`,children:vc(e.value)})})},t)})}),(0,q.jsx)(`div`,{className:`cf-chart-x-axis`,children:g.bars.map((e,t)=>(0,q.jsx)(`div`,{className:`cf-chart-x-label`,children:e.label},t))})]})]})]}),(0,q.jsxs)(`div`,{className:`cf-analytics-channels-card`,children:[(0,q.jsxs)(`div`,{className:`cf-analytics-channels-header`,children:[(0,q.jsx)(`div`,{className:`cf-analytics-channels-title`,children:`Channel Breakdown`}),(0,q.jsx)(`div`,{className:`cf-analytics-channels-desc`,children:`Conversion distribution by communication channel`})]}),(0,q.jsx)(`div`,{className:`cf-analytics-channels-list`,children:g.channelStats.map(e=>{let t={width:`${e.percentage}%`,backgroundColor:e.color},n={backgroundColor:e.color};return(0,q.jsxs)(`div`,{className:`cf-channel-stat-row`,children:[(0,q.jsxs)(`div`,{className:`cf-channel-stat-meta`,children:[(0,q.jsxs)(`div`,{className:`cf-channel-stat-brand`,children:[(0,q.jsx)(`span`,{className:`cf-channel-stat-badge`,style:n,children:ui(e.id,16)}),(0,q.jsx)(`span`,{className:`cf-channel-stat-name`,children:e.label})]}),(0,q.jsxs)(`div`,{className:`cf-channel-stat-count`,children:[(0,q.jsxs)(`span`,{className:`cf-channel-stat-clicks`,children:[vc(e.clicks),` clicks`]}),(0,q.jsxs)(`span`,{className:`cf-channel-stat-pct`,children:[e.percentage,`%`]})]})]}),(0,q.jsx)(`div`,{className:`cf-channel-stat-bar-track`,children:(0,q.jsx)(`div`,{className:`cf-channel-stat-bar-fill`,style:t})})]},e.id)})})]})]}):(0,q.jsx)(`div`,{className:`cf-analytics-page`,children:(0,q.jsxs)(`div`,{className:`cf-analytics-disabled-state`,children:[(0,q.jsx)(`div`,{className:`cf-analytics-disabled-icon`,children:(0,q.jsx)(Zi,{size:28})}),(0,q.jsx)(`h3`,{className:`cf-analytics-disabled-title`,children:`Analytics is disabled`}),(0,q.jsxs)(`p`,{className:`cf-analytics-disabled-desc`,children:[`Turn on Widget Analytics in `,(0,q.jsx)(`strong`,{children:`Settings`}),` to track views and clicks.`]}),(0,q.jsxs)(`div`,{className:`cf-analytics-disabled-actions`,children:[(0,q.jsxs)(`button`,{type:`button`,className:`primary-cta`,onClick:()=>t(!0),children:[(0,q.jsx)(zi,{size:14}),(0,q.jsx)(`span`,{children:`Enable Widget Analytics`})]}),(0,q.jsx)(`button`,{type:`button`,className:`secondary-cta`,onClick:r,children:`Go to Settings`})]})]})})}var Sc=null;function Cc(){if(typeof window>`u`)return null;let e=window.AudioContext||window.webkitAudioContext;if(!e)return null;if(!Sc||Sc.state===`closed`)try{Sc=new e}catch{return null}return Sc}function wc(){try{let e=Cc();if(!e)return!1;let t=()=>{let t=e.currentTime,n=e.createOscillator(),r=e.createGain();n.type=`sine`,n.frequency.setValueAtTime(587.33,t),r.gain.setValueAtTime(1e-4,t),r.gain.linearRampToValueAtTime(.24,t+.015),r.gain.exponentialRampToValueAtTime(1e-4,t+.22),n.connect(r),r.connect(e.destination),n.start(t),n.stop(t+.22);let i=e.createOscillator(),a=e.createGain();i.type=`sine`,i.frequency.setValueAtTime(880,t+.08),a.gain.setValueAtTime(1e-4,t+.08),a.gain.linearRampToValueAtTime(.28,t+.095),a.gain.exponentialRampToValueAtTime(1e-4,t+.4),i.connect(a),a.connect(e.destination),i.start(t+.08),i.stop(t+.4)};return e.state===`suspended`?e.resume().then(()=>{e.state===`running`&&t()}).catch(()=>{}):t(),!0}catch{return!1}}var Tc=Jr,Ec={whatsapp:{label:`WhatsApp Number`,placeholder:`+1 234 567 8900`,hint:`Include country code (e.g. +1 for US).`},messenger:{label:`Messenger Username / Page`,placeholder:`username or page name`,hint:`Facebook page username or profile handle without @.`},instagram:{label:`Instagram Username`,placeholder:`username`,hint:`Instagram account handle without @.`},telegram:{label:`Telegram Username`,placeholder:`username`,hint:`Telegram handle or public channel without @.`},tiktok:{label:`TikTok Username`,placeholder:`username`,hint:`TikTok handle without @.`},wechat:{label:`WeChat ID / QR URL`,placeholder:`wechat_id or https://...`,hint:`WeChat ID or full profile URL.`},viber:{label:`Viber Number`,placeholder:`+1 234 567 8900`,hint:`Phone number with country code.`},line:{label:`LINE ID`,placeholder:`line_id`,hint:`Official or personal LINE ID.`},signal:{label:`Signal ID / Link`,placeholder:`username or link`,hint:`Signal profile URL or identifier.`},phone:{label:`Phone Number`,placeholder:`+1 234 567 8900`,hint:`Direct dial phone number.`},sms:{label:`SMS Phone Number`,placeholder:`+1 234 567 8900`,hint:`Mobile number for SMS text messages.`},email:{label:`Email Address`,placeholder:`hello@yourcompany.com`,hint:`Contact email for visitors.`},discord:{label:`Discord Invite / Server`,placeholder:`https://discord.gg/yourserver or invite code`,hint:`Discord invite code or full invite URL.`},slack:{label:`Slack Workspace / Channel`,placeholder:`https://join.slack.com/t/...`,hint:`Public Slack community invite link or workspace URL.`},teams:{label:`Microsoft Teams User / Link`,placeholder:`email@company.com or meeting link`,hint:`User email or Teams direct conversation link.`},x:{label:`X (Twitter) Handle`,placeholder:`username`,hint:`X handle without @ or profile URL.`},linkedin:{label:`LinkedIn Profile / Company`,placeholder:`in/username or company/name`,hint:`Profile slug, company path, or full LinkedIn URL.`},maps:{label:`Google Maps Address / Link`,placeholder:`1600 Amphitheatre Pkwy or Google Maps URL`,hint:`Store address or Google Maps location link.`},custom:{label:`Custom URL Link`,placeholder:`https://yourwebsite.com/chat`,hint:`Any valid web URL or custom protocol.`}},Dc={},Oc=e=>e?(Dc[e]||(Dc[e]=rc(e).catch(e=>(console.error(`[ChatBubbles] Failed to load Stripe.js:`,e),null))),Dc[e]):null;function kc(){let[e,t]=(0,d.useState)(ti()),[n,r]=(0,d.useState)(()=>{try{localStorage.removeItem(`chatfic_theme_preference`),localStorage.removeItem(`chatfic_theme_pref_v2`),localStorage.removeItem(`chatfic_theme_pref_v3`);let e=localStorage.getItem(`chatfic_theme_pref_v4`);if(e===`light`||e===`dark`||e===`auto`)return e}catch{}return`auto`}),[i,a]=(0,d.useState)(()=>{if(typeof document<`u`){let e=document.body?.getAttribute(`data-framer-theme`);if(e===`light`||e===`dark`)return e;let t=document.documentElement?.getAttribute(`data-framer-theme`);if(t===`light`||t===`dark`)return t}return`dark`}),[o,s]=(0,d.useState)(`home`),[c,l]=(0,d.useState)(`channels`),[u,f]=(0,d.useState)(!1),[p,m]=(0,d.useState)(!1),[h,g]=(0,d.useState)(null);(0,d.useEffect)(()=>{if(!h)return;let e=setTimeout(()=>{g(null)},5e3);return()=>clearTimeout(e)},[h]),(0,d.useEffect)(()=>{o===`analytics`&&e.enableAnalytics===!1&&s(`home`)},[o,e.enableAnalytics]);let _=Io(),v=(0,d.useCallback)(e=>{g({type:e.type===`Success`?`success`:`error`,text:e.message});try{typeof U.notify==`function`&&U.notify(e.message)}catch{}},[]),y=Lo({notify:v,authEmail:_.user?.email}),[b,x]=(0,d.useState)(`profile`),[S,C]=(0,d.useState)(0),[w,T]=(0,d.useState)(null),[E,D]=(0,d.useState)(null),[O,k]=(0,d.useState)(Date.now()),A=(0,d.useRef)(!1),j=(0,d.useMemo)(()=>{if(y.planDetails?.trialEndsAt){let e=String(y.planDetails.trialEndsAt).trim(),t=!e.endsWith(`Z`)&&!e.includes(`+`)?e.replace(` `,`T`)+`Z`:e,n=new Date(t).getTime();if(!isNaN(n)&&n>0)return n}return typeof y.planDetails?.trialSecondsRemaining==`number`&&y.planDetails.trialSecondsRemaining>0?(y.planDetails?.fetchTimestamp||Date.now())+y.planDetails.trialSecondsRemaining*1e3:null},[y.planDetails?.trialEndsAt,y.planDetails?.trialSecondsRemaining,y.planDetails?.fetchTimestamp]),M=(0,d.useMemo)(()=>y.isPaid&&(!y.planDetails||y.planDetails.plan===`lifetime`||y.planDetails.status===`active`||y.planDetails.status===`trialing`||y.planDetails.status===`paid`||y.planDetails.status===`Scheduled to cancel`),[y.isPaid,y.planDetails]),N=_.isLoggedIn&&M,P=(0,d.useMemo)(()=>!!(N&&(y.planDetails?.isTrial||y.planDetails?.plan===`trial`||y.planDetails?.status===`trialing`)&&(!j||j>O)),[N,y.planDetails,j,O]);(0,d.useEffect)(()=>{if(!_.isLoggedIn||!y.planDetails?.isTrial&&y.planDetails?.plan!==`trial`&&y.planDetails?.status!==`trialing`)return;k(Date.now());let e=window.setInterval(()=>{let e=Date.now();k(e),j&&j<=e&&(T(`expired`),y.refreshSubscriptionStatus())},1e3);return()=>window.clearInterval(e)},[_.isLoggedIn,y.planDetails?.isTrial,y.planDetails?.plan,y.planDetails?.status,j,y.refreshSubscriptionStatus]);let ee=(0,d.useRef)(null);(0,d.useEffect)(()=>{hi(N,P,Ti),ee.current?(ee.current.hasActiveAccess!==N||ee.current.isTrialActive!==P)&&(ee.current={hasActiveAccess:N,isTrialActive:P},e&&Si(e,!0)):(ee.current={hasActiveAccess:N,isTrialActive:P},e&&Si(e,!0))},[N,P,e]),(0,d.useEffect)(()=>{if(y.isCheckingPayment)return;let t=!0;return(async()=>{try{if(!(typeof U.isAllowedTo!=`function`||await U.isAllowedTo(`CodeFile.setFileContent`)))return;let n=(await U.getCodeFiles()).filter(e=>e.name.toLowerCase().startsWith(`chatbubble`)||e.name.toLowerCase().startsWith(`chatfic`)),r=await fi().catch(()=>null),i=!N;for(let a of n){if(!t)break;let n=a.content||``,o=n,s=n.match(/const IS_LOCKED = (true|false);?/),c=s?s[1]===`true`:!1,l=n.match(/const showBranding = (true|false);?/),u=l?l[1]===`true`:!1;(!s||!n.includes(`cf-canvas-pro-locked-container`))&&e?o=_i(e,r?.siteId,r?.siteUrl,P,i):(o=o.replace(/const IS_LOCKED = (true|false);?/,`const IS_LOCKED = ${i};`),o=o.replace(/\/\/ @chat-bubbles-lock-state: (locked|unlocked)/,`// @chat-bubbles-lock-state: ${i?`locked`:`unlocked`}`),o=o.replace(/const showBranding = (true|false);?/,`const showBranding = ${!!P};`)),(!s||c!==i||u!==!!P||o!==n)&&await a.setFileContent(o)}}catch(e){console.error(`Failed to enforce lock state:`,e)}})(),()=>{t=!1}},[y.isCheckingPayment,N,P,e]);let F=(0,d.useCallback)(e=>{f(!1),s(e),e!==`home`&&!N&&(_.isLoggedIn?T(`expired`):_.openAuthModal(`register`))},[_,N]),te=(0,d.useCallback)((e,t,n)=>{if(!_.isLoggedIn){D(t),_.openAuthModal(`register`);return}y.makePayment(e,t,n)},[_,y]),I=(0,d.useCallback)(async e=>{A.current=!0;try{let t=await y.refreshSubscriptionStatus(e);if(!t)try{let n=await fi().catch(()=>({siteId:``,userId:null,siteUrl:null})),r=e||_.user?.email||null;(await ro(n.siteId,r)).eligible?(y.handleStartTrial&&(await y.handleStartTrial(),t=!0),T(`started`)):T(`expired`)}catch(e){console.error(`Error checking trial eligibility after auth:`,e)}if(E){let e=E;D(null),y.makePayment(null,e)}}finally{A.current=!1}},[_.user,y,E]),ne=(0,d.useMemo)(()=>{if(!_.isLoggedIn||!y.isPaid||!P)return null;let e=0;if(j?e=Math.max(0,Math.floor((j-O)/1e3)):typeof y.planDetails?.trialSecondsRemaining==`number`&&(e=Math.max(0,y.planDetails.trialSecondsRemaining)),e<=0)return null;let t;if(e<86400)t=`${Math.floor(e/3600).toString().padStart(2,`0`)}:${Math.floor(e%3600/60).toString().padStart(2,`0`)}:${(e%60).toString().padStart(2,`0`)}`;else{let n=Math.floor(e/86400),r=Math.floor(e%86400/3600),i=Math.floor(e%3600/60),a=[`${n} ${n===1?`day`:`days`}`];r>0&&a.push(`${r}h`),(i>0||r>0)&&a.push(`${i}m`),t=a.join(` `)}return(0,q.jsxs)(`div`,{className:`framefic-trial-sticky-banner`,children:[(0,q.jsxs)(`span`,{children:[`Free trial! `,(0,q.jsx)(`strong`,{children:t}),` left`]}),(0,q.jsxs)(`button`,{type:`button`,className:`framefic-trial-sticky-upgrade-btn`,onClick:()=>{C(e=>e+1),f(!0),x(`subscription`)},children:[(0,q.jsx)(Sa,{size:12,className:`framefic-trial-sticky-btn-icon`}),(0,q.jsx)(`span`,{children:`Upgrade`})]})]})},[_.isLoggedIn,y.isPaid,P,j,O,y.planDetails?.trialSecondsRemaining]),[re,ie]=(0,d.useState)(!1),[L,ae]=(0,d.useState)(``),[oe,se]=(0,d.useState)(``),[R,ce]=(0,d.useState)(Tc[0]),[le,ue]=(0,d.useState)(`whatsapp`),[de,fe]=(0,d.useState)(``),[pe,me]=(0,d.useState)(``),[he,ge]=(0,d.useState)(``),[_e,ve]=(0,d.useState)(`upload`),[ye,be]=(0,d.useState)(!1),[xe,Se]=(0,d.useState)(null),[Ce,we]=(0,d.useState)(null),[Te,Ee]=(0,d.useState)({}),[De,Oe]=(0,d.useState)([`Every page`,`Home page`]);(0,d.useEffect)(()=>{let e=!0;async function t(){try{let t=await U.getNodesWithType(`WebPageNode`)||[],n=await U.getNodesWithType(`DesignPageNode`)||[],r=[...t,...n],i=[`Every page`,...new Set(r.map(e=>`path`in e&&e.path?e.path===`/`||e.path===``?`Home page`:e.path:`name`in e&&e.name?e.name===`Home`||e.name===`index`?`Home page`:`/`+e.name.replace(/^\/+/,``):e.id).filter(e=>typeof e==`string`&&e!==`Every page`))];e&&i.length>0&&Oe(i)}catch{}}t();let n=setInterval(t,3e3);return()=>{e=!1,clearInterval(n)}},[]);function ke(e){Ee(t=>({...t,[e]:!t[e]}))}(0,d.useEffect)(()=>{function e(){let e=document.body?.getAttribute(`data-framer-theme`);if(e===`light`||e===`dark`)return e;let t=document.documentElement?.getAttribute(`data-framer-theme`);if(t===`light`||t===`dark`)return t;try{if(typeof U.getTheme==`function`){let e=U.getTheme(),t=typeof e==`string`?e:e?.mode;if(t===`light`||t===`dark`)return t}if(U.theme){let e=U.theme,t=typeof e==`string`?e:e?.mode;if(t===`light`||t===`dark`)return t}}catch{}return`dark`}let t=e();a(t);let n;try{typeof U.subscribe==`function`&&(n=U.subscribe(`theme`,e=>{let t=typeof e==`string`?e:e?.mode;(t===`light`||t===`dark`)&&(a(t),r(`auto`))}))}catch{}let i=new MutationObserver(()=>{let t=e();a(e=>e===t?e:(r(`auto`),t))});return document.body&&i.observe(document.body,{attributes:!0,attributeFilter:[`data-framer-theme`]}),document.documentElement&&i.observe(document.documentElement,{attributes:!0,attributeFilter:[`data-framer-theme`]}),()=>{n&&n(),i.disconnect()}},[]);let Ae=n===`auto`?i:n;(0,d.useEffect)(()=>{n===`auto`?document.documentElement.setAttribute(`data-framer-theme`,i):document.documentElement.setAttribute(`data-framer-theme`,Ae)},[Ae,n,i]);function je(e){r(e);try{localStorage.setItem(`chatfic_theme_pref_v4`,e)}catch{}}(0,d.useEffect)(()=>{si().then(e=>{t(e)}).catch(()=>g({type:`error`,text:`Unable to load plugin data.`}))},[]);let Me=(0,d.useRef)(!0);(0,d.useEffect)(()=>{if(Me.current){Me.current=!1;return}let t=setTimeout(async()=>{try{let t=ei(e);await ci(t),await Si(t)}catch(e){console.warn(`Auto-save and sync config failed:`,e),e&&e.message&&e.message.includes(`Framer project data limit`)&&v({type:`Error`,message:e.message})}},300);return()=>clearTimeout(t)},[e]);let Ne=(0,d.useMemo)(()=>e.channels.filter(e=>e.enabled&&e.value.trim()),[e.channels]);function z(e){t(t=>ei({...t,...e})),g(null)}function Pe(e,n){t(t=>({...t,channels:t.channels.map(t=>t.id===e?Wr({...t,...n}):t)})),g(null)}function Fe(e,n){t(t=>({...t,agents:t.agents.map(t=>t.id===e?Gr({...t,...n}):t)})),g(null)}function Ie(e){t(t=>({...t,agents:t.agents.filter(t=>t.id!==e)}))}async function Le(e){if(!e.type.startsWith(`image/`))throw Error(`Please select an image file (PNG, JPG, SVG, WebP, etc.).`);if(e.size>5242880)throw Error(`Image size should be less than 5MB.`);if(typeof U?.uploadImage==`function`)try{let t=await U.uploadImage(e);if(t&&t.url)return t.url}catch(e){console.warn(`framer.uploadImage unavailable in current context:`,e)}return new Promise((t,n)=>{let r=new FileReader;r.onload=()=>t(r.result),r.onerror=()=>n(Error(`Failed to read image file.`)),r.readAsDataURL(e)})}async function Re(e){let t=e.target.files?.[0];if(t){be(!0);try{let e=await Le(t);ce(e),g({type:`success`,text:`Avatar image uploaded successfully!`})}catch(e){g({type:`error`,text:e instanceof Error?e.message:`Failed to upload image.`})}finally{be(!1),e.target.value=``}}}async function ze(e,t){let n=t.target.files?.[0];if(n){we(e);try{Fe(e,{avatar:await Le(n)}),g({type:`success`,text:`Agent avatar updated!`})}catch(e){g({type:`error`,text:e instanceof Error?e.message:`Failed to upload image.`})}finally{we(null),t.target.value=``}}}function Be(){let e=W(L,60);if(!e)return;let n={id:`agent-`+Date.now(),name:e,role:W(oe,80,`Customer Support`),avatar:Br(R),channelId:le,value:W(de,150,``)||void 0,message:Rr(pe,300,``)||void 0,emailSubject:W(he,150,``)||void 0,online:!0};t(e=>({...e,agents:[...e.agents,n]})),ae(``),se(``),fe(``),me(``),ge(``),ce(Tc[0]),ie(!1),g({type:`success`,text:`Added `+n.name+` to chat team.`})}async function Ve(){if(!N){_.isLoggedIn?T(`expired`):_.openAuthModal(`register`);return}m(!0),g(null);try{let t=ei(e);await ci(t);let n=await Ci(t,N,P);g({type:n.success?`success`:`error`,text:n.message})}catch(e){g({type:`error`,text:e instanceof Error?e.message:`Failed to insert component onto canvas.`})}finally{m(!1)}}async function He(){let e=ti();t(e),await ci(e),await Si(e),g({type:`info`,text:`Settings restored to defaults.`})}let Ue=!u&&o!==`home`&&!N;return y.showPaymentModal&&!y.showPaymentSuccessModal?(0,q.jsx)(`div`,{className:`app `+Ae+` crestbar-checkout-shell`,children:(0,q.jsx)(Ms,{paymentError:y.paymentError,onRetry:()=>{y.payingPlan&&y.makePayment(null,y.payingPlan)},defaultCouponCode:y.appliedCouponCode||``,isOpen:y.showPaymentModal,clientSecret:y.clientSecret,showPaymentSuccessModal:y.showPaymentSuccessModal,originalAmount:y.originalAmount,showAmount:y.showAmount,showCurrency:y.showCurrency,showType:y.showType,plan:y.payingPlan,stripePromise:y.showPaymentModal&&y.publishableKey?Oc(y.publishableKey):null,onClose:y.closePaymentModal,defaultEmail:_.user?.email??null,subscriptionId:y.activeSubscriptionId,setClientSecret:y.setClientSecret,setShowAmount:y.setShowAmount,onSuccess:()=>{y.handlePaymentSuccess()},notify:v})}):(0,q.jsxs)(`div`,{className:`app `+Ae,children:[ne,(0,q.jsxs)(`nav`,{className:`cf-tabs`,children:[(0,q.jsxs)(`div`,{className:`cf-tabs-list`,children:[(0,q.jsx)(`button`,{type:`button`,className:`cf-tab `+(!u&&o===`home`?`active`:``),onClick:()=>F(`home`),children:`Home`}),(0,q.jsx)(`button`,{type:`button`,className:`cf-tab `+(!u&&o===`builder`?`active`:``),onClick:()=>F(`builder`),children:`Builder`}),(0,q.jsx)(`button`,{type:`button`,className:`cf-tab `+(!u&&o===`design`?`active`:``),onClick:()=>F(`design`),children:`Design`}),e.enableAnalytics!==!1&&(0,q.jsx)(`button`,{type:`button`,className:`cf-tab `+(!u&&o===`analytics`?`active`:``),onClick:()=>F(`analytics`),children:`Analytics`}),(0,q.jsx)(`button`,{type:`button`,className:`cf-tab `+(!u&&o===`settings`?`active`:``),onClick:()=>F(`settings`),children:`Settings`})]}),(0,q.jsx)(`button`,{type:`button`,className:`cf-tab-profile `+(u?`active`:``),onClick:()=>{!_.isLoggedIn&&!u&&_.openAuthModal(`register`),f(!u)},title:`Account & Profile`,"aria-label":`Account & Profile`,children:(0,q.jsx)(Ni,{size:18})})]}),(0,q.jsxs)(`main`,{className:`content`+(Ue?` cf-content-blurred`:``),children:[h&&(0,q.jsxs)(`div`,{className:`cf-notice `+h.type,children:[(0,q.jsxs)(`div`,{className:`cf-notice-icon-col`,children:[h.type===`info`&&(0,q.jsx)(Ui,{size:18}),h.type===`success`&&(0,q.jsx)(Wi,{size:18}),h.type===`warning`&&(0,q.jsx)(Gi,{size:18}),h.type===`error`&&(0,q.jsx)(Ki,{size:18})]}),(0,q.jsxs)(`div`,{className:`cf-notice-content`,children:[(0,q.jsx)(`h5`,{className:`cf-notice-title`,children:h.title||(h.type===`success`?`Success`:h.type===`error`?`Error`:h.type===`warning`?`Warning`:`Notice`)}),(0,q.jsx)(`p`,{className:`cf-notice-desc`,children:h.text})]}),(0,q.jsx)(`button`,{type:`button`,className:`cf-notice-close`,onClick:()=>g(null),"aria-label":`Dismiss notice`,children:(0,q.jsx)(Ai,{size:12})})]}),u?b===`subscription`?(0,q.jsx)(Fo,{onClose:()=>x(`profile`),hasSubscription:!!(_.isLoggedIn&&y.isPaid),planDetails:_.isLoggedIn?y.planDetails:null,isCreatingPayment:y.isCreatingPayment,payingPlan:y.payingPlan,lifetimeAvailability:y.lifetimeAvailability,onPay:te,onRefreshSubscription:y.refreshSubscriptionStatus,notify:v,defaultShowPlans:S}):(0,q.jsx)(Ao,{onBack:()=>f(!1),authUser:_.user,planDetails:_.isLoggedIn?y.planDetails:null,hasSubscription:!!(_.isLoggedIn&&y.isPaid),theme:n,onSignIn:()=>_.openAuthModal(`login`),onSignUp:()=>_.openAuthModal(`register`),onLogout:_.logout,onManageSubscription:()=>x(`subscription`),onRefreshSubscription:y.refreshSubscriptionStatus,onStartTrial:y.handleStartTrial}):(0,q.jsxs)(q.Fragment,{children:[o===`home`&&(0,q.jsxs)(q.Fragment,{children:[(0,q.jsx)(Do,{isLoggedIn:_.isLoggedIn,isPaidUser:!!(_.isLoggedIn&&y.isPaid&&!P),hasActiveTrial:P,user:_.user,trialEndTimestamp:_.isLoggedIn&&j?j:null,onUpgrade:()=>{C(e=>e+1),f(!0),x(`subscription`)}}),(0,q.jsx)(Qi,{badgeLabel:`Chat Widget`,badgeType:`brand`,badgeIcon:(0,q.jsx)(zi,{size:11}),title:`Welcome to Chat Bubbles`,description:`WhatsApp & multi-channel social chat buttons for Framer.`,ctaLabel:`Configure in Builder`,ctaIcon:(0,q.jsx)(Ii,{size:14}),onCtaClick:()=>F(`builder`),children:(0,q.jsxs)(`div`,{className:`cf-hero-config-grid`,children:[(0,q.jsxs)(`button`,{type:`button`,className:`cf-hero-config-item`,onClick:()=>F(`design`),title:`Current widget mode`,children:[(0,q.jsx)(`span`,{className:`cf-hero-config-label`,children:`Mode`}),(0,q.jsx)(`span`,{className:`cf-hero-config-val`,children:e.widgetMode===`modal`?`Live Modal`:`Buttons`})]}),(0,q.jsxs)(`button`,{type:`button`,className:`cf-hero-config-item`,onClick:()=>{F(`builder`),l(`channels`)},title:`Active channels in builder`,children:[(0,q.jsx)(`span`,{className:`cf-hero-config-label`,children:`Channels`}),(0,q.jsxs)(`span`,{className:`cf-hero-config-val`,children:[Ne.length,` Active`]})]}),(0,q.jsxs)(`button`,{type:`button`,className:`cf-hero-config-item`,onClick:()=>{F(`builder`),l(`agents`)},title:`Team agents in builder`,children:[(0,q.jsx)(`span`,{className:`cf-hero-config-label`,children:`Team`}),(0,q.jsxs)(`span`,{className:`cf-hero-config-val`,children:[e.agents.length,` Agents`]})]})]})}),(0,q.jsx)(ko,{}),(0,q.jsxs)(`div`,{className:`help-section`,children:[(0,q.jsx)(`h3`,{className:`help-section-title`,children:`More from Framefic`}),(0,q.jsxs)(`div`,{className:`help-products`,children:[(0,q.jsx)(ic,{name:`Before After Images Slider`,description:`Advanced image slider fully customizable and responsive`,logoSrc:`./Favicon.png`,marketplaceUrl:`https://www.framer.com/marketplace/plugins/beaf/`}),(0,q.jsx)(ic,{name:`Connectfic`,description:`Connect your framer site with shopify store and components`,logoSrc:`./Connectfic.png`,marketplaceUrl:`https://www.framer.com/marketplace/plugins/connectfic/`}),(0,q.jsx)(ic,{name:`Announcement Bar`,description:`Create bars and countdown timers to boost engagement and conversions.`,logoSrc:`./Crestbar.png`,marketplaceUrl:`https://www.framer.com/community/marketplace/plugins/announcement-bar/`}),(0,q.jsx)(ic,{name:`CMS Filter`,description:`Transform your Framer CMS with effortless collection and filter field selection, filter grids with pagination.`,logoSrc:`./Cmsfilter.png`,marketplaceUrl:`https://www.framer.com/marketplace/plugins/cms-filter/`})]})]})]}),o===`builder`&&(0,q.jsxs)(q.Fragment,{children:[(0,q.jsxs)(`div`,{className:`cf-builder-subtabs`,children:[(0,q.jsxs)(`button`,{type:`button`,className:`cf-builder-subtab `+(c===`channels`?`active`:``),onClick:()=>l(`channels`),children:[`Channels (`,Ne.length,`)`]}),(0,q.jsxs)(`button`,{type:`button`,className:`cf-builder-subtab `+(c===`agents`?`active`:``),onClick:()=>l(`agents`),children:[`Support Team (`,e.agents.length,`)`]})]}),c===`channels`&&(0,q.jsx)(Oi,{title:`Messaging Channels (${e.channels.length} Platforms Supported)`,description:`Configure handles, phone numbers, and pre-filled greetings for your visitors.`,children:e.channels.map(e=>{let t=Ec[e.id],n=`cf-ch-${e.id}`,r=e.enabled&&!!Te[e.id];return(0,q.jsxs)(`div`,{className:`cf-channel-card `+(e.enabled?`is-active`:``)+(r?` is-minimized`:``),children:[(0,q.jsxs)(`div`,{className:`cf-channel-header`,children:[(0,q.jsxs)(`div`,{className:`cf-channel-info`+(e.enabled?` cf-channel-info-clickable`:``),onClick:()=>e.enabled&&ke(e.id),title:e.enabled?r?`Click to expand options`:`Click to minimize options`:void 0,children:[(0,q.jsx)(`span`,{className:`cf-channel-icon-badge `+n,children:ui(e.id,18)}),(0,q.jsxs)(`div`,{className:`cf-channel-meta`,children:[(0,q.jsxs)(`div`,{className:`cf-channel-meta-title`,children:[e.id===`custom`?e.label.trim()||`Custom`:e.label,e.enabled&&e.value.trim()?(0,q.jsx)(`span`,{className:`cf-channel-pill live`,children:`Active`}):null]}),(0,q.jsx)(`div`,{className:`cf-channel-meta-hint`,children:t?.hint||``})]})]}),(0,q.jsxs)(`div`,{className:`cf-channel-actions`,children:[e.enabled&&(0,q.jsx)(`button`,{type:`button`,className:`cf-channel-btn-collapse `+(r?`is-collapsed`:``),onClick:t=>{t.stopPropagation(),ke(e.id)},title:r?`Expand options`:`Minimize options`,"aria-label":r?`Expand options`:`Minimize options`,children:(0,q.jsx)(Bi,{size:14})}),(0,q.jsx)(Y,{checked:e.enabled,onChange:t=>{Pe(e.id,{enabled:t}),t&&Ee(t=>({...t,[e.id]:!1}))}})]})]}),e.enabled&&!r&&(0,q.jsxs)(`div`,{className:`cf-channel-body`,children:[e.id===`custom`?(0,q.jsxs)(q.Fragment,{children:[(0,q.jsxs)(`div`,{className:`cf-field-grid`,children:[(0,q.jsx)(J,{label:`Custom URL Link`,hint:`Any valid web URL or custom protocol.`,children:(0,q.jsx)(`input`,{className:`cf-input`,maxLength:150,value:e.value,onChange:t=>Pe(e.id,{value:t.target.value}),placeholder:t?.placeholder||`https://yourwebsite.com/chat`})}),(0,q.jsx)(J,{label:`Channel / Button Label`,hint:`Name displayed on button badge & tooltip.`,children:(0,q.jsx)(`input`,{className:`cf-input`,maxLength:40,value:e.label,onChange:t=>Pe(e.id,{label:t.target.value}),placeholder:`Custom`})})]}),(0,q.jsxs)(`div`,{className:`cf-field-grid`,children:[(0,q.jsx)(J,{label:`Button Color`,children:(0,q.jsx)(fc,{value:e.color||`#5271FF`,fallback:`#5271FF`,onChange:t=>Pe(e.id,{color:t}),ariaLabel:`Button Color`})}),(0,q.jsx)(J,{label:`Open Link In`,children:(0,q.jsxs)(`div`,{className:`cf-flex-center-gap-6 cf-mt-6`,children:[(0,q.jsx)(Y,{checked:e.openInNewTab,onChange:t=>Pe(e.id,{openInNewTab:t})}),(0,q.jsx)(`span`,{className:`cf-subtext-sm`,children:e.openInNewTab?`New browser tab`:`Same browser tab`})]})})]})]}):(0,q.jsxs)(`div`,{className:`cf-field-grid`,children:[(0,q.jsx)(J,{label:t?.label||`Handle / ID`,children:(0,q.jsx)(`input`,{className:`cf-input`,maxLength:150,value:e.value,onChange:t=>Pe(e.id,{value:t.target.value}),placeholder:t?.placeholder})}),(0,q.jsx)(J,{label:`Button Color`,children:(0,q.jsx)(fc,{value:e.color||`#5271FF`,fallback:`#5271FF`,onChange:t=>Pe(e.id,{color:t}),ariaLabel:`Button Color`})})]}),[`whatsapp`,`telegram`,`sms`].includes(e.id)&&(0,q.jsx)(J,{label:`Pre-filled Welcome Message`,hint:`Automatically fills visitor's chat input. Supports {url} and {title} variables.`,children:(0,q.jsx)(`input`,{className:`cf-input`,maxLength:300,value:e.message||``,onChange:t=>Pe(e.id,{message:t.target.value}),placeholder:`Hello! I'd like to know more about {title}.`})}),e.id===`email`&&(0,q.jsxs)(q.Fragment,{children:[(0,q.jsx)(J,{label:`Email Subject`,hint:`Pre-fills the email subject line when visitors reach out.`,children:(0,q.jsx)(`input`,{className:`cf-input`,maxLength:150,value:e.emailSubject||``,onChange:t=>Pe(e.id,{emailSubject:t.target.value}),placeholder:`Inquiry from website`})}),(0,q.jsx)(J,{label:`Pre-filled Email Message Body`,hint:`Automatically fills visitor's email body. Supports {url} and {title} variables.`,children:(0,q.jsx)(`textarea`,{className:`cf-textarea`,rows:2,maxLength:300,value:e.message||``,onChange:t=>Pe(e.id,{message:t.target.value}),placeholder:`Hello! I have a question about {title}.`})})]})]})]},e.id)})}),c===`agents`&&(0,q.jsxs)(Oi,{title:`Support Team / Agents`,description:`Add team members visitors can chat with. Each agent can have their own direct number or custom message.`,children:[(0,q.jsx)(`div`,{className:`cf-agents-list`,children:e.agents.map(t=>{let n=e.channels.find(e=>e.id===t.channelId)||e.channels[0],r=xe===t.id,i=Ce===t.id,a=Ec[t.channelId],o=!!(t.value&&t.value.trim()),s=`cf-ch-${t.channelId}`;return(0,q.jsxs)(`div`,{className:`cf-agent-manage-item `+(r?`is-expanded`:``),children:[(0,q.jsxs)(`div`,{className:`cf-agent-manage-header`,children:[(0,q.jsxs)(`div`,{className:`cf-agent-avatar-wrap`,title:`Click to upload/change photo`,onClick:()=>{document.getElementById(`cf-agent-file-${t.id}`)?.click()},children:[(0,q.jsx)(`img`,{src:t.avatar,alt:t.name,className:`cf-agent-manage-avatar`}),(0,q.jsx)(`div`,{className:`cf-agent-avatar-hover-icon`,children:i?(0,q.jsx)(Li,{size:14}):(0,q.jsx)(ji,{size:14})}),(0,q.jsx)(`input`,{id:`cf-agent-file-${t.id}`,type:`file`,accept:`image/*`,className:`cf-hidden-file-input`,onChange:e=>ze(t.id,e)})]}),(0,q.jsxs)(`div`,{className:`cf-agent-manage-fields`,children:[(0,q.jsx)(`input`,{className:`cf-input`,maxLength:60,value:t.name,onChange:e=>Fe(t.id,{name:e.target.value}),placeholder:`Agent Name`}),(0,q.jsx)(`input`,{className:`cf-input`,maxLength:80,value:t.role,onChange:e=>Fe(t.id,{role:e.target.value}),placeholder:`Role / Department`})]}),(0,q.jsxs)(`div`,{className:`cf-agent-meta-badge-wrap`,children:[(0,q.jsx)(`span`,{className:`cf-agent-channel-tag `+s,children:n?.label||`Chat`}),o&&(0,q.jsx)(`span`,{className:`cf-agent-custom-tag`,title:`Direct value: `+t.value,children:`Custom #`})]}),(0,q.jsx)(`button`,{type:`button`,className:`cf-agent-btn-configure `+(r?`active`:``),onClick:()=>Se(r?null:t.id),title:r?`Collapse settings`:`Configure direct number, message & photo`,children:(0,q.jsx)(ki,{size:13})}),(0,q.jsx)(`button`,{type:`button`,className:`cf-agent-del-btn`,onClick:()=>Ie(t.id),title:`Remove agent`,children:(0,q.jsx)(Ai,{size:12})})]}),r&&(0,q.jsxs)(`div`,{className:`cf-agent-expanded-body`,children:[(0,q.jsx)(J,{label:`Assigned Channel`,hint:`Only channels enabled in the Channels tab appear here.`,children:(0,q.jsx)(`select`,{className:`cf-input`,value:t.channelId,onChange:e=>Fe(t.id,{channelId:e.target.value}),children:(()=>{let n=e.channels.filter(e=>e.enabled||e.id===t.channelId);return(n.length>0?n:e.channels).map(e=>(0,q.jsxs)(`option`,{value:e.id,children:[e.label,e.enabled?e.value?` (${e.value})`:` (Active, no default)`:` (Disabled in Channels)`]},e.id))})()})}),(0,q.jsx)(J,{label:`Direct ${n?.label||`Channel`} ${t.channelId===`email`?`Email`:t.channelId===`phone`||t.channelId===`whatsapp`||t.channelId===`viber`?`Number`:`Handle`} (Optional)`,hint:n?.value?`Default: ${n.value}. Leave blank to use default.`:`Leave blank to use channel default.`,children:(0,q.jsx)(`input`,{className:`cf-input`,maxLength:150,value:t.value||``,onChange:e=>Fe(t.id,{value:e.target.value}),placeholder:a?.placeholder||`Direct contact value`})}),(0,q.jsx)(J,{label:`Direct Pre-filled Message (Optional)`,hint:n?.message?`Default: "${n.message}". Leave blank to use default.`:`Leave blank to use welcome chat bubble.`,children:(0,q.jsx)(`textarea`,{className:`cf-input`,rows:2,maxLength:300,value:t.message||``,onChange:e=>Fe(t.id,{message:e.target.value}),placeholder:`e.g. Hi there! Emma here from billing. How can I help you today?`})}),t.channelId===`email`&&(0,q.jsx)(J,{label:`Direct Email Subject (Optional)`,hint:n?.emailSubject?`Default: "${n.emailSubject}". Leave blank to use default.`:`Leave blank to use default subject.`,children:(0,q.jsx)(`input`,{className:`cf-input`,maxLength:150,value:t.emailSubject||``,onChange:e=>Fe(t.id,{emailSubject:e.target.value}),placeholder:`Inquiry from website`})}),(0,q.jsxs)(J,{label:`Avatar Photo`,children:[(0,q.jsxs)(`div`,{className:`cf-avatar-edit-row`,children:[(0,q.jsx)(`button`,{type:`button`,className:`cf-btn secondary cf-avatar-upload-trigger cf-btn-inline-flex`,onClick:()=>{document.getElementById(`cf-agent-file-${t.id}`)?.click()},disabled:i,children:i?(0,q.jsxs)(q.Fragment,{children:[(0,q.jsx)(Li,{size:12}),(0,q.jsx)(`span`,{children:`Uploading photo...`})]}):(0,q.jsxs)(q.Fragment,{children:[(0,q.jsx)(Mi,{size:12}),(0,q.jsx)(`span`,{children:`Upload New Photo`})]})}),(0,q.jsx)(`div`,{className:`cf-avatar-presets-mini`,children:Tc.map((e,n)=>(0,q.jsx)(`button`,{type:`button`,className:`cf-avatar-preset-btn `+(t.avatar===e?`active`:``),onClick:()=>Fe(t.id,{avatar:e}),title:`Preset `+(n+1),children:(0,q.jsx)(`img`,{src:e,alt:`Preset `+(n+1)})},n))})]}),(0,q.jsx)(`input`,{className:`cf-input cf-mt-6`,maxLength:500,value:t.avatar,onChange:e=>Fe(t.id,{avatar:e.target.value}),placeholder:`Or paste image URL...`})]}),(0,q.jsxs)(`div`,{className:`cf-agent-detail-row`,children:[(0,q.jsxs)(`div`,{className:`cf-agent-detail-left`,children:[(0,q.jsx)(Y,{checked:t.online!==!1,onChange:e=>Fe(t.id,{online:e})}),(0,q.jsx)(`span`,{className:`cf-agent-detail-lbl`,children:t.online===!1?`Away / Offline`:`Active / Online (shows green dot)`})]}),(0,q.jsx)(`button`,{type:`button`,className:`cf-btn secondary cf-badge-sm`,onClick:()=>Se(null),children:`Done`})]})]})]},t.id)})}),re?(0,q.jsxs)(`div`,{className:`cf-add-agent-box`,children:[(0,q.jsxs)(`div`,{className:`cf-add-member-header`,children:[(0,q.jsx)(`span`,{className:`cf-add-member-title`,children:`Add New Team Member`}),(0,q.jsx)(`button`,{type:`button`,className:`cf-agent-del-btn`,onClick:()=>ie(!1),title:`Close`,children:(0,q.jsx)(Ai,{size:12})})]}),(0,q.jsxs)(`div`,{className:`cf-field-grid`,children:[(0,q.jsx)(J,{label:`Agent Name *`,children:(0,q.jsx)(`input`,{className:`cf-input`,maxLength:60,value:L,onChange:e=>ae(e.target.value),placeholder:`e.g. Emma Watson`,autoFocus:!0})}),(0,q.jsx)(J,{label:`Role / Department`,children:(0,q.jsx)(`input`,{className:`cf-input`,maxLength:80,value:oe,onChange:e=>se(e.target.value),placeholder:`e.g. Sales Specialist`})})]}),(0,q.jsx)(J,{label:`Assigned Channel`,hint:`Only channels enabled in the Channels tab appear here.`,children:(0,q.jsx)(`select`,{className:`cf-input`,value:le,onChange:e=>ue(e.target.value),children:(()=>{let t=e.channels.filter(e=>e.enabled);return(t.length>0?t:e.channels).map(e=>(0,q.jsxs)(`option`,{value:e.id,children:[e.label,` `,e.value?`(${e.value})`:`(Active, no default)`]},e.id))})()})}),(0,q.jsx)(J,{label:`Direct ${e.channels.find(e=>e.id===le)?.label||`Channel`} ${le===`email`?`Email`:le===`phone`||le===`whatsapp`||le===`viber`?`Number`:`Handle`} (Optional)`,hint:(()=>{let t=e.channels.find(e=>e.id===le);return t?.value?`Default: ${t.value}. Leave blank to inherit default.`:`Leave blank to inherit channel default.`})(),children:(0,q.jsx)(`input`,{className:`cf-input`,maxLength:150,value:de,onChange:e=>fe(e.target.value),placeholder:Ec[le]?.placeholder||`Custom number or handle`})}),(0,q.jsx)(J,{label:`Direct Welcome Message (Optional)`,hint:(()=>{let t=e.channels.find(e=>e.id===le);return t?.message?`Default: "${t.message}". Leave blank to inherit.`:`Leave blank to use general chat bubble.`})(),children:(0,q.jsx)(`textarea`,{className:`cf-input`,rows:2,maxLength:300,value:pe,onChange:e=>me(e.target.value),placeholder:`e.g. Hi there! Emma here from billing. How can I help you today?`})}),le===`email`&&(0,q.jsx)(J,{label:`Direct Email Subject (Optional)`,hint:(()=>{let t=e.channels.find(e=>e.id===le);return t?.emailSubject?`Default: "${t.emailSubject}". Leave blank to inherit.`:`Leave blank to use default subject.`})(),children:(0,q.jsx)(`input`,{className:`cf-input`,maxLength:150,value:he,onChange:e=>ge(e.target.value),placeholder:`Inquiry from website`})}),(0,q.jsxs)(J,{label:`Avatar Photo`,children:[(0,q.jsxs)(`div`,{className:`cf-avatar-picker-tabs`,children:[(0,q.jsxs)(`button`,{type:`button`,className:`cf-avatar-picker-tab `+(_e===`upload`?`active`:``),onClick:()=>ve(`upload`),children:[(0,q.jsx)(Mi,{size:12}),(0,q.jsx)(`span`,{children:`Upload Image`})]}),(0,q.jsxs)(`button`,{type:`button`,className:`cf-avatar-picker-tab `+(_e===`presets`?`active`:``),onClick:()=>ve(`presets`),children:[(0,q.jsx)(Ni,{size:12}),(0,q.jsx)(`span`,{children:`Presets`})]}),(0,q.jsxs)(`button`,{type:`button`,className:`cf-avatar-picker-tab `+(_e===`url`?`active`:``),onClick:()=>ve(`url`),children:[(0,q.jsx)(Pi,{size:12}),(0,q.jsx)(`span`,{children:`Image URL`})]})]}),(0,q.jsxs)(`div`,{className:`cf-avatar-picker-content`,children:[(0,q.jsx)(`div`,{className:`cf-avatar-picker-preview-wrap`,children:(0,q.jsx)(`img`,{src:R,alt:`New agent avatar`,className:`cf-avatar-picker-preview`})}),(0,q.jsxs)(`div`,{className:`cf-avatar-picker-controls`,children:[_e===`upload`&&(0,q.jsxs)(`div`,{className:`cf-avatar-upload-zone`,children:[(0,q.jsxs)(`label`,{className:`cf-btn secondary cf-avatar-upload-button`,children:[ye?(0,q.jsxs)(q.Fragment,{children:[(0,q.jsx)(Li,{size:13}),(0,q.jsx)(`span`,{children:`Uploading photo...`})]}):(0,q.jsxs)(q.Fragment,{children:[(0,q.jsx)(Mi,{size:13}),(0,q.jsx)(`span`,{children:`Choose Image File`})]}),(0,q.jsx)(`input`,{type:`file`,accept:`image/*`,className:`cf-hidden-file-input`,onChange:Re,disabled:ye})]}),(0,q.jsx)(`span`,{className:`cf-avatar-upload-hint`,children:`JPG, PNG, WebP or SVG. Uploads to Framer CDN.`})]}),_e===`presets`&&(0,q.jsx)(`div`,{className:`cf-avatar-presets-grid`,children:Tc.map((e,t)=>(0,q.jsx)(`button`,{type:`button`,className:`cf-avatar-preset-btn `+(R===e?`active`:``),onClick:()=>ce(e),title:`Preset `+(t+1),children:(0,q.jsx)(`img`,{src:e,alt:`Preset `+(t+1)})},t))}),_e===`url`&&(0,q.jsx)(`input`,{className:`cf-input`,maxLength:500,value:R,onChange:e=>ce(e.target.value),placeholder:`Paste image URL (https://...)`})]})]})]}),(0,q.jsxs)(`div`,{className:`cf-flex-end-gap-8`,children:[(0,q.jsx)(`button`,{type:`button`,className:`cf-btn secondary`,onClick:()=>ie(!1),children:`Cancel`}),(0,q.jsx)(`button`,{type:`button`,className:`cf-btn primary`,onClick:Be,disabled:!L.trim()||ye,children:ye?`Uploading...`:`Add to Team`})]})]}):(0,q.jsxs)(`button`,{type:`button`,className:`cf-btn secondary full-col cf-btn-add-agent`,onClick:()=>{let t=e.channels.find(e=>e.enabled)?.id||`whatsapp`;ue(t),ie(!0)},children:[(0,q.jsx)(Z,{size:13}),(0,q.jsx)(`span`,{children:`Add Team Member`})]})]})]}),o===`design`&&(0,q.jsxs)(q.Fragment,{children:[(0,q.jsxs)(Oi,{title:`Chat Window Header & Theme`,description:`Customize the top header gradient, greeting, and response time.`,children:[(0,q.jsx)(J,{label:`Header Theme Gradient`,children:(0,q.jsx)(`div`,{className:`cf-theme-grid`,children:[[`whatsapp`,`WhatsApp`],[`messenger`,`Messenger`],[`telegram`,`Telegram`],[`instagram`,`Instagram`],[`tiktok`,`TikTok`],[`wechat`,`WeChat`],[`dark`,`Modern Dark`],[`custom`,`Custom`]].map(([t,n])=>(0,q.jsxs)(`div`,{className:`cf-theme-card `+(e.modalTheme===t?`active`:``),onClick:()=>z({modalTheme:t}),children:[(0,q.jsx)(`div`,{className:`cf-theme-swatch cf-theme-grad-`+t}),(0,q.jsx)(`span`,{className:`cf-theme-name`,children:n})]},t))})}),e.modalTheme===`custom`&&(0,q.jsx)(J,{label:`Custom Gradient & Color Palette`,hint:`Choose from curated presets, pick start & end colors, or rotate the angle`,children:(0,q.jsx)(hc,{value:e.modalCustomGradient||`linear-gradient(135deg, #6366f1 0%, #a855f7 100%)`,onChange:e=>z({modalCustomGradient:e})})}),(0,q.jsxs)(`div`,{className:`cf-field-grid`,children:[(0,q.jsx)(J,{label:`Header Title`,children:(0,q.jsx)(`input`,{className:`cf-input`,maxLength:100,value:e.modalTitle,onChange:e=>z({modalTitle:e.target.value}),placeholder:`Hi there!`})}),(0,q.jsx)(J,{label:`Response Time Badge`,children:(0,q.jsx)(`input`,{className:`cf-input`,maxLength:60,value:e.modalResponseTime,onChange:e=>z({modalResponseTime:e.target.value}),placeholder:`Typically replies in minutes`})})]}),(0,q.jsx)(J,{label:`Header Subtitle`,children:(0,q.jsx)(`input`,{className:`cf-input`,maxLength:250,value:e.modalSubtitle,onChange:e=>z({modalSubtitle:e.target.value}),placeholder:`Welcome to our live chat! Feel free to ask any questions.`})})]}),(0,q.jsx)(Oi,{title:`Widget Experience Mode`,description:`Choose how visitors interact when clicking your floating button.`,children:(0,q.jsxs)(`div`,{className:`cf-field-grid`,children:[(0,q.jsxs)(`div`,{className:`cf-theme-card cf-mode-card `+(e.widgetMode===`modal`?`active`:``),onClick:()=>z({widgetMode:`modal`}),children:[(0,q.jsxs)(`div`,{className:`cf-mode-card-header`,children:[(0,q.jsx)(`span`,{className:`cf-mode-card-icon`,children:(0,q.jsx)(Ri,{size:16})}),(0,q.jsx)(`strong`,{className:`cf-mode-card-title`,children:`Live Chat Modal`})]}),(0,q.jsx)(`span`,{className:`cf-mode-card-desc`,children:`Popup chat window with support team and preview.`})]}),(0,q.jsxs)(`div`,{className:`cf-theme-card cf-mode-card `+(e.widgetMode===`buttons`?`active`:``),onClick:()=>z({widgetMode:`buttons`}),children:[(0,q.jsxs)(`div`,{className:`cf-mode-card-header`,children:[(0,q.jsx)(`span`,{className:`cf-mode-card-icon`,children:(0,q.jsx)(X,{size:16})}),(0,q.jsx)(`strong`,{className:`cf-mode-card-title`,children:`Icon Buttons`})]}),(0,q.jsx)(`span`,{className:`cf-mode-card-desc`,children:`Classic floating icon list opening direct channel URLs.`})]})]})}),(0,q.jsxs)(Oi,{title:`Chat Preview & Start CTA`,description:`Configure the simulated incoming message and the action button.`,children:[(0,q.jsx)(J,{label:`Welcome Chat Bubble Message`,children:(0,q.jsx)(`textarea`,{className:`cf-input`,rows:2,maxLength:500,value:e.modalChatBubble,onChange:e=>z({modalChatBubble:e.target.value}),placeholder:`We typically reply within a few minutes. How can we help you today?`})}),(0,q.jsx)(J,{label:`CTA Button Text`,children:(0,q.jsx)(`input`,{className:`cf-input`,maxLength:50,value:e.modalStartChatText,onChange:e=>z({modalStartChatText:e.target.value}),placeholder:`Start chat`})})]}),(0,q.jsxs)(Oi,{title:`Floating Launcher Design`,description:`Customize the floating button shape, size, layout, animation, and responsive offsets.`,children:[(0,q.jsxs)(`div`,{className:`cf-field-grid`,children:[(0,q.jsx)(J,{label:`Toggle Button Icon`,hint:`Icon displayed on the main floating toggle button`,children:(0,q.jsxs)(`select`,{className:`cf-input`,value:e.launcherIcon||`chat`,onChange:e=>z({launcherIcon:e.target.value}),children:[(0,q.jsx)(`option`,{value:`chat`,children:`Live Chat (Speech Bubble)`}),(0,q.jsx)(`option`,{value:`whatsapp`,children:`WhatsApp`}),(0,q.jsx)(`option`,{value:`messenger`,children:`Messenger`}),(0,q.jsx)(`option`,{value:`telegram`,children:`Telegram`}),(0,q.jsx)(`option`,{value:`instagram`,children:`Instagram`}),(0,q.jsx)(`option`,{value:`phone`,children:`Phone Call`}),(0,q.jsx)(`option`,{value:`email`,children:`Email`}),(0,q.jsx)(`option`,{value:`support`,children:`Customer Support (Headset)`})]})}),(0,q.jsx)(J,{label:`Button Shape`,children:(0,q.jsxs)(`select`,{className:`cf-input`,value:e.buttonShape,onChange:e=>z({buttonShape:e.target.value}),children:[(0,q.jsx)(`option`,{value:`circle`,children:`Circle`}),(0,q.jsx)(`option`,{value:`rounded`,children:`Rounded Square`}),(0,q.jsx)(`option`,{value:`pill`,children:`Pill`})]})})]}),(0,q.jsxs)(`div`,{className:`cf-field-grid`,children:[(0,q.jsx)(J,{label:`Button Menu Layout`,hint:`Arrange channel buttons in vertical stack, 2-column grid, or horizontal row`,children:(0,q.jsxs)(`select`,{className:`cf-input`,value:e.layout,onChange:e=>z({layout:e.target.value}),children:[(0,q.jsx)(`option`,{value:`stack`,children:`Stack (Vertical)`}),(0,q.jsx)(`option`,{value:`grid`,children:`Grid (2 Columns)`}),(0,q.jsx)(`option`,{value:`horizontal`,children:`Horizontal Row`})]})}),(0,q.jsx)(J,{label:`Entrance Animation`,hint:`Motion preset when launcher/window opens`,children:(0,q.jsxs)(`select`,{className:`cf-input`,value:e.animation,onChange:e=>z({animation:e.target.value}),children:[(0,q.jsx)(`option`,{value:`pop`,children:`Pop In`}),(0,q.jsx)(`option`,{value:`bounce`,children:`Playful Bounce`}),(0,q.jsx)(`option`,{value:`slide`,children:`Slide Up`}),(0,q.jsx)(`option`,{value:`pulse`,children:`Pulse Glow`}),(0,q.jsx)(`option`,{value:`none`,children:`None (Instant)`})]})})]}),(0,q.jsxs)(`div`,{className:`cf-field-grid`,children:[(0,q.jsx)(J,{label:`Button Size`,children:(0,q.jsxs)(`select`,{className:`cf-input`,value:e.buttonSize,onChange:e=>z({buttonSize:Number(e.target.value)}),children:[(0,q.jsx)(`option`,{value:46,children:`Small (46px)`}),(0,q.jsx)(`option`,{value:56,children:`Medium (56px)`}),(0,q.jsx)(`option`,{value:64,children:`Large (64px)`})]})}),(0,q.jsx)(J,{label:`Launcher Default Color`,children:(0,q.jsx)(fc,{value:e.buttonColor||`#5271FF`,fallback:`#5271FF`,onChange:e=>z({buttonColor:e}),ariaLabel:`Launcher Default Color`})})]}),(0,q.jsxs)(`div`,{className:`cf-field-grid`,children:[(0,q.jsx)(J,{label:`Desktop Offset X (px)`,children:(0,q.jsx)(`input`,{type:`number`,className:`cf-input`,min:0,max:300,value:e.offsetX,onChange:e=>z({offsetX:Number(e.target.value)||0})})}),(0,q.jsx)(J,{label:`Desktop Offset Y (px)`,children:(0,q.jsx)(`input`,{type:`number`,className:`cf-input`,min:0,max:300,value:e.offsetY,onChange:e=>z({offsetY:Number(e.target.value)||0})})})]}),(0,q.jsxs)(`div`,{className:`cf-field-grid`,children:[(0,q.jsx)(J,{label:`Mobile Offset X (px)`,hint:`Distance from screen edge on mobile (<640px)`,children:(0,q.jsx)(`input`,{type:`number`,className:`cf-input`,min:0,max:200,value:e.mobileOffsetX,onChange:e=>z({mobileOffsetX:Number(e.target.value)||0})})}),(0,q.jsx)(J,{label:`Mobile Offset Y (px)`,hint:`Distance from screen edge on mobile (<640px)`,children:(0,q.jsx)(`input`,{type:`number`,className:`cf-input`,min:0,max:200,value:e.mobileOffsetY,onChange:e=>z({mobileOffsetY:Number(e.target.value)||0})})})]}),(0,q.jsxs)(`div`,{className:`cf-flex-between`,children:[(0,q.jsxs)(`div`,{className:`cf-setting-info`,children:[(0,q.jsx)(`div`,{className:`cf-text-sm-semibold`,children:`Mobile Layout Constraint (Cap 4+)`}),(0,q.jsx)(`div`,{className:`cf-text-xs-secondary`,children:`When 5+ channels are enabled, caps visible mobile buttons (<640px) to the top 4 channels with an expandable '+ More' button to prevent screen clutter.`})]}),(0,q.jsx)(Y,{checked:e.mobileCapChannels??!0,onChange:e=>z({mobileCapChannels:e})})]}),(0,q.jsx)(J,{label:`Accessibility ARIA Label`,hint:`Screen reader text describing the floating launcher button`,children:(0,q.jsx)(`input`,{className:`cf-input`,maxLength:80,value:e.ariaLabel,onChange:e=>z({ariaLabel:e.target.value}),placeholder:`Open chat options`})}),(0,q.jsxs)(`div`,{className:`cf-field-grid`,children:[(0,q.jsx)(J,{label:`Unread Notification Badge`,children:(0,q.jsxs)(`div`,{className:`cf-flex-center-gap-10`,children:[(0,q.jsx)(Y,{checked:e.showBadge,onChange:e=>z({showBadge:e})}),e.showBadge&&(0,q.jsx)(`input`,{className:`cf-input cf-input-w60`,maxLength:10,value:e.badgeText,onChange:e=>z({badgeText:e.target.value}),placeholder:`1`})]})}),(0,q.jsx)(J,{label:`Greeting Bubble Preview`,children:(0,q.jsxs)(`div`,{className:`cf-flex-center-gap-10`,children:[(0,q.jsx)(Y,{checked:e.greetingEnabled,onChange:e=>z({greetingEnabled:e})}),(0,q.jsx)(`span`,{className:`cf-text-xs-secondary`,children:e.greetingEnabled?`Visible`:`Hidden`})]})})]}),e.greetingEnabled&&(0,q.jsx)(J,{label:`Greeting Bubble Text`,children:(0,q.jsx)(`input`,{className:`cf-input`,maxLength:200,value:e.greetingText,onChange:e=>z({greetingText:e.target.value}),placeholder:`Need help? Chat with us.`})})]})]}),o===`analytics`&&e.enableAnalytics!==!1&&(0,q.jsx)(xc,{enabled:!0,onToggleEnabled:e=>z({enableAnalytics:e}),channels:e.channels,widgetId:e.widgetId,onNavigateToSettings:()=>{f(!1),s(`settings`)}}),o===`settings`&&(0,q.jsxs)(q.Fragment,{children:[(0,q.jsx)(Oi,{title:`Interface Theme`,description:`Choose your preferred color theme for the Chat Bubbles plugin shell.`,children:(0,q.jsx)(`div`,{className:`cf-segmented-control-wrapper`,children:(0,q.jsxs)(`div`,{className:`cf-segmented-control`,role:`tablist`,"aria-label":`Theme selection`,children:[(0,q.jsx)(`button`,{type:`button`,role:`tab`,"aria-selected":n===`light`,className:`cf-segment-item ${n===`light`?`active`:``}`,onClick:()=>je(`light`),children:`Light`}),(0,q.jsx)(`button`,{type:`button`,role:`tab`,"aria-selected":n===`dark`,className:`cf-segment-item ${n===`dark`?`active`:``}`,onClick:()=>je(`dark`),children:`Dark`}),(0,q.jsx)(`button`,{type:`button`,role:`tab`,"aria-selected":n===`auto`,className:`cf-segment-item ${n===`auto`?`active`:``}`,onClick:()=>je(`auto`),children:`Match site`})]})})}),(0,q.jsx)(Oi,{title:`Enable Analytics`,description:`Track views, clicks, and conversion rates for your chat bubbles.`,action:(0,q.jsx)(Y,{checked:e.enableAnalytics!==!1,onChange:e=>z({enableAnalytics:e})}),children:e.enableAnalytics!==!1&&(0,q.jsxs)(`div`,{className:`cf-analytics-settings-wrapper`,children:[(0,q.jsx)(`div`,{className:`cf-analytics-settings-action`,children:(0,q.jsxs)(`button`,{type:`button`,className:`cf-btn-view-analytics`,onClick:()=>{f(!1),s(`analytics`)},children:[(0,q.jsx)(qi,{size:14}),(0,q.jsx)(`span`,{children:`View Analytics Dashboard`}),(0,q.jsx)(Ii,{size:13})]})}),(0,q.jsx)(J,{label:`Forward to Google Analytics (gtag / dataLayer)`,hint:`Optionally push widget views and channel clicks to your site's window.dataLayer or window.gtag if installed.`,children:(0,q.jsx)(Y,{checked:!!e.forwardEventsToSiteAnalytics,onChange:e=>z({forwardEventsToSiteAnalytics:e})})})]})}),(0,q.jsxs)(Oi,{title:`Widget Placement`,description:`Configure the default screen anchor for your live chat floating button.`,children:[(0,q.jsx)(J,{label:`Screen Corner Position`,children:(0,q.jsxs)(`select`,{className:`cf-input`,value:e.position,onChange:e=>z({position:e.target.value}),children:[(0,q.jsx)(`option`,{value:`bottom-right`,children:`Bottom Right (Recommended)`}),(0,q.jsx)(`option`,{value:`bottom-left`,children:`Bottom Left`}),(0,q.jsx)(`option`,{value:`top-right`,children:`Top Right`}),(0,q.jsx)(`option`,{value:`top-left`,children:`Top Left`})]})}),(0,q.jsxs)(`div`,{className:`cf-field-grid`,children:[(0,q.jsx)(J,{label:`Show Channel Labels`,hint:`Display text labels alongside channel buttons`,children:(0,q.jsxs)(`div`,{className:`cf-flex-center-gap-10`,children:[(0,q.jsx)(Y,{checked:e.showLabels,onChange:e=>z({showLabels:e})}),(0,q.jsx)(`span`,{className:`cf-text-xs-secondary`,children:e.showLabels?`Visible`:`Hidden`})]})}),(0,q.jsx)(J,{label:`Labels on Mobile`,hint:`Keep labels visible on smaller screens (<640px)`,children:(0,q.jsxs)(`div`,{className:`cf-flex-center-gap-10`,children:[(0,q.jsx)(Y,{checked:e.mobileShowLabels,onChange:e=>z({mobileShowLabels:e})}),(0,q.jsx)(`span`,{className:`cf-text-xs-secondary`,children:e.mobileShowLabels?`Visible`:`Hidden`})]})})]})]}),(0,q.jsx)(Oi,{title:`Interaction & Behavior`,description:`Configure how and when the chat button triggers, auto-opens, and closes for site visitors.`,children:(0,q.jsxs)(`div`,{className:`cf-flex-col-gap-14`,children:[(0,q.jsxs)(`div`,{className:`cf-flex-between`,children:[(0,q.jsxs)(`div`,{className:`cf-setting-info`,children:[(0,q.jsx)(`div`,{className:`cf-text-sm-semibold`,children:`Auto-open on Load`}),(0,q.jsx)(`div`,{className:`cf-text-xs-secondary`,children:`Automatically pop open the chat modal or channel menu for visitors.`})]}),(0,q.jsx)(Y,{checked:e.autoOpen||!1,onChange:e=>z({autoOpen:e})})]}),e.autoOpen&&(0,q.jsx)(J,{label:`Auto-open Delay (Seconds)`,hint:`How long to wait after page load before opening`,children:(0,q.jsx)(`input`,{type:`number`,className:`cf-input`,min:0,max:60,value:Math.round((e.autoOpenDelay||1200)/1e3),onChange:e=>z({autoOpenDelay:(Number(e.target.value)||0)*1e3})})}),(0,q.jsxs)(`div`,{className:`cf-flex-between`,children:[(0,q.jsxs)(`div`,{className:`cf-setting-info`,children:[(0,q.jsx)(`div`,{className:`cf-text-sm-semibold`,children:`Close on Outside Click`}),(0,q.jsx)(`div`,{className:`cf-text-xs-secondary`,children:`Dismiss the menu or modal when visitor clicks elsewhere on the page.`})]}),(0,q.jsx)(Y,{checked:e.closeOnOutsideClick??!0,onChange:e=>z({closeOnOutsideClick:e})})]}),(0,q.jsxs)(`div`,{className:`cf-flex-between`,children:[(0,q.jsxs)(`div`,{className:`cf-setting-info`,children:[(0,q.jsx)(`div`,{className:`cf-text-sm-semibold`,children:`Close on Escape Key`}),(0,q.jsx)(`div`,{className:`cf-text-xs-secondary`,children:`Press Escape to dismiss chat and return keyboard focus to the launcher.`})]}),(0,q.jsx)(Y,{checked:e.closeOnEscape??!0,onChange:e=>z({closeOnEscape:e})})]}),(0,q.jsxs)(`div`,{className:`cf-flex-between`,children:[(0,q.jsxs)(`div`,{className:`cf-setting-info`,children:[(0,q.jsx)(`div`,{className:`cf-text-sm-semibold`,children:`Close After Clicking Channel`}),(0,q.jsx)(`div`,{className:`cf-text-xs-secondary`,children:`Collapse the menu after a visitor selects and opens a channel.`})]}),(0,q.jsx)(Y,{checked:e.closeAfterClick??!0,onChange:e=>z({closeAfterClick:e})})]}),(0,q.jsxs)(`div`,{className:`cf-flex-between`,children:[(0,q.jsxs)(`div`,{className:`cf-setting-info`,children:[(0,q.jsx)(`div`,{className:`cf-text-sm-semibold`,children:`Open Channels in New Tab`}),(0,q.jsx)(`div`,{className:`cf-text-xs-secondary`,children:`Launch chat app in a fresh browser tab so users keep your site open.`})]}),(0,q.jsx)(Y,{checked:e.openInNewTab??!0,onChange:e=>z({openInNewTab:e})})]}),(0,q.jsxs)(`div`,{className:`cf-flex-between`,children:[(0,q.jsxs)(`div`,{className:`cf-setting-info`,children:[(0,q.jsx)(`div`,{className:`cf-text-sm-semibold`,children:`Greeting Bubble Sound`}),(0,q.jsx)(`div`,{className:`cf-text-xs-secondary`,children:`Play a subtle notification chime when the bubble pops up.`})]}),(0,q.jsxs)(`div`,{className:`cf-flex-center-gap-8`,children:[(0,q.jsxs)(`button`,{type:`button`,className:`cf-btn-test-chime`,onClick:()=>wc(),title:`Listen to notification sound preview`,children:[(0,q.jsx)(Hi,{size:13}),(0,q.jsx)(`span`,{children:`Test Sound`})]}),(0,q.jsx)(Y,{checked:e.enableSound??!1,onChange:e=>{z({enableSound:e}),e&&wc()}})]})]}),(0,q.jsx)(J,{label:`Greeting Appearance Delay (Seconds)`,children:(0,q.jsx)(`input`,{type:`number`,className:`cf-input`,min:0,max:60,value:Math.round(e.greetingDelay/1e3),onChange:e=>z({greetingDelay:(Number(e.target.value)||0)*1e3})})})]})}),(0,q.jsx)(Oi,{title:`Behavioral Triggers & Smart Display`,description:`Enterprise triggers: scroll depth, desktop exit-intent, operating hours schedule, and page targeting.`,children:(0,q.jsxs)(`div`,{className:`cf-flex-col-gap-14`,children:[(0,q.jsxs)(`div`,{className:`cf-trigger-card ${e.scrollTriggerEnabled?`is-active`:``}`,children:[(0,q.jsxs)(`div`,{className:`cf-trigger-card-header`,children:[(0,q.jsxs)(`div`,{className:`cf-trigger-info`,children:[(0,q.jsx)(`div`,{className:`cf-trigger-title`,children:`Scroll Depth Trigger`}),(0,q.jsx)(`div`,{className:`cf-trigger-desc`,children:`Only reveal the floating launcher or greeting bubble after visitor scrolls past a percentage of the page.`})]}),(0,q.jsx)(Y,{checked:e.scrollTriggerEnabled||!1,onChange:e=>z({scrollTriggerEnabled:e})})]}),e.scrollTriggerEnabled&&(0,q.jsxs)(`div`,{className:`cf-trigger-body`,children:[(0,q.jsx)(J,{label:`Scroll Percentage Threshold`,hint:`Reveal after visitor scrolls past this depth`,children:(0,q.jsxs)(`div`,{className:`cf-flex-center-gap-10`,children:[(0,q.jsx)(`input`,{type:`range`,min:5,max:95,step:5,className:`cf-range-input`,value:e.scrollTriggerPercent??25,onChange:e=>z({scrollTriggerPercent:Number(e.target.value)})}),(0,q.jsxs)(`span`,{className:`cf-badge-value`,children:[e.scrollTriggerPercent??25,`%`]})]})}),(0,q.jsx)(J,{label:`Trigger Target`,hint:`Choose what to reveal once threshold is met`,children:(0,q.jsxs)(`select`,{className:`cf-input`,value:e.scrollTriggerTarget||`launcher`,onChange:e=>z({scrollTriggerTarget:e.target.value}),children:[(0,q.jsx)(`option`,{value:`launcher`,children:`Floating Launcher (Reveal Entire Widget)`}),(0,q.jsx)(`option`,{value:`greeting`,children:`Greeting Bubble Only (Launcher Stays Visible)`})]})})]})]}),(0,q.jsxs)(`div`,{className:`cf-trigger-card ${e.exitIntentEnabled?`is-active`:``}`,children:[(0,q.jsxs)(`div`,{className:`cf-trigger-card-header`,children:[(0,q.jsxs)(`div`,{className:`cf-trigger-info`,children:[(0,q.jsx)(`div`,{className:`cf-trigger-title`,children:`Exit-Intent Trigger (Desktop)`}),(0,q.jsx)(`div`,{className:`cf-trigger-desc`,children:`Detect when desktop visitors move cursor towards the browser tab bar to exit, re-engaging them before they leave.`})]}),(0,q.jsx)(Y,{checked:e.exitIntentEnabled||!1,onChange:e=>z({exitIntentEnabled:e})})]}),e.exitIntentEnabled&&(0,q.jsx)(`div`,{className:`cf-trigger-body`,children:(0,q.jsx)(J,{label:`Exit-Intent Action`,hint:`Action to take when visitor heads to leave`,children:(0,q.jsxs)(`select`,{className:`cf-input`,value:e.exitIntentAction||`modal`,onChange:e=>z({exitIntentAction:e.target.value}),children:[(0,q.jsx)(`option`,{value:`modal`,children:`Pop Open Chat Window (High Conversion)`}),(0,q.jsx)(`option`,{value:`greeting`,children:`Display Greeting Bubble (Subtle Notice)`})]})})})]}),(0,q.jsxs)(`div`,{className:`cf-trigger-card ${e.scheduleEnabled?`is-active`:``}`,children:[(0,q.jsxs)(`div`,{className:`cf-trigger-card-header`,children:[(0,q.jsxs)(`div`,{className:`cf-trigger-info`,children:[(0,q.jsx)(`div`,{className:`cf-trigger-title`,children:`Operating Hours & Days Schedule`}),(0,q.jsx)(`div`,{className:`cf-trigger-desc`,children:`Set working hours. Automatically switch agent badges to Offline outside office hours, or adjust the response badge.`})]}),(0,q.jsx)(Y,{checked:e.scheduleEnabled||!1,onChange:e=>z({scheduleEnabled:e})})]}),e.scheduleEnabled&&(0,q.jsxs)(`div`,{className:`cf-trigger-body`,children:[(0,q.jsxs)(J,{label:`Operating Days`,hint:`Select active days of the week`,children:[(0,q.jsx)(`div`,{className:`cf-day-selector`,children:[{label:`Mon`,day:1},{label:`Tue`,day:2},{label:`Wed`,day:3},{label:`Thu`,day:4},{label:`Fri`,day:5},{label:`Sat`,day:6},{label:`Sun`,day:0}].map(({label:t,day:n})=>{let r=(e.scheduleDays||[1,2,3,4,5]).includes(n);return(0,q.jsx)(`button`,{type:`button`,className:`cf-day-pill ${r?`active`:``}`,onClick:()=>{let t=e.scheduleDays||[1,2,3,4,5],i=r?t.filter(e=>e!==n):[...t,n];i.length>0&&z({scheduleDays:i})},children:t},n)})}),(0,q.jsxs)(`div`,{className:`cf-day-presets`,children:[(0,q.jsx)(`button`,{type:`button`,className:`cf-preset-pill ${(e.scheduleDays||[1,2,3,4,5]).length===5&&[1,2,3,4,5].every(t=>(e.scheduleDays||[1,2,3,4,5]).includes(t))?`is-active`:``}`,onClick:()=>z({scheduleDays:[1,2,3,4,5]}),children:`Weekdays (Mon-Fri)`}),(0,q.jsx)(`button`,{type:`button`,className:`cf-preset-pill ${(e.scheduleDays||[1,2,3,4,5]).length===2&&[6,0].every(t=>(e.scheduleDays||[1,2,3,4,5]).includes(t))?`is-active`:``}`,onClick:()=>z({scheduleDays:[6,0]}),children:`Weekends`}),(0,q.jsx)(`button`,{type:`button`,className:`cf-preset-pill ${(e.scheduleDays||[1,2,3,4,5]).length===7?`is-active`:``}`,onClick:()=>z({scheduleDays:[1,2,3,4,5,6,0]}),children:`All 7 Days`})]})]}),(0,q.jsxs)(`div`,{className:`cf-field-grid`,children:[(0,q.jsx)(J,{label:`Opening Time`,hint:`Store opening time`,children:(0,q.jsx)(`input`,{type:`time`,className:`cf-input`,value:e.scheduleStart||`09:00`,onChange:e=>z({scheduleStart:e.target.value})})}),(0,q.jsx)(J,{label:`Closing Time`,hint:`Store closing time`,children:(0,q.jsx)(`input`,{type:`time`,className:`cf-input`,value:e.scheduleEnd||`18:00`,onChange:e=>z({scheduleEnd:e.target.value})})})]}),(0,q.jsxs)(`div`,{className:`cf-field-grid`,children:[(0,q.jsx)(J,{label:`Outside Hours Action`,hint:`What happens outside business hours`,children:(0,q.jsxs)(`select`,{className:`cf-input`,value:e.scheduleOfflineAction||`badge`,onChange:e=>z({scheduleOfflineAction:e.target.value}),children:[(0,q.jsx)(`option`,{value:`badge`,children:`Show "Offline" Badge & Notice`}),(0,q.jsx)(`option`,{value:`hide`,children:`Hide Widget Completely`})]})}),e.scheduleOfflineAction!==`hide`&&(0,q.jsx)(J,{label:`Offline Badge Notice`,hint:`Header badge shown outside hours`,children:(0,q.jsx)(`input`,{className:`cf-input`,maxLength:80,value:e.scheduleOfflineText||`Back tomorrow at 9:00 AM`,onChange:e=>z({scheduleOfflineText:e.target.value}),placeholder:`Back tomorrow at 9:00 AM`})})]})]})]}),(0,q.jsxs)(`div`,{className:`cf-trigger-card is-active`,children:[(0,q.jsx)(`div`,{className:`cf-trigger-card-header`,children:(0,q.jsxs)(`div`,{className:`cf-trigger-info`,children:[(0,q.jsx)(`div`,{className:`cf-trigger-title`,children:`Page / URL Targeting Filter`}),(0,q.jsx)(`div`,{className:`cf-trigger-desc`,children:`Choose specific pages or URLs where the chat widget will appear on your published site.`})]})}),(0,q.jsxs)(`div`,{className:`cf-trigger-body`,children:[(0,q.jsx)(J,{label:`Where the widget will be shown?`,hint:`Select which page of your Framer project should show the chat widget.`,children:(0,q.jsxs)(`select`,{className:`cf-input`,value:e.showOn||`Every page`,onChange:e=>z({showOn:e.target.value}),children:[De.map(e=>(0,q.jsx)(`option`,{value:e,children:e},e)),(0,q.jsx)(`option`,{value:`custom`,children:`Custom URL Paths & Wildcards...`})]})}),e.showOn===`custom`&&(0,q.jsxs)(q.Fragment,{children:[(0,q.jsx)(J,{label:`Targeting Mode`,hint:`Show only on listed paths, or hide on listed paths`,children:(0,q.jsxs)(`select`,{className:`cf-input`,value:e.targetingMode||`show`,onChange:e=>z({targetingMode:e.target.value}),children:[(0,q.jsx)(`option`,{value:`show`,children:`Show Widget Only on Listed Paths`}),(0,q.jsx)(`option`,{value:`hide`,children:`Hide Widget on Listed Paths (Show Everywhere Else)`})]})}),(0,q.jsx)(J,{label:`URL Paths & Wildcards`,hint:`Enter paths separated by lines or commas. Use * for wildcards (e.g. /checkout, /blog/*).`,children:(0,q.jsx)(`textarea`,{className:`cf-textarea`,rows:3,value:e.targetingRules||``,onChange:e=>z({targetingRules:e.target.value}),placeholder:`/pricing
/checkout
/products/*`})})]})]})]})]})})]})]}),Ue&&(0,q.jsx)(`div`,{className:`cf-tab-blur-overlay`,onClick:()=>{_.isLoggedIn?T(`expired`):_.openAuthModal(`register`)}})]}),!u&&(0,q.jsxs)(`footer`,{className:`actions`+(o===`home`||Ue?` cf-home-actions`:``),children:[o!==`home`&&!Ue&&(0,q.jsxs)(`div`,{className:`cf-footer-grid`,children:[(0,q.jsxs)(`button`,{type:`button`,className:`primary-cta`,onClick:Ve,disabled:p,title:`Insert reusable Chat Bubbles component onto the Framer canvas`,children:[(0,q.jsx)(`span`,{children:p?`Inserting...`:`Insert Chat Bubbles`}),(0,q.jsx)(zi,{size:16})]}),(0,q.jsxs)(`button`,{type:`button`,className:`secondary-cta`,onClick:He,disabled:p,title:`Restore default settings`,children:[(0,q.jsx)(`span`,{children:`Reset`}),(0,q.jsx)(Fi,{size:13})]})]}),(0,q.jsxs)(`div`,{className:`cf-shell-footer-bar`,children:[(0,q.jsxs)(`a`,{href:`https://www.framefic.com/`,target:`_blank`,rel:`noopener noreferrer`,className:`cf-shell-company-link`,title:`Visit Framefic website`,children:[(0,q.jsx)(`span`,{children:`@Framefic`}),(0,q.jsx)(Vi,{size:12})]}),(0,q.jsx)(`span`,{className:`cf-shell-version`,children:`v1.0.0`})]})]}),(0,q.jsx)(zo,{isOpen:_.showAuthModal,initialMode:_.authModalMode,onRegister:async e=>{let t=null;try{t=(await fi()).siteId||null}catch{}await _.register({...e,siteId:t})},onVerifySignup:async(e,t)=>{await _.verifySignup({email:e,code:t}),I(e)},onLogin:async e=>{let t=await _.login(e);return e.code&&I(e.email),t},onSocialAuthSuccess:e=>{_.socialLogin(e.token,e.user),I(e.user?.email)},onClose:_.closeAuthModal}),(0,q.jsx)(Ns,{isOpen:y.showPaymentSuccessModal}),(0,q.jsx)(Ps,{isOpen:w!==null,status:w,onClose:()=>T(null),onUpgrade:()=>{f(!0),x(`subscription`),T(null)},onLogout:()=>{_.logout(),T(null)}})]})}var Ac=class extends d.Component{constructor(e){super(e),this.state={hasError:!1,error:null}}static getDerivedStateFromError(e){return{hasError:!0,error:e}}componentDidCatch(e,t){console.error(`Chat Bubbles Plugin Error Boundary Caught:`,e,t)}render(){return this.state.hasError?(0,q.jsxs)(`div`,{className:`cf-error-fallback`,children:[(0,q.jsxs)(`div`,{className:`cf-error-header`,children:[(0,q.jsx)(`span`,{className:`cf-error-icon`,children:`⚠️`}),(0,q.jsx)(`h3`,{className:`cf-error-title`,children:`Plugin Error`})]}),(0,q.jsx)(`p`,{className:`cf-error-text`,children:this.state.error?.message||`An unexpected error occurred while loading Chat Bubbles.`}),(0,q.jsx)(`button`,{className:`cf-error-btn`,onClick:()=>{window.location.reload()},children:`Reload Plugin`})]}):this.props.children}};try{U.showUncheckedPermissionToasts!==void 0&&(U.showUncheckedPermissionToasts=!1),typeof U.isAllowedTo==`function`&&U.isAllowedTo(`CodeFile.setFileContent`,`createCodeFile`,`setAttributes`,`addComponentInstance`,`setSelection`,`getNodesWithType`,`setPluginData`,`getPluginData`)}catch{}try{U.showUI({position:`top right`,width:390,minHeight:600,resizable:`height`})}catch{}var jc=document.getElementById(`root`);if(!jc)throw Error(`Root element not found`);(0,Lr.createRoot)(jc).render((0,q.jsx)(d.StrictMode,{children:(0,q.jsx)(Ac,{children:(0,q.jsx)(kc,{})})}));